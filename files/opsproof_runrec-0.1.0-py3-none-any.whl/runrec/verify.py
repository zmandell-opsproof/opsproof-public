"""Run Record verifier: spec section 8 (procedure) and section 9 (report), draft 9.

Entry points: ``verify_bytes(data, pin=None)`` and ``verify_file(path, pin=None)``.
Both return a ``VerifyResult`` whose ``report`` is the section 9 report.

Since draft 5 the spec fixes the order of every check and the code each one reports. The
methods below follow section 8 item by item; comments give the item number
(for example "5.3.2"). Where draft 9 still leaves a choice open, the choice
is recorded in SPEC-NOTES.md and cited here as [N#id].
"""
from __future__ import annotations

import hashlib
import re
from collections import deque
from typing import Any, Deque, Dict, List, Optional, Set, Tuple

from . import b64, ed25519, jcs, policy
from .schema import (
    Failure,
    Schema,
    first_duplicate,
    is_hash,
    is_identifier,
    is_integer,
    is_number,
)
from .ziprofile import ZipProfileError, read_archive

__all__ = ["verify_bytes", "verify_file", "VerifyResult", "Failure"]

FORMAT = "runrec/0.1"
STATEMENT_TYPE = "https://in-toto.io/Statement/v1"
PAYLOAD_TYPE = "application/vnd.in-toto+json"
PREDICATE_PREFIX = "https://opsproof.systems/runrec/v0.1/"
MAX_SAFE = 2 ** 53 - 1

GRANTS = ("author", "operate", "act", "observe", "authorize", "decide", "start", "review", "disclose")  # the last three: draft 11
PARTICIPANT_KINDS = ("human", "agent", "system")
DECISION_TYPES = ("release", "rework", "scrap", "accept", "reject", "waive", "stop")
# Decision types that decide against the work going on and fail the step; rework and scrap are verdicts on the product (sections 6.2 and 6.5).
AGAINST_DECISIONS = ("reject", "stop")
EVENT_KINDS = (
    "RunStarted", "StepOpened", "Proposal", "Authorization", "Action", "Observation",
    "Evaluation", "Decision", "Note", "ChildStarted", "ChildSealed", "StepClosed", "RunClosed",
)
# Section 6.1 "Signed by (MUST)" column.
SIGNERS = {
    "RunStarted": ("runtime",),
    "StepOpened": ("runtime",),
    "Proposal": ("human", "agent"),
    "Authorization": ("runtime", "human"),
    "Action": ("human", "system"),
    "Observation": ("human", "system"),
    "Evaluation": ("runtime",),
    "Decision": ("human",),
    "Note": ("runtime", "human", "agent", "system"),
    "ChildStarted": ("human", "agent"),  # draft 11, section 4.4
    "ChildSealed": ("runtime",),
    "StepClosed": ("runtime",),
    "RunClosed": ("runtime",),
}
OPEN_MATTER_KINDS = ("step", "criterion", "decision", "proposal", "action", "observation", "child")
OPEN_MATTER_STATES = (
    "blocked", "undetermined", "nonconforming", "missing", "against", "denied", "pending", "failed",
    "unknown_uncertainty",
)

# Section 7: the names an entry may have.
_PART_RE = re.compile(r"participants/([a-z0-9][a-z0-9._-]{0,127})\.dsse\.json")
_EVENT_RE = re.compile(r"events/([0-9]{6})-([A-Za-z]+)\.dsse\.json")
_EVID_RE = re.compile(r"evidence/sha256/([0-9a-f]{64})")
_TSR_RE = re.compile(r"timestamps/[0-9]+\.tsr")  # draft 11, reserved: reported, never checked


def _sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def pae(payload_type: str, payload: bytes) -> bytes:
    t = payload_type.encode("utf-8")
    return b"DSSEv1 %d %s %d %s" % (len(t), t, len(payload), payload)


def _jcs(v: Any) -> bytes:
    return jcs.canonical_bytes(v)


# ---------------------------------------------------------------------------
# Reading an attestation file (section 8, first list)
# ---------------------------------------------------------------------------

class Attestation:
    __slots__ = ("name", "payload", "digest", "statement", "predicate", "keyid", "sig", "signatures", "subject_name", "subject_hex")

    def __init__(self) -> None:
        self.name = ""
        self.payload = b""
        self.digest = ""
        self.statement: dict = {}
        self.predicate: dict = {}
        self.keyid = ""
        self.sig = b""
        self.signatures: List[Tuple[str, bytes]] = []  # draft 11: more than one only on a Procedure with parties
        self.subject_name = ""
        self.subject_hex = ""


def read_attestation(name: str, data: bytes, step: int, predicate_type: str) -> Attestation:
    """Section 8 "Reading an attestation file": json, canonical, envelope,
    json, canonical, statement, in that order, all reported at ``step``."""
    # 1. json
    try:
        env = jcs.parse(data)
    except jcs.JSONError as exc:
        raise Failure(step, "json", "%s: %s" % (name, exc)) from None
    # 2. canonical
    if _jcs(env) != data:
        raise Failure(step, "canonical", "%s: the envelope file is not its RFC 8785 (JCS) serialization" % name)
    # 3. envelope
    es = Schema(step, "envelope")
    es.check_obj(
        env,
        name,
        {
            "payload": es.string,
            "payloadType": es.const(PAYLOAD_TYPE),
            "signatures": es.array(es.obj({"keyid": es.string, "sig": es.string})),
        },
    )
    sigs = env["signatures"]
    if not sigs:
        raise Failure(step, "envelope", "%s: signatures must not be empty" % name)
    try:
        payload = b64.b64decode_std(env["payload"])
    except ValueError as exc:
        raise Failure(step, "envelope", "%s: payload: %s" % (name, exc)) from None
    signatures: List[Tuple[str, bytes]] = []
    for sg in sigs:
        try:
            signatures.append((sg["keyid"], b64.b64decode_std(sg["sig"])))
        except ValueError as exc:
            raise Failure(step, "envelope", "%s: sig: %s" % (name, exc)) from None
    # 4. json, then canonical, on the payload
    try:
        st = jcs.parse(payload)
    except jcs.JSONError as exc:
        raise Failure(step, "json", "%s: payload: %s" % (name, exc)) from None
    if _jcs(st) != payload:
        raise Failure(step, "canonical", "%s: the payload is not its RFC 8785 (JCS) serialization" % name)
    # 5. statement
    ss = Schema(step, "statement")
    ss.check_obj(
        st,
        name + ":statement",
        {
            "_type": ss.const(STATEMENT_TYPE),
            "subject": ss.array(ss.obj({"name": ss.string, "digest": ss.obj({"sha256": ss.hex64})})),
            "predicateType": ss.const(PREDICATE_PREFIX + predicate_type),
            "predicate": ss.object_any,
        },
    )
    if len(st["subject"]) != 1:
        raise Failure(step, "statement", "%s: subject must hold exactly one object" % name)
    if len(signatures) != 1 and predicate_type != "procedure":  # only a Procedure carries one signature per party (section 4.1)
        raise Failure(step, "envelope", "%s: signatures must hold exactly one object, has %d" % (name, len(signatures)))
    att = Attestation()
    att.name = name
    att.payload = payload
    att.digest = "sha256:" + _sha256_hex(payload)
    att.statement = st
    att.predicate = st["predicate"]
    att.keyid, att.sig = signatures[0]
    att.signatures = signatures
    att.subject_name = st["subject"][0]["name"]
    att.subject_hex = st["subject"][0]["digest"]["sha256"]
    return att


def _verify_sig(pub: bytes, att: Attestation, sig: Optional[bytes] = None) -> bool:
    return ed25519.verify(pub, pae(PAYLOAD_TYPE, att.payload), att.sig if sig is None else sig)


def _strict_key(s: Any) -> Tuple[Optional[bytes], Optional[str]]:
    """(raw key, None) for canonical base64url of a strict key, else (None, why)."""
    try:
        pub = b64.b64decode_url(s)
    except ValueError as exc:
        return None, str(exc)
    problem = ed25519.public_key_problem(pub)
    if problem:
        return None, problem
    return pub, None


# ---------------------------------------------------------------------------
# Appendix D grammar
# ---------------------------------------------------------------------------

def _ref_check(s: Schema):
    def chk(v: Any, path: str) -> None:
        if not (is_identifier(v) or is_hash(v)):
            raise s.fail(path, "must be an identifier or a digest")

    return chk


def _open_matter(s: Schema):
    """Appendix D OpenMatter, used by the manifest (step 1) and RunClosed (step 5).
    kind and state are checked as separate enumerations; their pairing and what
    ref names are compared with the recomputation at step 8."""
    return s.obj({
        "step_id": s.ident,
        "kind": s.enum(*OPEN_MATTER_KINDS),
        "ref": _ref_check(s),
        "state": s.enum(*OPEN_MATTER_STATES),
    })


def check_manifest(pred: dict, name: str) -> None:
    s = Schema(1, "schema")
    s.check_obj(
        pred,
        name,
        {
            "format": s.const(FORMAT),
            "workspace": s.obj({"workspace_id": s.ident, "key_id": s.hash, "public_key": s.text_plus,
                                "display_name": s.text_plus}),
            "run_id": s.ident,
            "sequence": s.integer(1),
            "procedure": s.obj({"procedure_id": s.ident, "version": s.version, "digest": s.hash}),
            "events": s.obj({"count": s.integer(2, 999999), "head": s.hash}),
            "participants": s.array(s.obj({"participant_id": s.ident, "digest": s.hash})),
            "evidence": s.array(s.obj({"digest": s.hash, "media_type": s.media_type, "size": s.integer(0)},
                                      {"external": s.obj({"location": s.text_plus})})),  # draft 11: kept elsewhere
            "outcome": s.enum("complete", "incomplete", "failed"),
            "open_matters": s.array(_open_matter(s)),
        },
        {
            "published_by": s.text_plus, "published_time": s.timestamp,
            # draft 11, section 7: recomputed from the events at step 8
            "outputs": s.array(s.obj({"output_id": s.ident, "digest": s.hash, "media_type": s.media_type, "size": s.integer(0)})),
            "related": s.array(s.obj({"kind": s.enum("parent", "child", "retry_of", "input"), "run_id": s.ident},
                                     {"record": s.hash, "step_id": s.ident})),
        },
        ext=True,
    )


def check_enrollment(pred: dict, name: str) -> None:
    s = Schema(3, "schema")

    def pid(v: Any, path: str) -> None:
        s.ident(v, path)
        if v == "runtime":
            raise s.fail(path, "'runtime' is reserved for the workspace key")

    s.check_obj(
        pred,
        name,
        {
            "workspace_id": s.ident,
            "participant_id": pid,
            "display_name": s.text_plus,
            "kind": s.enum(*PARTICIPANT_KINDS),
            "public_key": s.text_plus,
            "key_id": s.hash,
            "grants": s.array(s.enum(*GRANTS), unique=True),
            "roles": s.array(s.ident, unique=True),
            "status": s.enum("active", "revoked"),
        },
        {"granted_by": s.text_plus, "party": s.ident},
        ext=True,
    )


def check_procedure(pred: dict, name: str) -> None:
    """Appendix D grammar and section 4 validity (both step 4, schema)."""
    s = Schema(4, "schema")

    def criterion(v: Any, path: str) -> None:
        if type(v) is not dict:
            raise s.fail(path, "must be an object")
        t = v.get("type")
        if t == "measurement":
            s.check_obj(v, path, {
                "criterion_id": s.ident,
                "type": s.const("measurement"),
                "quantity": s.ident,
                "unit": s.text_plus,
                "tolerance": s.obj({"min": s.number, "max": s.number}),
                "consecutive": s.integer(1),
                "max_observations": s.integer(1),
            })
        elif t == "artifact":
            s.check_obj(v, path, {
                "criterion_id": s.ident,
                "type": s.const("artifact"),
                "media_types": s.array(s.media_range, unique=True, min_items=1),
            })
        elif t == "confirmation":  # draft 11: a person vouches for a stated sentence
            s.check_obj(v, path, {
                "criterion_id": s.ident,
                "type": s.const("confirmation"),
                "statement": s.text_plus,
                "roles": s.array(s.ident, unique=True, min_items=1),
            })
        elif t == "derived":  # draft 11: a sealed policy decides it (Appendix L)
            def policy(p: Any, pp: str) -> None:
                s.check_obj(p, pp, {"digest": s.hash, "media_type": s.const("application/wasm"), "size": s.integer(1)},
                            {"title": s.string})

            def inp(x: Any, ip: str) -> None:
                if type(x) is dict and "quantity" in x:
                    s.check_obj(x, ip, {"name": s.ident, "quantity": s.ident, "unit": s.string, "last": s.integer(1)})
                elif type(x) is dict and "actions" in x:
                    s.check_obj(x, ip, {"name": s.ident, "actions": s.ident})
                elif type(x) is dict and "input" in x:
                    s.check_obj(x, ip, {"name": s.ident, "input": s.ident})
                elif type(x) is dict and "derived" in x:
                    s.check_obj(x, ip, {"name": s.ident, "derived": s.ident})
                else:
                    raise s.fail(ip, "must read a quantity, actions, an input or a derived criterion")

            def result(r: Any, rp: str) -> None:
                if r == "conforming" and isinstance(r, str):
                    return
                s.check_obj(r, rp, {"min": s.number, "max": s.number})
                if r["min"] > r["max"]:
                    raise s.fail(rp, "min must not exceed max")

            s.check_obj(v, path, {"criterion_id": s.ident, "type": s.const("derived"), "policy": policy,
                                  "inputs": s.array(inp, min_items=1), "result": result})
            names = [i["name"] for i in v["inputs"]]
            if len(set(names)) != len(names):
                raise s.fail(path + ".inputs", "input names must be unique")
        else:
            raise s.fail(path + ".type", "must be 'measurement', 'artifact', 'confirmation' or 'derived'")

    def limit(v: Any, path: str) -> None:  # draft 11: a number, or a number input of the Run, scaled
        if is_number(v):
            return
        s.check_obj(v, path, {"input": s.ident}, {"scale": s.number, "offset": s.number})

    def input_decl(v: Any, path: str) -> None:  # draft 11, section 4.2
        if type(v) is not dict:
            raise s.fail(path, "must be an object")
        k = v.get("kind")
        s.enum("number", "text", "artifact", "output")(k, path + ".kind")
        if k == "number":
            s.check_obj(v, path, {"input_id": s.ident, "kind": s.anyv, "unit": s.string}, {"range": s.obj({"min": s.number, "max": s.number})})
            if "range" in v and v["range"]["min"] > v["range"]["max"]:
                raise s.fail(path + ".range", "min must not exceed max")
        elif k == "text":
            s.check_obj(v, path, {"input_id": s.ident, "kind": s.anyv})
        elif k == "artifact":
            s.check_obj(v, path, {"input_id": s.ident, "kind": s.anyv, "media_types": s.array(s.media_range, unique=True, min_items=1)})
        else:
            s.check_obj(v, path, {"input_id": s.ident, "kind": s.anyv, "from": s.obj({"procedure_id": s.ident, "output_id": s.ident})})

    step = s.obj(
        {
            "step_id": s.ident,
            "title": s.text_plus,
            "requires": s.array(s.ident, unique=True),
            "performers": s.array(s.obj({"kind": s.enum("human", "system"), "role": s.nullable(s.ident)}), unique=True),
            "evidence": s.array(criterion),
            "decisions": s.array(s.obj({
                "decision_id": s.ident,
                "types": s.array(s.enum(*DECISION_TYPES), unique=True, min_items=1),
                "decider_roles": s.array(s.ident, unique=True, min_items=1),
                "required": s.boolean,
            })),
        },
        {
            "instructions": s.string,
            "proposals": s.obj({
                "allowed_kinds": s.array(s.enum("human", "agent"), unique=True, min_items=1),
                "bound_ids": s.array(s.ident, unique=True),
                "fallback_roles": s.array(s.ident, unique=True),
            }),
            "actions": s.obj({"types": s.array(s.ident, unique=True, min_items=1), "requires_authorization": s.boolean}),
            # draft 11, section 4.4
            "children": s.obj({
                "procedure_id": s.ident,
                "starters": s.array(s.obj({"kind": s.enum("human", "agent"), "role": s.nullable(s.ident)}), min_items=1),
                "min": s.integer(1),
                "require": s.enum("all_complete", "min_complete"),
            }, {"max": s.integer(1)}),
        },
    )
    s.check_obj(
        pred,
        name,
        {
            "procedure_id": s.ident,
            "version": s.version,
            "title": s.text_plus,
            "roles": s.array(s.ident, unique=True),
            "bounds": s.array(s.obj(
                {"bound_id": s.ident, "action_type": s.ident, "parameter": s.ident, "min": limit, "max": limit},
                {"max_count_per_run": s.integer(1),
                 "when": s.obj({"quantity": s.ident, "unit": s.text_plus, "min": s.number, "max": s.number})},
            )),
            "steps": s.array(step, min_items=1),
        },
        {
            "purpose": s.string,
            "source": s.obj({"title": s.text_plus}, {"digest": s.hash}),
            # draft 11: parties (section 4.1), and the version this one replaces with a note of what changed (section 4)
            "parties": s.array(s.obj({"party_id": s.ident, "display_name": s.text_plus}), min_items=1),
            "supersedes": s.obj({"procedure_id": s.ident, "version": s.version, "digest": s.hash}),
            "change": s.obj({"summary": s.text_plus}, {"basis": s.array(s.hash)}),
            # draft 11, sections 4.2 and 4.3
            "inputs": s.array(input_decl),
            "subjects": s.array(s.obj({"kind": s.ident, "required": s.boolean})),
            "outputs": s.array(s.obj({"output_id": s.ident, "step_id": s.ident, "criterion_id": s.ident})),
        },
        ext=True,
    )
    if "parties" in pred and first_duplicate(p["party_id"] for p in pred["parties"]) is not None:
        raise s.fail(name + ".parties", "party_id values must be unique")
    if "supersedes" in pred:
        if pred["supersedes"]["procedure_id"] != pred["procedure_id"]:
            raise s.fail(name + ".supersedes.procedure_id", "a version supersedes an earlier version of the same Procedure")
        if pred["supersedes"]["version"] == pred["version"]:
            raise s.fail(name + ".supersedes.version", "a version cannot supersede itself")
    if ("change" in pred) != ("supersedes" in pred):
        raise s.fail(name + ".change", "change is present exactly when supersedes is")
    _check_procedure_validity(pred)


def _check_procedure_validity(pred: dict) -> None:
    """Section 4 "Validity", items 1-7."""

    def fail(msg: str) -> Failure:
        return Failure(4, "schema", msg)

    roles = set(pred["roles"])
    steps = pred["steps"]
    if not steps:  # 1 (also enforced by the grammar)
        raise fail("the Procedure has no Steps")
    bounds: Dict[str, dict] = {}
    for b in pred["bounds"]:  # 2
        if b["bound_id"] in bounds:
            raise fail("bound_id %r is not unique" % b["bound_id"])
        bounds[b["bound_id"]] = b
    step_ids: Dict[str, dict] = {}
    criterion_ids: Set[str] = set()
    decision_ids: Set[str] = set()
    for st in steps:
        if st["step_id"] in step_ids:
            raise fail("step_id %r is not unique" % st["step_id"])
        step_ids[st["step_id"]] = st
        for c in st["evidence"]:
            if c["criterion_id"] in criterion_ids:
                raise fail("criterion_id %r is not unique" % c["criterion_id"])
            criterion_ids.add(c["criterion_id"])
        for d in st["decisions"]:
            if d["decision_id"] in decision_ids:
                raise fail("decision_id %r is not unique" % d["decision_id"])
            decision_ids.add(d["decision_id"])
    # 9 (draft 11): inputs, the Limits that read them, subjects and outputs
    inputs: Dict[str, dict] = {}
    for i in pred.get("inputs", []):
        if i["input_id"] in inputs:
            raise fail("input_id %r is not unique" % i["input_id"])
        inputs[i["input_id"]] = i
    for b in pred["bounds"]:
        for lim in (b["min"], b["max"]):
            if not is_number(lim) and inputs.get(lim["input"], {}).get("kind") != "number":
                raise fail("bound %r: a limit reads %r, which is not a number input of this Procedure" % (b["bound_id"], lim["input"]))
    if first_duplicate(x["kind"] for x in pred.get("subjects", [])) is not None:
        raise fail("subject kinds must be unique")
    output_ids: Set[str] = set()
    for o in pred.get("outputs", []):
        if o["output_id"] in output_ids:
            raise fail("output_id %r is not unique" % o["output_id"])
        output_ids.add(o["output_id"])
        st = step_ids.get(o["step_id"])
        if st is None or not any(c["criterion_id"] == o["criterion_id"] and c["type"] == "artifact" for c in st["evidence"]):
            raise fail("output %r does not name an artifact criterion of a step" % o["output_id"])
    for st in steps:
        sid = st["step_id"]
        for r in st["requires"]:  # 3
            if r not in step_ids or r == sid:
                raise fail("step %r: requires entry %r does not name another Step" % (sid, r))
        for pf in st["performers"]:  # 4
            if pf["role"] is not None and pf["role"] not in roles:
                raise fail("step %r: performer role %r is not in roles" % (sid, pf["role"]))
        ch = st.get("children")
        if ch is not None:  # 9 (draft 11): a step done by child Runs neither acts nor takes proposals
            if "actions" in st or "proposals" in st:
                raise fail("step %r: a step with children has no actions and no proposals" % sid)
            if "max" in ch and ch["min"] > ch["max"]:
                raise fail("step %r: children.min exceeds children.max" % sid)
            for x in ch["starters"]:
                if x["role"] is not None and x["role"] not in roles:
                    raise fail("step %r: starter role %r is not in roles" % (sid, x["role"]))
            if ch["procedure_id"] == pred["procedure_id"]:
                raise fail("step %r: a step cannot start Runs of its own Procedure" % sid)
        for c in st["evidence"]:  # 9 (draft 11)
            for r in c.get("roles", []) if c["type"] == "confirmation" else []:
                if r not in roles:
                    raise fail("step %r: confirmation role %r is not in roles" % (sid, r))
            for i in c["inputs"] if c["type"] == "derived" else []:  # 10 (draft 11): inputs the Procedure can produce
                if "quantity" in i and not any(m["type"] == "measurement" and m["quantity"] == i["quantity"] and m["unit"] == i["unit"]
                                               for s2 in steps for m in s2["evidence"]):
                    raise fail("%s: no measurement criterion measures %s in %s" % (c["criterion_id"], i["quantity"], i["unit"]))
                if "input" in i and i["input"] not in inputs:
                    raise fail("%s: no input %s is declared" % (c["criterion_id"], i["input"]))
                if "derived" in i:
                    earlier = st["evidence"][:st["evidence"].index(c)]
                    if not any(x["criterion_id"] == i["derived"] and x["type"] == "derived" for x in earlier):
                        raise fail("%s: %s is not a derived criterion listed earlier on this step" % (c["criterion_id"], i["derived"]))
                if "actions" in i and not any(i["actions"] in (s2.get("actions") or {}).get("types", []) for s2 in steps):
                    raise fail("%s: no step allows %s actions" % (c["criterion_id"], i["actions"]))
            if c["type"] == "derived" and not any("quantity" in i or "actions" in i for i in c["inputs"]):
                raise fail("%s: reads no quantity and no actions, so nothing would ever decide it" % c["criterion_id"])
        for d in st["decisions"]:
            for r in d["decider_roles"]:
                if r not in roles:
                    raise fail("step %r: decider role %r is not in roles" % (sid, r))
        props = st.get("proposals")
        acts = st.get("actions")
        if props is not None:
            for r in props["fallback_roles"]:
                if r not in roles:
                    raise fail("step %r: fallback role %r is not in roles" % (sid, r))
            if acts is None or acts["requires_authorization"] is not True:  # 5
                raise fail("step %r has proposals but not actions with requires_authorization: true" % sid)
            for bid in props["bound_ids"]:
                if bid not in bounds:
                    raise fail("step %r names unknown bound %r" % (sid, bid))
                if bounds[bid]["action_type"] not in acts["types"]:
                    raise fail("step %r: bound %r has an action_type not in actions.types" % (sid, bid))
            for bid in props["bound_ids"]:  # 8: a condition reads a quantity some criterion measures
                w = bounds[bid].get("when")
                if w is not None and not any(c["type"] == "measurement" and c["quantity"] == w["quantity"] and c["unit"] == w["unit"]
                                             for s2 in steps for c in s2["evidence"]):
                    raise fail("step %r: bound %r: no criterion measures %s in %s" % (sid, bid, w["quantity"], w["unit"]))
            plain: Dict[Tuple[str, str], str] = {}  # 7: one unconditioned Bound, after the conditioned ones
            for bid in props["bound_ids"]:
                b = bounds[bid]
                k = (b["action_type"], b["parameter"])
                if k in plain:
                    raise fail("step %r: bound %r is listed after %r, which has no condition, so it could never govern %r" % (
                        sid, bid, plain[k], b["parameter"]))
                if "when" not in b:
                    plain[k] = bid
        elif acts is not None and acts["requires_authorization"] is True:
            raise fail("step %r: requires_authorization: true without proposals" % sid)
        for c in st["evidence"]:  # 6
            if c["type"] == "measurement":
                if c["tolerance"]["min"] > c["tolerance"]["max"]:
                    raise fail("criterion %r: tolerance.min > tolerance.max" % c["criterion_id"])
                if c["max_observations"] < c["consecutive"]:
                    raise fail("criterion %r: max_observations < consecutive" % c["criterion_id"])
    for b in pred["bounds"]:
        if is_number(b["min"]) and is_number(b["max"]) and b["min"] > b["max"]:
            raise fail("bound %r: min > max" % b["bound_id"])
        if "when" in b and b["when"]["min"] > b["when"]["max"]:
            raise fail("bound %r: when.min > when.max" % b["bound_id"])
    # 3: acyclic
    state: Dict[str, int] = {}
    for root in step_ids:
        if state.get(root) == 2:
            continue
        stack: List[Tuple[str, int]] = [(root, 0)]
        state[root] = 1
        while stack:
            node, i = stack[-1]
            reqs = step_ids[node]["requires"]
            if i < len(reqs):
                stack[-1] = (node, i + 1)
                nxt = reqs[i]
                if state.get(nxt) == 1:
                    raise fail("the requires graph has a cycle through step %r" % nxt)
                if state.get(nxt) is None:
                    state[nxt] = 1
                    stack.append((nxt, 0))
            else:
                state[node] = 2
                stack.pop()


def _basis(s: Schema):
    """An Authorization's basis: a bound ruling names its governing Bounds and the readings consulted (draft 6)."""
    kind = s.enum("bound", "human")
    bound = s.obj({"kind": kind, "bounds": s.array(s.ident), "inputs": s.array(s.hash)})
    human = s.obj({"kind": kind})

    def chk(v: Any, path: str) -> None:
        if type(v) is not dict:
            raise s.fail(path, "must be an object")
        kind(v.get("kind"), path + ".kind")
        (bound if v["kind"] == "bound" else human)(v, path)

    return chk


def policies_of(procedure: dict) -> List[dict]:
    """Draft 11: the derived criteria, whose sealed policies the Procedure cites as evidence (Appendix L)."""
    return [c for st in procedure["steps"] for c in st["evidence"] if c["type"] == "derived"]


def binding_problem(proc: dict, rs: dict) -> Optional[str]:
    """Draft 11, sections 4.2, 4.3 and 6.2: inputs bound with their kinds, subjects of declared kinds, relations."""
    declared = {i["input_id"]: i for i in proc.get("inputs", [])}
    inputs = rs.get("inputs", {})
    for k in sorted(inputs):
        if k not in declared:
            return "input %s is not declared by the Procedure" % k
    for iid, i in declared.items():
        if iid not in inputs:
            return "input %s is not bound" % iid
        v = inputs[iid]
        if i["kind"] == "number":
            if not is_number(v):
                return "input %s must be a number" % iid
            if "range" in i and not (i["range"]["min"] <= v <= i["range"]["max"]):
                return "input %s is %s, outside its range" % (iid, v)
        elif i["kind"] == "text":
            if not isinstance(v, str):
                return "input %s must be text" % iid
        elif i["kind"] == "artifact":
            if type(v) is not dict or sorted(v) != ["digest", "media_type", "size"]:
                return "input %s must be a file" % iid
            if not _media_matches(v["media_type"], i["media_types"]):
                return "input %s is %s, not an allowed type" % (iid, v["media_type"])
        elif type(v) is not dict or sorted(v) != ["digest", "output_id", "record", "run_id"] or v["output_id"] != i["from"]["output_id"]:
            return "input %s must name the output %s of a sealed Record" % (iid, i["from"]["output_id"])
    kinds = {x["kind"] for x in proc.get("subjects", [])}
    subjects = rs.get("subjects", [])
    for x in subjects:
        if x["kind"] not in kinds:
            return "subject kind %s is not declared by the Procedure" % x["kind"]
    for k in proc.get("subjects", []):
        if k["required"] and not any(x["kind"] == k["kind"] for x in subjects):
            return "the Run names no %s, which the Procedure requires" % k["kind"]
    related = rs.get("related", [])
    if sum(1 for x in related if x["kind"] == "parent") > 1:
        return "a Run has at most one parent"
    if any(x["kind"] == "parent" and "step_id" not in x for x in related):
        return "a parent relation names the parent Step"
    return None


def related_of(rs: dict, child_sealed: List[dict]) -> List[dict]:
    """Draft 11, section 7: RunStarted.related, one input per output input (input_id order), one child per ChildSealed."""
    out = [dict(x) for x in rs.get("related", [])]
    ins = rs.get("inputs", {})
    for k in sorted(ins):
        v = ins[k]
        if type(v) is dict and "record" in v:
            out.append({"kind": "input", "run_id": v["run_id"], "record": v["record"]})
    for c in child_sealed:
        out.append({"kind": "child", "run_id": c["child_run_id"], "record": c["record"]})
    return out


def citations_of(pred: dict) -> List[dict]:
    """Section 8 step 6: an Observation's artifact, a Proposal's or Action's trace, and (draft 11) RunStarted's
    artifact inputs in input_id order."""
    k = pred["kind"]
    if k == "RunStarted":
        ins = pred.get("inputs", {})
        return [ins[n] for n in sorted(ins) if type(ins[n]) is dict and "media_type" in ins[n]]
    a = pred.get("artifact") if k == "Observation" else pred.get("trace") if k in ("Proposal", "Action", "ChildStarted") else None
    return [a] if a is not None else []


def check_event_grammar(pred: dict, name: str) -> None:
    """Appendix D, Event (step 5, schema). step_id resolution is step 7 (reference)."""
    s = Schema(5, "schema")
    kind = pred.get("kind")
    if kind not in EVENT_KINDS:
        raise s.fail(name + ".kind", "unknown event kind %r" % (kind,))
    req: Dict[str, Any] = {
        "run_id": s.ident,
        "workspace_id": s.ident,
        "seq": s.integer(1, 999999),
        "previous": s.nullable(s.hash),
        "kind": s.anyv,
        "actor": s.obj({
            "participant_id": s.text_plus,
            "kind": s.enum("human", "agent", "system", "runtime"),
            "key_id": s.hash,
        }),
        "declared_time": s.timestamp,
    }
    opt: Dict[str, Any] = {}

    def params(v: Any, path: str) -> None:
        if type(v) is not dict:
            raise s.fail(path, "must be an object")
        for k, x in v.items():
            if not is_identifier(k):
                raise s.fail(path, "parameter name %r is not an identifier" % k)
            if type(x) not in (float, str, bool):
                raise s.fail(path + "." + k, "must be a number, string or boolean")

    action = s.obj({"type": s.ident, "parameters": params})
    device = s.obj({}, {
        "action_time": s.timestamp,
        "status": s.string,
        "server_id": s.string,
        "client_audit_entry_id": s.string,
        "client_user_id": s.string,
    })
    digests = s.array(s.hash, unique=True)
    artifact = s.obj({"digest": s.hash, "media_type": s.media_type, "size": s.integer(0)})

    if kind == "RunStarted":
        req.update(procedure_id=s.ident, version=s.version, procedure_digest=s.hash)
        opt.update(title=s.string, site=s.string, started_by=s.string)

        def bound_inputs(v: Any, path: str) -> None:  # draft 11, section 4.2
            if type(v) is not dict:
                raise s.fail(path, "must be an object")
            for k, x in v.items():
                s.ident(k, path)
                if type(x) in (float, str):
                    continue
                if type(x) is dict and "record" in x:
                    s.check_obj(x, path + "." + k, {"run_id": s.ident, "record": s.hash, "output_id": s.ident, "digest": s.hash})
                else:
                    artifact(x, path + "." + k)
        opt.update(inputs=bound_inputs,
                   subjects=s.array(s.obj({"kind": s.ident, "id": s.text_plus})),
                   related=s.array(s.obj({"kind": s.enum("parent", "retry_of"), "run_id": s.ident}, {"step_id": s.ident})))
    elif kind == "StepOpened":
        req.update(step_id=s.ident)
    elif kind == "Proposal":
        req.update(step_id=s.ident, action=action, cites=digests)
        opt.update(rationale=s.string, trace=artifact)
    elif kind == "Authorization":
        req.update(step_id=s.ident, proposal=s.hash, result=s.enum("allow", "deny"),
                   basis=_basis(s))
        opt.update(reason=s.string)
    elif kind == "Action":
        req.update(step_id=s.ident, action=action,
                   result=s.obj({"status": s.enum("success", "failure")}, {"detail": s.string}))
        opt.update(authorization=s.hash, device=device, trace=artifact)
    elif kind == "Observation":
        has_m = "measurement" in pred
        has_a = "artifact" in pred
        has_c = "confirmation" in pred
        if has_m + has_a + has_c != 1:
            raise s.fail(name, "an Observation carries exactly one of measurement, artifact and confirmation")
        req.update(step_id=s.ident, source=s.obj({}, {"device_id": s.string, "method": s.string}))
        if has_m:
            unc = pred.get("uncertainty")
            stated = type(unc) is dict and unc.get("kind") == "stated"
            unc_req: Dict[str, Any] = {"kind": s.enum("stated", "unknown")}
            unc_opt: Dict[str, Any] = {"note": s.string}
            (unc_req if stated else unc_opt).update(value=s.number, unit=s.text_plus)
            req.update(measurement=s.obj({"quantity": s.ident, "unit": s.text_plus, "value": s.number}),
                       uncertainty=s.obj(unc_req, unc_opt))
        elif has_a:
            req.update(artifact=artifact)
        else:
            req.update(confirmation=s.obj({"criterion_id": s.ident}))
        opt.update(observed_time=s.timestamp)
    elif kind == "Evaluation":
        req.update(step_id=s.ident, criterion_id=s.ident,
                   result=s.enum("conforming", "nonconforming", "undetermined"))
        opt.update(inputs=s.array(s.hash), explanation=s.string)
    elif kind == "Decision":
        req.update(type=s.enum(*DECISION_TYPES), reason=s.text_plus, cites=digests)
        opt.update(step_id=s.ident, decision_id=s.ident, scope=s.object_any)
        if "decision_id" in pred and "step_id" not in pred:
            raise s.fail(name, "decision_id is allowed only with step_id")
    elif kind == "Note":
        req.update(text=s.text_plus)
        opt.update(step_id=s.ident)
    elif kind == "ChildStarted":  # draft 11, section 4.4: the child's run_id is child_run_id
        req.update(step_id=s.ident, child_run_id=s.ident, procedure=s.obj({"procedure_id": s.ident, "version": s.version, "digest": s.hash}))
        opt.update(trace=artifact)

        def child_inputs(v: Any, path: str) -> None:
            if type(v) is not dict:
                raise s.fail(path, "must be an object")
            for k, x in v.items():
                s.ident(k, path)
                if type(x) in (float, str):
                    continue
                if type(x) is dict and "record" in x:
                    s.check_obj(x, path + "." + k, {"run_id": s.ident, "record": s.hash, "output_id": s.ident, "digest": s.hash})
                else:
                    artifact(x, path + "." + k)
        opt.update(inputs=child_inputs)
    elif kind == "ChildSealed":
        req.update(step_id=s.ident, child_run_id=s.ident, record=s.hash, outcome=s.enum("complete", "incomplete", "failed"))
    elif kind == "StepClosed":
        req.update(step_id=s.ident, outcome=s.enum("complete", "failed"))
        opt.update(reason=s.string)
    elif kind == "RunClosed":
        req.update(outcome=s.enum("complete", "incomplete", "failed"), open_matters=s.array(_open_matter(s)))
        opt.update(closed_by=s.string)
    s.check_obj(pred, name, req, opt, ext=True)


# ---------------------------------------------------------------------------
# Run state for steps 7 and 8
# ---------------------------------------------------------------------------

class Event:
    __slots__ = ("seq", "name", "att", "pred", "digest", "enrollment")

    def __init__(self, name: str, att: Attestation, seq: int) -> None:
        self.name = name
        self.att = att
        self.pred = att.predicate
        self.seq = seq
        self.digest = att.digest
        self.enrollment: Optional[dict] = None

    @property
    def kind(self) -> Any:
        return self.pred.get("kind")

    @property
    def actor(self) -> Any:
        return self.pred.get("actor")

    @property
    def step_id(self) -> Any:
        return self.pred.get("step_id")

    @property
    def by(self) -> str:
        return self.pred["actor"]["participant_id"]


class CritState:
    __slots__ = ("crit", "state", "seen", "run", "value", "artifact")

    def __init__(self, crit: dict) -> None:
        self.crit = crit
        self.state = "undetermined"
        self.seen = 0
        self.run = 0
        self.value: Optional[float] = None  # draft 11: what a band-result policy returned
        self.artifact: Optional[dict] = None  # draft 11: the file that met an artifact criterion, an output


class StepState:
    def __init__(self, step: dict) -> None:
        self.step = step
        self.opened = False
        self.closed: Optional[str] = None
        self.crit = [CritState(c) for c in step["evidence"]]
        self.satisfied: Set[str] = set()
        self.against: Set[str] = set()  # decided reject or stop while open: the step fails (sections 6.2 and 6.5)
        self.successes = 0
        self.failed_actions: List[str] = []
        self.proposals: List[str] = []
        # [digest, quantity, unit, superseded]
        self.unknown_obs: List[list] = []
        self.stated: List[dict] = []  # draft 11: stated readings on this Step, in chain order, for sealed policies
        self.children: Dict[str, list] = {}  # draft 11: child run_id -> [seq, sealed outcome or None], in start order

    @property
    def is_open(self) -> bool:
        return self.opened and self.closed is None

    @property
    def actions_recorded(self) -> int:
        return self.successes + len(self.failed_actions)


class Proposal:
    __slots__ = ("digest", "seq", "step_id", "author", "action_jcs", "rulings", "human_ruled")

    def __init__(self, ev: Event) -> None:
        self.digest = ev.digest
        self.seq = ev.seq
        self.step_id = ev.step_id
        self.author = ev.by
        self.action_jcs = _jcs(ev.pred["action"])
        self.rulings: List[str] = []
        self.human_ruled = False

    @property
    def has_allow(self) -> bool:
        return "allow" in self.rulings


class Authz:
    __slots__ = ("digest", "seq", "proposal", "basis", "result", "step_id", "used_by", "governing")

    def __init__(self, ev: Event) -> None:
        self.digest = ev.digest
        self.seq = ev.seq
        self.proposal = ev.pred["proposal"]
        self.basis = ev.pred["basis"]["kind"]
        self.result = ev.pred["result"]
        self.step_id = ev.step_id
        self.used_by: Optional[int] = None
        self.governing: List[dict] = []  # for a bound ruling, the Bounds that governed it


class Expected:
    """A runtime event the chain owes at this point (section 6.3)."""

    __slots__ = ("kind", "step_id", "criterion_id", "proposal", "result", "governing", "inputs")

    def __init__(self, kind: str, step_id: str, result: Optional[str] = None,
                 criterion_id: Optional[str] = None, proposal: Optional[str] = None,
                 governing: Optional[List[dict]] = None, inputs: Optional[List[str]] = None) -> None:
        self.governing = governing or []
        self.inputs = inputs or []
        self.kind = kind
        self.step_id = step_id
        self.result = result
        self.criterion_id = criterion_id
        self.proposal = proposal

    def describe(self) -> str:
        if self.kind == "Authorization":
            return "a bound Authorization of Proposal %s on step %r" % (self.proposal, self.step_id)
        if self.kind == "Evaluation":
            return "an Evaluation of criterion %r on step %r" % (self.criterion_id, self.step_id)
        return "%s for step %r" % (self.kind, self.step_id)


def _media_matches(mt: str, patterns: List[str]) -> bool:
    for r in patterns:
        if r.endswith("/*"):
            if mt.split("/", 1)[0] == r[:-2]:
                return True
        elif r == mt:
            return True
    return False


# ---------------------------------------------------------------------------
# The verifier
# ---------------------------------------------------------------------------

class VerifyResult:
    def __init__(self, report: dict) -> None:
        self.report = report

    @property
    def integrity(self) -> str:
        return self.report["integrity"]

    @property
    def human_authorizations(self) -> List[dict]:
        return self.report.get("human_authorizations", [])


class _Verifier:
    def __init__(self, data: bytes, pin: Any, published: Any = None) -> None:
        self.data = data
        self.pin = pin
        self.published = published
        self.known = False  # manifest grammar passed (step 1.6)
        self.key_established = False  # step 2.1 passed
        self.ws_key_id: Optional[str] = None
        self.warnings: List[str] = []
        self.human_authorizations: List[dict] = []
        self.decisions: List[dict] = []

    def run(self) -> VerifyResult:
        failure: Optional[Failure] = None
        try:
            self.step1_open()
            self.step2_manifest()
            self.step3_enrollments()
            self.step4_procedure()
            self.step5_chain()
            self.step6_evidence()
            self.step78()
        except Failure as f:
            failure = f
        return self.build_report(failure)

    # --- step 1 -------------------------------------------------------------
    def step1_open(self) -> None:
        # 1.1 limit, then archive. This verifier imposes no limits (they are optional).
        try:
            entries = read_archive(self.data)
        except ZipProfileError as exc:
            raise Failure(1, "archive", str(exc)) from None
        manifest_bytes: Optional[bytes] = None
        procedure_bytes: Optional[bytes] = None
        self.participant_files: List[Tuple[str, str, bytes]] = []
        self.event_files: List[Tuple[str, bytes]] = []
        self.evidence: Dict[str, bytes] = {}
        self.disclosure_bytes: Optional[bytes] = None
        self.timestamps = False
        # 1.2 layout
        for name, content in entries:
            if name == "manifest.dsse.json":
                manifest_bytes = content
            elif name == "procedure.dsse.json":
                procedure_bytes = content
            elif name == "README.txt":
                pass  # informative, never checked
            elif name == "disclosure.dsse.json":  # draft 11: an edition (section 7.4)
                self.disclosure_bytes = content
            elif _TSR_RE.fullmatch(name):
                self.timestamps = True
            elif _PART_RE.fullmatch(name):
                self.participant_files.append((name, _PART_RE.fullmatch(name).group(1), content))  # type: ignore[union-attr]
            elif _EVENT_RE.fullmatch(name):
                self.event_files.append((name, content))
            elif _EVID_RE.fullmatch(name):
                self.evidence[_EVID_RE.fullmatch(name).group(1)] = content  # type: ignore[union-attr]
            else:
                raise Failure(1, "layout", "entry %r is not a name section 7 allows" % name)
        # 1.3 missing
        if manifest_bytes is None:
            raise Failure(1, "missing", "manifest.dsse.json is absent")
        if procedure_bytes is None:
            raise Failure(1, "missing", "procedure.dsse.json is absent")
        self.procedure_bytes = procedure_bytes
        # 1.4 read the manifest
        self.manifest = read_attestation("manifest.dsse.json", manifest_bytes, 1, "manifest")
        m = self.manifest.predicate
        # 1.5 format
        if m.get("format") != FORMAT:
            raise Failure(1, "format", "manifest format is %r, only %r is supported" % (m.get("format"), FORMAT))
        # 1.6 schema
        check_manifest(m, "manifest")
        self.known = True  # run_id, procedure and event_count are reported from here (section 9)

    # --- step 2 -------------------------------------------------------------
    def step2_manifest(self) -> None:
        att = self.manifest
        m = att.predicate
        ws = m["workspace"]
        # 2.1 key
        pub, problem = _strict_key(ws["public_key"])
        if pub is None:
            raise Failure(2, "key", "workspace.public_key: %s" % problem)
        kid = "sha256:" + _sha256_hex(pub)
        if ws["key_id"] != kid:
            raise Failure(2, "key", "workspace.key_id %s is not the digest of workspace.public_key (%s)" % (ws["key_id"], kid))
        self.ws_pub = pub
        self.ws_key_id = kid
        self.key_established = True
        # 2.2 keyid
        if att.keyid != kid:
            raise Failure(2, "keyid", "manifest keyid %s is not the workspace key_id" % att.keyid)
        # 2.3 signature
        if not _verify_sig(pub, att):
            raise Failure(2, "signature", "the manifest signature does not verify with the workspace key")
        # 2.4 subject
        if att.subject_name != "runrec:run:" + m["run_id"] or att.subject_hex != m["events"]["head"][7:]:
            raise Failure(2, "subject", "the manifest subject is not runrec:run:%s with digest events.head" % m["run_id"])

    # --- step 3 -------------------------------------------------------------
    def step3_enrollments(self) -> None:
        m = self.manifest.predicate
        bound = m["participants"]
        # 3.1 manifest
        dup = first_duplicate(p["participant_id"] for p in bound)
        if dup is not None:
            raise Failure(3, "manifest", "manifest.participants lists participant_id %r twice" % dup)
        dup = first_duplicate(p["digest"] for p in bound)
        if dup is not None:
            raise Failure(3, "manifest", "manifest.participants lists digest %s twice" % dup)
        bound_pid = {p["digest"]: p["participant_id"] for p in bound}
        ws_id = m["workspace"]["workspace_id"]
        self.enrollments: Dict[str, dict] = {}
        self.enrollment_pub: Dict[str, bytes] = {}
        keys_seen: Dict[bytes, str] = {}
        seen_digests: Set[str] = set()
        # 3.2 each file, in name order
        for name, file_pid, content in sorted(self.participant_files, key=lambda t: t[0]):
            att = read_attestation(name, content, 3, "enrollment")  # 3.2.1
            if att.digest not in bound_pid:  # 3.2.2
                raise Failure(3, "unbound", "%s (digest %s) is not in manifest.participants" % (name, att.digest))
            seen_digests.add(att.digest)
            if att.keyid != self.ws_key_id:  # 3.2.3
                raise Failure(3, "keyid", "%s: keyid %s is not the workspace key_id" % (name, att.keyid))
            if not _verify_sig(self.ws_pub, att):  # 3.2.4
                raise Failure(3, "signature", "%s: the signature does not verify with the workspace key" % name)
            e = att.predicate
            check_enrollment(e, name)  # 3.2.5
            pid = e["participant_id"]
            if bound_pid[att.digest] != pid:  # 3.2.6
                raise Failure(3, "manifest", "manifest.participants binds %s to %r, the enrollment is for %r" % (att.digest, bound_pid[att.digest], pid))
            if e["workspace_id"] != ws_id:  # 3.2.7
                raise Failure(3, "workspace", "%s: workspace_id %r is not the manifest's %r" % (name, e["workspace_id"], ws_id))
            pub, problem = _strict_key(e["public_key"])  # 3.2.8
            if pub is None:
                raise Failure(3, "key", "%s: public_key: %s" % (name, problem))
            kid = "sha256:" + _sha256_hex(pub)
            if e["key_id"] != kid:
                raise Failure(3, "key", "%s: key_id is not the digest of public_key" % name)
            if att.subject_name != "runrec:participant:" + pid or att.subject_hex != kid[7:]:  # 3.2.9
                raise Failure(3, "subject", "%s: the subject is not runrec:participant:%s with the key's digest" % (name, pid))
            if file_pid != pid:  # 3.2.10
                raise Failure(3, "layout", "%s holds the enrollment of %r; it must be named participants/%s.dsse.json" % (name, pid, pid))
            if pid in self.enrollments:  # 3.2.11
                raise Failure(3, "duplicate", "participant_id %r is enrolled twice" % pid)
            if pub == self.ws_pub:
                raise Failure(3, "duplicate", "%s enrolls the workspace key" % name)
            if pub in keys_seen:
                raise Failure(3, "duplicate", "%s: the key is already enrolled as %r" % (name, keys_seen[pub]))
            keys_seen[pub] = pid
            self.enrollments[pid] = e
            self.enrollment_pub[pid] = pub
        # 3.3 missing
        for p in bound:
            if p["digest"] not in seen_digests:
                raise Failure(3, "missing", "manifest.participants binds %s (%s) but no file holds it" % (p["participant_id"], p["digest"]))

    # --- step 4 -------------------------------------------------------------
    def step4_procedure(self) -> None:
        att = read_attestation("procedure.dsse.json", self.procedure_bytes, 4, "procedure")  # 4.1
        pred = att.predicate
        m = self.manifest.predicate
        digest = "sha256:" + _sha256_hex(_jcs(pred))
        if digest != m["procedure"]["digest"]:  # 4.2
            raise Failure(4, "digest", "the Procedure digest %s is not manifest.procedure.digest %s" % (digest, m["procedure"]["digest"]))
        if att.subject_hex != digest[7:]:  # 4.3
            raise Failure(4, "subject", "the procedure subject digest is not its predicate digest")
        # Draft 11: with parties, one signature per party (section 4.1). The parties are read before the schema
        # (4.6): the party_id strings of a non-empty array of objects; anything else is no parties.
        raw = pred.get("parties")
        parties: Optional[List[str]] = None
        if type(raw) is list and raw and all(type(x) is dict and isinstance(x.get("party_id"), str) for x in raw):
            parties = [x["party_id"] for x in raw]
        signers: List[str] = []
        for keyid, _sig in att.signatures:  # 4.4
            signer = next((pid for pid, e in self.enrollments.items() if e["key_id"] == keyid), None)
            if signer is None:
                raise Failure(4, "signer", "no enrollment has key_id %s, the Procedure's keyid" % keyid)
            e = self.enrollments[signer]
            if e["status"] != "active" or e["kind"] != "human" or "author" not in e["grants"]:
                raise Failure(4, "signer", "the Procedure signer %r is not an active Human holding author" % signer)
            if parties is not None and e.get("party") not in parties:
                raise Failure(4, "signer", "the Procedure is signed by %r, who signs for no party it names" % signer)
            signers.append(signer)
        if parties is not None:
            for party in parties:
                n = sum(1 for sid in signers if self.enrollments[sid].get("party") == party)
                if n != 1:
                    raise Failure(4, "signer", "party %r has not signed the Procedure" % party if n == 0 else
                                  "party %r signed the Procedure %d times" % (party, n))
        elif len(signers) != 1:
            raise Failure(4, "signer", "a Procedure without parties carries exactly one signature, not %d" % len(signers))
        for signer, (_k, sig) in zip(signers, att.signatures):  # 4.5
            if not _verify_sig(self.enrollment_pub[signer], att, sig):
                raise Failure(4, "signature", "the Procedure signature by %r does not verify" % signer)
        if parties is not None:
            self.agreed_by = [{"party_id": p, "participant_id": next(sid for sid in signers if self.enrollments[sid].get("party") == p)}
                              for p in parties]
        else:
            self.agreed_by = [{"participant_id": signers[0]}]
        check_procedure(pred, "procedure")  # 4.6
        name = "runrec:procedure:%s@%s" % (pred["procedure_id"], pred["version"])
        if att.subject_name != name:  # 4.7
            raise Failure(4, "subject", "the procedure subject name is %r, expected %r" % (att.subject_name, name))
        mp = m["procedure"]
        if (mp["procedure_id"], mp["version"]) != (pred["procedure_id"], pred["version"]):  # 4.8
            raise Failure(4, "manifest", "manifest.procedure names %s@%s but the Procedure is %s@%s" % (
                mp["procedure_id"], mp["version"], pred["procedure_id"], pred["version"]))
        self.procedure = pred
        self.procedure_digest = digest
        self.procedure_subject = name
        self.steps_by_id = {s["step_id"]: s for s in pred["steps"]}
        self.bounds = {b["bound_id"]: b for b in pred["bounds"]}

    # --- step 5 -------------------------------------------------------------
    def step5_chain(self) -> None:
        m = self.manifest.predicate
        events: List[Event] = []
        # 5.1 read every event file in name order; seq must be an integer >= 1
        for name, content in sorted(self.event_files, key=lambda t: t[0]):
            att = read_attestation(name, content, 5, "event")
            seq = att.predicate.get("seq")
            if not (type(seq) is float and seq.is_integer() and seq >= 1):
                raise Failure(5, "schema", "%s: seq is not an integer of at least 1" % name)
            events.append(Event(name, att, int(seq)))
        # 5.2 chain
        events.sort(key=lambda e: e.seq)
        n = len(events)
        if [e.seq for e in events] != list(range(1, n + 1)):
            seqs = [e.seq for e in events]
            for i, sq in enumerate(seqs):
                if sq != i + 1:
                    if i > 0 and sq == seqs[i - 1]:
                        raise Failure(5, "chain", "seq %d appears more than once" % sq)
                    raise Failure(5, "chain", "seq %d is missing (the chain jumps from %d to %d)" % (i + 1, i, sq))
        if n != int(m["events"]["count"]):
            raise Failure(5, "chain", "the bundle holds %d events but events.count is %d" % (n, int(m["events"]["count"])))
        ws_id = m["workspace"]["workspace_id"]
        prev: Optional[str] = None
        # 5.3 each event in seq order
        for ev in events:
            label = "event %d (%s)" % (ev.seq, ev.name)
            p = ev.pred
            actor = p.get("actor")
            if not (type(actor) is dict and all(isinstance(actor.get(k), str) for k in ("participant_id", "kind", "key_id"))):
                raise Failure(5, "schema", "%s: actor is not an object with string participant_id, kind and key_id" % label)  # 5.3.1
            if actor["participant_id"] == "runtime":  # 5.3.2
                if actor["kind"] != "runtime" or actor["key_id"] != self.ws_key_id:
                    raise Failure(5, "actor", "%s: a 'runtime' actor must have kind 'runtime' and the workspace key_id" % label)
                pub = self.ws_pub
            else:
                e = self.enrollments.get(actor["participant_id"])
                if e is None:
                    raise Failure(5, "enrollment", "%s: actor %r has no enrollment in this Record" % (label, actor["participant_id"]))
                if e["status"] != "active":
                    raise Failure(5, "enrollment", "%s: actor %r is not active" % (label, actor["participant_id"]))
                if e["kind"] != actor["kind"] or e["key_id"] != actor["key_id"]:
                    raise Failure(5, "enrollment", "%s: actor kind/key_id differ from %r's enrollment" % (label, actor["participant_id"]))
                pub = self.enrollment_pub[actor["participant_id"]]
                ev.enrollment = e
            if ev.att.keyid != actor["key_id"]:  # 5.3.3
                raise Failure(5, "keyid", "%s: envelope keyid %s is not the actor's key_id %s" % (label, ev.att.keyid, actor["key_id"]))
            if not _verify_sig(pub, ev.att):  # 5.3.4
                raise Failure(5, "signature", "%s: the signature does not verify with %r's key" % (label, actor["participant_id"]))
            check_event_grammar(p, ev.name)  # 5.3.5
            want = "events/%06d-%s.dsse.json" % (ev.seq, p["kind"])
            if ev.name != want:  # 5.3.6
                raise Failure(5, "layout", "%s holds seq %d %s; it must be named %s" % (ev.name, ev.seq, p["kind"], want))
            if p["run_id"] != m["run_id"] or p["workspace_id"] != ws_id:  # 5.3.7
                raise Failure(5, "splice", "%s: run_id/workspace_id %r/%r are not the manifest's %r/%r" % (label, p["run_id"], p["workspace_id"], m["run_id"], ws_id))
            if ev.att.subject_name != self.procedure_subject or ev.att.subject_hex != self.procedure_digest[7:]:  # 5.3.8
                raise Failure(5, "subject", "%s: the subject is not %s with the Procedure digest" % (label, self.procedure_subject))
            if p["previous"] != prev:  # 5.3.9
                raise Failure(5, "chain", "%s: previous is %s, expected %s" % (label, p["previous"], prev))
            if actor["kind"] not in SIGNERS[p["kind"]]:  # 5.3.10
                raise Failure(5, "signer", "%s: a %s may not be signed by %s" % (label, p["kind"], actor["kind"]))
            prev = ev.digest
        # 5.4 chain
        kinds = [e.pred["kind"] for e in events]
        if kinds[0] != "RunStarted":
            raise Failure(5, "chain", "the first event is a %s, not RunStarted" % kinds[0])
        if kinds[-1] != "RunClosed":
            raise Failure(5, "chain", "the last event is a %s, not RunClosed" % kinds[-1])
        for e in events[1:-1]:
            if e.pred["kind"] in ("RunStarted", "RunClosed"):
                raise Failure(5, "chain", "event %d is a %s; it may only be first or last" % (e.seq, e.pred["kind"]))
        if events[-1].digest != m["events"]["head"]:
            raise Failure(5, "chain", "the last event's digest %s is not events.head %s" % (events[-1].digest, m["events"]["head"]))
        rs = events[0].pred
        mp = m["procedure"]
        if (rs["procedure_id"], rs["version"], rs["procedure_digest"]) != (mp["procedure_id"], mp["version"], mp["digest"]):
            raise Failure(5, "chain", "RunStarted names %s@%s %s, not the manifest's Procedure" % (rs["procedure_id"], rs["version"], rs["procedure_digest"]))
        problem = binding_problem(self.procedure, rs)  # draft 11: what RunStarted binds is what the Procedure declares
        if problem is not None:
            raise Failure(5, "reference", "RunStarted: %s" % problem)
        self.events = events

    # --- step 6 -------------------------------------------------------------
    def step6_evidence(self) -> None:
        m = self.manifest.predicate
        cited: Dict[str, Tuple[str, int, int]] = {}  # insertion order = order of first citation
        for c in policies_of(self.procedure):  # draft 11: the Procedure cites its sealed policies (Appendix L)
            hx = c["policy"]["digest"][7:]
            if hx not in cited:
                cited[hx] = (c["policy"]["media_type"], int(c["policy"]["size"]), 0)
        for ev in self.events:  # 6.1 alias
            for art in citations_of(ev.pred):
                hx = art["digest"][7:]
                key = (art["media_type"], int(art["size"]))
                if hx in cited and cited[hx][:2] != key:
                    raise Failure(6, "alias", "event %d cites %s as %s/%d, event %d cited it as %s/%d" % (
                        ev.seq, art["digest"], key[0], key[1], cited[hx][2], cited[hx][0], cited[hx][1]))
                if hx not in cited:
                    cited[hx] = (key[0], key[1], ev.seq)
        manifest_ev: Dict[str, dict] = {}
        for entry in m["evidence"]:  # 6.2 manifest
            hx = entry["digest"][7:]
            if hx in manifest_ev:
                raise Failure(6, "manifest", "manifest.evidence lists %s twice" % entry["digest"])
            manifest_ev[hx] = entry
        withheld: Dict[str, dict] = {}  # draft 11: an edition, evidence withheld on a named person's order (section 7.4)
        ordered_by = None
        if self.disclosure_bytes is not None:
            att = read_attestation("disclosure.dsse.json", self.disclosure_bytes, 6, "disclosure")
            d = att.predicate
            ds = Schema(6, "schema")
            ds.check_obj(d, "disclosure.dsse.json", {
                "run_id": ds.ident, "workspace_id": ds.ident, "head": ds.hash,
                "withheld": ds.array(ds.obj({"digest": ds.hash}, {"reason": ds.string}), min_items=1),
                "ordered_by": ds.ident, "ordered_time": ds.timestamp,
            }, ext=True)
            by = self.enrollments.get(d["ordered_by"])
            if by is None or by["status"] != "active" or by["kind"] != "human" or "disclose" not in by["grants"]:
                raise Failure(6, "signer", "the disclosure is ordered by %r, who is not an active Human holding disclose in this Record" % d["ordered_by"])
            if att.keyid != by["key_id"]:
                raise Failure(6, "keyid", "the disclosure keyid is not its orderer's key_id")
            if not _verify_sig(self.enrollment_pub[d["ordered_by"]], att):
                raise Failure(6, "signature", "the disclosure signature does not verify")
            head = m["events"]["head"]
            if (att.subject_name != "runrec:run:%s" % m["run_id"] or att.subject_hex != head[7:] or d["run_id"] != m["run_id"]
                    or d["workspace_id"] != m["workspace"]["workspace_id"] or d["head"] != head):
                raise Failure(6, "subject", "the disclosure is not about this Run and its chain head")
            policies = {c["policy"]["digest"][7:] for c in policies_of(self.procedure)}
            for w in d["withheld"]:
                hx = w["digest"][7:]
                if hx in policies:
                    raise Failure(6, "reference", "a sealed policy (%s) is withheld, so its Evaluations cannot be re-run" % w["digest"])
                if hx not in cited:
                    raise Failure(6, "reference", "the disclosure withholds %s, which nothing cites" % w["digest"])
                if hx in withheld:
                    raise Failure(6, "reference", "the disclosure lists %s twice" % w["digest"])
                if hx in self.evidence:
                    raise Failure(6, "reference", "the disclosure withholds %s, but the file is in this edition" % w["digest"])
                withheld[hx] = w
            ordered_by = d["ordered_by"]
        self.edition_findings: List[dict] = []
        for hx, (mt, size, seq) in cited.items():  # 6.3
            blob = self.evidence.get(hx)
            if blob is None and (hx in withheld or "external" in manifest_ev.get(hx, {})):
                if hx in withheld:
                    f = {"kind": "withheld", "digest": "sha256:" + hx, "ordered_by": ordered_by}
                    if "reason" in withheld[hx]:
                        f["reason"] = withheld[hx]["reason"]
                else:
                    f = {"kind": "external", "digest": "sha256:" + hx}
                self.edition_findings.append(f)
                continue
            if blob is None:
                raise Failure(6, "missing", "%s cites sha256:%s, which is not in the bundle" % ("event %d" % seq if seq else "the Procedure", hx))
            if _sha256_hex(blob) != hx:
                raise Failure(6, "digest", "evidence/sha256/%s does not hash to its name" % hx)
            if len(blob) != size:
                raise Failure(6, "size", "sha256:%s is %d bytes, cited as %d" % (hx, len(blob), size))
            me = manifest_ev.get(hx)
            if me is None or me["media_type"] != mt or int(me["size"]) != size:
                raise Failure(6, "manifest", "manifest.evidence has no entry for sha256:%s as %s/%d" % (hx, mt, size))
        for hx in manifest_ev:  # 6.4 uncited
            if hx not in cited:
                raise Failure(6, "uncited", "manifest.evidence lists sha256:%s, which no event cites" % hx)
        for hx in sorted(self.evidence):
            if hx not in cited:
                raise Failure(6, "uncited", "evidence/sha256/%s is not cited by any event" % hx)

    # --- steps 7 and 8 ------------------------------------------------------
    def step78(self) -> None:
        self.state: Dict[str, StepState] = {s["step_id"]: StepState(s) for s in self.procedure["steps"]}
        self.proposals: Dict[str, Proposal] = {}
        self.authz: Dict[str, Authz] = {}
        self.success_by_type: Dict[str, int] = {}
        self.readings: Dict[Tuple[str, str], Tuple[str, bool, float]] = {}  # latest (digest, stated, value)
        self.earlier: Set[str] = set()
        self.action_log: List[dict] = []  # draft 11: every Action in the Run, for sealed policies
        self.policies: Dict[str, Optional[policy.Module]] = {}
        queue: Deque[Expected] = deque()
        for ev in self.events:
            kind = ev.pred["kind"]
            runtime = ev.pred["actor"]["participant_id"] == "runtime"
            if kind == "RunStarted":  # seq 1 (step 5.4); followed by the settle
                self.bound = ev.pred.get("inputs", {})  # draft 11, section 4.2
                queue.extend(self.settle())
            elif kind == "RunClosed":
                if queue:
                    raise Failure(7, "sequencing", "event %d: RunClosed while the runtime still owes %s" % (ev.seq, queue[0].describe()))
                self.check_run_closed(ev)
            elif runtime and kind == "Note":
                if queue:
                    raise Failure(7, "sequencing", "event %d: a runtime Note while the runtime owes %s" % (ev.seq, queue[0].describe()))
                if ev.step_id is not None and ev.step_id not in self.state:  # section 6.3 (draft 5, second pass)
                    raise Failure(7, "reference", "event %d: the runtime Note's step %r is not a Step of the Procedure" % (ev.seq, ev.step_id))
            elif runtime and kind == "ChildSealed" and not queue:
                queue.extend(self.on_child_sealed(ev))
            elif runtime:
                if not queue:
                    raise Failure(7, "sequencing", "event %d is a runtime %s%s that nothing calls for" % (
                        ev.seq, kind, (" for step %r" % ev.step_id) if ev.step_id is not None else ""))
                self.match_expected(ev, queue.popleft())
            else:
                queue.extend(self.participant_event(ev, queue))
            self.earlier.add(ev.digest)
        m = self.manifest.predicate
        outcome, matters = self.recompute()
        if m["outcome"] != outcome:
            raise Failure(8, "recompute", "manifest outcome is %r, recomputed %r" % (m["outcome"], outcome))
        if _jcs(m["open_matters"]) != _jcs(matters):
            raise Failure(8, "recompute", "manifest open_matters differ from the recomputed %s" % jcs.canonicalize(matters))
        # draft 11, section 7: outputs and relations recomputed from the events
        outputs = None
        if "outputs" in self.procedure:
            outputs = []
            for o in self.procedure["outputs"]:
                a = next(cs.artifact for cs in self.state[o["step_id"]].crit if cs.crit["criterion_id"] == o["criterion_id"])
                if a is not None:
                    outputs.append({"output_id": o["output_id"], "digest": a["digest"], "media_type": a["media_type"], "size": a["size"]})
        if _jcs(m.get("outputs")) != _jcs(outputs):
            raise Failure(8, "recompute", "manifest outputs differ from those the events give")
        related = related_of(self.events[0].pred, [e.pred for e in self.events if e.pred["kind"] == "ChildSealed"])
        if _jcs(m.get("related")) != _jcs(related or None):
            raise Failure(8, "recompute", "manifest related differs from what the events give")
        self.outputs = outputs or []
        self.related = related
        self.outcome = outcome
        self.open_matters = matters

    def match_expected(self, ev: Event, exp: Expected) -> None:
        p = ev.pred
        if p["kind"] != exp.kind or ev.step_id != exp.step_id:
            found = p["kind"] + ((" for step %r" % ev.step_id) if ev.step_id is not None else "")
            raise Failure(7, "sequencing", "event %d: expected %s, found %s" % (ev.seq, exp.describe(), found))
        if exp.kind == "Authorization":
            if p["basis"]["kind"] != "bound" or p["proposal"] != exp.proposal:
                raise Failure(7, "sequencing", "event %d: expected %s, found a %s Authorization of %s" % (ev.seq, exp.describe(), p["basis"]["kind"], p["proposal"]))
            if p["result"] != exp.result:
                raise Failure(8, "recompute", "event %d: the bound Authorization records %r, the Bounds give %r" % (ev.seq, p["result"], exp.result))
            want = [b["bound_id"] for b in exp.governing]
            if _jcs(p["basis"]["bounds"]) != _jcs(want):
                raise Failure(8, "recompute", "event %d: the bound Authorization names governing Bounds %s, the Bounds give %s" % (
                    ev.seq, jcs.canonicalize(p["basis"]["bounds"]), jcs.canonicalize(want)))
            if _jcs(p["basis"]["inputs"]) != _jcs(exp.inputs):
                raise Failure(8, "recompute", "event %d: the bound Authorization cites readings %s, the Bounds give %s" % (
                    ev.seq, jcs.canonicalize(p["basis"]["inputs"]), jcs.canonicalize(exp.inputs)))
            az = Authz(ev)
            az.governing = exp.governing
            self.authz[ev.digest] = az
            self.proposals[az.proposal].rulings.append(az.result)
        elif exp.kind == "Evaluation":
            if p["criterion_id"] != exp.criterion_id:
                raise Failure(7, "sequencing", "event %d: expected %s, found an Evaluation of %r" % (ev.seq, exp.describe(), p["criterion_id"]))
            if p["result"] != exp.result:
                raise Failure(8, "recompute", "event %d: the Evaluation of %r records %r, recomputed %r" % (ev.seq, exp.criterion_id, p["result"], exp.result))
        elif exp.kind == "StepClosed":
            if p["outcome"] != exp.result:
                raise Failure(8, "recompute", "event %d: StepClosed records %r for step %r, recomputed %r" % (ev.seq, p["outcome"], exp.step_id, exp.result))

    # --- settle (section 6.3 item 3) ---------------------------------------
    def settle(self) -> List[Expected]:
        out: List[Expected] = []
        while True:
            emitted = False
            for step in self.procedure["steps"]:
                sid = step["step_id"]
                st = self.state[sid]
                if not st.opened and all(self.state[r].closed == "complete" for r in step["requires"]):
                    st.opened = True
                    out.append(Expected("StepOpened", sid))
                    emitted = True
                if st.is_open:
                    term = self.terminal(st)
                    if term is not None:
                        st.closed = term
                        out.append(Expected("StepClosed", sid, result=term))
                        emitted = True
            if not emitted:
                return out

    def terminal(self, st: StepState) -> Optional[str]:
        if st.failed_actions or st.against or any(c.state == "nonconforming" for c in st.crit):
            return "failed"  # failure takes precedence over completion (section 6.5)
        ch = st.step.get("children")
        if ch is not None:  # draft 11: under all_complete every child is sealed complete; enough of them either way
            kids = list(st.children.values())
            if ch["require"] == "all_complete" and any(k[1] is not None and k[1] != "complete" for k in kids):
                return "failed"
            if any(k[1] is None for k in kids) or sum(1 for k in kids if k[1] == "complete") < ch["min"]:
                return None
        if not all(c.state == "conforming" for c in st.crit):
            return None
        for d in st.step["decisions"]:
            if d["required"] is True and d["decision_id"] not in st.satisfied:
                return None
        if "actions" in st.step and st.successes < 1:
            return None
        return "complete"

    # --- section 6.2 ---------------------------------------------------------
    def _fail(self, code: str, ev: Event, msg: str) -> Failure:
        return Failure(7, code, "event %d (%s by %s): %s" % (ev.seq, ev.pred["kind"], ev.by, msg))

    def _grants(self, ev: Event) -> List[str]:
        return ev.enrollment["grants"] if ev.enrollment else []

    def _roles(self, ev: Event) -> List[str]:
        return ev.enrollment["roles"] if ev.enrollment else []

    def _open(self, ev: Event) -> StepState:
        st = self.state[ev.step_id]
        if not st.is_open:
            why = "has not opened" if not st.opened else "is closed (%s)" % st.closed
            raise self._fail("authority", ev, "step %r %s" % (ev.step_id, why))
        return st

    def _performer(self, ev: Event, step: dict) -> bool:
        kind = ev.pred["actor"]["kind"]
        roles = self._roles(ev)
        for pf in step["performers"]:
            if pf["kind"] == kind and (pf["role"] is None or pf["role"] in roles):
                return True
        return False

    def _cites(self, ev: Event) -> None:
        for c in ev.pred["cites"]:
            if c not in self.earlier:
                raise self._fail("reference", ev, "cites %s, which is not an earlier event" % c)

    def participant_event(self, ev: Event, queue: Deque[Expected]) -> List[Expected]:
        if queue:  # common check 1
            raise self._fail("sequencing", ev, "arrives while the runtime owes %s" % queue[0].describe())
        if ev.step_id is not None and ev.step_id not in self.state:  # common check 2
            raise self._fail("reference", ev, "step %r is not a Step of the Procedure" % ev.step_id)
        k = ev.pred["kind"]
        if k == "Proposal":
            return self.on_proposal(ev)
        if k == "Authorization":
            return self.on_human_authorization(ev)
        if k == "Action":
            return self.on_action(ev)
        if k == "Observation":
            return self.on_observation(ev)
        if k == "Decision":
            return self.on_decision(ev)
        if k == "ChildStarted":
            return self.on_child_started(ev)
        return []  # Note: no further checks, triggers nothing

    def on_child_started(self, ev: Event) -> List[Expected]:
        """Draft 11, sections 4.4 and 6.2: a named slot holding start, under the Procedure the step names."""
        st = self._open(ev)
        ch = st.step.get("children")
        if ch is None:
            raise self._fail("authority", ev, "step %r starts no child Runs" % ev.step_id)
        kind = ev.pred["actor"]["kind"]
        if not any(x["kind"] == kind and (x["role"] is None or x["role"] in self._roles(ev)) for x in ch["starters"]):
            raise self._fail("authority", ev, "the actor is not a starter on step %r" % ev.step_id)
        if "start" not in self._grants(ev):
            raise self._fail("authority", ev, "the actor does not hold start")
        if ev.pred["procedure"]["procedure_id"] != ch["procedure_id"]:
            raise self._fail("reference", ev, "a child of step %r runs %s" % (ev.step_id, ch["procedure_id"]))
        if "max" in ch and len(st.children) >= ch["max"]:
            raise self._fail("authority", ev, "step %r allows at most %d children" % (ev.step_id, int(ch["max"])))
        cid = ev.pred["child_run_id"]
        if any(cid in s2.children for s2 in self.state.values()):
            raise self._fail("reference", ev, "%s is already a child of this Run" % cid)
        st.children[cid] = [ev.seq, None]
        return self.settle()

    def on_child_sealed(self, ev: Event) -> List[Expected]:
        """Draft 11, section 6.3: owed by no Participant event here, it may come whenever nothing is owed."""
        st = self.state.get(ev.step_id)
        if st is None:
            raise Failure(7, "reference", "event %d: step %r is not a Step of the Procedure" % (ev.seq, ev.step_id))
        child = st.children.get(ev.pred["child_run_id"])
        if child is None or child[1] is not None:
            raise Failure(7, "reference", "event %d: %s is not an unsealed child of step %r" % (ev.seq, ev.pred["child_run_id"], ev.step_id))
        if not st.is_open:
            raise Failure(7, "sequencing", "event %d: ChildSealed on step %r, which is not open" % (ev.seq, ev.step_id))
        child[1] = ev.pred["outcome"]
        return self.settle()

    def on_proposal(self, ev: Event) -> List[Expected]:
        st = self._open(ev)
        step = st.step
        props = step.get("proposals")
        if props is None:
            raise self._fail("authority", ev, "step %r has no proposals" % ev.step_id)
        if ev.pred["actor"]["kind"] not in props["allowed_kinds"]:
            raise self._fail("authority", ev, "actor kind %r is not in allowed_kinds" % ev.pred["actor"]["kind"])
        if "operate" not in self._grants(ev):
            raise self._fail("authority", ev, "the actor does not hold operate")
        atype = ev.pred["action"]["type"]
        if atype not in step["actions"]["types"]:
            raise self._fail("authority", ev, "action type %r is not in actions.types" % atype)
        self._cites(ev)
        self.proposals[ev.digest] = Proposal(ev)
        st.proposals.append(ev.digest)
        out: List[Expected] = []
        if props["bound_ids"]:
            result, governing, inputs = self.bound_ruling(step, ev.pred["action"])
            out.append(Expected("Authorization", ev.step_id, result=result, proposal=ev.digest, governing=governing, inputs=inputs))
        out.extend(self.settle())
        return out

    def _applicable(self, step: dict, atype: str) -> List[dict]:
        props = step.get("proposals")
        if props is None:
            return []
        return [self.bounds[b] for b in props["bound_ids"] if self.bounds[b]["action_type"] == atype]

    def bound_ruling(self, step: dict, action: dict) -> Tuple[str, List[dict], List[str]]:
        """Section 6.3 item 1: the ruling, the governing Bounds and the readings consulted."""
        applicable = self._applicable(step, action["type"])
        params = action["parameters"]
        names = sorted(params, key=lambda n: [ord(c) for c in n])
        governing: List[dict] = []
        inputs: List[str] = []
        for name in names:
            for b in applicable:
                if b["parameter"] != name:
                    continue
                w = b.get("when")
                if w is None:
                    governing.append(b)
                    break
                rd = self.readings.get((w["quantity"], w["unit"]))
                if rd is not None and rd[0] not in inputs:
                    inputs.append(rd[0])
                if rd is not None and not rd[1]:
                    break  # unknown uncertainty: no limit on this parameter can be chosen (draft 8)
                if rd is not None and w["min"] <= rd[2] <= w["max"]:
                    governing.append(b)
                    break

        def done(result: str) -> Tuple[str, List[dict], List[str]]:
            return result, governing, inputs

        if not applicable:
            return done("deny")
        ruled = {b["parameter"] for b in governing}
        if any(n not in ruled for n in names):
            return done("deny")
        if any(b["parameter"] not in params for b in applicable):
            return done("deny")
        for b in governing:
            v = params[b["parameter"]]
            if type(v) is not float or not (self.limit(b["min"]) <= v <= self.limit(b["max"])):  # draft 11: limits may read inputs
                return done("deny")
            if "max_count_per_run" in b and self.success_by_type.get(b["action_type"], 0) >= b["max_count_per_run"]:
                return done("deny")
        return done("allow")

    def on_human_authorization(self, ev: Event) -> List[Expected]:
        p = ev.pred
        if p["basis"]["kind"] != "human":
            raise self._fail("authority", ev, "only the runtime records bound rulings")
        st = self._open(ev)
        prop = self.proposals.get(p["proposal"])
        if prop is None or prop.step_id != ev.step_id:
            raise self._fail("reference", ev, "proposal %s does not name a Proposal on step %r" % (p["proposal"], ev.step_id))
        if "authorize" not in self._grants(ev):
            raise self._fail("authority", ev, "the actor does not hold authorize")
        fallback = (st.step.get("proposals") or {}).get("fallback_roles", [])
        if not any(r in fallback for r in self._roles(ev)):
            raise self._fail("authority", ev, "the actor holds no role in fallback_roles %s" % fallback)
        if prop.has_allow:
            raise self._fail("authority", ev, "Proposal %s already has an allow ruling" % prop.digest)
        if prop.human_ruled:
            raise self._fail("authority", ev, "Proposal %s already has a human ruling" % prop.digest)
        if prop.author == ev.by:
            raise self._fail("authority", ev, "nobody authorizes their own Proposal")
        az = Authz(ev)
        self.authz[ev.digest] = az
        prop.rulings.append(az.result)
        prop.human_ruled = True
        self.human_authorizations.append({"seq": ev.seq, "step_id": ev.step_id, "result": az.result, "by": ev.by})
        return self.settle()

    def on_action(self, ev: Event) -> List[Expected]:
        p = ev.pred
        st = self._open(ev)
        step = st.step
        if not self._performer(ev, step):
            raise self._fail("authority", ev, "the actor matches no performers entry of step %r" % ev.step_id)
        if "act" not in self._grants(ev):
            raise self._fail("authority", ev, "the actor does not hold act")
        acts = step.get("actions")
        if acts is None:
            raise self._fail("authority", ev, "step %r has no actions" % ev.step_id)
        atype = p["action"]["type"]
        if atype not in acts["types"]:
            raise self._fail("authority", ev, "action type %r is not in actions.types" % atype)
        if acts["requires_authorization"]:
            ref = p.get("authorization")
            if ref is None:
                raise self._fail("authority", ev, "step %r requires authorization and the Action names none" % ev.step_id)
            az = self.authz.get(ref)
            if az is None:
                raise self._fail("reference", ev, "authorization %s does not name an earlier Authorization" % ref)
            if az.result != "allow":
                raise self._fail("authority", ev, "Authorization %s is a deny" % ref)
            prop = self.proposals[az.proposal]
            if prop.step_id != ev.step_id:
                raise self._fail("reference", ev, "Authorization %s is for a Proposal on step %r" % (ref, prop.step_id))
            if prop.action_jcs != _jcs(p["action"]):
                raise self._fail("authority", ev, "the action is not JCS-equal to the authorized Proposal's")
            if az.used_by is not None:
                raise self._fail("authority", ev, "Authorization %s is already cited by event %d" % (ref, az.used_by))
            if az.basis == "bound":
                for b in az.governing:
                    w = b.get("when")
                    if w is not None:  # the condition must still hold at the Action (section 6.2, draft 8)
                        rd = self.readings.get((w["quantity"], w["unit"]))
                        if rd is None or not rd[1] or not (w["min"] <= rd[2] <= w["max"]):
                            raise self._fail("authority", ev, "bound %r applied when the Proposal was allowed, but the latest %s reading no longer meets its condition" % (
                                b["bound_id"], w["quantity"]))
                    if "max_count_per_run" in b and self.success_by_type.get(atype, 0) >= b["max_count_per_run"]:
                        raise self._fail("authority", ev, "bound %r allows %d successful %s Actions per Run and that many precede this one" % (
                            b["bound_id"], int(b["max_count_per_run"]), atype))
            az.used_by = ev.seq
        elif "authorization" in p:
            raise self._fail("authority", ev, "step %r does not require authorization, so authorization must be absent" % ev.step_id)
        if p["result"]["status"] == "success":
            st.successes += 1
            self.success_by_type[atype] = self.success_by_type.get(atype, 0) + 1
        else:
            st.failed_actions.append(ev.digest)
        # draft 11: sealed policies that read Actions of this type, on every open Step, in Procedure order
        self.action_log.append({"digest": ev.digest, "seq": ev.seq, "type": atype, "parameters": p["action"]["parameters"],
                                "status": p["result"]["status"], "declared_time": p["declared_time"]})
        out: List[Expected] = []
        for s2 in self.procedure["steps"]:
            st2 = self.state[s2["step_id"]]
            if not st2.is_open:
                continue
            for cs in st2.crit:
                if cs.crit["type"] == "derived" and any(i.get("actions") == atype for i in cs.crit["inputs"]):
                    out.append(self.derive(st2, cs))
        out.extend(self.settle())
        return out

    def on_observation(self, ev: Event) -> List[Expected]:
        p = ev.pred
        st = self._open(ev)
        step = st.step
        if not self._performer(ev, step):
            raise self._fail("authority", ev, "the actor matches no performers entry of step %r" % ev.step_id)
        if "observe" not in self._grants(ev):
            raise self._fail("authority", ev, "the actor does not hold observe")
        out: List[Expected] = []
        if "confirmation" in p:  # draft 11, section 6.2
            cid = p["confirmation"]["criterion_id"]
            if ev.pred["actor"]["kind"] != "human":
                raise self._fail("authority", ev, "only a person confirms")
            crit = next((c for c in step["evidence"] if c["criterion_id"] == cid and c["type"] == "confirmation"), None)
            if crit is None:
                raise self._fail("reference", ev, "%r is not a confirmation criterion of step %r" % (cid, ev.step_id))
            if not any(r in crit["roles"] for r in self._roles(ev)):
                raise self._fail("authority", ev, "the actor holds none of the roles that confirm %r" % cid)
            for cs in st.crit:
                if cs.crit["criterion_id"] == cid:
                    if cs.state == "undetermined":
                        cs.state = "conforming"
                    out.append(Expected("Evaluation", ev.step_id, result=cs.state, criterion_id=cid))
            out.extend(self.settle())
            return out
        if "measurement" in p:
            q = p["measurement"]["quantity"]
            u = p["measurement"]["unit"]
            v = p["measurement"]["value"]
            stated = p["uncertainty"]["kind"] == "stated"
            if stated:
                st.stated.append({"digest": ev.digest, "seq": ev.seq, "quantity": q, "unit": u, "value": v, "declared_time": p["declared_time"]})
                for o in st.unknown_obs:
                    if o[1] == q and o[2] == u:
                        o[3] = True
            else:
                st.unknown_obs.append([ev.digest, q, u, False])
            if any(c["type"] == "measurement" and c["quantity"] == q and c["unit"] == u for c in step["evidence"]):
                self.readings[(q, u)] = (ev.digest, stated, v)  # for Bound conditions, from a Step that asks for it (section 6.3, draft 8)
            for cs in st.crit:
                c = cs.crit
                if c["type"] == "derived":
                    if stated and any(i.get("quantity") == q and i.get("unit") == u for i in c["inputs"]):
                        out.append(self.derive(st, cs))
                    continue
                if c["type"] != "measurement" or c["quantity"] != q or c["unit"] != u:
                    continue
                if stated and cs.state == "undetermined":
                    cs.seen += 1
                    if c["tolerance"]["min"] <= v <= c["tolerance"]["max"]:
                        cs.run += 1
                    else:
                        cs.run = 0
                    if cs.run >= c["consecutive"]:
                        cs.state = "conforming"
                    elif cs.seen >= c["max_observations"]:
                        cs.state = "nonconforming"
                out.append(Expected("Evaluation", ev.step_id, result=cs.state, criterion_id=c["criterion_id"]))
        else:
            mt = p["artifact"]["media_type"]
            for cs in st.crit:
                c = cs.crit
                if c["type"] != "artifact" or not _media_matches(mt, c["media_types"]):
                    continue
                if cs.state == "undetermined":
                    cs.state = "conforming"  # presence and integrity were established in step 6
                    cs.artifact = p["artifact"]
                out.append(Expected("Evaluation", ev.step_id, result=cs.state, criterion_id=c["criterion_id"]))
        out.extend(self.settle())
        return out

    def derive(self, st: StepState, cs: CritState) -> Expected:
        """Draft 11: run a derived criterion's sealed policy on its inputs while it is undetermined (Appendix L)."""
        c = cs.crit
        if cs.state == "undetermined":
            inputs: Dict[str, list] = {}
            for i in c["inputs"]:
                if "quantity" in i:
                    rows = [x for x in st.stated if x["quantity"] == i["quantity"] and x["unit"] == i["unit"]][-int(i["last"]):]
                    inputs[i["name"]] = [{"digest": x["digest"], "declared_time": x["declared_time"], "value": x["value"]} for x in rows]
                elif "actions" in i:
                    rows = [x for x in self.action_log if x["type"] == i["actions"]]
                    inputs[i["name"]] = [{"digest": x["digest"], "declared_time": x["declared_time"], "parameters": x["parameters"],
                                          "status": x["status"]} for x in rows]
                elif "input" in i:  # draft 11: as RunStarted bound it
                    inputs[i["name"]] = self.bound[i["input"]]
                else:  # an earlier derived criterion on this Step, as it stands
                    d = next(x for x in st.crit if x.crit["criterion_id"] == i["derived"])
                    inputs[i["name"]] = {"result": d.state, **({"value": d.value} if d.value is not None else {})}
            cs.state, value = self.run_policy(c, _jcs({"criterion_id": c["criterion_id"], "inputs": inputs, "step_id": st.step["step_id"]}))
            if value is not None:
                cs.value = value
        return Expected("Evaluation", st.step["step_id"], result=cs.state, criterion_id=c["criterion_id"])

    def limit(self, lim: Any) -> float:
        """Draft 11: a Limit is a number, or a number input of the Run read as value * scale + offset."""
        if is_number(lim):
            return lim
        return self.bound[lim["input"]] * lim.get("scale", 1) + lim.get("offset", 0)

    def run_policy(self, c: dict, data: bytes) -> Tuple[str, Optional[float]]:
        """Whatever goes wrong in the policy gives nonconforming: it did not show the evidence conforms."""
        hx = c["policy"]["digest"][7:]
        if hx not in self.policies:
            blob = self.evidence.get(hx)
            try:
                self.policies[hx] = policy.decode(blob) if blob is not None else None
            except policy.PolicyFault:
                self.policies[hx] = None
        m = self.policies[hx]
        no = ("nonconforming", None)
        out = policy.run_decoded(m, data) if m is not None else None
        if out is None:
            return no
        try:
            o = jcs.parse(out)
            if jcs.canonical_bytes(o) != out:
                return no
        except Exception:
            return no
        if type(o) is not dict or len(o) != 1:
            return no
        want = c["result"]
        if want == "conforming":
            r = o.get("result")
            return (r, None) if r in ("conforming", "nonconforming", "undetermined") and isinstance(r, str) else no
        v = o.get("value")
        if not is_number(v):
            return no
        return ("conforming" if want["min"] <= v <= want["max"] else "undetermined"), v

    def on_decision(self, ev: Event) -> List[Expected]:
        p = ev.pred
        if ev.pred["actor"]["kind"] != "human":
            raise self._fail("authority", ev, "the actor is not a Human")
        if "decide" not in self._grants(ev):
            raise self._fail("authority", ev, "the actor does not hold decide")
        self._cites(ev)
        did = p.get("decision_id")
        counted = False
        if did is not None:
            st = self.state[ev.step_id]
            rd = None
            for d in st.step["decisions"]:
                if d["decision_id"] == did:
                    rd = d
            if rd is None:
                raise self._fail("reference", ev, "decision_id %r names no RequiredDecision on step %r" % (did, ev.step_id))
            if p["type"] not in rd["types"]:
                raise self._fail("authority", ev, "type %r is not in %r's types %s" % (p["type"], did, rd["types"]))
            if not any(r in rd["decider_roles"] for r in self._roles(ev)):
                raise self._fail("authority", ev, "the actor holds no role in decider_roles %s" % rd["decider_roles"])
            if st.is_open:
                (st.against if p["type"] in AGAINST_DECISIONS else st.satisfied).add(did)
                counted = True
            else:
                state = "blocked" if not st.opened else "closed (%s)" % st.closed
                self.warnings.append(
                    "Decision at seq %d (%s, decision_id %s) was recorded on step %r while it was %s; it is reported but counts for nothing"
                    % (ev.seq, p["type"], did, ev.step_id, state))
        entry: Dict[str, Any] = {"seq": ev.seq}
        if ev.step_id is not None:
            entry["step_id"] = ev.step_id
        entry.update(type=p["type"], by=ev.by, counted=counted)
        self.decisions.append(entry)
        return self.settle()

    # --- section 6.6 ----------------------------------------------------------
    def recompute(self) -> Tuple[str, List[dict]]:
        rows: List[dict] = []
        any_failed = False
        all_complete = True
        for step in self.procedure["steps"]:
            sid = step["step_id"]
            st = self.state[sid]
            if st.closed == "complete":
                continue
            all_complete = False
            if st.closed == "failed":
                any_failed = True
            if not st.opened:
                rows.append(_om(sid, "step", sid, "blocked"))
                continue
            for cs in st.crit:
                if cs.state != "conforming":
                    rows.append(_om(sid, "criterion", cs.crit["criterion_id"], cs.state))
            for d in step["decisions"]:
                if d["decision_id"] in st.against:
                    rows.append(_om(sid, "decision", d["decision_id"], "against"))
                elif d["required"] is True and d["decision_id"] not in st.satisfied:
                    rows.append(_om(sid, "decision", d["decision_id"], "missing"))
            for dg in st.proposals:
                prop = self.proposals[dg]
                if not prop.has_allow:
                    rows.append(_om(sid, "proposal", dg, "denied" if "deny" in prop.rulings else "pending"))
            if "actions" in step and st.actions_recorded == 0:
                rows.append(_om(sid, "action", sid, "missing"))
            for dg in st.failed_actions:
                rows.append(_om(sid, "action", dg, "failed"))
            measured = {(c["quantity"], c["unit"]) for c in step["evidence"] if c["type"] == "measurement"}
            for o in st.unknown_obs:
                if not o[3] and (o[1], o[2]) in measured:
                    rows.append(_om(sid, "observation", o[0], "unknown_uncertainty"))
            if "children" in step:  # draft 11: a child still unsealed; or too few complete, with none pending
                kids = sorted(st.children.items(), key=lambda kv: kv[1][0])
                for cid, k in kids:
                    if k[1] is None:
                        rows.append(_om(sid, "child", cid, "pending"))
                if all(k[1] is not None for _, k in kids) and sum(1 for _, k in kids if k[1] == "complete") < step["children"]["min"]:
                    rows.append(_om(sid, "child", sid, "missing"))
        if all_complete:
            outcome = "complete"
        elif any_failed:
            outcome = "failed"
        else:
            outcome = "incomplete"
        return outcome, rows

    def check_run_closed(self, ev: Event) -> None:
        outcome, matters = self.recompute()
        p = ev.pred
        if p["outcome"] != outcome:
            raise Failure(8, "recompute", "event %d: RunClosed records outcome %r, recomputed %r" % (ev.seq, p["outcome"], outcome))
        if _jcs(p["open_matters"]) != _jcs(matters):
            raise Failure(8, "recompute", "event %d: RunClosed open_matters differ from the recomputed %s" % (ev.seq, jcs.canonicalize(matters)))

    # --- section 9 ------------------------------------------------------------
    def build_report(self, failure: Optional[Failure]) -> VerifyResult:
        from .trust import provenance_of
        trust_warnings: List[str] = []
        finding = None
        if self.key_established:
            prov, finding = provenance_of(self.ws_key_id or "", self.pin, self.published, trust_warnings, "Record")
        else:
            prov = "unpinned" if self.pin is None and self.published is None else "mismatch"
        rep: Dict[str, Any] = {"integrity": "fail" if failure else "pass", "provenance": prov}
        if failure:
            rep["failure"] = {"step": failure.step, "code": failure.code, "message": failure.message}
        if self.known:  # step 1.6 passed
            m = self.manifest.predicate
            rep["run_id"] = m["run_id"]
            rep["sequence"] = int(m["sequence"])
            rep["procedure"] = {k: m["procedure"][k] for k in ("procedure_id", "version", "digest")}
            rep["event_count"] = int(m["events"]["count"])
        if self.key_established:  # step 2.1 passed
            ws = self.manifest.predicate["workspace"]
            rep["workspace"] = {"key_id": self.ws_key_id, "workspace_id": ws["workspace_id"], "display_name": ws["display_name"]}
        if not failure:
            rep["outcome"] = self.outcome
            rep["open_matters"] = self.open_matters
            rep["steps"] = [{"step_id": s["step_id"], "state": _step_state(self.state[s["step_id"]])}
                            for s in self.procedure["steps"]]
            rep["human_authorizations"] = self.human_authorizations
            rep["decisions"] = self.decisions
            rep["agreed_by"] = self.agreed_by
            rep["inputs"] = self.events[0].pred.get("inputs", {})
            rep["subjects"] = self.events[0].pred.get("subjects", [])
            rep["outputs"] = self.outputs
            rep["related"] = self.related
            rep["findings"] = ([finding] if finding else []) + self.edition_findings + ([{"kind": "timestamps"}] if self.timestamps else [])
        warnings: List[str] = []
        key = rep["workspace"]["key_id"] if "workspace" in rep else None
        if prov == "unpinned" and finding is None:
            warnings.append(
                "unpinned: no workspace key fingerprint was supplied; workspace_id, display_name and every other "
                "name in this Record are issuer-chosen strings. Only the workspace key %s is established." % (key or "(unknown)"))
        elif prov == "mismatch":
            if self.key_established:
                warnings.extend(trust_warnings)
            else:
                warnings.append("provenance mismatch: %s was supplied but verification failed before the "
                                "workspace key was established" % ("a fingerprint (%s)" % self.pin if self.pin is not None
                                                                     else "a domain (%s)" % self.published[0]))
        if failure is None:
            warnings.extend(self.warnings)
        rep["warnings"] = warnings
        rep["summary"] = _summary(rep, failure)
        return VerifyResult(rep)


def _om(step_id: str, kind: str, ref: str, state: str) -> dict:
    return {"step_id": step_id, "kind": kind, "ref": ref, "state": state}


def _step_state(st: StepState) -> str:
    if not st.opened:
        return "blocked"
    if st.closed is not None:
        return st.closed
    return "open"


def _short_key(k: Optional[str]) -> str:
    if not k:
        return "(unknown)"
    if k.startswith("sha256:") and len(k) > 11:
        return k[:11] + "…"
    return k


def _summary(rep: dict, failure: Optional[Failure]) -> str:
    parts = []
    if failure:
        parts.append("integrity: fail (step %d, %s)" % (failure.step, failure.code))
    else:
        parts.append("integrity: pass")
    parts.append("provenance: %s" % rep["provenance"])
    for f in rep.get("findings", []):
        if f["kind"] == "published":
            parts.append("published by %s" % f["domain"])
    if not failure:
        n = len(rep["open_matters"])
        o = "outcome: %s" % rep["outcome"]
        if n:
            o += " (%d open matter%s)" % (n, "" if n == 1 else "s")
        parts.append(o)
    key = rep["workspace"]["key_id"] if "workspace" in rep else None
    parts.append("workspace %s" % _short_key(key))
    return " · ".join(parts)


def verify_bytes(data: bytes, pin: Any = None, published: Any = None) -> VerifyResult:
    """Verify a Run Record held in memory. ``pin`` is 'sha256:<hex>', a list of them (any will do) or None;
    ``published`` is (domain, the key ids it publishes or None if the lookup failed), from ``trust.lookup``."""
    return _Verifier(bytes(data), pin, published).run()


def verify_file(path: str, pin: Any = None, published: Any = None) -> VerifyResult:
    """Verify a Run Record file. Raises OSError if it cannot be read."""
    with open(path, "rb") as fh:
        data = fh.read()
    return verify_bytes(data, pin, published)
