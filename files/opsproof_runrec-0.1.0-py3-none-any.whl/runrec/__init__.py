"""Independent Python verifier for Run Records (spec v0.1-draft5).

Standard library only. ``verify_file(path, pin=None).report`` returns the
section 9 report as a dict.
"""
from __future__ import annotations

from .schema import Failure
from .verify import VerifyResult, verify_bytes, verify_file

__all__ = ["verify_bytes", "verify_file", "VerifyResult", "Failure"]
__version__ = "0.1.0"
