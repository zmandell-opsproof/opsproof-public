"""Grammar checks shared by every step (spec section 3).

Each check raises ``Failure(step, code, message)``. A ``Schema`` is bound to
the step and failure code under which its violations are reported.
"""
from __future__ import annotations

import datetime
import re
from typing import Any, Callable, Dict, Iterable, Optional

__all__ = [
    "VERSION_RE",
    "Failure",
    "Schema",
    "IDENT_RE",
    "HASH_RE",
    "HEX64_RE",
    "is_identifier",
    "is_hash",
    "is_timestamp",
    "is_integer",
    "is_number",
    "MAX_SAFE_INTEGER",
]

MAX_SAFE_INTEGER = 2 ** 53 - 1

# Section 3 patterns (draft 5). Always used with fullmatch(), and written
# with explicit ASCII classes, never \d or \w.
IDENT_RE = re.compile(r"[a-z0-9][a-z0-9._-]{0,127}")
VERSION_RE = re.compile(r"[0-9A-Za-z][0-9A-Za-z._+-]{0,63}")
HASH_RE = re.compile(r"sha256:[0-9a-f]{64}")
HEX64_RE = re.compile(r"[0-9a-f]{64}")
_TS_RE = re.compile(r"([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})(\.[0-9]{1,9})?Z")
_MT_TOKEN = r"[a-z0-9][a-z0-9!#$&^_.+-]*"
MEDIA_TYPE_RE = re.compile(_MT_TOKEN + "/" + _MT_TOKEN)
MEDIA_RANGE_RE = re.compile(_MT_TOKEN + "/(?:" + _MT_TOKEN + r"|\*)")


class Failure(Exception):
    """The first failure of verification: a step (1-8), a short code and a message."""

    def __init__(self, step: int, code: str, message: str) -> None:
        super().__init__("step %d (%s): %s" % (step, code, message))
        self.step = step
        self.code = code
        self.message = message


def is_identifier(v: Any) -> bool:
    return isinstance(v, str) and IDENT_RE.fullmatch(v) is not None


def is_hash(v: Any) -> bool:
    return isinstance(v, str) and HASH_RE.fullmatch(v) is not None


def is_number(v: Any) -> bool:
    return type(v) is float


def is_integer(v: Any, minimum: int = 0, maximum: int = MAX_SAFE_INTEGER) -> bool:
    return type(v) is float and v.is_integer() and minimum <= v <= maximum


def is_timestamp(v: Any) -> bool:
    """RFC 3339, UTC, 'Z' suffix, denoting a real calendar date and time."""
    if not isinstance(v, str):
        return False
    m = _TS_RE.fullmatch(v)
    if not m:
        return False
    year, month, day, hour, minute, second = (int(x) for x in m.groups()[:6])
    try:
        datetime.date(year, month, day)  # rejects year 0, month 13, Feb 30, ...
    except ValueError:
        return False
    # Draft 5: hour 00-23, minute 00-59, second 00-59 (no leap seconds).
    return hour <= 23 and minute <= 59 and second <= 59


Check = Callable[[Any, str], None]


class Schema:
    """Factory for grammar checks that fail under one (step, code)."""

    def __init__(self, step: int, code: str) -> None:
        self.step = step
        self.code = code

    def fail(self, path: str, msg: str) -> "Failure":
        return Failure(self.step, self.code, "%s: %s" % (path, msg))

    # --- object ---------------------------------------------------------
    def check_obj(
        self,
        v: Any,
        path: str,
        req: Dict[str, Check],
        opt: Optional[Dict[str, Check]] = None,
        ext: bool = False,
    ) -> dict:
        if type(v) is not dict:
            raise self.fail(path, "must be an object")
        opt = opt or {}
        for k in v:
            if k in req or k in opt:
                continue
            if ext and k == "ext":
                if type(v[k]) is not dict:
                    raise self.fail(path + ".ext", "must be an object")
                continue
            raise self.fail(path, "unknown member %r" % k)
        for k, chk in req.items():
            if k not in v:
                raise self.fail(path, "missing member %r" % k)
            chk(v[k], path + "." + k)
        for k, chk in opt.items():
            if k in v:
                chk(v[k], path + "." + k)
        return v

    def obj(self, req: Dict[str, Check], opt: Optional[Dict[str, Check]] = None) -> Check:
        def chk(v: Any, path: str) -> None:
            self.check_obj(v, path, req, opt)

        return chk

    # --- scalars ----------------------------------------------------------
    def string(self, v: Any, path: str) -> None:
        if not isinstance(v, str):
            raise self.fail(path, "must be a string")

    def text_plus(self, v: Any, path: str) -> None:
        if not isinstance(v, str) or v == "":
            raise self.fail(path, "must be a non-empty string")

    def ident(self, v: Any, path: str) -> None:
        if not is_identifier(v):
            raise self.fail(path, "must be an identifier matching ^[a-z0-9][a-z0-9._-]{0,127}$")

    def version(self, v: Any, path: str) -> None:
        if not (isinstance(v, str) and VERSION_RE.fullmatch(v)):
            raise self.fail(path, "must be a version matching ^[0-9A-Za-z][0-9A-Za-z._+-]{0,63}$")

    def hash(self, v: Any, path: str) -> None:
        if not is_hash(v):
            raise self.fail(path, "must be sha256:<64 lowercase hex>")

    def hex64(self, v: Any, path: str) -> None:
        if not (isinstance(v, str) and HEX64_RE.fullmatch(v)):
            raise self.fail(path, "must be 64 lowercase hex characters")

    def timestamp(self, v: Any, path: str) -> None:
        if not is_timestamp(v):
            raise self.fail(path, "must be an RFC 3339 UTC timestamp ending in Z that denotes a real date and time")

    def media_type(self, v: Any, path: str) -> None:
        if not (isinstance(v, str) and MEDIA_TYPE_RE.fullmatch(v)):
            raise self.fail(path, "must be a lowercase type/subtype media type without parameters")

    def media_range(self, v: Any, path: str) -> None:
        if not (isinstance(v, str) and MEDIA_RANGE_RE.fullmatch(v)):
            raise self.fail(path, "must be a lowercase type/subtype or type/* without parameters")

    def integer(self, minimum: int = 0, maximum: int = MAX_SAFE_INTEGER) -> Check:
        def chk(v: Any, path: str) -> None:
            if not is_integer(v, minimum, maximum):
                raise self.fail(path, "must be an integer in [%d, %d]" % (minimum, maximum))

        return chk

    def number(self, v: Any, path: str) -> None:
        if not is_number(v):
            raise self.fail(path, "must be a number")

    def boolean(self, v: Any, path: str) -> None:
        if type(v) is not bool:
            raise self.fail(path, "must be a boolean")

    def anyv(self, v: Any, path: str) -> None:
        return None

    def enum(self, *values: str) -> Check:
        allowed = frozenset(values)

        def chk(v: Any, path: str) -> None:
            if not (isinstance(v, str) and v in allowed):
                raise self.fail(path, "must be one of %s" % ", ".join(sorted(allowed)))

        return chk

    def const(self, value: str) -> Check:
        def chk(v: Any, path: str) -> None:
            if v != value or not isinstance(v, str):
                raise self.fail(path, "must be %r" % value)

        return chk

    def nullable(self, inner: Check) -> Check:
        def chk(v: Any, path: str) -> None:
            if v is not None:
                inner(v, path)

        return chk

    def array(self, inner: Check, unique: bool = False, min_items: int = 0) -> Check:
        """A list of T, or (unique=True) a set of T: an array of distinct T.

        Distinctness is JCS equality, so it also applies to sets of objects."""

        def chk(v: Any, path: str) -> None:
            if type(v) is not list:
                raise self.fail(path, "must be an array")
            if len(v) < min_items:
                raise self.fail(path, "must not be empty")
            for i, item in enumerate(v):
                inner(item, "%s[%d]" % (path, i))
            if unique:
                from .jcs import canonicalize

                seen = set()
                for item in v:
                    key = canonicalize(item)
                    if key in seen:
                        raise self.fail(path, "duplicate entry %s" % key)
                    seen.add(key)

        return chk

    def object_any(self, v: Any, path: str) -> None:
        if type(v) is not dict:
            raise self.fail(path, "must be an object")

    def one_of(self, *checks: Check) -> Check:
        def chk(v: Any, path: str) -> None:
            errors = []
            for c in checks:
                try:
                    c(v, path)
                    return
                except Failure as exc:
                    errors.append(exc.message)
            raise self.fail(path, " or ".join(e.split(": ", 1)[-1] for e in errors))

        return chk


def first_duplicate(items: Iterable[Any]) -> Optional[Any]:
    seen = set()
    for x in items:
        if x in seen:
            return x
        seen.add(x)
    return None
