"""Sealed policies (spec section 4, Appendix L), written from the
specification: a WebAssembly 1.0 module restricted to integer instructions,
validated and run here with metered fuel, so this checker re-decides a derived
criterion without any WebAssembly runtime and gets the same answer as any
other conforming checker."""
from __future__ import annotations

import sys
from typing import Dict, List, Optional, Tuple

PAGE = 65536
MAX_PAGES = 16
FUEL = 10_000_000
MAX_DEPTH = 1000
M32 = (1 << 32) - 1
M64 = (1 << 64) - 1


class PolicyFault(Exception):
    """The module is outside the profile, or the evaluation trapped."""


def _s(v: int, bits: int) -> int:
    v &= (1 << bits) - 1
    return v - (1 << bits) if v >> (bits - 1) else v


class _R:
    def __init__(self, b: bytes, end: Optional[int] = None, pos: int = 0) -> None:
        self.b, self.end, self.pos = b, len(b) if end is None else end, pos

    def byte(self) -> int:
        if self.pos >= self.end:
            raise PolicyFault("unexpected end")
        x = self.b[self.pos]
        self.pos += 1
        return x

    def u32(self) -> int:
        r = 0
        for n in range(5):
            x = self.byte()
            if n == 4 and x > 0x0F:
                raise PolicyFault("u32 too large")
            r |= (x & 0x7F) << (7 * n)
            if not x & 0x80:
                return r
        raise PolicyFault("u32 too long")

    def sleb(self, bits: int) -> int:
        r = 0
        shift = 0
        for _ in range(-(-bits // 7)):
            x = self.byte()
            r |= (x & 0x7F) << shift
            shift += 7
            if not x & 0x80:
                if x & 0x40:
                    r -= 1 << shift
                if _s(r, bits) != r:
                    raise PolicyFault("signed LEB out of range")
                return r
        raise PolicyFault("signed LEB too long")

    def take(self, n: int) -> bytes:
        if self.pos + n > self.end:
            raise PolicyFault("unexpected end")
        v = self.b[self.pos:self.pos + n]
        self.pos += n
        return v

    def valtype(self) -> str:
        t = self.byte()
        if t == 0x7F:
            return "i32"
        if t == 0x7E:
            return "i64"
        raise PolicyFault("value type 0x%x is outside the profile" % t)


LOAD = {0x28: ("i32", 4), 0x29: ("i64", 8), 0x2C: ("i32", 1), 0x2D: ("i32", 1), 0x2E: ("i32", 2), 0x2F: ("i32", 2),
        0x30: ("i64", 1), 0x31: ("i64", 1), 0x32: ("i64", 2), 0x33: ("i64", 2), 0x34: ("i64", 4), 0x35: ("i64", 4)}
STORE = {0x36: ("i32", 4), 0x37: ("i64", 8), 0x3A: ("i32", 1), 0x3B: ("i32", 2), 0x3C: ("i64", 1), 0x3D: ("i64", 2), 0x3E: ("i64", 4)}
SIGNED_LOADS = {0x28, 0x29, 0x2C, 0x2E, 0x30, 0x32, 0x34}


def _numeric(op: int) -> Optional[Tuple[List[str], str]]:
    if op == 0x45:
        return ["i32"], "i32"
    if 0x46 <= op <= 0x4F:
        return ["i32", "i32"], "i32"
    if op == 0x50:
        return ["i64"], "i32"
    if 0x51 <= op <= 0x5A:
        return ["i64", "i64"], "i32"
    if 0x67 <= op <= 0x69:
        return ["i32"], "i32"
    if 0x6A <= op <= 0x78:
        return ["i32", "i32"], "i32"
    if 0x79 <= op <= 0x7B:
        return ["i64"], "i64"
    if 0x7C <= op <= 0x8A:
        return ["i64", "i64"], "i64"
    if op == 0xA7:
        return ["i64"], "i32"
    if op in (0xAC, 0xAD):
        return ["i32"], "i64"
    return None


def _blocktype(r: _R) -> List[str]:
    b = r.byte()
    if b == 0x40:
        return []
    if b == 0x7F:
        return ["i32"]
    if b == 0x7E:
        return ["i64"]
    raise PolicyFault("block type outside the profile")


class _Func:
    def __init__(self, params: List[str], results: List[str], locals_: List[str], code: bytes) -> None:
        self.params, self.results, self.locals, self.code = params, results, locals_, code
        self.ends: Dict[int, int] = {}
        self.elses: Dict[int, int] = {}


def _validate(f: _Func, functypes: List[Tuple[List[str], List[str]]], globals_: List[list]) -> None:
    """Standard validation, restricted to the profile; records where each block ends and each if's else is."""
    r = _R(f.code)
    vals: List[str] = []
    ctrl = [{"op": 0, "label": f.results, "out": f.results, "h": 0, "u": False, "at": -1}]
    allv = f.params + f.locals

    def pop(want: Optional[str] = None) -> str:
        fr = ctrl[-1]
        if len(vals) == fr["h"]:
            if fr["u"]:
                return "any"
            raise PolicyFault("operand stack underflow")
        v = vals.pop()
        if want and v != "any" and v != want:
            raise PolicyFault("expected %s, found %s" % (want, v))
        return v

    def pops(ts: List[str]) -> None:
        for t in reversed(ts):
            pop(t)

    def unreachable() -> None:
        fr = ctrl[-1]
        del vals[fr["h"]:]
        fr["u"] = True

    def label(n: int) -> List[str]:
        if n >= len(ctrl):
            raise PolicyFault("branch to an unknown label")
        return ctrl[-1 - n]["label"]

    def local(i: int) -> str:
        if i >= len(allv):
            raise PolicyFault("unknown local")
        return allv[i]

    def glob(i: int) -> list:
        if i >= len(globals_):
            raise PolicyFault("unknown global")
        return globals_[i]

    while ctrl:
        at = r.pos
        op = r.byte()
        if op == 0x00:
            unreachable()
        elif op == 0x01:
            pass
        elif op in (0x02, 0x03, 0x04):
            bt = _blocktype(r)
            if op == 0x04:
                pop("i32")
            ctrl.append({"op": op, "label": [] if op == 0x03 else bt, "out": bt, "h": len(vals), "u": False, "at": at})
        elif op == 0x05:
            fr = ctrl[-1]
            if fr["op"] != 0x04 or fr["at"] in f.elses:
                raise PolicyFault("else without if")
            pops(fr["out"])
            if len(vals) != fr["h"]:
                raise PolicyFault("values left at else")
            f.elses[fr["at"]] = r.pos
            fr["u"] = False
        elif op == 0x0B:
            fr = ctrl[-1]
            pops(fr["out"])
            if len(vals) != fr["h"]:
                raise PolicyFault("values left at end")
            if fr["op"] == 0x04 and fr["at"] not in f.elses and fr["out"]:
                raise PolicyFault("if without else must not yield a value")
            ctrl.pop()
            if fr["at"] >= 0:
                f.ends[fr["at"]] = r.pos
            vals.extend(fr["out"])
        elif op == 0x0C:
            pops(label(r.u32()))
            unreachable()
        elif op == 0x0D:
            lt = label(r.u32())
            pop("i32")
            pops(lt)
            vals.extend(lt)
        elif op == 0x0E:
            n = r.u32()
            targets = [label(r.u32()) for _ in range(n + 1)]
            pop("i32")
            if any(t != targets[-1] for t in targets):
                raise PolicyFault("br_table targets differ")
            pops(targets[-1])
            unreachable()
        elif op == 0x0F:
            pops(f.results)
            unreachable()
        elif op == 0x10:
            i = r.u32()
            if i >= len(functypes):
                raise PolicyFault("unknown function")
            pops(functypes[i][0])
            vals.extend(functypes[i][1])
        elif op == 0x1A:
            pop()
        elif op == 0x1B:
            pop("i32")
            b = pop()
            a = pop(None if b == "any" else b)
            vals.append(b if a == "any" else a)
        elif op == 0x20:
            vals.append(local(r.u32()))
        elif op == 0x21:
            pop(local(r.u32()))
        elif op == 0x22:
            t = local(r.u32())
            pop(t)
            vals.append(t)
        elif op == 0x23:
            vals.append(glob(r.u32())[0])
        elif op == 0x24:
            g = glob(r.u32())
            if not g[1]:
                raise PolicyFault("global is immutable")
            pop(g[0])
        elif op in LOAD or op in STORE:
            t, size = LOAD.get(op) or STORE[op]
            if 2 ** r.u32() > size:
                raise PolicyFault("alignment larger than natural")
            r.u32()
            if op in STORE:
                pop(t)
            pop("i32")
            if op in LOAD:
                vals.append(t)
        elif op in (0x3F, 0x40):
            if r.byte() != 0:
                raise PolicyFault("memory index")
            if op == 0x40:
                pop("i32")
            vals.append("i32")
        elif op == 0x41:
            r.sleb(32)
            vals.append("i32")
        elif op == 0x42:
            r.sleb(64)
            vals.append("i64")
        else:
            n = _numeric(op)
            if n is None:
                raise PolicyFault("instruction 0x%x is outside the profile" % op)
            pops(n[0])
            vals.append(n[1])
    if r.pos != len(f.code):
        raise PolicyFault("code after the function end")


class Module:
    def __init__(self) -> None:
        self.funcs: List[_Func] = []
        self.mem_min = 0
        self.globals: List[list] = []  # [type, mutable, init]
        self.alloc = -1
        self.decide = -1
        self.data: List[Tuple[int, bytes]] = []


def decode(b: bytes) -> Module:
    """Decode and validate a module under the profile; raises PolicyFault otherwise."""
    r = _R(b)
    if r.take(8) != b"\x00asm\x01\x00\x00\x00":
        raise PolicyFault("not a WebAssembly 1.0 module")
    m = Module()
    types: List[Tuple[List[str], List[str]]] = []
    ftidx: List[int] = []
    mem = None
    exports: Dict[str, Tuple[int, int]] = {}
    bodies: List[bytes] = []
    last = 0
    while r.pos < len(b):
        sid = r.byte()
        size = r.u32()
        s = _R(b, r.pos + size, r.pos)
        r.take(size)
        if sid == 0:
            continue
        if sid <= last:
            raise PolicyFault("sections out of order or repeated")
        last = sid

        def vec(f):
            return [f() for _ in range(s.u32())]
        if sid == 1:
            def ftype():
                if s.byte() != 0x60:
                    raise PolicyFault("function type expected")
                p = vec(s.valtype)
                res = vec(s.valtype)
                if len(res) > 1:
                    raise PolicyFault("at most one result")
                return p, res
            types.extend(vec(ftype))
        elif sid == 3:
            ftidx = vec(s.u32)
        elif sid == 4:
            def table():
                s.byte()
                fl = s.byte()
                s.u32()
                if fl & 1:
                    s.u32()
            vec(table)
        elif sid == 5:
            def memory():
                fl = s.byte()
                lo = s.u32()
                hi = s.u32() if fl & 1 else None
                if fl > 1 or lo > MAX_PAGES or (hi is not None and (hi > MAX_PAGES or hi < lo)):
                    raise PolicyFault("memory outside the profile")
                return lo
            mems = vec(memory)
            if len(mems) != 1:
                raise PolicyFault("exactly one memory")
            mem = mems[0]
        elif sid == 6:
            def glob():
                t = s.valtype()
                mut = s.byte()
                if mut > 1:
                    raise PolicyFault("global mutability")
                if s.byte() != (0x41 if t == "i32" else 0x42):
                    raise PolicyFault("global initializer outside the profile")
                v = s.sleb(32 if t == "i32" else 64)
                if s.byte() != 0x0B:
                    raise PolicyFault("global initializer outside the profile")
                return [t, mut == 1, v]
            m.globals.extend(vec(glob))
        elif sid == 7:
            def export():
                try:
                    name = s.take(s.u32()).decode("utf-8")
                except UnicodeDecodeError:
                    raise PolicyFault("export name is not UTF-8") from None
                kind = s.byte()
                idx = s.u32()
                if name in exports:
                    raise PolicyFault("duplicate export")
                exports[name] = (kind, idx)
            vec(export)
        elif sid == 10:
            bodies.extend(vec(lambda: s.take(s.u32())))
        elif sid == 11:
            def seg():
                if s.u32() != 0 or s.byte() != 0x41:
                    raise PolicyFault("data segment outside the profile")
                off = s.sleb(32) & M32
                if s.byte() != 0x0B:
                    raise PolicyFault("data segment outside the profile")
                return off, s.take(s.u32())
            m.data.extend(vec(seg))
        else:
            raise PolicyFault("section %d is outside the profile" % sid)
        if s.pos != s.end:
            raise PolicyFault("section %d has trailing bytes" % sid)
    if mem is None:
        raise PolicyFault("no memory")
    if len(bodies) != len(ftidx):
        raise PolicyFault("function and code sections differ")
    for i in ftidx:
        if i >= len(types):
            raise PolicyFault("unknown type")
    functypes = [types[i] for i in ftidx]
    m.mem_min = mem
    for off, data in m.data:
        if off + len(data) > mem * PAGE:
            raise PolicyFault("data outside the initial memory")
    for i, body in enumerate(bodies):
        br = _R(body)
        locals_: List[str] = []
        for _ in range(br.u32()):
            count = br.u32()
            t = br.valtype()
            if len(locals_) + count > 50_000:
                raise PolicyFault("too many locals")
            locals_.extend([t] * count)
        f = _Func(functypes[i][0], functypes[i][1], locals_, body[br.pos:])
        _validate(f, functypes, m.globals)
        m.funcs.append(f)

    def fn(name: str, params: List[str], results: List[str]) -> int:
        e = exports.get(name)
        if e is None or e[0] != 0 or e[1] >= len(m.funcs) or m.funcs[e[1]].params != params or m.funcs[e[1]].results != results:
            raise PolicyFault("no export %s of the profile's type" % name)
        return e[1]
    m.alloc = fn("alloc", ["i32"], ["i32"])
    m.decide = fn("decide", ["i32", "i32"], ["i64"])
    return m


def _clz(v: int, bits: int) -> int:
    v &= (1 << bits) - 1
    return bits - v.bit_length()


def _ctz(v: int, bits: int) -> int:
    v &= (1 << bits) - 1
    if v == 0:
        return bits
    return (v & -v).bit_length() - 1


class _Machine:
    def __init__(self, m: Module) -> None:
        self.m = m
        self.pages = m.mem_min
        self.mem = bytearray(m.mem_min * PAGE)
        for off, data in m.data:
            self.mem[off:off + len(data)] = data
        self.globals = [g[2] for g in m.globals]
        self.fuel = FUEL
        self.depth = 0

    def addr(self, base: int, off: int, size: int) -> int:
        a = (base & M32) + off
        if a + size > len(self.mem):
            raise PolicyFault("memory access out of bounds")
        return a

    def call(self, fi: int, args: List[int]) -> Optional[int]:
        self.depth += 1
        if self.depth > MAX_DEPTH:
            raise PolicyFault("call depth exceeded")
        f = self.m.funcs[fi]
        loc = list(args) + [0] * len(f.locals)
        st: List[int] = []
        labels: List[list] = []  # [continuation, arity, height, is_loop]
        r = _R(f.code)
        n_code = len(f.code)

        def branch(n: int) -> None:
            if n >= len(labels):
                r.pos = n_code  # a branch to the function's own label returns
                return
            cont, arity, h, loop = labels[-1 - n]
            keep = st[len(st) - arity:] if arity else []
            del st[h:]
            st.extend(keep)
            del labels[len(labels) - (n if loop else n + 1):]
            r.pos = cont

        while r.pos < n_code:
            self.fuel -= 1
            if self.fuel < 0:
                raise PolicyFault("out of fuel")
            at = r.pos
            op = r.byte()
            if op == 0x00:
                raise PolicyFault("unreachable")
            elif op == 0x01:
                pass
            elif op in (0x02, 0x03):
                bt = _blocktype(r)
                labels.append([r.pos, 0, len(st), True] if op == 0x03 else [f.ends[at], len(bt), len(st), False])
            elif op == 0x04:
                bt = _blocktype(r)
                c = st.pop()
                labels.append([f.ends[at], len(bt), len(st), False])
                if not c:
                    if at in f.elses:
                        r.pos = f.elses[at]
                    else:
                        r.pos = f.ends[at]
                        labels.pop()
            elif op == 0x05:
                branch(0)  # the then-branch reached else: on to the end
            elif op == 0x0B:
                if labels:
                    labels.pop()
                else:
                    r.pos = n_code
            elif op == 0x0C:
                branch(r.u32())
            elif op == 0x0D:
                lab = r.u32()
                if st.pop():
                    branch(lab)
            elif op == 0x0E:
                n = r.u32()
                ts = [r.u32() for _ in range(n + 1)]
                i = st.pop() & M32
                branch(ts[min(i, n)])
            elif op == 0x0F:
                r.pos = n_code
            elif op == 0x10:
                gi = r.u32()
                k = len(self.m.funcs[gi].params)
                a = st[len(st) - k:] if k else []
                del st[len(st) - k:]
                v = self.call(gi, a)
                if v is not None:
                    st.append(v)
            elif op == 0x1A:
                st.pop()
            elif op == 0x1B:
                c = st.pop()
                b = st.pop()
                a = st.pop()
                st.append(a if c else b)
            elif op == 0x20:
                st.append(loc[r.u32()])
            elif op == 0x21:
                loc[r.u32()] = st.pop()
            elif op == 0x22:
                loc[r.u32()] = st[-1]
            elif op == 0x23:
                st.append(self.globals[r.u32()])
            elif op == 0x24:
                self.globals[r.u32()] = st.pop()
            elif op == 0x3F:
                r.byte()
                st.append(self.pages)
            elif op == 0x40:
                r.byte()
                n = st.pop() & M32
                old = self.pages
                if old + n > MAX_PAGES:
                    st.append(-1)
                else:
                    self.mem.extend(bytes(n * PAGE))
                    self.pages = old + n
                    st.append(old)
            elif op == 0x41:
                st.append(r.sleb(32))
            elif op == 0x42:
                st.append(r.sleb(64))
            elif op in LOAD or op in STORE:
                r.u32()
                off = r.u32()
                t, size = LOAD.get(op) or STORE[op]
                if op in STORE:
                    v = st.pop()
                    a = self.addr(st.pop(), off, size)
                    self.mem[a:a + size] = (v & ((1 << (8 * size)) - 1)).to_bytes(size, "little")
                else:
                    a = self.addr(st.pop(), off, size)
                    x = int.from_bytes(self.mem[a:a + size], "little")
                    if op in SIGNED_LOADS:
                        x = _s(x, 8 * size)
                    st.append(_s(x, 32) if t == "i32" else _s(x, 64))
            else:
                st.append(self.numeric(op, st))
        self.depth -= 1
        return st.pop() if f.results else None

    def numeric(self, op: int, st: List[int]) -> int:
        if op in (0x45, 0x50, 0x67, 0x68, 0x69, 0x79, 0x7A, 0x7B, 0xA7, 0xAC, 0xAD):
            a = st.pop()
            if op == 0x45 or op == 0x50:
                return int(a == 0)
            if op == 0x67:
                return _clz(a, 32)
            if op == 0x68:
                return _ctz(a, 32)
            if op == 0x69:
                return bin(a & M32).count("1")
            if op == 0x79:
                return _clz(a, 64)
            if op == 0x7A:
                return _ctz(a, 64)
            if op == 0x7B:
                return bin(a & M64).count("1")
            if op == 0xA7:
                return _s(a, 32)
            if op == 0xAC:
                return a
            return a & M32
        b = st.pop()
        a = st.pop()
        if op <= 0x4F or 0x6A <= op <= 0x78:
            bits, mask = 32, M32
            base = 0x46 if op <= 0x4F else 0x6A
        else:
            bits, mask = 64, M64
            base = 0x51 if op <= 0x5A else 0x7C
        k = op - base
        ua, ub = a & mask, b & mask
        if op <= 0x5A:  # comparisons: eq ne lt_s lt_u gt_s gt_u le_s le_u ge_s ge_u
            return int([a == b, a != b, a < b, ua < ub, a > b, ua > ub, a <= b, ua <= ub, a >= b, ua >= ub][k])
        if k == 0:
            return _s(a + b, bits)
        if k == 1:
            return _s(a - b, bits)
        if k == 2:
            return _s(a * b, bits)
        if k in (3, 4, 5, 6) and b == 0:
            raise PolicyFault("integer divide by zero")
        if k == 3:
            if a == -(1 << (bits - 1)) and b == -1:
                raise PolicyFault("integer overflow")
            q = abs(a) // abs(b)
            return _s(q if (a < 0) == (b < 0) else -q, bits)
        if k == 4:
            return _s(ua // ub, bits)
        if k == 5:
            rem = abs(a) % abs(b)
            return _s(-rem if a < 0 else rem, bits)
        if k == 6:
            return _s(ua % ub, bits)
        if k == 7:
            return _s(a & b, bits)
        if k == 8:
            return _s(a | b, bits)
        if k == 9:
            return _s(a ^ b, bits)
        sh = ub & (bits - 1)
        if k == 10:
            return _s(ua << sh, bits)
        if k == 11:
            return _s(a >> sh, bits)
        if k == 12:
            return _s(ua >> sh, bits)
        if k == 13:
            return _s((ua << sh) | (ua >> (bits - sh)), bits) if sh else a
        return _s((ua >> sh) | (ua << (bits - sh)), bits) if sh else a


def run_decoded(m: Module, data: bytes) -> Optional[bytes]:
    """Instantiate afresh and run alloc then decide on the input; None when the evaluation ends without an output."""
    vm = _Machine(m)
    limit = sys.getrecursionlimit()
    sys.setrecursionlimit(max(limit, MAX_DEPTH * 3 + 200))  # the profile's call depth, not Python's, decides
    try:
        ptr = vm.call(m.alloc, [_s(len(data), 32)])
        a = vm.addr(ptr, 0, len(data))
        vm.mem[a:a + len(data)] = data
        res = vm.call(m.decide, [ptr, _s(len(data), 32)]) & M64
        at, n = res >> 32, res & M32
        if at + n > len(vm.mem):
            return None
        return bytes(vm.mem[at:at + n])
    except PolicyFault:
        return None
    finally:
        sys.setrecursionlimit(limit)


def run_policy(module: bytes, data: bytes) -> Optional[bytes]:
    return run_decoded(decode(module), data)
