"""Command line: ``python3 -m runrec verify|verify-dir|register``.

Exit status for ``verify``: 0 integrity pass (and pin matches or no pin),
1 integrity fail, 2 usage or I/O error, 3 integrity pass but pin mismatch.

``verify-dir`` prints one JSON line per ``*.runrec`` file, sorted by name, and
exits 2 on a usage or I/O error, otherwise 1 if any integrity failed, else 3
if any pin mismatched, else 0.

``register`` checks a workspace's register (spec section 8.1) against the
Records named (files, or folders of ``*.runrec``), prints the report as JSON,
and exits as ``verify`` does for the register.
"""
from __future__ import annotations

import json
import os
import re
import sys
from typing import List, Optional

from .verify import VerifyResult, verify_bytes

USAGE = """usage:
  python3 -m runrec verify <file> [--pin sha256:<hex>] [--domain <domain>] [--json]
  python3 -m runrec verify-dir <dir> [--pin sha256:<hex>] [--domain <domain>]
  python3 -m runrec register <register.json> [<file.runrec> | <dir>]... [--previous <earlier.register.json>] [--pin sha256:<hex>] [--domain <domain>]
  python3 -m runrec journal <workspace.journal> [--register <register.json>] [--pin sha256:<hex>] [--domain <domain>]
  python3 -m runrec review <name.review.json> [--record <record.runrec>] [--pin sha256:<hex>] [--domain <domain>]
--domain looks up the workspace keys the domain publishes (_opsproof.<domain> TXT, by DNS over HTTPS);
the key must be among them, or provenance is mismatch.
"""

_PIN_RE = re.compile(r"sha256:[0-9a-fA-F]{64}")


class UsageError(Exception):
    pass


def _parse(argv: List[str], allow_json: bool):
    path: Optional[str] = None
    pin: Optional[str] = None
    as_json = False
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--pin" or a.startswith("--pin="):
            if a == "--pin":
                i += 1
                if i >= len(argv):
                    raise UsageError("--pin needs a value")
                val = argv[i]
            else:
                val = a[len("--pin="):]
            if not _PIN_RE.fullmatch(val):
                raise UsageError("--pin must be sha256:<64 hex characters>")
            pin = "sha256:" + val[7:].lower()
        elif a == "--json" and allow_json:
            as_json = True
        elif a.startswith("-") and a != "-":
            raise UsageError("unknown option %s" % a)
        elif path is None:
            path = a
        else:
            raise UsageError("unexpected argument %s" % a)
        i += 1
    if path is None:
        raise UsageError("missing path")
    return path, pin, as_json


def _exit_status(res: VerifyResult) -> int:
    rep = res.report
    if rep["integrity"] != "pass":
        return 1
    if rep["provenance"] == "mismatch":
        return 3
    return 0


def _human(res: VerifyResult) -> str:
    rep = res.report
    lines = [rep["summary"]]
    ws = rep.get("workspace")
    if ws:
        lines.append("workspace key: %s" % ws["key_id"])
        note = "" if rep["provenance"] == "pinned" else " (issuer-chosen names)"
        lines.append("workspace: %s %s%s" % (ws.get("workspace_id"), json.dumps(ws.get("display_name"), ensure_ascii=False), note))
    if "run_id" in rep:
        lines.append("run: %s (%s events)" % (rep["run_id"], rep["event_count"]))
    if rep["integrity"] == "fail":
        f = rep["failure"]
        lines.append("failure: step %d, %s: %s" % (f["step"], f["code"], f["message"]))
    else:
        lines.append("procedure signed by: " + ", ".join(
            "%s for %s" % (a["participant_id"], a["party_id"]) if "party_id" in a else a["participant_id"] for a in rep["agreed_by"]))
        lines.append("steps:")
        for s in rep["steps"]:
            lines.append("  %-24s %s" % (s["step_id"], s["state"]))
        if rep["open_matters"]:
            lines.append("open matters:")
            for m in rep["open_matters"]:
                lines.append("  %s  %s %s  %s" % (m["step_id"], m["kind"], m["ref"], m["state"]))
        else:
            lines.append("open matters: none")
        if rep["human_authorizations"]:
            lines.append("human authorizations:")
            for a in rep["human_authorizations"]:
                lines.append("  seq %d  %s  %s by %s" % (a["seq"], a["step_id"], a["result"], a["by"]))
        if rep["decisions"]:
            lines.append("decisions:")
            for d in rep["decisions"]:
                lines.append("  seq %d  %s  %s by %s%s" % (
                    d["seq"], d.get("step_id", "(run)"), d["type"], d["by"], "" if d["counted"] else "  (not counted)"))
    for f in rep.get("findings", []):
        if f["kind"] == "published":
            lines.append("published: %s publishes this workspace key" % f["domain"])
        elif f["kind"] == "revoked_later":
            lines.append("revoked later: key %s (%s), after this run" % (f["key_id"], f["reason"]))
    for w in rep["warnings"]:
        lines.append("warning: %s" % w)
    return "\n".join(lines)


def _write(text: str) -> None:
    out = sys.stdout
    try:
        out.write(text + "\n")
    except UnicodeEncodeError:
        out.buffer.write((text + "\n").encode("utf-8"))  # type: ignore[attr-defined]
    out.flush()


def _take_domain(argv: List[str]):
    """Remove --domain <d> from the arguments; return the rest and what the domain publishes, or None."""
    rest: List[str] = []
    domain = None
    i = 0
    while i < len(argv):
        if argv[i] == "--domain":
            if i + 1 >= len(argv) or argv[i + 1].startswith("-"):
                raise UsageError("--domain needs a domain")
            domain = argv[i + 1]
            i += 2
            continue
        rest.append(argv[i])
        i += 1
    if domain is None:
        return rest, None
    from .trust import lookup
    return rest, lookup(domain)


def cmd_verify(argv: List[str], published=None) -> int:
    path, pin, as_json = _parse(argv, allow_json=True)
    try:
        with open(path, "rb") as fh:
            data = fh.read()
    except OSError as exc:
        sys.stderr.write("runrec: cannot read %s: %s\n" % (path, exc.strerror or exc))
        return 2
    res = verify_bytes(data, pin, published)
    if as_json:
        _write(json.dumps(res.report, ensure_ascii=False))
    else:
        _write(_human(res))
    return _exit_status(res)


def cmd_verify_dir(argv: List[str], published=None) -> int:
    path, pin, _ = _parse(argv, allow_json=False)
    try:
        names = sorted(n for n in os.listdir(path) if n.endswith(".runrec"))
    except OSError as exc:
        sys.stderr.write("runrec: cannot list %s: %s\n" % (path, exc.strerror or exc))
        return 2
    worst = 0
    for name in names:
        full = os.path.join(path, name)
        try:
            with open(full, "rb") as fh:
                data = fh.read()
        except OSError as exc:
            sys.stderr.write("runrec: cannot read %s: %s\n" % (full, exc.strerror or exc))
            return 2
        res = verify_bytes(data, pin, published)
        _write(json.dumps({"file": name, "report": res.report}, ensure_ascii=False, separators=(",", ":")))
        status = _exit_status(res)
        if status == 1:
            worst = 1
        elif status == 3 and worst == 0:
            worst = 3
    return worst


def cmd_register(argv: List[str], published=None) -> int:
    from .register import verify_register

    paths: List[str] = []
    pin: Optional[str] = None
    previous: Optional[str] = None
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--pin":
            i += 1
            if i >= len(argv) or not _PIN_RE.fullmatch(argv[i]):
                raise UsageError("--pin must be sha256:<64 hex characters>")
            pin = "sha256:" + argv[i][7:].lower()
        elif a == "--previous":
            i += 1
            if i >= len(argv):
                raise UsageError("--previous needs a file")
            previous = argv[i]
        elif a.startswith("-"):
            raise UsageError("unknown option %s" % a)
        else:
            paths.append(a)
        i += 1
    if not paths:
        raise UsageError("missing register file")
    try:
        with open(paths[0], "rb") as fh:
            data = fh.read()
        prev = None
        if previous is not None:
            with open(previous, "rb") as fh:
                prev = fh.read()
        records = []
        for p in paths[1:]:
            names = sorted(os.path.join(p, n) for n in os.listdir(p) if n.endswith(".runrec")) if os.path.isdir(p) else [p]
            for full in names:
                with open(full, "rb") as fh:
                    records.append((os.path.basename(full), fh.read()))
    except OSError as exc:
        sys.stderr.write("runrec: cannot read %s: %s\n" % (exc.filename, exc.strerror or exc))
        return 2
    rep = verify_register(data, records, pin, prev, published)
    _write(json.dumps(rep, ensure_ascii=False))
    if rep["integrity"] != "pass":
        return 1
    return 3 if rep["provenance"] == "mismatch" else 0


def cmd_journal(argv: List[str], published=None, review: bool = False) -> int:
    from .journal import verify_journal
    from .review import verify_review

    path = None
    pin = None
    register = None
    other = "--record" if review else "--register"
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("--pin", other):
            i += 1
            if i >= len(argv):
                raise UsageError("%s needs a value" % a)
            if a == "--pin":
                if not _PIN_RE.fullmatch(argv[i]):
                    raise UsageError("--pin must be sha256:<64 hex characters>")
                pin = "sha256:" + argv[i][7:].lower()
            else:
                register = argv[i]
        elif a.startswith("-") or path is not None:
            raise UsageError("unexpected argument %s" % a)
        else:
            path = a
        i += 1
    if path is None:
        raise UsageError("missing %s file" % ("review" if review else "journal"))
    try:
        with open(path, "rb") as fh:
            data = fh.read()
        reg = None
        if register is not None:
            with open(register, "rb") as fh:
                reg = fh.read()
    except OSError as exc:
        sys.stderr.write("runrec: cannot read %s: %s\n" % (exc.filename, exc.strerror or exc))
        return 2
    rep = verify_review(data, pin, published, reg) if review else verify_journal(data, pin, published, reg)
    _write(json.dumps(rep, ensure_ascii=False))
    if rep["integrity"] != "pass":
        return 1
    return 3 if rep["provenance"] == "mismatch" else 0


def main(argv: Optional[List[str]] = None) -> int:
    if argv is None:
        argv = sys.argv[1:]
    if not argv or argv[0] in ("-h", "--help", "help"):
        sys.stdout.write(USAGE)
        return 0 if argv else 2
    cmd, rest = argv[0], argv[1:]
    try:
        if cmd not in ("verify", "verify-dir", "register", "journal", "review"):
            raise UsageError("unknown command %r" % cmd)
        rest, published = _take_domain(rest)
        if cmd == "verify":
            return cmd_verify(rest, published)
        if cmd == "verify-dir":
            return cmd_verify_dir(rest, published)
        if cmd == "register":
            return cmd_register(rest, published)
        if cmd == "journal":
            return cmd_journal(rest, published)
        if cmd == "review":
            return cmd_journal(rest, published, review=True)
        raise UsageError("unknown command %r" % cmd)
    except UsageError as exc:
        sys.stderr.write("runrec: %s\n%s" % (exc, USAGE))
        return 2
