"""The register (spec section 7.3) and its verification (section 8.1), written
from the specification text alone, like the rest of this verifier.

A register is one attestation in a file of its own: a workspace's signed list
of every Run it has started, by sequence number. ``verify_register`` checks
it (R1 to R3), checks each supplied Record against its entry (R4), checks
continuity with an earlier register when one is given (R5), and reports
which closed Runs were not supplied (R6).
"""
from __future__ import annotations

import hashlib
from typing import Any, Callable, Dict, List, Optional, Tuple

from . import jcs
from .schema import Failure, Schema, first_duplicate
from .trust import provenance_of
from .verify import Attestation, _strict_key, _verify_sig, read_attestation, verify_bytes
from .ziprofile import read_archive

REGISTER_FORMAT = "runrec-register/0.1"


class RegisterFailure(Exception):
    """The first failure: a step R1 to R5, a code and a message."""

    def __init__(self, step: str, code: str, message: str) -> None:
        super().__init__("step %s (%s): %s" % (step, code, message))
        self.step = step
        self.code = code
        self.message = message


def _check_register(pred: dict, name: str) -> None:
    """Appendix D Register (step R1 schema)."""
    s = Schema(1, "schema")
    entry = s.obj(
        {
            "sequence": s.integer(1),
            "run_id": s.ident,
            "status": s.enum("open", "closed"),
            "procedure": s.obj({"procedure_id": s.ident, "version": s.version, "digest": s.hash}),
            "head": s.hash,
        },
        {"outcome": s.enum("complete", "incomplete", "failed")},
    )
    s.check_obj(
        pred,
        name,
        {
            "format": s.const(REGISTER_FORMAT),
            "workspace": s.obj({"workspace_id": s.ident, "key_id": s.hash, "public_key": s.text_plus,
                                "display_name": s.text_plus}),
            "through": s.integer(0),
            "previous": s.nullable(s.hash),
            "issued_time": s.timestamp,
            "runs": s.array(entry),
        },
        {
            # draft 11, section 5
            "successor": s.obj({"key_id": s.hash, "public_key": s.text_plus}),
            "former_keys": s.array(s.obj({"key_id": s.hash, "public_key": s.text_plus, "through": s.integer(0)})),
            "revoked": s.array(s.obj({"key_id": s.hash, "as_of": s.integer(0), "reason": s.text_plus})),
            "published": s.obj({"log": s.text_plus, "entry": s.text_plus}),
            "journal": s.obj({"head": s.hash, "length": s.integer(0)}),
            # draft 11, section 7.3
            "procedures": s.array(s.obj({"procedure_id": s.ident, "version": s.version, "digest": s.hash,
                                         "status": s.enum("draft", "agreed", "active", "retired"), "since": s.timestamp})),
            "reviews": s.array(s.obj({"run_id": s.ident, "review": s.hash})),
        },
        ext=True,
    )


def _read_register(first: str, name: str, data: bytes,
                   on_key: Optional[Callable[[str, dict], None]] = None) -> Tuple[Attestation, dict, str]:
    """Steps R1 to R3 on one register file; ``on_key`` runs once the workspace key is
    established. The register under check reports from R1; a previous register (R5)
    reports every failure under R5."""
    def at(s: str) -> str:
        return s if first == "R1" else first

    try:
        att = read_attestation(name, data, 1, "register")
    except Failure as f:
        raise RegisterFailure(at("R1"), f.code, f.message) from None
    pred = att.predicate
    if pred.get("format") != REGISTER_FORMAT:
        raise RegisterFailure(at("R1"), "format", "%s: format is %r, only %r is supported" % (name, pred.get("format"), REGISTER_FORMAT))
    try:
        _check_register(pred, name)
    except Failure as f:
        raise RegisterFailure(at("R1"), "schema", f.message) from None
    # R2
    ws = pred["workspace"]
    pub, problem = _strict_key(ws["public_key"])
    if pub is None:
        raise RegisterFailure(at("R2"), "key", "%s: workspace.public_key: %s" % (name, problem))
    kid = "sha256:" + hashlib.sha256(pub).hexdigest()
    if ws["key_id"] != kid:
        raise RegisterFailure(at("R2"), "key", "%s: workspace.key_id is not the digest of workspace.public_key" % name)
    if on_key is not None:
        on_key(kid, pred)
    if att.keyid != kid:
        raise RegisterFailure(at("R2"), "keyid", "%s: keyid %s is not the workspace key_id" % (name, att.keyid))
    if not _verify_sig(pub, att):
        raise RegisterFailure(at("R2"), "signature", "%s: the signature does not verify with the workspace key" % name)
    own = hashlib.sha256(jcs.canonicalize(pred).encode("utf-8")).hexdigest()
    if att.subject_name != "runrec:register:" + ws["workspace_id"] or att.subject_hex != own:
        raise RegisterFailure(at("R2"), "subject", "%s: the subject is not runrec:register:%s with the predicate digest" % (name, ws["workspace_id"]))
    # R3
    runs = pred["runs"]
    if len(runs) != pred["through"] or any(e["sequence"] != i + 1 for i, e in enumerate(runs)):
        raise RegisterFailure(at("R3"), "sequence", "%s: runs are not exactly 1 to %d, in order, each once" % (name, pred["through"]))
    dup = first_duplicate(e["run_id"] for e in runs)
    if dup is not None:
        raise RegisterFailure(at("R3"), "duplicate", "%s: run_id %r appears twice" % (name, dup))
    for e in runs:
        if (e["status"] == "closed") != ("outcome" in e):
            raise RegisterFailure(at("R3"), "status", "%s: run %d is %s but %s an outcome"
                                  % (name, e["sequence"], e["status"], "has" if "outcome" in e else "has no"))
    # R3, draft 11: the workspace's keys

    def strict(k: dict) -> bool:
        p, _ = _strict_key(k["public_key"])
        return p is not None and "sha256:" + hashlib.sha256(p).hexdigest() == k["key_id"]

    keys = {kid}
    last = 0
    for f in pred.get("former_keys", []):
        if not strict(f):
            raise RegisterFailure(at("R3"), "former", "%s: former key %s is not a strict key with that key_id" % (name, f["key_id"]))
        if f["key_id"] in keys:
            raise RegisterFailure(at("R3"), "former", "%s: key %s appears twice among the workspace's keys" % (name, f["key_id"]))
        if f["through"] < last or f["through"] > pred["through"]:
            raise RegisterFailure(at("R3"), "former", "%s: former key %s retired at %d, out of order or beyond %d"
                                  % (name, f["key_id"], f["through"], pred["through"]))
        keys.add(f["key_id"])
        last = f["through"]
    succ = pred.get("successor")
    if succ is not None:
        if not strict(succ):
            raise RegisterFailure(at("R3"), "successor", "%s: the successor is not a strict key with that key_id" % name)
        if succ["key_id"] in keys:
            raise RegisterFailure(at("R3"), "successor", "%s: the successor is this register's key or a former key" % name)
    seen = set()
    for x in pred.get("revoked", []):
        if x["key_id"] in seen:
            raise RegisterFailure(at("R3"), "revoked", "%s: key %s is revoked twice" % (name, x["key_id"]))
        if x["as_of"] > pred["through"]:
            raise RegisterFailure(at("R3"), "revoked", "%s: key %s is revoked as of run %d, beyond %d"
                                  % (name, x["key_id"], x["as_of"], pred["through"]))
        if x["key_id"] == kid:
            raise RegisterFailure(at("R3"), "revoked", "%s: a register cannot revoke the key that signs it" % name)
        seen.add(x["key_id"])
    return att, pred, kid


def _same_procedure(a: dict, b: dict) -> bool:
    return all(a[k] == b[k] for k in ("procedure_id", "version", "digest"))


def _signers_of(record: bytes) -> List[str]:
    """The keys that signed a Record's manifest and events, once it has passed section 8."""
    out: List[str] = []
    for name, data in read_archive(record):
        if name == "manifest.dsse.json" or name.startswith("events/"):
            k = read_attestation(name, data, 1, "manifest" if name == "manifest.dsse.json" else "event").keyid
            if k not in out:
                out.append(k)
    return sorted(out)  # in key_id order, so every checker names the same key first


def _head_of(record: bytes) -> str:
    """events.head of a Record that has already passed section 8."""
    for name, data in read_archive(record):
        if name == "manifest.dsse.json":
            return read_attestation(name, data, 1, "manifest").predicate["events"]["head"]
    raise AssertionError("a verified Record has a manifest")


def _events_of(record: bytes) -> List[dict]:
    """The event predicates of a Record that has already passed section 8, in seq order."""
    evs = [read_attestation(n, d, 1, "event").predicate for n, d in read_archive(record) if n.startswith("events/")]
    return sorted(evs, key=lambda e: e["seq"])


def _summary(rep: dict) -> str:
    parts = ["register: %s" % rep["integrity"], "provenance: %s" % rep["provenance"]]
    f = rep.get("failure")
    if f:
        parts.append("step %s %s: %s" % (f["step"], f["code"], f["message"]))
    elif "through" in rep:
        n, m = rep["through"], len(rep["records"])
        parts.append("%d run%s through issue" % (n, "" if n == 1 else "s"))
        parts.append("%d record%s supplied" % (m, "" if m == 1 else "s"))
        parts.append("%d missing" % len(rep["missing"]))
        parts.append("%d open" % len(rep["open"]))
        if rep["later"]:
            parts.append("%d closed since" % len(rep["later"]))
    for x in rep.get("findings", []):
        if x["kind"] == "published":
            parts.insert(2, "published by %s" % x["domain"])
    if "workspace" in rep:
        parts.append("workspace %s" % rep["workspace"]["key_id"])
    return " · ".join(parts)


def verify_register(data: bytes, records: List[Tuple[str, bytes]], pin: Any = None,
                    previous: Optional[bytes] = None, published: Any = None) -> dict:
    """Section 8.1. ``records`` are (name, bytes) in the order supplied; ``published`` as for verify_bytes."""
    rep: Dict[str, Any] = {
        "integrity": "fail",
        "provenance": "mismatch" if pin is not None or published is not None else "unpinned",
        "records": [], "missing": [], "open": [], "later": [], "warnings": [],
    }
    found: List[dict] = []

    def on_key(kid: str, pred: dict) -> None:
        ws = pred["workspace"]
        rep["workspace"] = {"key_id": kid, "workspace_id": ws["workspace_id"], "display_name": ws["display_name"]}
        rep["provenance"], f = provenance_of(kid, pin, published, rep["warnings"], "register")
        if f:
            found.append(f)

    try:
        att, pred, key_id = _read_register("R1", "register", data, on_key)
        rep["through"] = int(pred["through"])
        rep["issued_time"] = pred["issued_time"]
        for k in ("successor", "former_keys", "revoked", "published", "journal"):
            if k in pred:
                rep[k] = pred[k]
        # A former key seals Runs numbered up to its through; the register's own key, any.
        sealers: Dict[str, float] = {key_id: float("inf")}
        for f in pred.get("former_keys", []):
            sealers[f["key_id"]] = f["through"]
        revoked = {x["key_id"]: x for x in pred.get("revoked", [])}
        # R4
        by_id = {e["run_id"]: e for e in pred["runs"]}
        seen: Dict[str, str] = {}
        supplied = set()
        later: List[int] = []
        passed: List[Tuple[dict, bytes]] = []
        for name, rec in records:
            # As much the workspace's as the register shows: pinned through a pinned register, else as given.
            r = (verify_bytes(rec, list(sealers)) if rep["provenance"] == "pinned" else verify_bytes(rec, pin, published)).report
            row: Dict[str, Any] = {"name": name, "report": r}
            if "sequence" in r:
                row["sequence"] = r["sequence"]
            rep["records"].append(row)
            if r["integrity"] != "pass":
                continue
            sealer = r["workspace"]["key_id"]
            if sealer not in sealers:
                raise RegisterFailure("R4", "workspace", "%s: issued by workspace key %s, which is not the register's %s "
                                      "or a former key" % (name, sealer, key_id))
            if r["sequence"] > sealers[sealer]:
                raise RegisterFailure("R4", "workspace", "%s: run %d is sealed by former key %s, retired at run %d"
                                      % (name, r["sequence"], sealer, sealers[sealer]))
            for k in _signers_of(rec):
                x = revoked.get(k)
                if x is None:
                    continue
                if r["sequence"] > x["as_of"]:
                    raise RegisterFailure("R4", "revoked", "%s: run %d carries key %s, revoked as of run %d (%s)"
                                          % (name, r["sequence"], k, x["as_of"], x["reason"]))
                r["findings"].append({"kind": "revoked_later", "key_id": k, "reason": x["reason"]})
            e = by_id.get(r["run_id"])
            if e is None or e["sequence"] != r["sequence"]:
                raise RegisterFailure("R4", "unlisted", "%s: run %s (number %d) is not in the register" % (name, r["run_id"], r["sequence"]))
            if not _same_procedure(e["procedure"], r["procedure"]):
                raise RegisterFailure("R4", "mismatch", "%s: the register lists run %d under a different Procedure" % (name, e["sequence"]))
            if e["status"] == "closed":
                if e["head"] != _head_of(rec) or e.get("outcome") != r["outcome"]:
                    raise RegisterFailure("R4", "mismatch", "%s: the register's entry for run %d ends differently from this Record"
                                          % (name, e["sequence"]))
            else:
                later.append(int(e["sequence"]))
            if r["run_id"] in seen:
                raise RegisterFailure("R4", "duplicate", "%s and %s are both run %s" % (name, seen[r["run_id"]], r["run_id"]))
            seen[r["run_id"]] = name
            supplied.add(int(e["sequence"]))
            passed.append((r, rec))
        # draft 11, sections 4.2 and 4.4: a parent's ChildSealed, and an output input, held to the supplied Records they name
        by_run = {r["run_id"]: (r, _head_of(rec)) for r, rec in passed}
        for r, rec in passed:
            evs = _events_of(rec)
            for ev in evs:
                if ev["kind"] != "ChildSealed" or ev["child_run_id"] not in by_run:
                    continue
                child, head = by_run[ev["child_run_id"]]
                if head != ev["record"] or child["outcome"] != ev["outcome"]:
                    raise RegisterFailure("R4", "child", "run %s records child %s differently from its Record" % (r["run_id"], ev["child_run_id"]))
            ins = evs[0].get("inputs", {})
            for k in sorted(ins):
                v = ins[k]
                if type(v) is not dict or "record" not in v or v["run_id"] not in by_run:
                    continue
                src, head = by_run[v["run_id"]]
                if head != v["record"] or not any(o["output_id"] == v["output_id"] and o["digest"] == v["digest"] for o in src["outputs"]):
                    raise RegisterFailure("R4", "input", "run %s binds %s to an output run %s's Record does not hold" % (r["run_id"], k, v["run_id"]))
        # R5
        if previous is not None:
            p_att, p_pred, p_kid = _read_register("R5", "previous register", previous)
            if p_kid not in sealers:
                raise RegisterFailure("R5", "workspace", "the previous register is from another workspace")
            if pred["previous"] != p_att.digest:
                raise RegisterFailure("R5", "previous", "this register does not name the previous one (%s) as the register it extends" % p_att.digest)
            for x in p_pred.get("revoked", []):
                if revoked.get(x["key_id"]) != x:
                    raise RegisterFailure("R5", "continuity", "the revocation of %s differs between the previous register and this one" % x["key_id"])
            now_former = pred.get("former_keys", [])
            for i, f in enumerate(p_pred.get("former_keys", [])):
                if i >= len(now_former) or now_former[i] != f:
                    raise RegisterFailure("R5", "continuity", "former key %s differs between the previous register and this one" % f["key_id"])
            for old in p_pred["runs"]:
                i = int(old["sequence"]) - 1
                now = pred["runs"][i] if i < len(pred["runs"]) else None
                unchanged = now is not None and now["run_id"] == old["run_id"] and _same_procedure(now["procedure"], old["procedure"])
                # an open entry's head is informative: the Run goes on between registers (section 7.3)
                same_end = unchanged and now["status"] == old["status"] and (old["status"] == "open" or (now["head"] == old["head"] and now.get("outcome") == old.get("outcome")))
                if not (unchanged and (same_end or (old["status"] == "open" and now["status"] == "closed"))):
                    raise RegisterFailure("R5", "continuity", "run %d differs between the previous register and this one" % old["sequence"])
            p_succ = (p_pred.get("successor") or {}).get("key_id")
            if p_kid == key_id:
                if p_succ is not None and p_succ != (pred.get("successor") or {}).get("key_id"):
                    raise RegisterFailure("R5", "succession", "the previous register committed to successor %s; this one, "
                                          "signed by the same key, does not" % p_succ)
            elif p_succ != key_id:
                raise RegisterFailure("R5", "succession", "this register is signed by %s, which the previous register did not "
                                      "name as its successor" % key_id)
        # R6
        for e in pred["runs"]:
            if e["status"] == "open":
                rep["open"].append(int(e["sequence"]))
            elif e["sequence"] not in supplied:
                rep["missing"].append(int(e["sequence"]))
        rep["later"] = sorted(later)
        rep["findings"] = found
        rep["integrity"] = "pass"
        del att
    except RegisterFailure as f:
        rep["failure"] = {"step": f.step, "code": f.code, "message": f.message}
        rep["missing"], rep["open"], rep["later"] = [], [], []
    rep["summary"] = _summary(rep)
    return rep
