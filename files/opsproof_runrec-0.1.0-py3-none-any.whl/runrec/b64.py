"""Strict base64 decoders.

Both decoders accept exactly one spelling per byte string: the alphabet is
checked, padding must be exactly what the encoder would write (standard) or
absent (url), and unused trailing bits must be zero. Anything else raises
``ValueError``. The spec says which alphabet and padding to use but not
that other spellings must be rejected; see SPEC-NOTES.md.
"""
from __future__ import annotations

import base64
import binascii
import re

__all__ = ["b64decode_std", "b64decode_url", "b64encode_url"]

_STD_RE = re.compile(r"^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$")
_URL_RE = re.compile(r"^[A-Za-z0-9_-]*$")


def b64decode_std(s: str) -> bytes:
    """Standard alphabet, with padding (RFC 4648 section 4), canonical only."""
    if not isinstance(s, str) or not _STD_RE.match(s):
        raise ValueError("not canonical standard base64 with padding")
    try:
        raw = base64.b64decode(s, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise ValueError("invalid base64: %s" % exc) from None
    if base64.b64encode(raw).decode("ascii") != s:
        raise ValueError("non-canonical base64 (unused bits set)")
    return raw


def b64decode_url(s: str) -> bytes:
    """URL-safe alphabet, no padding (RFC 4648 section 5), canonical only."""
    if not isinstance(s, str) or not _URL_RE.match(s) or len(s) % 4 == 1:
        raise ValueError("not canonical base64url without padding")
    padded = s + "=" * (-len(s) % 4)
    try:
        raw = base64.urlsafe_b64decode(padded)
    except (binascii.Error, ValueError) as exc:
        raise ValueError("invalid base64url: %s" % exc) from None
    if b64encode_url(raw) != s:
        raise ValueError("non-canonical base64url (unused bits set)")
    return raw


def b64encode_url(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")
