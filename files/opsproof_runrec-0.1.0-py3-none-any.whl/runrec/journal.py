"""The workspace journal (spec section 7.6, draft 11), written from the
specification text: a signed, hash-chained log of everything done to a
workspace outside any Run. ``verify_journal`` checks a journal file, steps J1
to J6."""
from __future__ import annotations

import hashlib
import re
from typing import Any, Dict, List, Optional

from . import jcs
from .register import verify_register
from .schema import Failure, Schema
from .trust import provenance_of
from .verify import _strict_key, _verify_sig, check_enrollment, read_attestation
from .ziprofile import ZipProfileError, read_archive

KINDS = ("WorkspaceCreated", "KeyRotated", "KeyRevoked", "ProcedureDrafted", "ProcedureAgreed", "ProcedureRetired",
         "ParticipantEnrolled", "ParticipantRetired", "RunStarted", "RecordSealed", "RegisterIssued", "EditionMade",
         "PackExported", "ReviewSigned", "SessionOpened")
LAYOUT = (re.compile(r"entries/[0-9]{6}-[A-Za-z]+\.dsse\.json"), re.compile(r"enrollments/[0-9a-f]{64}\.dsse\.json"),
          re.compile(r"evidence/sha256/[0-9a-f]{64}"))


class JournalFailure(Exception):
    def __init__(self, step: str, code: str, message: str) -> None:
        super().__init__(message)
        self.step, self.code, self.message = step, code, message


def _check(cond: Any, step: str, code: str, message: str) -> None:
    if not cond:
        raise JournalFailure(step, code, message)


def _sha(b: bytes) -> str:
    return "sha256:" + hashlib.sha256(b).hexdigest()


def check_entry(pred: dict, name: str) -> None:
    """Appendix D Journal."""
    s = Schema(1, "schema")

    def actor(v: Any, path: str) -> None:
        s.check_obj(v, path, {"participant_id": s.text_plus, "kind": s.enum("human", "agent", "runtime"), "key_id": s.hash},
                    {"on_behalf_of": s.ident})
        if (v["participant_id"] == "runtime") != (v["kind"] == "runtime"):
            raise s.fail(path, "participant_id is runtime exactly when kind is runtime")
        if v["kind"] != "runtime":
            s.ident(v["participant_id"], path + ".participant_id")

    s.check_obj(
        pred, name,
        {"workspace_id": s.ident, "seq": s.integer(1), "previous": s.nullable(s.hash), "kind": s.enum(*KINDS),
         "actor": actor, "declared_time": s.timestamp, "refs": s.array(s.hash)},
        {"key": s.obj({"key_id": s.hash, "public_key": s.text_plus}),
         "trace": s.obj({"digest": s.hash, "media_type": s.media_type, "size": s.integer(0)}),
         "note": s.string},
        ext=True,
    )
    if ("key" in pred) != (pred["kind"] in ("WorkspaceCreated", "KeyRotated")):
        raise s.fail(name + ".key", "is present exactly on WorkspaceCreated and KeyRotated")


def _entry_name(p: dict) -> str:
    return "entries/%06d-%s.dsse.json" % (p["seq"], p["kind"])


def verify_journal(data: bytes, pin: Any = None, published: Any = None, register: Optional[bytes] = None) -> dict:
    rep: Dict[str, Any] = {"integrity": "fail",
                           "provenance": "mismatch" if pin is not None or published is not None else "unpinned",
                           "warnings": []}
    try:
        # J1
        try:
            files = dict(read_archive(data))
        except ZipProfileError as exc:
            raise JournalFailure("J1", "archive", str(exc)) from None
        for name in files:
            _check(any(r.fullmatch(name) for r in LAYOUT), "J1", "layout", "entry outside the journal layout: %r" % name)
        entries = []
        enrollments: Dict[str, Any] = {}
        for name in sorted(files):
            try:
                if name.startswith("entries/"):
                    att = read_attestation(name, files[name], 1, "journal")
                    check_entry(att.predicate, name)
                    entries.append((att, att.predicate, name))
                elif name.startswith("enrollments/"):
                    att = read_attestation(name, files[name], 1, "enrollment")
                    _check(name == "enrollments/%s.dsse.json" % att.digest[7:], "J1", "layout",
                           "%s is not named by its attestation digest" % name)
                    check_enrollment(att.predicate, name)
                    enrollments[att.digest] = att
            except Failure as f:
                raise JournalFailure("J1", f.code, f.message) from None
        # J2
        entries.sort(key=lambda x: x[1]["seq"])
        _check(entries, "J2", "chain", "the journal has no entries")
        prev = None
        ws = entries[0][1]["workspace_id"]
        for i, (att, p, name) in enumerate(entries):
            _check(p["seq"] == i + 1, "J2", "chain",
                   "entry %d appears twice" % p["seq"] if p["seq"] <= i else "entries jump from %d to %d" % (i, p["seq"]))
            _check(p["previous"] == prev, "J2", "chain", "entry %d does not link to the entry before it" % p["seq"])
            _check(name == _entry_name(p), "J2", "layout", "%s must be named %s" % (name, _entry_name(p)))
            _check(p["workspace_id"] == ws, "J2", "splice", "entry %d belongs to workspace %s" % (p["seq"], p["workspace_id"]))
            own = hashlib.sha256(jcs.canonicalize(p).encode("utf-8")).hexdigest()
            _check(att.subject_name == "runrec:journal:%s#%d" % (ws, p["seq"]) and att.subject_hex == own, "J2", "subject",
                   "entry %d: the subject is not this entry with its predicate digest" % p["seq"])
            prev = att.digest
        rep["workspace_id"] = ws
        # J3
        first = entries[0][1]
        _check(first["kind"] == "WorkspaceCreated" and first["actor"]["kind"] == "runtime", "J3", "key",
               "entry 1 is not WorkspaceCreated by the runtime")
        chain: List[tuple] = []  # (key_id, public key bytes)
        key_at: List[tuple] = []
        for att, p, _ in entries:
            if p["kind"] == "WorkspaceCreated" and p["seq"] != 1:
                raise JournalFailure("J3", "key", "entry %d: WorkspaceCreated after the first entry" % p["seq"])
            signing = chain[-1] if chain else None
            if "key" in p:
                pub, _problem = _strict_key(p["key"]["public_key"])
                _check(pub is not None and _sha(pub) == p["key"]["key_id"], "J3", "key",
                       "entry %d: its key is not a strict key with that key_id" % p["seq"])
                _check(all(k[0] != p["key"]["key_id"] for k in chain), "J3", "key",
                       "entry %d: key %s was already used" % (p["seq"], p["key"]["key_id"]))
                _check(p["actor"]["kind"] == "runtime", "J3", "key", "entry %d: only the runtime names a workspace key" % p["seq"])
                chain.append((p["key"]["key_id"], pub))
            key_at.append(chain[-1] if p["kind"] == "WorkspaceCreated" else signing)
        rep["keys"] = [k[0] for k in chain]
        current = chain[-1][0]
        pins = None if pin is None else ([pin] if isinstance(pin, str) else list(pin))
        rep["provenance"], finding = provenance_of(current, current if pins and any(x in rep["keys"] for x in pins) else pins,
                                                   published, rep["warnings"], "journal")
        # J4
        enrolled: Dict[str, dict] = {}
        gone = set()
        revoked = set()
        for i, (att, p, _) in enumerate(entries):
            ws_key = key_at[i]
            a = p["actor"]
            if a["kind"] == "runtime":
                _check(att.keyid == ws_key[0] and a["key_id"] == ws_key[0], "J4", "keyid",
                       "entry %d: the runtime signs with workspace key %s" % (p["seq"], ws_key[0]))
                _check(_verify_sig(ws_key[1], att), "J4", "signature", "entry %d: the signature does not verify" % p["seq"])
            else:
                en = enrolled.get(a["participant_id"])
                _check(en is not None and en["kind"] == a["kind"] and en["key_id"] == a["key_id"]
                       and a["participant_id"] not in gone and en["key_id"] not in revoked, "J4", "enrollment",
                       "entry %d: %s is not an enrolled, active %s with this key" % (p["seq"], a["participant_id"], a["kind"]))
                _check(att.keyid == a["key_id"], "J4", "keyid", "entry %d: signed with %s, not the actor's key" % (p["seq"], att.keyid))
                pub, _problem = _strict_key(en["public_key"])
                _check(pub is not None and _verify_sig(pub, att), "J4", "signature", "entry %d: the signature does not verify" % p["seq"])
            if p["kind"] == "ParticipantEnrolled":
                ref = enrollments.get(p["refs"][0] if p["refs"] else "")
                _check(ref is not None, "J4", "missing", "entry %d: the enrollment it names is not in the file" % p["seq"])
                known = chain[: chain.index(ws_key) + 1]
                signer = next((k for k in known if k[0] == ref.keyid), None)
                _check(signer is not None and _verify_sig(signer[1], ref), "J4", "signature",
                       "entry %d: the enrollment is not signed by a workspace key of this journal" % p["seq"])
                _check(ref.predicate["workspace_id"] == ws, "J4", "splice",
                       "entry %d: the enrollment is for workspace %s" % (p["seq"], ref.predicate["workspace_id"]))
                enrolled[ref.predicate["participant_id"]] = ref.predicate
                gone.discard(ref.predicate["participant_id"])
            if p["kind"] == "ParticipantRetired":
                ref = enrollments.get(p["refs"][0] if p["refs"] else "")
                if ref is not None:
                    gone.add(ref.predicate["participant_id"])
            if p["kind"] == "KeyRevoked":
                revoked.update(p["refs"])
        # J5
        cited = set()
        for _att, p, _ in entries:
            t = p.get("trace")
            if t is None:
                continue
            blob = files.get("evidence/sha256/" + t["digest"][7:])
            _check(blob is not None, "J5", "missing", "entry %d: its trace %s is not in the file" % (p["seq"], t["digest"]))
            _check(_sha(blob) == t["digest"], "J5", "digest", "trace %s does not hash to its name" % t["digest"])
            _check(len(blob) == t["size"], "J5", "size", "trace %s is %d bytes, cited as %d" % (t["digest"], len(blob), t["size"]))
            cited.add(t["digest"])
        for name in files:
            if name.startswith("evidence/"):
                _check("sha256:" + name[16:] in cited, "J5", "uncited", "%s is not cited by any entry" % name)
        # J6
        if register is not None:
            reg = verify_register(register, [], pin=rep["keys"])
            _check(reg["integrity"] == "pass", "J6", "register", "the register failed its check: %s" % reg["summary"])
            _check(reg.get("workspace", {}).get("key_id") in rep["keys"], "J6", "workspace",
                   "the register is not signed by one of this journal's workspace keys")
            j = reg.get("journal")
            if j is not None:
                j = {"head": j["head"], "length": int(j["length"])}
                _check(len(entries) >= j["length"] and (j["length"] == 0 or entries[j["length"] - 1][0].digest == j["head"]),
                       "J6", "head", "the register's journal (length %d, head %s) is not this journal's" % (j["length"], j["head"]))
        rep["length"] = len(entries)
        rep["head"] = entries[-1][0].digest
        rep["entries"] = []
        for _att, p, _ in entries:
            row = {"seq": p["seq"], "kind": p["kind"], "actor": p["actor"]["participant_id"], "actor_kind": p["actor"]["kind"]}
            if "on_behalf_of" in p["actor"]:
                row["on_behalf_of"] = p["actor"]["on_behalf_of"]
            row.update(declared_time=p["declared_time"], refs=p["refs"])
            if "note" in p:
                row["note"] = p["note"]
            rep["entries"].append(row)
        rep["findings"] = [finding] if finding else []
        rep["integrity"] = "pass"
    except JournalFailure as f:
        rep["failure"] = {"step": f.step, "code": f.code, "message": f.message}
    parts = ["journal: %s" % rep["integrity"], "provenance: %s" % rep["provenance"]]
    if "failure" in rep:
        parts.append("step %s %s: %s" % (rep["failure"]["step"], rep["failure"]["code"], rep["failure"]["message"]))
    else:
        parts.append("%d entr%s" % (rep["length"], "y" if rep["length"] == 1 else "ies"))
    rep["summary"] = " · ".join(parts)
    return rep
