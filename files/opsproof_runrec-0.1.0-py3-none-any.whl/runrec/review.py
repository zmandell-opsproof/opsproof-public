"""Reviews (spec section 7.5, draft 11) and their verification (section 8.2), written from the specification text.

A review is a person's signed judgment on a sealed Record, kept beside it. A review file carries what checking it
needs: the workspace's public key, the reviewer's enrollment signed by that key, and the review signed by the
reviewer. ``verify_review`` checks it (V1 to V3) and, when the Record is supplied, holds it to that Record (V4).
"""
from __future__ import annotations

import hashlib
from typing import Any, List, Optional

from . import jcs
from .schema import Failure, Schema
from .trust import provenance_of
from .verify import _strict_key, _verify_sig, check_enrollment, read_attestation, verify_bytes
from .ziprofile import read_archive

VERDICTS = ("concur", "do_not_concur", "more_examination")


class ReviewFailure(Exception):
    def __init__(self, step: str, code: str, message: str) -> None:
        super().__init__("step %s (%s): %s" % (step, code, message))
        self.step = step
        self.code = code
        self.message = message


def _check_review(pred: dict, name: str) -> None:
    s = Schema(1, "schema")
    s.check_obj(pred, name, {
        "workspace_id": s.ident, "run_id": s.ident, "head": s.hash, "verdict": s.enum(*VERDICTS),
        "basis": s.array(s.hash), "previous": s.nullable(s.hash), "reviewed_time": s.timestamp,
    }, {"terms": s.hash, "note": s.string}, ext=True)


def verify_review(data: bytes, pin: Any = None, published: Any = None, record: Optional[bytes] = None) -> dict:
    """Check a review file; returns the section 8.2 report as a dict."""
    rep: dict = {"integrity": "fail", "provenance": "mismatch" if pin is not None or published is not None else "unpinned", "warnings": []}
    try:
        # V1. Open
        try:
            f = jcs.parse(data)
        except jcs.JSONError as exc:
            raise ReviewFailure("V1", "json", str(exc)) from None
        if jcs.canonical_bytes(f) != data:
            raise ReviewFailure("V1", "canonical", "the review file is not its RFC 8785 (JCS) serialization")
        if type(f) is not dict or sorted(f) != ["enrollment", "review", "workspace"] or not all(type(f[k]) is dict for k in f):
            raise ReviewFailure("V1", "layout", "a review file is an object of exactly workspace, enrollment and review")
        try:
            s = Schema(1, "schema")
            s.check_obj(f["workspace"], "workspace", {"workspace_id": s.ident, "key_id": s.hash, "public_key": s.string})
            e_att = read_attestation("enrollment", jcs.canonical_bytes(f["enrollment"]), 1, "enrollment")
            r_att = read_attestation("review", jcs.canonical_bytes(f["review"]), 1, "review")
            check_enrollment(e_att.predicate, "enrollment")
            _check_review(r_att.predicate, "review")
        except Failure as exc:
            raise ReviewFailure("V1", exc.code, exc.message) from None
        w = f["workspace"]
        e = e_att.predicate
        rv = r_att.predicate
        # V2. Reviewer
        ws_pub, why = _strict_key(w["public_key"])
        if ws_pub is None or "sha256:" + hashlib.sha256(ws_pub).hexdigest() != w["key_id"]:
            raise ReviewFailure("V2", "key", "workspace public_key is not a strict key with this key_id")
        rep["workspace"] = {"key_id": w["key_id"], "workspace_id": w["workspace_id"]}
        prov, finding = provenance_of(w["key_id"], pin, published, rep["warnings"], "review")
        rep["provenance"] = prov
        if e_att.keyid != w["key_id"]:
            raise ReviewFailure("V2", "keyid", "the enrollment keyid is not the workspace key_id")
        if not _verify_sig(ws_pub, e_att):
            raise ReviewFailure("V2", "signature", "the enrollment is not signed by the workspace key")
        if e["workspace_id"] != w["workspace_id"]:
            raise ReviewFailure("V2", "workspace", "the enrollment is for another workspace")
        pub, _ = _strict_key(e["public_key"])
        if pub is None or "sha256:" + hashlib.sha256(pub).hexdigest() != e["key_id"] or e["key_id"] == w["key_id"]:
            raise ReviewFailure("V2", "key", "the reviewer key is not a strict key with this key_id, or is the workspace key")
        if e_att.subject_name != "runrec:participant:%s" % e["participant_id"] or e_att.subject_hex != e["key_id"][7:]:
            raise ReviewFailure("V2", "subject", "the enrollment subject is not this Participant and key")
        if e["status"] != "active" or e["kind"] != "human" or "review" not in e["grants"]:
            raise ReviewFailure("V2", "signer", "%s is not an active Human holding review" % e["participant_id"])
        rep["reviewer"] = {"participant_id": e["participant_id"], "display_name": e["display_name"]}
        if "party" in e:
            rep["reviewer"]["party"] = e["party"]
        # V3. Review
        if r_att.keyid != e["key_id"]:
            raise ReviewFailure("V3", "keyid", "the review keyid is not the reviewer's key_id")
        if not _verify_sig(pub, r_att):
            raise ReviewFailure("V3", "signature", "the review signature does not verify")
        if r_att.subject_name != "runrec:review:%s" % rv["run_id"] or r_att.subject_hex != hashlib.sha256(jcs.canonical_bytes(rv)).hexdigest():
            raise ReviewFailure("V3", "subject", "the review subject is not runrec:review:<run_id> with its predicate digest")
        if rv["workspace_id"] != w["workspace_id"]:
            raise ReviewFailure("V3", "workspace", "the review is about a Run of another workspace")
        rep["digest"] = r_att.digest
        rep["review"] = rv
        # V4. Record: issued by the review's workspace key, or by a key the recipient pinned
        if record is not None:
            pins: List[str] = [w["key_id"]] + ([] if pin is None else ([pin] if isinstance(pin, str) else list(pin)))
            res = verify_bytes(record, pin=pins).report
            rep["record"] = {"integrity": res["integrity"], "summary": res["summary"]}
            if res["integrity"] != "pass":
                raise ReviewFailure("V4", "record", "the reviewed Record does not verify: %s" % res["summary"])
            head = read_attestation("manifest.dsse.json", dict(read_archive(record))["manifest.dsse.json"], 1, "manifest").predicate["events"]["head"]
            if res["run_id"] != rv["run_id"] or head != rv["head"]:
                raise ReviewFailure("V4", "record", "the review is about another Record: its run_id or head differs")
            if res["workspace"]["workspace_id"] != w["workspace_id"] or res["provenance"] != "pinned":
                raise ReviewFailure("V4", "workspace", "the Record was not issued by the review's workspace key, nor by a key the recipient pinned")
        rep["findings"] = [finding] if finding else []
        rep["integrity"] = "pass"
    except ReviewFailure as f:
        rep["failure"] = {"step": f.step, "code": f.code, "message": f.message}
        rep.pop("review", None)
    parts = ["review: %s" % rep["integrity"], "provenance: %s" % rep["provenance"]]
    if "review" in rep:
        parts.append("%s on %s by %s" % (rep["review"]["verdict"].replace("_", " "), rep["review"]["run_id"], rep["reviewer"]["participant_id"]))
    if "failure" in rep:
        parts.append("%s %s: %s" % (rep["failure"]["step"], rep["failure"]["code"], rep["failure"]["message"]))
    rep["summary"] = " · ".join(parts)
    return rep
