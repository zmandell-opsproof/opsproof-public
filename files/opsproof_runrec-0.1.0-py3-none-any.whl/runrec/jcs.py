"""Strict JSON parsing (spec section 3) and RFC 8785 canonicalization (JCS).

Parsed values use these Python types:

* object -> dict (insertion order preserved, duplicate names rejected)
* array  -> list
* string -> str (never contains a lone surrogate)
* number -> float (IEEE 754 binary64, always; never int)
* true / false -> True / False
* null -> None

Numbers are always floats so that ``type(v) is float`` distinguishes a
number from a boolean, and so that values round-trip exactly the way an
ECMAScript implementation would see them.
"""
from __future__ import annotations

import math
import re
from typing import Any, List, Tuple

__all__ = [
    "JSONError",
    "parse",
    "canonicalize",
    "canonical_bytes",
    "es_number",
    "MAX_DEPTH",
]

# Section 3 (draft 5): arrays and objects nest at most 64 levels, the
# outermost value being level 1. Deeper text is not valid JSON (code json).
MAX_DEPTH = 64


class JSONError(ValueError):
    """Raised for any input that is not strict JSON as section 3 defines it."""

    def __init__(self, message: str, limit: bool = False) -> None:
        super().__init__(message)
        self.limit = limit


_WS = " \t\n\r"
_NUMBER_RE = re.compile(r"-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?")
# A run of string characters that need no special handling.
_PLAIN_RE = re.compile(r'[^"\\\x00-\x1f]+')
_HEX4_RE = re.compile(r"[0-9a-fA-F]{4}")
_ESCAPES = {
    '"': '"',
    "\\": "\\",
    "/": "/",
    "b": "\b",
    "f": "\f",
    "n": "\n",
    "r": "\r",
    "t": "\t",
}


def parse(data: bytes) -> Any:
    """Parse UTF-8 JSON bytes strictly.

    Rejects: a byte-order mark, invalid UTF-8, any RFC 8259 syntax error,
    duplicate member names, lone surrogates (escaped or otherwise), numbers
    that overflow binary64, and arrays/objects nested deeper than MAX_DEPTH
    levels (the outermost container is level 1).
    """
    if not isinstance(data, (bytes, bytearray)):
        raise TypeError("parse() takes bytes")
    if data[:3] == b"\xef\xbb\xbf":
        raise JSONError("byte-order mark is forbidden")
    try:
        text = bytes(data).decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        raise JSONError("invalid UTF-8: %s" % exc) from None
    parser = _Parser(text)
    parser.skip_ws()
    value = parser.value(0)
    parser.skip_ws()
    if parser.pos != len(text):
        raise JSONError("trailing data at offset %d" % parser.pos)
    return value


class _Parser:
    __slots__ = ("text", "pos")

    def __init__(self, text: str) -> None:
        self.text = text
        self.pos = 0

    def skip_ws(self) -> None:
        text = self.text
        pos = self.pos
        n = len(text)
        while pos < n and text[pos] in _WS:
            pos += 1
        self.pos = pos

    def error(self, msg: str) -> JSONError:
        return JSONError("%s at offset %d" % (msg, self.pos))

    def value(self, depth: int) -> Any:
        text = self.text
        if self.pos >= len(text):
            raise self.error("unexpected end of input")
        c = text[self.pos]
        if c == "{":
            if depth >= MAX_DEPTH:
                raise JSONError("arrays and objects nest deeper than %d levels" % MAX_DEPTH)
            return self.obj(depth + 1)
        if c == "[":
            if depth >= MAX_DEPTH:
                raise JSONError("arrays and objects nest deeper than %d levels" % MAX_DEPTH)
            return self.arr(depth + 1)
        if c == '"':
            return self.string()
        if c == "t":
            return self.literal("true", True)
        if c == "f":
            return self.literal("false", False)
        if c == "n":
            return self.literal("null", None)
        if c == "-" or "0" <= c <= "9":
            return self.number()
        raise self.error("unexpected character %r" % c)

    def literal(self, word: str, val: Any) -> Any:
        if self.text.startswith(word, self.pos):
            self.pos += len(word)
            return val
        raise self.error("invalid literal")

    def number(self) -> float:
        m = _NUMBER_RE.match(self.text, self.pos)
        if not m:
            raise self.error("invalid number")
        tok = m.group(0)
        self.pos = m.end()
        val = float(tok)
        if math.isinf(val):
            raise JSONError("number %s overflows binary64" % tok)
        return val

    def string(self) -> str:
        text = self.text
        n = len(text)
        pos = self.pos + 1  # skip opening quote
        parts: List[str] = []
        while True:
            m = _PLAIN_RE.match(text, pos)
            if m:
                parts.append(m.group(0))
                pos = m.end()
            if pos >= n:
                self.pos = pos
                raise self.error("unterminated string")
            c = text[pos]
            if c == '"':
                pos += 1
                break
            if c == "\\":
                if pos + 1 >= n:
                    self.pos = pos
                    raise self.error("unterminated escape")
                e = text[pos + 1]
                if e in _ESCAPES:
                    parts.append(_ESCAPES[e])
                    pos += 2
                    continue
                if e == "u":
                    cp, pos = self._unicode_escape(pos)
                    parts.append(cp)
                    continue
                self.pos = pos
                raise self.error("invalid escape \\%s" % e)
            # control character
            self.pos = pos
            raise self.error("unescaped control character U+%04X in string" % ord(c))
        self.pos = pos
        s = "".join(parts)
        # Python's strict UTF-8 decoder never yields surrogates, and escapes
        # are paired above, so s is well formed here.
        return s

    def _unicode_escape(self, pos: int) -> Tuple[str, int]:
        text = self.text
        m = _HEX4_RE.match(text, pos + 2)
        if not m:
            self.pos = pos
            raise self.error("invalid \\u escape")
        cu = int(m.group(0), 16)
        pos += 6
        if 0xD800 <= cu <= 0xDBFF:
            if text.startswith("\\u", pos):
                m2 = _HEX4_RE.match(text, pos + 2)
                if m2:
                    lo = int(m2.group(0), 16)
                    if 0xDC00 <= lo <= 0xDFFF:
                        cp = 0x10000 + ((cu - 0xD800) << 10) + (lo - 0xDC00)
                        return chr(cp), pos + 6
            self.pos = pos
            raise self.error("lone high surrogate \\u%04x" % cu)
        if 0xDC00 <= cu <= 0xDFFF:
            self.pos = pos
            raise self.error("lone low surrogate \\u%04x" % cu)
        return chr(cu), pos

    def obj(self, depth: int) -> dict:
        text = self.text
        self.pos += 1
        out: dict = {}
        self.skip_ws()
        if self.pos < len(text) and text[self.pos] == "}":
            self.pos += 1
            return out
        while True:
            self.skip_ws()
            if self.pos >= len(text) or text[self.pos] != '"':
                raise self.error("expected member name")
            key = self.string()
            if key in out:
                raise self.error("duplicate member name %r" % key)
            self.skip_ws()
            if self.pos >= len(text) or text[self.pos] != ":":
                raise self.error("expected ':'")
            self.pos += 1
            self.skip_ws()
            out[key] = self.value(depth)
            self.skip_ws()
            if self.pos >= len(text):
                raise self.error("unterminated object")
            c = text[self.pos]
            if c == ",":
                self.pos += 1
                continue
            if c == "}":
                self.pos += 1
                return out
            raise self.error("expected ',' or '}'")

    def arr(self, depth: int) -> list:
        text = self.text
        self.pos += 1
        out: list = []
        self.skip_ws()
        if self.pos < len(text) and text[self.pos] == "]":
            self.pos += 1
            return out
        while True:
            self.skip_ws()
            out.append(self.value(depth))
            self.skip_ws()
            if self.pos >= len(text):
                raise self.error("unterminated array")
            c = text[self.pos]
            if c == ",":
                self.pos += 1
                continue
            if c == "]":
                self.pos += 1
                return out
            raise self.error("expected ',' or ']'")


# ---------------------------------------------------------------------------
# RFC 8785 serialization
# ---------------------------------------------------------------------------

_SURROGATE_RE = re.compile("[\ud800-\udfff]")
_NEEDS_ESCAPE_RE = re.compile('["\\\\\x00-\x1f]')
_SHORT = {
    '"': '\\"',
    "\\": "\\\\",
    "\b": "\\b",
    "\f": "\\f",
    "\n": "\\n",
    "\r": "\\r",
    "\t": "\\t",
}


def _escape_char(m: "re.Match[str]") -> str:
    c = m.group(0)
    s = _SHORT.get(c)
    if s is not None:
        return s
    return "\\u%04x" % ord(c)


def es_string(s: str) -> str:
    """ECMAScript JSON.stringify string serialization; lone surrogates rejected."""
    if _SURROGATE_RE.search(s):
        raise JSONError("lone surrogate in string cannot be canonicalized")
    return '"' + _NEEDS_ESCAPE_RE.sub(_escape_char, s) + '"'


def es_number(x: float) -> str:
    """ECMAScript Number::toString for a finite binary64 value (RFC 8785 3.2.2.3)."""
    if isinstance(x, bool) or not isinstance(x, (int, float)):
        raise JSONError("not a number")
    x = float(x)
    if math.isnan(x) or math.isinf(x):
        raise JSONError("NaN and Infinity cannot be canonicalized")
    if x == 0.0:
        return "0"  # covers -0 as well
    if x < 0:
        return "-" + es_number(-x)
    # repr() gives the shortest digit string that round-trips, choosing the
    # candidate closest to the exact value, which is what ECMAScript requires.
    r = repr(x)
    if "e" in r:
        mant, exp_s = r.split("e")
        exp = int(exp_s)
    else:
        mant, exp = r, 0
    if "." in mant:
        ip, fp = mant.split(".")
    else:
        ip, fp = mant, ""
    digits = (ip + fp).lstrip("0")
    stripped = digits.rstrip("0")
    trailing = len(digits) - len(stripped)
    s = stripped
    k = len(s)
    # value = int(s) * 10 ** (exp - len(fp) + trailing) = s * 10 ** (n - k)
    n = k + exp - len(fp) + trailing
    if k <= n <= 21:
        return s + "0" * (n - k)
    if 0 < n <= 21:
        return s[:n] + "." + s[n:]
    if -6 < n <= 0:
        return "0." + "0" * (-n) + s
    e = n - 1
    sign = "+" if e >= 0 else "-"
    if k == 1:
        return s + "e" + sign + str(abs(e))
    return s[0] + "." + s[1:] + "e" + sign + str(abs(e))


def _utf16_key(s: str) -> bytes:
    # Big-endian UTF-16 bytes compare in the same order as UTF-16 code units.
    # surrogatepass only keeps sorting from raising; es_string rejects them.
    return s.encode("utf-16-be", errors="surrogatepass")


def canonicalize(value: Any) -> str:
    """Return the RFC 8785 serialization of a parsed JSON value as text."""
    out: List[str] = []
    _canon(value, out, 0)
    return "".join(out)


def canonical_bytes(value: Any) -> bytes:
    return canonicalize(value).encode("utf-8")


def _canon(v: Any, out: List[str], depth: int) -> None:
    if depth > MAX_DEPTH + 1:
        raise JSONError("nesting deeper than %d" % MAX_DEPTH, limit=True)
    if v is None:
        out.append("null")
    elif v is True:
        out.append("true")
    elif v is False:
        out.append("false")
    elif isinstance(v, str):
        out.append(es_string(v))
    elif isinstance(v, (float, int)):
        out.append(es_number(v))
    elif isinstance(v, list):
        out.append("[")
        first = True
        for item in v:
            if not first:
                out.append(",")
            first = False
            _canon(item, out, depth + 1)
        out.append("]")
    elif isinstance(v, dict):
        out.append("{")
        first = True
        for key in sorted(v.keys(), key=_utf16_key):
            if not isinstance(key, str):
                raise JSONError("member names must be strings")
            if not first:
                out.append(",")
            first = False
            out.append(es_string(key))
            out.append(":")
            _canon(v[key], out, depth + 1)
        out.append("}")
    else:
        raise JSONError("cannot canonicalize %s" % type(v).__name__)
