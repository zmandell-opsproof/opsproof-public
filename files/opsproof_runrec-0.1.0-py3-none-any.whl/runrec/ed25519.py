"""Pure-Python Ed25519 verification (RFC 8032) with the strict rules of spec section 3.

The spec names "libsodium's strict rules" without spelling out the
verification equation. This module follows libsodium's
``crypto_sign_verify_detached`` exactly:

* the public key A must be a canonical encoding (y < p), decode to a curve
  point, and not have small order;
* S must be below the group order L;
* R must not have small order; it is not decoded beyond that, but because
  the check compares encodings, a non-canonical or undecodable R can never
  verify;
* the equation is the cofactorless one, checked by encoding:
  ``encode([S]B - [k]A) == R``, with ``k = SHA-512(R || A || M) mod L``.

Signing is included only so tests can build fixtures; the verifier never signs.
"""
from __future__ import annotations

import hashlib
from typing import Dict, List, Optional, Tuple

__all__ = [
    "verify",
    "check_public_key",
    "public_key_problem",
    "sign",
    "public_from_seed",
    "L",
    "P",
]

P = 2 ** 255 - 19
L = 2 ** 252 + 27742317777372353535851937790883648493
_D = (-121665 * pow(121666, P - 2, P)) % P
_D2 = (2 * _D) % P
_SQRT_M1 = pow(2, (P - 1) // 4, P)

Point = Tuple[int, int, int, int]  # extended coordinates (X, Y, Z, T)
_IDENTITY: Point = (0, 1, 1, 0)


def _add(p1: Point, p2: Point) -> Point:
    x1, y1, z1, t1 = p1
    x2, y2, z2, t2 = p2
    a = (y1 - x1) * (y2 - x2) % P
    b = (y1 + x1) * (y2 + x2) % P
    c = t1 * _D2 * t2 % P
    d = 2 * z1 * z2 % P
    e = b - a
    f = d - c
    g = d + c
    h = b + a
    return (e * f % P, g * h % P, f * g % P, e * h % P)


def _double(p1: Point) -> Point:
    x1, y1, z1, _ = p1
    a = x1 * x1 % P
    b = y1 * y1 % P
    c = 2 * z1 * z1 % P
    h = a + b
    e = h - (x1 + y1) * (x1 + y1)
    g = a - b
    f = c + g
    return (e * f % P, g * h % P, f * g % P, e * h % P)


def _neg(p1: Point) -> Point:
    x, y, z, t = p1
    return ((-x) % P, y, z, (-t) % P)


def _is_identity(p1: Point) -> bool:
    x, y, z, _ = p1
    return x % P == 0 and (y - z) % P == 0


def _encode(p1: Point) -> bytes:
    x, y, z, _ = p1
    zi = pow(z, P - 2, P)
    x = x * zi % P
    y = y * zi % P
    return (y | ((x & 1) << 255)).to_bytes(32, "little")


def _decode(s: bytes) -> Optional[Point]:
    """RFC 8032 5.1.3 decoding. Returns None for non-canonical or off-curve input."""
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    if y >= P:
        return None  # non-canonical y
    yy = y * y % P
    u = (yy - 1) % P
    v = (_D * yy + 1) % P
    v3 = v * v % P * v % P
    v7 = v3 * v3 % P * v % P
    x = u * v3 % P * pow(u * v7 % P, (P - 5) // 8, P) % P
    vxx = v * x % P * x % P
    if vxx == u:
        pass
    elif vxx == (-u) % P:
        x = x * _SQRT_M1 % P
    else:
        return None  # not on the curve
    if x == 0 and sign == 1:
        return None  # RFC 8032: x = 0 with sign bit set fails
    if (x & 1) != sign:
        x = P - x
    return (x, y, 1, x * y % P)


def _has_small_order(pt: Point) -> bool:
    return _is_identity(_double(_double(_double(pt))))


# Fixed-base table: _BASE_TABLE[i][j] = j * 16**i * B
_BY = 4 * pow(5, P - 2, P) % P
_B = _decode(_BY.to_bytes(32, "little"))
assert _B is not None


def _build_table(pt: Point) -> List[List[Point]]:
    """table[i][j] = j * 16**i * pt, for 64 nibbles."""
    table: List[List[Point]] = []
    base = pt
    for _ in range(64):
        row = [_IDENTITY, base]
        for _j in range(2, 16):
            row.append(_add(row[-1], base))
        table.append(row)
        for _k in range(4):
            base = _double(base)
    return table


_BASE_TABLE = _build_table(_B)


def _table_mult(table: List[List[Point]], k: int, acc: Point = _IDENTITY) -> Point:
    for i in range(64):
        nib = (k >> (4 * i)) & 15
        if nib:
            acc = _add(acc, table[i][nib])
    return acc


def _base_mult(k: int) -> Point:
    return _table_mult(_BASE_TABLE, k)


# Records sign many events with few keys, so a key seen more than once gets
# a precomputed table of its negation (bounded cache; about 0.2 MB per key).
_NEG_TABLES: Dict[bytes, List[List[Point]]] = {}
_KEY_USES: Dict[bytes, int] = {}
_MAX_TABLES = 64


def _var_mult(k: int, pt: Point) -> Point:
    table = [_IDENTITY, pt]
    for _ in range(2, 16):
        table.append(_add(table[-1], pt))
    acc = _IDENTITY
    for i in range(63, -1, -1):
        acc = _double(_double(_double(_double(acc))))
        nib = (k >> (4 * i)) & 15
        if nib:
            acc = _add(acc, table[nib])
    return acc


_KEY_CACHE: Dict[bytes, Optional[Point]] = {}


def public_key_problem(pub: bytes) -> Optional[str]:
    """Return why a public key is not strict, or None if it is acceptable."""
    if len(pub) != 32:
        return "public key is not 32 bytes"
    y = int.from_bytes(pub, "little") & ((1 << 255) - 1)
    if y >= P:
        return "public key is a non-canonical point encoding (y >= p)"
    pt = _decode(pub)
    if pt is None:
        return "public key is not a valid curve point"
    if _has_small_order(pt):
        return "public key is a point of small order"
    return None


def check_public_key(pub: bytes) -> bool:
    return _strict_key(pub) is not None


def _strict_key(pub: bytes) -> Optional[Point]:
    if pub in _KEY_CACHE:
        return _KEY_CACHE[pub]
    pt: Optional[Point] = None
    if public_key_problem(pub) is None:
        pt = _decode(pub)
    if len(_KEY_CACHE) < 4096:
        _KEY_CACHE[pub] = pt
    return pt


def verify(pub: bytes, msg: bytes, sig: bytes) -> bool:
    """Strict Ed25519 verification (see module docstring)."""
    if len(sig) != 64 or len(pub) != 32:
        return False
    a = _strict_key(bytes(pub))
    if a is None:
        return False
    r_bytes = bytes(sig[:32])
    s = int.from_bytes(sig[32:], "little")
    if s >= L:
        return False
    r = _decode(r_bytes)
    if r is None:
        return False  # non-canonical or undecodable R can never match encode(.)
    if _has_small_order(r):
        return False
    pub = bytes(pub)
    k = int.from_bytes(hashlib.sha512(r_bytes + pub + bytes(msg)).digest(), "little") % L
    table = _NEG_TABLES.get(pub)
    if table is None:
        uses = _KEY_USES.get(pub, 0) + 1
        if len(_KEY_USES) > 4096:
            _KEY_USES.clear()
        _KEY_USES[pub] = uses
        if uses >= 2:
            if len(_NEG_TABLES) >= _MAX_TABLES:
                _NEG_TABLES.clear()
            table = _NEG_TABLES[pub] = _build_table(_neg(a))
    if table is not None:
        check = _table_mult(table, k, _base_mult(s))  # [S]B + [k](-A)
    else:
        check = _add(_base_mult(s), _neg(_var_mult(k, a)))
    return _encode(check) == r_bytes


# --- signing, for test fixtures only ---------------------------------------

def _expand_seed(seed: bytes) -> Tuple[int, bytes]:
    if len(seed) != 32:
        raise ValueError("seed must be 32 bytes")
    h = hashlib.sha512(seed).digest()
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def public_from_seed(seed: bytes) -> bytes:
    a, _ = _expand_seed(seed)
    return _encode(_scalar_base(a))


def _scalar_base(a: int) -> Point:
    # a may exceed L; reduce first (B has order L).
    return _base_mult(a % L)


def sign(seed: bytes, msg: bytes) -> bytes:
    a, prefix = _expand_seed(seed)
    pub = _encode(_scalar_base(a))
    r = int.from_bytes(hashlib.sha512(prefix + msg).digest(), "little") % L
    r_enc = _encode(_scalar_base(r))
    k = int.from_bytes(hashlib.sha512(r_enc + pub + msg).digest(), "little") % L
    s = (r + k * a) % L
    return r_enc + s.to_bytes(32, "little")
