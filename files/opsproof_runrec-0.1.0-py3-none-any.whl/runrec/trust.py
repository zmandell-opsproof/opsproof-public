"""Trust a stranger can check (spec section 5, draft 11): the workspace keys a
domain publishes in DNS, and how a pin and a domain together decide provenance.

The standard library cannot ask DNS for TXT records, so ``lookup`` uses DNS
over HTTPS (RFC 8484, JSON form), as a browser must; the reading of the
records is separate and runs anywhere.
"""
from __future__ import annotations

import json
import re
import urllib.parse
import urllib.request
from typing import Iterable, List, Optional, Sequence, Tuple, Union

_DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")
DOH = "https://cloudflare-dns.com/dns-query"


def published_name(domain: str) -> str:
    """The DNS name a domain publishes its workspace keys under."""
    return "_opsproof." + domain.strip(" \t").rstrip(".").lower()


def published_key_ids(records: Iterable[str]) -> List[str]:
    """Key ids in TXT records of the form ``v=runrec1; k=<key_id>``; anything else is ignored."""
    out: List[str] = []
    for rec in records:
        fields = [f.strip(" \t") for f in rec.split(";")]  # spaces and tabs only, as every checker
        if fields[0] != "v=runrec1":
            continue
        for f in fields[1:]:
            if f.startswith("k=") and _DIGEST.fullmatch(f[2:]) and f[2:] not in out:
                out.append(f[2:])
    return out


Published = Tuple[str, Optional[List[str]]]
"""(domain, the key ids it publishes, or None when the lookup failed)"""


def lookup(domain: str, timeout: float = 10.0) -> Published:
    """The keys a domain publishes, by DNS over HTTPS."""
    url = DOH + "?" + urllib.parse.urlencode({"name": published_name(domain), "type": "TXT"})
    try:
        req = urllib.request.Request(url, headers={"accept": "application/dns-json"})
        with urllib.request.urlopen(req, timeout=timeout) as res:
            body = json.loads(res.read().decode("utf-8"))
    except Exception:
        return domain, None
    return domain, records_of(body)


def records_of(body: dict) -> Optional[List[str]]:
    """Key ids from a DNS-over-HTTPS JSON answer; None unless the answer is a success or 'no such name'."""
    status = body.get("Status")
    if status == 3:
        return []
    if status != 0:
        return None
    texts = []
    for a in body.get("Answer") or []:
        if a.get("type") == 16:
            parts = re.findall(r'"((?:[^"\\]|\\.)*)"', a.get("data", ""))
            texts.append("".join(re.sub(r"\\(.)", r"\1", p) for p in parts))
    return published_key_ids(texts)


def provenance_of(key_id: str, pin: Union[None, str, Sequence[str]], published: Optional[Published],
                  warnings: List[str], what: str) -> Tuple[str, Optional[dict]]:
    """Provenance once the workspace key is established (section 9), and the finding a published key earns."""
    prov = "unpinned"
    if pin is not None:
        pins = [pin] if isinstance(pin, str) else list(pin)
        if key_id in pins:
            prov = "pinned"
        else:
            prov = "mismatch"
            warnings.append("provenance mismatch: the pinned fingerprint is %s but this %s was issued by workspace key %s; "
                            "do not treat it as a pass" % (" or ".join(pins), what, key_id))
    if published is None:
        return prov, None
    domain, keys = published
    if keys is None:
        warnings.append("provenance mismatch: the keys %s publishes could not be looked up" % domain)
        return "mismatch", None
    if key_id not in keys:
        warnings.append("provenance mismatch: %s does not publish workspace key %s" % (domain, key_id))
        return "mismatch", None
    return prov, {"kind": "published", "domain": domain}
