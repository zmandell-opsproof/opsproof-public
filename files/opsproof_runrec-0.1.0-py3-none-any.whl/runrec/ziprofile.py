"""Reader for the canonical archive profile of spec section 7.1 (draft 5).

This is deliberately not ``zipfile``: it accepts exactly one byte layout per
set of entries and rejects everything the profile excludes. The reader
walks the central directory and the local headers and requires them to
describe the same bytes with nothing in between, before or after.
"""
from __future__ import annotations

import struct
import zlib
from typing import List, Tuple

__all__ = ["ZipProfileError", "read_archive"]

_EOCD_SIG = 0x06054B50
_CDH_SIG = 0x02014B50
_LFH_SIG = 0x04034B50
_EOCD = struct.Struct("<IHHHHIIH")  # 22 bytes
_CDH = struct.Struct("<IHHHHHHIIIHHHHHII")  # 46 bytes
_LFH = struct.Struct("<IHHHHHIIIHH")  # 30 bytes

_UTF8_FLAG = 0x0800
_VERSION = 20  # "version made by" and "version needed to extract" (draft 5)
_TIME = 0x0000
_DATE = 0x0021  # 1980-01-01


class ZipProfileError(ValueError):
    pass


def read_archive(data: bytes) -> List[Tuple[str, bytes]]:
    """Return ``[(name, content), ...]`` in central-directory order.

    Raises ZipProfileError for anything outside the section 7.1 profile.
    """
    n = len(data)
    if n < _EOCD.size:
        raise ZipProfileError("file is too short to be a ZIP archive")
    (sig, disk, cd_disk, n_disk, n_total, cd_size, cd_off, comment_len) = _EOCD.unpack_from(
        data, n - _EOCD.size
    )
    if sig != _EOCD_SIG:
        raise ZipProfileError(
            "the file does not end with an end-of-central-directory record "
            "(archive comment, trailing data, or not a ZIP archive)"
        )
    if comment_len != 0:
        raise ZipProfileError("archive comment is not empty")
    if disk != 0 or cd_disk != 0:
        raise ZipProfileError("multi-disk archives are not allowed")
    if n_disk != n_total:
        raise ZipProfileError("entry counts in the end-of-central-directory record disagree")
    if n_total == 0xFFFF or cd_size == 0xFFFFFFFF or cd_off == 0xFFFFFFFF:
        raise ZipProfileError("zip64 markers are not allowed")
    if cd_off + cd_size != n - _EOCD.size:
        raise ZipProfileError(
            "the end-of-central-directory record must directly follow the central directory "
            "and end the file"
        )

    entries = []
    pos = cd_off
    cd_end = cd_off + cd_size
    for i in range(n_total):
        if pos + _CDH.size > cd_end:
            raise ZipProfileError("central directory is truncated")
        (
            sig, ver_made, ver_need, flags, method, mtime, mdate, crc, csize, usize,
            name_len, extra_len, comment_len, disk_start, iattr, eattr, loff,
        ) = _CDH.unpack_from(data, pos)
        if sig != _CDH_SIG:
            raise ZipProfileError("bad central directory record signature at entry %d" % i)
        name_b = data[pos + _CDH.size: pos + _CDH.size + name_len]
        if len(name_b) != name_len:
            raise ZipProfileError("central directory is truncated")
        pos += _CDH.size + name_len + extra_len + comment_len
        if pos > cd_end:
            raise ZipProfileError("central directory is truncated")
        label = name_b.decode("utf-8", errors="replace")
        if flags != _UTF8_FLAG:
            raise ZipProfileError(
                "entry %r: general-purpose flags are 0x%04x, must be exactly 0x0800" % (label, flags)
            )
        if method != 0:
            raise ZipProfileError("entry %r: compression method %d, must be 0 (stored)" % (label, method))
        if extra_len != 0:
            raise ZipProfileError("entry %r: extra field is not empty" % label)
        if comment_len != 0:
            raise ZipProfileError("entry %r: entry comment is not empty" % label)
        if disk_start != 0:
            raise ZipProfileError("entry %r: multi-disk archives are not allowed" % label)
        if csize != usize:
            raise ZipProfileError("entry %r: stored entry has different compressed and uncompressed sizes" % label)
        if csize == 0xFFFFFFFF or usize == 0xFFFFFFFF or loff == 0xFFFFFFFF:
            raise ZipProfileError("entry %r: zip64 sentinel values are not allowed" % label)
        if ver_made != _VERSION or ver_need != _VERSION:
            raise ZipProfileError(
                "entry %r: version made by %d / needed %d, both must be 20" % (label, ver_made, ver_need)
            )
        if iattr != 0 or eattr != 0:
            raise ZipProfileError("entry %r: internal and external file attributes must be 0" % label)
        if mtime != _TIME or mdate != _DATE:
            raise ZipProfileError("entry %r: modification time/date must be 0x0000/0x0021" % label)
        entries.append((name_b, ver_need, flags, method, mtime, mdate, crc, csize, loff))
    if pos != cd_end:
        raise ZipProfileError("central directory size does not match its records")

    out: List[Tuple[str, bytes]] = []
    seen = set()
    expected_off = 0
    for (name_b, ver_need, flags, method, mtime, mdate, crc, csize, loff) in entries:
        label = name_b.decode("utf-8", errors="replace")
        if loff != expected_off:
            raise ZipProfileError(
                "entry %r: local header at offset %d, expected %d (local headers must be back to "
                "back from offset 0 in central-directory order)" % (label, loff, expected_off)
            )
        if loff + _LFH.size > cd_off:
            raise ZipProfileError("entry %r: local header overlaps the central directory" % label)
        (
            sig, l_ver_need, l_flags, l_method, l_mtime, l_mdate, l_crc, l_csize, l_usize,
            l_name_len, l_extra_len,
        ) = _LFH.unpack_from(data, loff)
        if sig != _LFH_SIG:
            raise ZipProfileError("entry %r: bad local header signature" % label)
        l_name = data[loff + _LFH.size: loff + _LFH.size + l_name_len]
        if l_name != name_b:
            raise ZipProfileError("entry %r: local header name differs from central directory" % label)
        if l_extra_len != 0:
            raise ZipProfileError("entry %r: local extra field is not empty" % label)
        if (l_ver_need, l_flags, l_method, l_mtime, l_mdate, l_crc, l_csize, l_usize) != (
            ver_need, flags, method, mtime, mdate, crc, csize, csize,
        ):
            raise ZipProfileError(
                "entry %r: local header fields differ from the central directory record" % label
            )
        start = loff + _LFH.size + l_name_len
        end = start + csize
        if end > cd_off:
            raise ZipProfileError("entry %r: data overlaps the central directory" % label)
        content = bytes(data[start:end])
        if zlib.crc32(content) & 0xFFFFFFFF != crc:
            raise ZipProfileError("entry %r: CRC-32 does not match the data" % label)
        expected_off = end

        try:
            name = name_b.decode("utf-8", errors="strict")
        except UnicodeDecodeError:
            raise ZipProfileError("entry name is not valid UTF-8") from None
        _check_name(name)
        if name in seen:
            raise ZipProfileError("duplicate entry name %r" % name)
        seen.add(name)
        out.append((name, content))
    if expected_off != cd_off:
        raise ZipProfileError(
            "the central directory must directly follow the last entry (found %d unaccounted bytes)"
            % (cd_off - expected_off)
        )
    return out


def _check_name(name: str) -> None:
    if name == "":
        raise ZipProfileError("empty entry name")
    if "\\" in name:
        raise ZipProfileError("entry name %r contains a backslash" % name)
    if "\x00" in name:
        raise ZipProfileError("entry name %r contains NUL" % name)
    if name.startswith("/"):
        raise ZipProfileError("entry name %r is absolute" % name)
    if name.endswith("/"):
        raise ZipProfileError("directory entry %r is not allowed" % name)
    for seg in name.split("/"):
        if seg in ("", ".", ".."):
            raise ZipProfileError("entry name %r has an empty, '.' or '..' segment" % name)
