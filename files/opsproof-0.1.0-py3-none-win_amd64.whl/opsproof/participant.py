"""How a System (a sensor, a controller, a robot's adapter) or an Agent joins
Runs in an OpsProof workspace.

    from opsproof import ParticipantClient, Key

    key = Key.load("sensor.key")              # made once with Key.generate(...).save(...)
    c = ParticipantClient("http://127.0.0.1:7341", "sensor-cam3", key)
    c.observe(run_id, "apply-correction", quantity="bead_width_mm", unit="mm", value=2.31, uncertainty=0.03)

Every event is prepared by the kernel, checked here to be exactly what was
asked for, signed with this Participant's key, and committed. The kernel
never signs for a System or an Agent. Standard library only, plus the runrec
package (the Python checker) for canonical JSON and Ed25519.
"""
from __future__ import annotations

import base64
import calendar
import hashlib
import json
import os
import random
import secrets
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Dict, List, Optional

from runrec import ed25519, jcs
from runrec.b64 import b64decode_url, b64encode_url

__all__ = ["Key", "ParticipantClient", "KernelError", "PAYLOAD_TYPE", "run_id_of"]

PAYLOAD_TYPE = "application/vnd.in-toto+json"
STATEMENT_TYPE = "https://in-toto.io/Statement/v1"
PREDICATE_PREFIX = "https://opsproof.systems/runrec/v0.1/"
HEADER = ("run_id", "workspace_id", "seq", "previous", "kind", "actor", "declared_time")
MAX_SKEW_S = 600


def run_id_of(run: Any) -> str:
    """A Run given as its id or as an object with one (an opsproof.Run)."""
    return run if isinstance(run, str) else run.id


class KernelError(Exception):
    def __init__(self, status: int, code: str, message: str) -> None:
        super().__init__("%s (%s): %s" % (code, status, message))
        self.status, self.code, self.message = status, code, message


class Key:
    """An Ed25519 key. The file holds the private seed, readable only by you (mode 0600)."""

    def __init__(self, participant_id: str, seed: bytes) -> None:
        if len(seed) != 32:
            raise ValueError("an Ed25519 seed is 32 bytes")
        self.participant_id = participant_id
        self.seed = seed
        self.public_key = ed25519.public_from_seed(seed)
        self.public_b64url = b64encode_url(self.public_key)
        self.key_id = "sha256:" + hashlib.sha256(self.public_key).hexdigest()

    @classmethod
    def generate(cls, participant_id: str) -> "Key":
        return cls(participant_id, secrets.token_bytes(32))

    @classmethod
    def load(cls, path: str) -> "Key":
        with open(path) as f:
            d = json.load(f)
        return cls(d["participant_id"], b64decode_url(d["seed"]))

    def save(self, path: str) -> None:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump({"participant_id": self.participant_id, "seed": b64encode_url(self.seed)}, f)
            f.write("\n")

    def setup_entry(self, display_name: str, kind: str, roles: List[str], grants: List[str]) -> Dict[str, Any]:
        """This Participant's entry for the workspace's setup file."""
        return {"participant_id": self.participant_id, "display_name": display_name, "kind": kind,
                "roles": roles, "grants": grants, "public_key": self.public_b64url}

    def sign(self, message: bytes) -> bytes:
        return ed25519.sign(self.seed, message)


def _pae(payload_type: str, payload: bytes) -> bytes:
    t = payload_type.encode()
    return b"DSSEv1 %d %s %d %s" % (len(t), t, len(payload), payload)


def _session_message(workspace_id: str, participant_id: str, nonce: str, origin: str) -> bytes:
    return ("opsproof-session-v2\n%s\n%s\n%s\n%s" % (workspace_id, participant_id, nonce, origin)).encode()


class ParticipantClient:
    def __init__(self, url: str, participant_id: str, key: Key, workspace_id: Optional[str] = None) -> None:
        self.url = url.rstrip("/")
        self.participant_id = participant_id
        self.key = key
        self.workspace_id = workspace_id
        self._token: Optional[str] = None
        self._kind: Optional[str] = None
        self._subjects: Dict[str, Dict[str, str]] = {}

    # --- transport -----------------------------------------------------
    def _http(self, method: str, path: str, body: Any = None, content_type: Optional[str] = None, auth: bool = True) -> Any:
        headers = {}
        data = None
        if isinstance(body, (bytes, bytearray)):
            data = bytes(body)
            headers["content-type"] = content_type or "application/octet-stream"
        elif body is not None:
            data = json.dumps(body).encode()
            headers["content-type"] = "application/json"
        if auth and self._token:
            headers["authorization"] = "Bearer " + self._token
        req = urllib.request.Request(self.url + path, data=data, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=30) as res:
                text = res.read()
                return json.loads(text) if text else {}
        except urllib.error.HTTPError as e:
            raw = e.read()
            try:
                err = json.loads(raw).get("error", {})
            except ValueError:
                err = {}
            raise KernelError(e.code, err.get("code", "http"), err.get("message", str(e))) from None

    def _call(self, method: str, path: str, body: Any = None, content_type: Optional[str] = None) -> Any:
        if not self._token:
            self.connect()
        try:
            return self._http(method, path, body, content_type)
        except KernelError as e:
            if e.status != 401:
                raise
            self._token = None
            self.connect()
            return self._http(method, path, body, content_type)

    def connect(self) -> None:
        """Open a session by signing the kernel's challenge with this Participant's key."""
        ch = self._http("POST", "/v1/sessions/challenge", {"participant_id": self.participant_id}, auth=False)
        ws, nonce = ch["workspace_id"], ch["nonce"]
        if self.workspace_id is not None and ws != self.workspace_id:
            raise RuntimeError("kernel serves workspace %s, not %s" % (ws, self.workspace_id))
        parts = urllib.parse.urlsplit(self.url)
        origin = "%s://%s" % (parts.scheme, parts.netloc)
        sig = self.key.sign(_session_message(ws, self.participant_id, nonce, origin))
        s = self._http("POST", "/v1/sessions", {"participant_id": self.participant_id, "nonce": nonce,
                                                "signature": base64.b64encode(sig).decode()}, auth=False)
        self._token = s["token"]
        self.workspace_id = ws
        me = [p for p in self._http("GET", "/v1/participants")["participants"] if p["participant_id"] == self.participant_id]
        if not me or me[0]["key_id"] != self.key.key_id:
            raise RuntimeError("%s is not enrolled with this key" % self.participant_id)
        self._kind = me[0]["kind"]

    # --- reading -------------------------------------------------------
    def runs(self) -> List[Dict[str, Any]]:
        return self._call("GET", "/v1/runs")["runs"]

    def state(self, run_id: Any) -> Dict[str, Any]:
        run_id = run_id_of(run_id)
        return self._call("GET", "/v1/runs/" + urllib.parse.quote(run_id))

    def work(self, run_id: Any) -> List[Dict[str, Any]]:
        run_id = run_id_of(run_id)
        return self._call("GET", "/v1/runs/%s/work" % urllib.parse.quote(run_id))["work"]

    def events(self, run_id: Any, after: int = 0) -> List[Dict[str, Any]]:
        run_id = run_id_of(run_id)
        return self._call("GET", "/v1/runs/%s/events?after=%d" % (urllib.parse.quote(run_id), after))["events"]

    def blob(self, data: bytes, media_type: str) -> Dict[str, Any]:
        """Upload evidence (a file, or a trace); returns the artifact object an event cites."""
        return self._call("POST", "/v1/blobs", data, content_type=media_type)

    # --- recording -----------------------------------------------------
    def _subject(self, run_id: str) -> Dict[str, str]:
        if run_id not in self._subjects:
            p = self.state(run_id)["procedure"]
            self._subjects[run_id] = {"name": "runrec:procedure:%s@%s" % (p["procedure_id"], p["version"]), "digest": p["digest"]}
        return self._subjects[run_id]

    def _check(self, run_id: str, kind: str, fields: Dict[str, Any], p: Dict[str, Any]) -> bytes:
        """Refuse to sign anything but exactly the event asked for."""
        def fail(why: str) -> None:
            raise RuntimeError("refusing to sign: " + why)
        if p.get("payload_type") != PAYLOAD_TYPE:
            fail("unexpected payload type")
        payload = base64.b64decode(p["payload"], validate=True)
        st = jcs.parse(payload)
        if jcs.canonical_bytes(st) != payload:
            fail("payload is not canonical JSON")
        if sorted(st) != ["_type", "predicate", "predicateType", "subject"] or st["_type"] != STATEMENT_TYPE or st["predicateType"] != PREDICATE_PREFIX + "event":
            fail("not an event Statement")
        sub = self._subject(run_id)
        subs = st["subject"]
        if len(subs) != 1 or subs[0].get("name") != sub["name"] or "sha256:" + str(subs[0].get("digest", {}).get("sha256")) != sub["digest"]:
            fail("subject is not this Run's Procedure")
        pred = st["predicate"]
        for k in pred:
            if k not in HEADER and k not in fields:
                fail("unrequested member " + k)
        for k, v in fields.items():
            if k not in pred or jcs.canonicalize(pred[k]) != jcs.canonicalize(v):
                fail("member %s differs from the request" % k)
        a = pred.get("actor", {})
        if pred.get("kind") != kind or pred.get("run_id") != run_id or pred.get("workspace_id") != self.workspace_id:
            fail("kind, Run or workspace differs from the request")
        if a != {"participant_id": self.participant_id, "kind": self._kind, "key_id": self.key.key_id}:
            fail("actor is not this Participant, kind and key")
        if pred.get("seq") != p["seq"] or pred.get("previous") != p["previous"]:
            fail("position differs from the prepared one")
        t = calendar.timegm(time.strptime(pred["declared_time"][:19], "%Y-%m-%dT%H:%M:%S"))
        if abs(t - time.time()) > MAX_SKEW_S:
            fail("declared_time is not near this machine's clock")
        return payload

    def record(self, run_id: Any, kind: str, fields: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Record an event: prepare, check, sign, commit. Returns it and the runtime events it caused."""
        run_id = run_id_of(run_id)
        q = urllib.parse.quote(run_id)
        for attempt in range(31):
            p = self._call("POST", "/v1/runs/%s/prepare" % q, {"kind": kind, "fields": fields})
            payload = self._check(run_id, kind, fields, p)
            sig = self.key.sign(_pae(PAYLOAD_TYPE, payload))
            env = {"payloadType": PAYLOAD_TYPE, "payload": p["payload"], "signatures": [{"keyid": self.key.key_id, "sig": base64.b64encode(sig).decode()}]}
            try:
                return self._call("POST", "/v1/runs/%s/commit" % q, {"envelope": env})["events"]
            except KernelError as e:
                if e.code != "conflict" or attempt == 30:
                    raise
                time.sleep(random.random() * min(0.05, 0.005 * (attempt + 1)))
        raise AssertionError("unreachable")

    def observe(self, run_id: Any, step_id: str, quantity: str, unit: str, value: float,
                uncertainty: Optional[float] = None, device_id: Optional[str] = None, method: Optional[str] = None) -> List[Dict[str, Any]]:
        """Record a measurement; uncertainty None means it is not known (it then counts for nothing)."""
        source: Dict[str, Any] = {}
        if device_id:
            source["device_id"] = device_id
        if method:
            source["method"] = method
        unc = {"kind": "stated", "value": uncertainty, "unit": unit} if uncertainty is not None else {"kind": "unknown"}
        return self.record(run_id, "Observation", {"step_id": step_id, "measurement": {"quantity": quantity, "unit": unit, "value": value},
                                                    "uncertainty": unc, "source": source})

    def attach(self, run_id: Any, step_id: str, data: bytes, media_type: str, device_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Record a file (a photo, a report) as an Observation."""
        art = self.blob(data, media_type)
        return self.record(run_id, "Observation", {"step_id": step_id, "artifact": art, "source": {"device_id": device_id} if device_id else {}})

    def propose(self, run_id: Any, step_id: str, action_type: str, parameters: Dict[str, Any], cites: List[str],
                rationale: Optional[str] = None, trace: Optional[bytes] = None) -> List[Dict[str, Any]]:
        fields: Dict[str, Any] = {"step_id": step_id, "action": {"type": action_type, "parameters": parameters}, "cites": cites}
        if rationale is not None:
            fields["rationale"] = rationale
        if trace is not None:
            fields["trace"] = self.blob(trace, "application/x-ndjson")
        return self.record(run_id, "Proposal", fields)

    def act(self, run_id: Any, step_id: str, action_type: str, parameters: Dict[str, Any], status: str = "success",
            authorization: Optional[str] = None, detail: Optional[str] = None, trace: Optional[bytes] = None) -> List[Dict[str, Any]]:
        """Report an action this System carried out; trace is its own log of doing it (setpoints, commands)."""
        result: Dict[str, Any] = {"status": status}
        if detail is not None:
            result["detail"] = detail
        fields: Dict[str, Any] = {"step_id": step_id, "action": {"type": action_type, "parameters": parameters}, "result": result}
        if authorization is not None:
            fields["authorization"] = authorization
        if trace is not None:
            fields["trace"] = self.blob(trace, "application/x-ndjson")
        return self.record(run_id, "Action", fields)

    def note(self, run_id: Any, text: str, step_id: Optional[str] = None) -> List[Dict[str, Any]]:
        return self.record(run_id, "Note", {"text": text, **({"step_id": step_id} if step_id else {})})
