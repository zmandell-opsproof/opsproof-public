"""The OpsProof engine, from Python.

The engine (the kernel: the workspace store, the rules, signing and the
local API) is one JavaScript file run by Node. A platform wheel of this
package carries both, so ``pip install opsproof`` is all a Python shop needs;
from a source checkout it runs the kernel in the repository with the Node on
your PATH (22.14 or later).

    import opsproof

    with opsproof.Engine.ephemeral() as eng:      # a throwaway workspace held in memory
        ...

    eng = opsproof.Engine.dev("./my-workspace")   # persistent, development keys, no fingerprint
    eng = opsproof.Engine.connect(url, token)     # an engine someone else started (the app)

An Engine is the workspace's administrator: it enrolls Participants, adds
Procedures, starts, closes and seals Runs, issues registers, and records
events for the people whose keys it holds. Agents and Systems sign their own
events with their own keys, through the ParticipantClient each enrollment
returns; the engine never signs for them.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import threading
import urllib.error
import urllib.parse
import urllib.request
from collections import deque
from typing import Any, Dict, Iterable, List, Optional, Sequence, Union

from .participant import Key, KernelError, ParticipantClient, run_id_of

__all__ = ["Engine", "Run", "Person", "Record", "EngineNotFound", "find_engine"]

MIN_NODE = (22, 14)
HERE = os.path.dirname(os.path.abspath(__file__))


class EngineNotFound(RuntimeError):
    pass


def _node_version(node: str) -> Optional[tuple]:
    try:
        out = subprocess.run([node, "--version"], capture_output=True, text=True, timeout=20).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return None
    try:
        major, minor = out.lstrip("v").split(".")[:2]
        return int(major), int(minor)
    except ValueError:
        return None


def find_engine() -> List[str]:
    """The command that runs the engine: [node, flags..., engine].

    In order: OPSPROOF_ENGINE (a path to opsproof-engine.mjs, run by
    OPSPROOF_NODE or the Node on PATH); the engine and Node this wheel carries;
    the kernel source of the repository this package sits in.
    """
    flags = ["--disable-sigusr1", "--no-warnings"]
    exe = "node.exe" if os.name == "nt" else "node"
    bundled_node = os.path.join(HERE, "_engine", exe)
    bundled_engine = os.path.join(HERE, "_engine", "opsproof-engine.mjs")

    def system_node() -> str:
        node = os.environ.get("OPSPROOF_NODE") or shutil.which("node")
        if not node:
            raise EngineNotFound("OpsProof needs Node.js 22.14 or later to run its engine from a source checkout; install it, or install a platform wheel of opsproof, which carries its own")
        v = _node_version(node)
        if v is None or v < MIN_NODE:
            raise EngineNotFound("%s is Node %s; the engine needs 22.14 or later" % (node, ".".join(map(str, v)) if v else "of unknown version"))
        return node

    override = os.environ.get("OPSPROOF_ENGINE")
    if override:
        node = os.environ.get("OPSPROOF_NODE") or (bundled_node if os.path.exists(bundled_node) else system_node())
        return [node, *flags, override]
    if os.path.exists(bundled_engine) and os.path.exists(bundled_node):
        return [bundled_node, *flags, bundled_engine]
    # A source checkout: packages/opsproof-py/opsproof -> the repository root.
    root = os.path.dirname(os.path.dirname(os.path.dirname(HERE)))
    cli = os.path.join(root, "kernel", "src", "cli.ts")
    if os.path.exists(cli):
        return [system_node(), *flags, "--experimental-strip-types", cli]
    if os.path.exists(bundled_engine):
        return [system_node(), *flags, bundled_engine]
    raise EngineNotFound("no OpsProof engine found: this install carries none, and it is not in a source checkout; install a platform wheel of opsproof")


class Record:
    """A sealed Run Record: its bytes, and what the free checker says of them."""

    def __init__(self, data: bytes, run_id: str, digest: str, key_id: str) -> None:
        self.bytes = data
        self.run_id = run_id
        self.digest = digest
        self.key_id = key_id

    def save(self, path: str) -> str:
        with open(path, "wb") as f:
            f.write(self.bytes)
        return path

    def verify(self, pin: Optional[str] = None) -> Dict[str, Any]:
        """The independent Python checker's report (spec section 9), pinned to this workspace's key by default."""
        from runrec import verify_bytes
        return verify_bytes(self.bytes, pin=pin if pin is not None else self.key_id).report

    def __len__(self) -> int:
        return len(self.bytes)

    def __repr__(self) -> str:
        return "<Record %s, %d bytes, %s>" % (self.run_id, len(self.bytes), self.digest)


class Run:
    """One Run, as the engine sees it."""

    def __init__(self, engine: "Engine", run_id: str) -> None:
        self.engine = engine
        self.id = run_id

    def state(self) -> Dict[str, Any]:
        return self.engine._call("GET", "/v1/runs/" + urllib.parse.quote(self.id))

    def events(self, after: int = 0) -> List[Dict[str, Any]]:
        return self.engine._call("GET", "/v1/runs/%s/events?after=%d" % (urllib.parse.quote(self.id), after))["events"]

    @property
    def outcome(self) -> str:
        return self.state()["outcome"]

    def close(self, by: Optional[Union["Person", str]] = None) -> Dict[str, Any]:
        body = {"closed_by": _pid(by)} if by is not None else {}
        return self.engine._call("POST", "/v1/runs/%s/close" % urllib.parse.quote(self.id), body)

    def seal(self, by: Optional[Union["Person", str]] = None) -> Record:
        """Seal the closed Run into its Record. The engine checks it with the reference checker first."""
        body = {"published_by": _pid(by)} if by is not None else {}
        r = self.engine._call("POST", "/v1/runs/%s/seal" % urllib.parse.quote(self.id), body)
        data = self.engine._raw("GET", "/v1/runs/%s/record" % urllib.parse.quote(self.id))
        return Record(data, self.id, r["digest"], r["key_id"])

    def __repr__(self) -> str:
        return "<Run %s>" % self.id


def _pid(p: Union["Person", ParticipantClient, str]) -> str:
    if isinstance(p, str):
        return p
    return p.participant_id


class Person:
    """A Human whose key the workspace holds. In a protected workspace every signature asks them in person
    (Touch ID, Windows Hello); in an ephemeral or development workspace it does not."""

    def __init__(self, engine: "Engine", participant_id: str) -> None:
        self.engine = engine
        self.participant_id = participant_id

    def submit(self, run: Any, kind: str, fields: Dict[str, Any]) -> List[Dict[str, Any]]:
        rid = run_id_of(run)
        return self.engine._call("POST", "/v1/runs/%s/submit" % urllib.parse.quote(rid),
                                 {"participant_id": self.participant_id, "kind": kind, "fields": fields})["events"]

    def authorize(self, run: Any, step_id: str, proposal: str, reason: str, allow: bool = True) -> List[Dict[str, Any]]:
        """Rule on a Proposal the limits did not allow: approve (or refuse) it, with a reason."""
        return self.submit(run, "Authorization", {"step_id": step_id, "proposal": proposal, "result": "allow" if allow else "deny",
                                                  "basis": {"kind": "human"}, "reason": reason})

    def decide(self, run: Any, step_id: str, decision_id: str, type: str, reason: str,
               cites: Sequence[str] = (), scope: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """Make a decision the Procedure requires of a person (release, rework, scrap ...)."""
        fields: Dict[str, Any] = {"step_id": step_id, "decision_id": decision_id, "type": type, "reason": reason, "cites": list(cites)}
        if scope is not None:
            fields["scope"] = scope
        return self.submit(run, "Decision", fields)

    def observe(self, run: Any, step_id: str, quantity: str, unit: str, value: float,
                uncertainty: Optional[float] = None) -> List[Dict[str, Any]]:
        unc = {"kind": "stated", "value": uncertainty, "unit": unit} if uncertainty is not None else {"kind": "unknown"}
        return self.submit(run, "Observation", {"step_id": step_id, "measurement": {"quantity": quantity, "unit": unit, "value": value},
                                                "uncertainty": unc, "source": {}})

    def note(self, run: Any, text: str, step_id: Optional[str] = None) -> List[Dict[str, Any]]:
        return self.submit(run, "Note", {"text": text, **({"step_id": step_id} if step_id else {})})

    def __repr__(self) -> str:
        return "<Person %s>" % self.participant_id


class Engine:
    """A running OpsProof engine and its workspace."""

    def __init__(self, url: str, token: str, process: Optional[subprocess.Popen] = None,
                 info: Optional[Dict[str, Any]] = None, log: Optional[deque] = None) -> None:
        self.url = url.rstrip("/")
        self.token = token
        self._process = process
        self._log = log if log is not None else deque(maxlen=200)
        info = info or self._http("GET", "/v1/workspace")
        self.workspace_id: str = info["workspace_id"]
        self.key_id: str = info["key_id"]

    # --- starting ------------------------------------------------------
    @classmethod
    def ephemeral(cls, name: str = "OpsProof quickstart (throwaway)", workspace_id: str = "ws-quickstart") -> "Engine":
        """A throwaway workspace held in the engine's memory: no keys on disk, no fingerprint, gone when it stops.
        Its Records are real and check out, pinned to the key it prints; nothing can make more under that key afterwards."""
        return cls._serve(["serve", "--ephemeral", "--id", workspace_id, "--name", name])

    @classmethod
    def dev(cls, directory: str, name: Optional[str] = None, workspace_id: Optional[str] = None) -> "Engine":
        """A persistent workspace in ``directory`` with development keys: plain files, no fingerprint, for building
        on OpsProof. Made on first use. A development workspace only ever opens as one."""
        directory = os.path.abspath(directory)
        if not os.path.exists(os.path.join(directory, "workspace.sqlite")):
            wid = workspace_id or "ws-" + "".join(c if c.isalnum() else "-" for c in os.path.basename(directory).lower()).strip("-")[:40] or "ws-dev"
            cmd = find_engine() + ["init", "--dir", directory, "--id", wid, "--name", name or "%s (development)" % wid, "--dev-keys"]
            r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode != 0:
                raise RuntimeError("could not make the workspace: " + (r.stderr.strip() or r.stdout.strip()))
        return cls._serve(["serve", "--dir", directory, "--dev-keys"])

    @classmethod
    def connect(cls, url: str, token: str) -> "Engine":
        """An engine started elsewhere, by its URL and launch token."""
        return cls(url, token)

    @classmethod
    def _serve(cls, args: List[str]) -> "Engine":
        cmd = find_engine() + args + ["--exit-with-stdin"]
        env = dict(os.environ)
        env.pop("NODE_OPTIONS", None)  # a key-holding engine refuses most of them; it needs none
        p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
        log: deque = deque(maxlen=200)

        def drain() -> None:
            assert p.stderr is not None
            for line in iter(p.stderr.readline, b""):
                log.append(line.decode(errors="replace").rstrip())
        threading.Thread(target=drain, daemon=True).start()
        assert p.stdout is not None
        ready: Optional[Dict[str, Any]] = None
        for line in iter(p.stdout.readline, b""):
            try:
                msg = json.loads(line)
            except ValueError:
                continue
            if "url" in msg and "token" in msg:
                ready = msg
                break
        if ready is None:
            p.wait(timeout=10)
            raise RuntimeError("the engine stopped before it was ready:\n" + "\n".join(log))
        threading.Thread(target=lambda: [None for _ in iter(p.stdout.readline, b"")], daemon=True).start()
        return cls(ready["url"], ready["token"], p, {"workspace_id": ready["workspace_id"], "key_id": ready["key_id"]}, log)

    def close(self) -> None:
        """Stop an engine this object started (open Runs in a development workspace survive; an ephemeral one is gone)."""
        p, self._process = self._process, None
        if p is None:
            return
        try:
            if p.stdin:
                p.stdin.close()
            p.wait(timeout=10)
        except subprocess.TimeoutExpired:
            p.kill()
            p.wait()

    def __enter__(self) -> "Engine":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    @property
    def log(self) -> List[str]:
        """What the engine wrote to its error stream (warnings, and why it stopped)."""
        return list(self._log)

    # --- transport -----------------------------------------------------
    def _request(self, method: str, path: str, body: Any = None, content_type: Optional[str] = None) -> bytes:
        headers = {"authorization": "Bearer " + self.token}
        data = None
        if isinstance(body, (bytes, bytearray)):
            data = bytes(body)
            headers["content-type"] = content_type or "application/octet-stream"
        elif body is not None:
            data = json.dumps(body).encode()
            headers["content-type"] = "application/json"
        req = urllib.request.Request(self.url + path, data=data, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=120) as res:
                return res.read()
        except urllib.error.HTTPError as e:
            raw = e.read()
            try:
                err = json.loads(raw).get("error", {})
            except ValueError:
                err = {}
            raise KernelError(e.code, err.get("code", "http"), err.get("message", str(e))) from None

    def _http(self, method: str, path: str, body: Any = None) -> Any:
        text = self._request(method, path, body)
        return json.loads(text) if text else {}

    _call = _http

    def _raw(self, method: str, path: str) -> bytes:
        return self._request(method, path)

    # --- the workspace -------------------------------------------------
    def summary(self) -> Dict[str, Any]:
        return self._http("GET", "/v1/workspace")

    def _enroll(self, participant_id: str, name: Optional[str], kind: str, roles: Iterable[str], grants: Iterable[str],
                public_key: Optional[str] = None) -> Dict[str, Any]:
        body: Dict[str, Any] = {"participant_id": participant_id, "display_name": name or participant_id, "kind": kind,
                                "roles": list(roles), "grants": list(grants)}
        if public_key is not None:
            body["public_key"] = public_key
        return self._http("POST", "/v1/participants", body)

    def person(self, participant_id: str, name: Optional[str] = None, roles: Iterable[str] = (),
               grants: Iterable[str] = ("author", "authorize", "decide", "observe")) -> Person:
        """Enroll a Human whose key this workspace holds."""
        self._enroll(participant_id, name, "human", roles, grants)
        return Person(self, participant_id)

    def agent(self, participant_id: str, name: Optional[str] = None, roles: Iterable[str] = (),
              key: Optional[Key] = None, grants: Iterable[str] = ("operate",)) -> ParticipantClient:
        """Enroll an Agent with its own key (made here unless given) and return its client: it proposes, never acts."""
        key = key or Key.generate(participant_id)
        self._enroll(participant_id, name, "agent", roles, grants, key.public_b64url)
        return ParticipantClient(self.url, participant_id, key, self.workspace_id)

    def system(self, participant_id: str, name: Optional[str] = None, roles: Iterable[str] = (),
               key: Optional[Key] = None, grants: Iterable[str] = ("observe", "act")) -> ParticipantClient:
        """Enroll a System (a sensor, a controller, a robot) with its own key and return its client."""
        key = key or Key.generate(participant_id)
        self._enroll(participant_id, name, "system", roles, grants, key.public_b64url)
        return ParticipantClient(self.url, participant_id, key, self.workspace_id)

    def procedure(self, procedure: Union[Dict[str, Any], str], author: Union[Person, str]) -> Dict[str, Any]:
        """Add a Procedure (a dict, or a path to its JSON), signed by a Human author whose key the workspace holds."""
        if isinstance(procedure, str):
            with open(procedure, encoding="utf-8") as f:
                procedure = json.load(f)
        return self._http("POST", "/v1/procedures", {"procedure": procedure, "author": _pid(author)})

    def describe(self, digest: str) -> Dict[str, Any]:
        """A Procedure in plain English, as the person who signs it reads it."""
        return self._http("GET", "/v1/procedures/%s/text" % urllib.parse.quote(digest))

    def start(self, procedure: Union[Dict[str, Any], str], run_id: Optional[str] = None, title: Optional[str] = None,
              started_by: Optional[Union[Person, str]] = None) -> Run:
        """Start a Run of a Procedure, given by the dict ``procedure()`` returned, its digest, or its procedure_id (latest version)."""
        body: Dict[str, Any] = {}
        if isinstance(procedure, dict):
            body["digest"] = procedure["digest"]
        elif procedure.startswith("sha256:"):
            body["digest"] = procedure
        else:
            body["procedure_id"] = procedure
        if run_id is not None:
            body["run_id"] = run_id
        if title is not None:
            body["title"] = title
        if started_by is not None:
            body["started_by"] = _pid(started_by)
        return Run(self, self._http("POST", "/v1/runs", body)["run_id"])

    def run(self, run_id: str) -> Run:
        return Run(self, run_id)

    def runs(self) -> List[Dict[str, Any]]:
        return self._http("GET", "/v1/runs")["runs"]

    def register(self) -> bytes:
        """Issue the workspace's register: the signed list of every Run it has started (spec section 7.3)."""
        return self._raw("GET", "/v1/register")

    def rotate_key(self, reason: str, exposed: bool = False, as_of: Optional[int] = None) -> Dict[str, Any]:
        """Hand over to the successor key the workspace committed to in advance (spec section 5). Every Run must
        be closed and sealed first. ``exposed`` also revokes the old key, as of Run ``as_of`` (default: the last)."""
        body: Dict[str, Any] = {"reason": reason, "exposed": exposed}
        if as_of is not None:
            body["as_of"] = as_of
        r = self._http("POST", "/v1/workspace/rotate", body)
        self.key_id = r["key_id"]
        return r

    def revoke(self, participant_id: str, reason: str) -> Dict[str, Any]:
        """Revoke a Participant's key: retired here, and named in every register from the next one on."""
        return self._http("POST", "/v1/participants/%s/revoke" % participant_id, {"reason": reason})

    def __repr__(self) -> str:
        return "<Engine %s at %s, workspace key %s>" % (self.workspace_id, self.url, self.key_id)


def authorization_of(events: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """The Authorization among the events a Proposal caused, if the limits ruled on it."""
    for e in events:
        if e.get("kind") == "Authorization":
            return e
    return None


if __name__ == "__main__":  # pragma: no cover
    print(find_engine())
    sys.exit(0)
