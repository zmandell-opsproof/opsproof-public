#!/usr/bin/env node
// OpsProof engine 0.1.0. Proprietary; see LICENSE in the OpsProof repository.
import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);

// src/cli.ts
import { writeFileSync as writeFileSync4, rmSync as rmSync4 } from "node:fs";
import { join as join6 } from "node:path";

// src/keys.ts
import { randomBytes } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";

// ../packages/runrec/src/crypto.ts
import { createHash, createPrivateKey, createPublicKey, sign as nodeSign, verify as nodeVerify } from "node:crypto";

// ../packages/runrec/src/digest.ts
function isDigest(v) {
  return typeof v === "string" && /^sha256:[0-9a-f]{64}$/.test(v);
}

// ../packages/runrec/src/crypto.ts
var SPKI_PREFIX = Buffer.from("302a300506032b6570032100", "hex");
var PKCS8_PREFIX = Buffer.from("302e020100300506032b657004220420", "hex");
function sha256Hex(bytes3) {
  return createHash("sha256").update(bytes3).digest("hex");
}
function digestOf(bytes3) {
  return `sha256:${sha256Hex(bytes3)}`;
}
function b64Encode(bytes3) {
  return Buffer.from(bytes3).toString("base64");
}
function b64Decode(s) {
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(s) || s.length % 4 !== 0) throw new Error("invalid base64");
  const out = Buffer.from(s, "base64");
  if (out.toString("base64") !== s) throw new Error("non-canonical base64");
  return new Uint8Array(out);
}
function b64urlEncode(bytes3) {
  return Buffer.from(bytes3).toString("base64url");
}
function b64urlDecode(s) {
  if (!/^[A-Za-z0-9_-]*$/.test(s)) throw new Error("invalid base64url");
  const out = Buffer.from(s, "base64url");
  if (out.toString("base64url") !== s) throw new Error("non-canonical base64url");
  return new Uint8Array(out);
}
function signerFor(publicKey, sign) {
  const pk = new Uint8Array(publicKey);
  return { keyId: keyIdOf(pk), publicKey: pk, publicKeyB64u: b64urlEncode(pk), sign };
}
function keyIdOf(publicKey) {
  return digestOf(publicKey);
}
function keyPairFromSeed(seed) {
  if (seed.length !== 32) throw new Error("Ed25519 seed must be 32 bytes");
  const priv = createPrivateKey({ key: Buffer.concat([PKCS8_PREFIX, seed]), format: "der", type: "pkcs8" });
  const spki = createPublicKey(priv).export({ format: "der", type: "spki" });
  const publicKey = new Uint8Array(spki.subarray(SPKI_PREFIX.length));
  return { publicKey, privateKey: new Uint8Array(seed), keyId: keyIdOf(publicKey), publicKeyB64u: b64urlEncode(publicKey) };
}
function privateKeyObject(seed) {
  return createPrivateKey({ key: Buffer.concat([PKCS8_PREFIX, Buffer.from(seed)]), format: "der", type: "pkcs8" });
}
function publicKeyObject(raw) {
  if (raw.length !== 32) throw new Error("Ed25519 public key must be 32 bytes");
  return createPublicKey({ key: Buffer.concat([SPKI_PREFIX, Buffer.from(raw)]), format: "der", type: "spki" });
}
function ed25519Sign(seed, message) {
  return new Uint8Array(nodeSign(null, message, privateKeyObject(seed)));
}
var SMALL_ORDER = [
  "0000000000000000000000000000000000000000000000000000000000000000",
  "0100000000000000000000000000000000000000000000000000000000000000",
  "26e8958fc2b227b045c3f489f2ef98f0d5dfac05d3c63339b13802886d53fc05",
  "c7176a703d4dd84fba3c0b760d10670f2a2053fa2c39ccc64ec7fd7792ac037a",
  "ecffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff7f",
  "edffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff7f",
  "eeffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff7f"
];
function hasSmallOrder(point) {
  const masked = Buffer.from(point);
  masked[31] = masked[31] & 127;
  const hex = masked.toString("hex");
  return SMALL_ORDER.includes(hex);
}
function isNonCanonicalPoint(point) {
  if ((point[31] & 127) !== 127) return false;
  for (let i = 1; i < 31; i++) if (point[i] !== 255) return false;
  return point[0] >= 237;
}
var L = Buffer.from("edd3f55c1a631258d69cf7a2def9de1400000000000000000000000000000010", "hex");
function scalarBelowL(s) {
  for (let i = 31; i >= 0; i--) {
    if (s[i] < L[i]) return true;
    if (s[i] > L[i]) return false;
  }
  return false;
}
var P = (1n << 255n) - 19n;
var D = (-121665n % P + P) % P * modPow(121666n, P - 2n, P) % P;
var SQRT_M1 = modPow(2n, (P - 1n) / 4n, P);
function modPow(b, e, m) {
  let r = 1n;
  b %= m;
  while (e > 0n) {
    if (e & 1n) r = r * b % m;
    b = b * b % m;
    e >>= 1n;
  }
  return r;
}
function decodesToPoint(enc2) {
  let y = 0n;
  for (let i = 31; i >= 0; i--) y = y << 8n | BigInt(i === 31 ? enc2[i] & 127 : enc2[i]);
  if (y >= P) return false;
  const sign = enc2[31] >> 7 & 1;
  const u = (y * y - 1n + P) % P;
  const v = (D * y * y + 1n) % P;
  let x = u * modPow(v, 3n, P) % P * modPow(u * modPow(v, 7n, P) % P, (P - 5n) / 8n, P) % P;
  const vx2 = v * x * x % P;
  if (vx2 === u) {
  } else if (vx2 === (P - u) % P) {
    x = x * SQRT_M1 % P;
  } else {
    return false;
  }
  return !(x === 0n && sign === 1);
}
function isStrictPublicKey(publicKey) {
  if (publicKey.length !== 32 || isNonCanonicalPoint(publicKey) || hasSmallOrder(publicKey)) return false;
  const hex = Buffer.from(publicKey).toString("hex");
  let ok = strictCache.get(hex);
  if (ok === void 0) {
    ok = decodesToPoint(publicKey);
    if (strictCache.size >= 4096) strictCache.clear();
    strictCache.set(hex, ok);
  }
  return ok;
}
var strictCache = /* @__PURE__ */ new Map();
function ed25519Verify(publicKey, message, signature) {
  if (signature.length !== 64 || !isStrictPublicKey(publicKey)) return false;
  const R = signature.subarray(0, 32);
  const S = signature.subarray(32);
  if (hasSmallOrder(R) || isNonCanonicalPoint(R) || !scalarBelowL(S)) return false;
  try {
    return nodeVerify(null, message, publicKeyObject(publicKey), signature);
  } catch {
    return false;
  }
}

// ../packages/runrec/src/json.ts
var JsonError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "JsonError";
  }
};
var CanonicalError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "CanonicalError";
  }
};
var MAX_DEPTH = 64;
function parseStrict(text) {
  let i = 0;
  let depth = 0;
  const n2 = text.length;
  const ws = () => {
    while (i < n2) {
      const c = text.charCodeAt(i);
      if (c === 32 || c === 9 || c === 10 || c === 13) i++;
      else break;
    }
  };
  const err = (msg) => {
    throw new JsonError(`${msg} at offset ${i}`);
  };
  const value2 = () => {
    ws();
    if (i >= n2) err("unexpected end of input");
    const c = text[i];
    if (c === "{") return object();
    if (c === "[") return array();
    if (c === '"') return string();
    if (c === "t") return literal("true", true);
    if (c === "f") return literal("false", false);
    if (c === "n") return literal("null", null);
    if (c === "-" || c >= "0" && c <= "9") return number();
    return err(`unexpected character ${JSON.stringify(c)}`);
  };
  const literal = (word, v) => {
    if (text.startsWith(word, i)) {
      i += word.length;
      return v;
    }
    return err(`invalid literal`);
  };
  const number = () => {
    const m = /^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?/.exec(text.slice(i));
    if (!m) return err("invalid number");
    i += m[0].length;
    const v = Number(m[0]);
    if (!Number.isFinite(v)) err("number out of binary64 range");
    return v;
  };
  const string = () => {
    i++;
    const parts = [];
    let run2 = i;
    while (true) {
      if (i >= n2) err("unterminated string");
      const c = text.charCodeAt(i);
      if (c === 34) {
        if (i > run2) parts.push(text.slice(run2, i));
        i++;
        const s = parts.join("");
        if (!isWellFormed(s)) err("lone surrogate in string");
        return s;
      }
      if (c < 32) err("control character in string");
      if (c === 92) {
        if (i > run2) parts.push(text.slice(run2, i));
        let out = "";
        const e = text[i + 1];
        i += 2;
        switch (e) {
          case '"':
            out += '"';
            break;
          case "\\":
            out += "\\";
            break;
          case "/":
            out += "/";
            break;
          case "b":
            out += "\b";
            break;
          case "f":
            out += "\f";
            break;
          case "n":
            out += "\n";
            break;
          case "r":
            out += "\r";
            break;
          case "t":
            out += "	";
            break;
          case "u": {
            const hex = text.slice(i, i + 4);
            if (!/^[0-9a-fA-F]{4}$/.test(hex)) err("invalid unicode escape");
            out += String.fromCharCode(parseInt(hex, 16));
            i += 4;
            break;
          }
          default:
            err("invalid escape");
        }
        parts.push(out);
        run2 = i;
        continue;
      }
      i++;
    }
  };
  const enter = () => {
    if (++depth > MAX_DEPTH) err(`nesting deeper than ${MAX_DEPTH} levels`);
  };
  const array = () => {
    i++;
    enter();
    const out = [];
    ws();
    if (text[i] === "]") {
      i++;
      depth--;
      return out;
    }
    while (true) {
      out.push(value2());
      ws();
      if (text[i] === ",") {
        i++;
        continue;
      }
      if (text[i] === "]") {
        i++;
        depth--;
        return out;
      }
      err("expected , or ]");
    }
  };
  const object = () => {
    i++;
    enter();
    const out = /* @__PURE__ */ Object.create(null);
    const seen = /* @__PURE__ */ new Set();
    ws();
    if (text[i] === "}") {
      i++;
      depth--;
      return { ...out };
    }
    while (true) {
      ws();
      if (text[i] !== '"') err("expected member name");
      const key = string();
      if (seen.has(key)) err(`duplicate member name ${JSON.stringify(key)}`);
      seen.add(key);
      ws();
      if (text[i] !== ":") err("expected :");
      i++;
      out[key] = value2();
      ws();
      if (text[i] === ",") {
        i++;
        continue;
      }
      if (text[i] === "}") {
        i++;
        depth--;
        return { ...out };
      }
      err("expected , or }");
    }
  };
  const result = value2();
  ws();
  if (i !== n2) err("trailing characters");
  return result;
}
function isWellFormed(s) {
  for (let k = 0; k < s.length; k++) {
    const c = s.charCodeAt(k);
    if (c >= 55296 && c <= 56319) {
      const d = s.charCodeAt(k + 1);
      if (!(d >= 56320 && d <= 57343)) return false;
      k++;
    } else if (c >= 56320 && c <= 57343) {
      return false;
    }
  }
  return true;
}
function assertWellFormed(s) {
  if (!isWellFormed(s)) throw new JsonError("lone surrogate in string");
}
function canonicalize(value2) {
  if (value2 === null || typeof value2 === "boolean") return JSON.stringify(value2);
  if (typeof value2 === "number") {
    if (!Number.isFinite(value2)) throw new JsonError("non-finite number");
    return JSON.stringify(Object.is(value2, -0) ? 0 : value2);
  }
  if (typeof value2 === "string") {
    assertWellFormed(value2);
    return JSON.stringify(value2);
  }
  if (Array.isArray(value2)) return `[${value2.map(canonicalize).join(",")}]`;
  const keys = Object.keys(value2).sort((a, b) => a < b ? -1 : a > b ? 1 : 0);
  return `{${keys.map((k) => {
    assertWellFormed(k);
    return `${JSON.stringify(k)}:${canonicalize(value2[k])}`;
  }).join(",")}}`;
}
function canonicalBytes(value2) {
  return new TextEncoder().encode(canonicalize(value2));
}
function decodeUtf8(bytes3) {
  try {
    return new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(bytes3);
  } catch {
    throw new JsonError("invalid UTF-8");
  }
}
function parseCanonical(bytes3) {
  const text = decodeUtf8(bytes3);
  const value2 = parseStrict(text);
  if (canonicalize(value2) !== text) throw new CanonicalError("not in RFC 8785 canonical form");
  return value2;
}
function isObject(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

// ../packages/runrec/src/dsse.ts
var PAYLOAD_TYPE = "application/vnd.in-toto+json";
var STATEMENT_TYPE = "https://in-toto.io/Statement/v1";
var PREDICATE_BASE = "https://opsproof.systems/runrec/v0.1/";
function pae(payloadType, payload) {
  const enc2 = new TextEncoder();
  const t = enc2.encode(payloadType);
  const head = enc2.encode(`DSSEv1 ${t.length} ${payloadType} ${payload.length} `);
  const out = new Uint8Array(head.length + payload.length);
  out.set(head, 0);
  out.set(payload, head.length);
  return out;
}
function makeStatement(type, subjectName, subjectDigest2, predicate) {
  return {
    _type: STATEMENT_TYPE,
    subject: [{ name: subjectName, digest: { sha256: subjectDigest2.slice("sha256:".length) } }],
    predicateType: PREDICATE_BASE + type,
    predicate
  };
}
function attestation(statement, payload, keyid, sig) {
  const envelope = {
    payloadType: PAYLOAD_TYPE,
    payload: b64Encode(payload),
    signatures: [{ keyid, sig: b64Encode(sig) }]
  };
  return { envelope, bytes: canonicalBytes(envelope), digest: digestOf(payload), statement };
}
async function cosignWith(att, signer) {
  const payload = b64Decode(att.envelope.payload);
  const message = pae(PAYLOAD_TYPE, payload);
  const sig = await signer.sign(message);
  if (!ed25519Verify(signer.publicKey, message, sig)) throw new Error(`signer ${signer.keyId} produced a signature that does not verify`);
  return withSignature(att, signer.keyId, sig);
}
function withSignature(att, keyid, sig) {
  const envelope = { ...att.envelope, signatures: [...att.envelope.signatures, { keyid, sig: b64Encode(sig) }] };
  return { ...att, envelope, bytes: canonicalBytes(envelope) };
}
async function signStatementWith(statement, signer) {
  const payload = canonicalBytes(statement);
  const message = pae(PAYLOAD_TYPE, payload);
  const sig = await signer.sign(message);
  if (!ed25519Verify(signer.publicKey, message, sig)) throw new Error(`the signer for ${signer.keyId} returned a signature that does not verify`);
  return attestation(statement, payload, signer.keyId, sig);
}
var AttestationError = class extends Error {
  code;
  constructor(code, message) {
    super(message);
    this.name = "AttestationError";
    this.code = code;
  }
};
function layer(code, what, bytes3) {
  try {
    return parseCanonical(bytes3);
  } catch (e) {
    if (e instanceof CanonicalError) throw new AttestationError("canonical", `${what} is not in canonical form`);
    throw new AttestationError(code, `${what}: ${e.message}`);
  }
}
function parseAttestation(fileBytes, expected) {
  const env = layer("json", "envelope file", fileBytes);
  const bad = (msg) => {
    throw new AttestationError("envelope", msg);
  };
  if (!isObject(env)) bad("envelope is not an object");
  const e = env;
  const keys = Object.keys(e).sort().join(",");
  if (keys !== "payload,payloadType,signatures") bad(`envelope has unexpected members: ${keys}`);
  if (e.payloadType !== PAYLOAD_TYPE) bad(`unsupported payloadType ${JSON.stringify(e.payloadType)}`);
  if (typeof e.payload !== "string") bad("payload must be a string");
  const sigs = e.signatures;
  if (!Array.isArray(sigs) || sigs.length === 0) bad("envelope must carry a signature");
  for (const s of sigs) {
    if (!isObject(s) || Object.keys(s).sort().join(",") !== "keyid,sig" || typeof s.keyid !== "string" || typeof s.sig !== "string") {
      bad("malformed signature entry");
    }
  }
  let payload;
  let signatures;
  try {
    payload = b64Decode(e.payload);
    signatures = sigs.map((s) => ({ keyid: s.keyid, sig: b64Decode(s.sig) }));
  } catch (err) {
    return bad(`payload or sig: ${err.message}`);
  }
  const statementJson = layer("json", "payload", payload);
  const no = (msg) => {
    throw new AttestationError("statement", msg);
  };
  if (!isObject(statementJson)) no("statement is not an object");
  const st = statementJson;
  const stKeys = Object.keys(statementJson).sort().join(",");
  if (stKeys !== "_type,predicate,predicateType,subject") no(`statement has unexpected members: ${stKeys}`);
  if (st._type !== STATEMENT_TYPE) no("unsupported statement _type");
  if (!Array.isArray(st.subject) || st.subject.length !== 1) no("statement must have exactly one subject");
  const sub = st.subject[0];
  if (!isObject(sub) || Object.keys(sub).sort().join(",") !== "digest,name" || typeof sub.name !== "string" || !isObject(sub.digest) || typeof sub.digest.sha256 !== "string") {
    no("subject must be exactly { name, digest: { sha256 } }");
  }
  const sd = sub.digest;
  if (Object.keys(sd).join(",") !== "sha256" || !/^[0-9a-f]{64}$/.test(sd.sha256)) no("subject digest must be a single sha256");
  if (typeof st.predicateType !== "string" || !st.predicateType.startsWith(PREDICATE_BASE)) no(`unsupported predicateType ${String(st.predicateType)}`);
  const pt = st.predicateType.slice(PREDICATE_BASE.length);
  if (!["procedure", "enrollment", "event", "manifest", "register", "journal", "disclosure", "review"].includes(pt)) no(`unknown predicate type ${pt}`);
  if (expected !== void 0 && pt !== expected) no(`expected a ${expected} attestation, found ${pt}`);
  if (!isObject(st.predicate)) no("predicate must be an object");
  if (signatures.length !== 1 && pt !== "procedure") bad("envelope must carry exactly one signature");
  return {
    envelope: e,
    payload,
    digest: digestOf(payload),
    statement: st,
    predicateType: pt,
    keyid: signatures[0].keyid,
    sig: signatures[0].sig,
    signatures
  };
}
function verifySignature(att, publicKey, sig = att.sig) {
  return ed25519Verify(publicKey, pae(PAYLOAD_TYPE, att.payload), sig);
}
function subjectDigest(st) {
  return `sha256:${st.subject[0].digest.sha256}`;
}

// ../packages/runrec/src/errors.ts
var RecordError = class extends Error {
  step;
  code;
  constructor(step, code, message) {
    super(message);
    this.name = "RecordError";
    this.step = step;
    this.code = code;
  }
};
function fail(step, code, message) {
  throw new RecordError(step, code, message);
}
function check(cond, step, code, message) {
  if (!cond) throw new RecordError(step, code, message);
}

// ../packages/runrec/src/policy.ts
var PolicyFault = class extends Error {
};
var fault = (m) => {
  throw new PolicyFault(m);
};
var PAGE = 65536;
var MAX_PAGES = 16;
var FUEL = 1e7;
var MAX_DEPTH2 = 1e3;
var Reader = class {
  pos = 0;
  b;
  end;
  constructor(b, end = b.length) {
    this.b = b;
    this.end = end;
  }
  byte() {
    if (this.pos >= this.end) fault("unexpected end");
    return this.b[this.pos++];
  }
  u32() {
    let r = 0;
    for (let shift = 0; ; shift += 7) {
      const x = this.byte();
      if (shift === 28 && x > 15) fault("u32 too large");
      r += (x & 127) * 2 ** shift;
      if (!(x & 128)) return r;
      if (shift >= 28) fault("u32 too long");
    }
  }
  s(bits2) {
    let r = 0n;
    let shift = 0n;
    for (let n2 = 0; ; n2++) {
      if (n2 >= Math.ceil(bits2 / 7)) fault("signed LEB too long");
      const x = this.byte();
      r |= BigInt(x & 127) << shift;
      shift += 7n;
      if (!(x & 128)) {
        if (x & 64) r -= 1n << shift;
        const v = BigInt.asIntN(bits2, r);
        if (v !== r) fault("signed LEB out of range");
        return v;
      }
    }
  }
  bytes(n2) {
    if (this.pos + n2 > this.end) fault("unexpected end");
    const v = this.b.subarray(this.pos, this.pos + n2);
    this.pos += n2;
    return v;
  }
  valtype() {
    const t = this.byte();
    return t === 127 ? "i32" : t === 126 ? "i64" : fault(`value type 0x${t.toString(16)} is outside the profile`);
  }
};
var LOAD = { 40: ["i32", 4], 41: ["i64", 8], 44: ["i32", 1], 45: ["i32", 1], 46: ["i32", 2], 47: ["i32", 2], 48: ["i64", 1], 49: ["i64", 1], 50: ["i64", 2], 51: ["i64", 2], 52: ["i64", 4], 53: ["i64", 4] };
var STORE = { 54: ["i32", 4], 55: ["i64", 8], 58: ["i32", 1], 59: ["i32", 2], 60: ["i64", 1], 61: ["i64", 2], 62: ["i64", 4] };
function numeric(op) {
  if (op === 69) return [["i32"], "i32"];
  if (op >= 70 && op <= 79) return [["i32", "i32"], "i32"];
  if (op === 80) return [["i64"], "i32"];
  if (op >= 81 && op <= 90) return [["i64", "i64"], "i32"];
  if (op >= 103 && op <= 105) return [["i32"], "i32"];
  if (op >= 106 && op <= 120) return [["i32", "i32"], "i32"];
  if (op >= 121 && op <= 123) return [["i64"], "i64"];
  if (op >= 124 && op <= 138) return [["i64", "i64"], "i64"];
  if (op === 167) return [["i64"], "i32"];
  if (op === 172 || op === 173) return [["i32"], "i64"];
  return void 0;
}
function blocktype(r) {
  const b = r.byte();
  return b === 64 ? [] : b === 127 ? ["i32"] : b === 126 ? ["i64"] : fault("block type outside the profile");
}
function validate(m, ft, locals, code) {
  const r = new Reader(code);
  const vals = [];
  const ctrl = [{ op: 0, label: ft.results, out: ft.results, height: 0, unreachable: false, at: -1 }];
  const ends = /* @__PURE__ */ new Map();
  const elses = /* @__PURE__ */ new Map();
  const all = [...ft.params, ...locals];
  const pop = (want) => {
    const f = ctrl.at(-1);
    if (vals.length === f.height) return f.unreachable ? "any" : fault("operand stack underflow");
    const v = vals.pop();
    if (want && v !== "any" && v !== want) fault(`expected ${want}, found ${v}`);
    return v;
  };
  const pops = (ts) => [...ts].reverse().forEach((t) => pop(t));
  const unreachable = () => {
    const f = ctrl.at(-1);
    vals.length = f.height;
    f.unreachable = true;
  };
  const label2 = (n2) => n2 < ctrl.length ? ctrl[ctrl.length - 1 - n2] : fault("branch to an unknown label");
  const local = (i) => i < all.length ? all[i] : fault("unknown local");
  const mem = () => m.hasMemory || fault("no memory");
  while (ctrl.length) {
    const at = r.pos;
    const op = r.byte();
    if (op === 0) unreachable();
    else if (op === 1) continue;
    else if (op === 2 || op === 3 || op === 4) {
      const bt = blocktype(r);
      if (op === 4) pop("i32");
      ctrl.push({ op, label: op === 3 ? [] : bt, out: bt, height: vals.length, unreachable: false, at });
    } else if (op === 5) {
      const f = ctrl.at(-1);
      if (f.op !== 4 || elses.has(f.at)) fault("else without if");
      pops(f.out);
      if (vals.length !== f.height) fault("values left at else");
      elses.set(f.at, r.pos);
      f.unreachable = false;
    } else if (op === 11) {
      const f = ctrl.at(-1);
      pops(f.out);
      if (vals.length !== f.height) fault("values left at end");
      if (f.op === 4 && !elses.has(f.at) && f.out.length) fault("if without else must not yield a value");
      ctrl.pop();
      if (f.at >= 0) ends.set(f.at, r.pos);
      vals.push(...f.out);
    } else if (op === 12) {
      pops(label2(r.u32()).label);
      unreachable();
    } else if (op === 13) {
      const l = label2(r.u32()).label;
      pop("i32");
      pops(l);
      vals.push(...l);
    } else if (op === 14) {
      const n2 = r.u32();
      const targets = Array.from({ length: n2 + 1 }, () => label2(r.u32()).label);
      pop("i32");
      for (const t of targets) if (t.join() !== targets.at(-1).join()) fault("br_table targets differ");
      pops(targets.at(-1));
      unreachable();
    } else if (op === 15) {
      pops(ft.results);
      unreachable();
    } else if (op === 16) {
      const f = m.funcTypes[r.u32()] ?? fault("unknown function");
      pops(f.params);
      vals.push(...f.results);
    } else if (op === 26) pop();
    else if (op === 27) {
      pop("i32");
      const b = pop();
      const a = pop(b === "any" ? void 0 : b);
      vals.push(a === "any" ? b : a);
    } else if (op === 32) vals.push(local(r.u32()));
    else if (op === 33) pop(local(r.u32()));
    else if (op === 34) {
      const t = local(r.u32());
      pop(t);
      vals.push(t);
    } else if (op === 35) vals.push((m.globals[r.u32()] ?? fault("unknown global")).type);
    else if (op === 36) {
      const g = m.globals[r.u32()] ?? fault("unknown global");
      if (!g.mut) fault("global is immutable");
      pop(g.type);
    } else if (LOAD[op] || STORE[op]) {
      mem();
      const [t, size] = LOAD[op] ?? STORE[op];
      if (2 ** r.u32() > size) fault("alignment larger than natural");
      r.u32();
      if (STORE[op]) pop(t);
      pop("i32");
      if (LOAD[op]) vals.push(t);
    } else if (op === 63 || op === 64) {
      mem();
      if (r.byte() !== 0) fault("memory index");
      if (op === 64) pop("i32");
      vals.push("i32");
    } else if (op === 65) {
      r.s(32);
      vals.push("i32");
    } else if (op === 66) {
      r.s(64);
      vals.push("i64");
    } else {
      const n2 = numeric(op) ?? fault(`instruction 0x${op.toString(16)} is outside the profile`);
      pops(n2[0]);
      vals.push(n2[1]);
    }
  }
  if (r.pos !== code.length) fault("code after the function end");
  return { ends, elses };
}
function decodePolicy(bytes3) {
  const r = new Reader(bytes3);
  if ([...r.bytes(8)].join() !== "0,97,115,109,1,0,0,0") fault("not a WebAssembly 1.0 module");
  const types = [];
  let funcTypeIdx = [];
  let memMin;
  const globals = [];
  const exports = /* @__PURE__ */ new Map();
  const bodies = [];
  const data = [];
  let last = 0;
  while (r.pos < bytes3.length) {
    const id = r.byte();
    const size = r.u32();
    const s = new Reader(bytes3, r.pos + size);
    s.pos = r.pos;
    r.bytes(size);
    if (id === 0) continue;
    if (id <= last) fault("sections out of order or repeated");
    last = id;
    const vec = (f) => Array.from({ length: s.u32() }, f);
    if (id === 1) types.push(...vec(() => {
      if (s.byte() !== 96) fault("function type expected");
      const params = vec(() => s.valtype());
      const results = vec(() => s.valtype());
      if (results.length > 1) fault("at most one result");
      return { params, results };
    }));
    else if (id === 3) funcTypeIdx = vec(() => s.u32());
    else if (id === 4) vec(() => {
      s.byte();
      const f = s.byte();
      s.u32();
      if (f & 1) s.u32();
    });
    else if (id === 5) {
      const mems = vec(() => {
        const f = s.byte();
        const min = s.u32();
        const max = f & 1 ? s.u32() : void 0;
        if (f > 1 || min > MAX_PAGES || max !== void 0 && (max > MAX_PAGES || max < min)) fault("memory outside the profile");
        return min;
      });
      if (mems.length !== 1) fault("exactly one memory");
      memMin = mems[0];
    } else if (id === 6) globals.push(...vec(() => {
      const type = s.valtype();
      const mut = s.byte();
      if (mut > 1) fault("global mutability");
      const op = s.byte();
      if (op !== (type === "i32" ? 65 : 66)) fault("global initializer outside the profile");
      const v = s.s(type === "i32" ? 32 : 64);
      if (s.byte() !== 11) fault("global initializer outside the profile");
      return { type, mut: mut === 1, init: type === "i32" ? Number(v) : v };
    }));
    else if (id === 7) vec(() => {
      const name = new TextDecoder("utf-8", { fatal: true }).decode(s.bytes(s.u32()));
      const kind = s.byte();
      const index = s.u32();
      if (exports.has(name)) fault("duplicate export");
      exports.set(name, { kind, index });
    });
    else if (id === 10) bodies.push(...vec(() => s.bytes(s.u32())));
    else if (id === 11) data.push(...vec(() => {
      if (s.u32() !== 0 || s.byte() !== 65) fault("data segment outside the profile");
      const offset = Number(s.s(32)) >>> 0;
      if (s.byte() !== 11) fault("data segment outside the profile");
      return { offset, bytes: s.bytes(s.u32()) };
    }));
    else fault(`section ${id} is outside the profile`);
    if (s.pos !== s.end) fault(`section ${id} has trailing bytes`);
  }
  if (memMin === void 0) fault("no memory");
  if (bodies.length !== funcTypeIdx.length) fault("function and code sections differ");
  const funcTypes = funcTypeIdx.map((i) => types[i] ?? fault("unknown type"));
  for (const d of data) if (d.offset + d.bytes.length > memMin * PAGE) fault("data outside the initial memory");
  const funcs = bodies.map((body, i) => {
    const b = new Reader(body);
    const locals = [];
    for (let n2 = b.u32(); n2 > 0; n2--) {
      const count = b.u32();
      const t = b.valtype();
      if (locals.length + count > 5e4) fault("too many locals");
      for (let k = 0; k < count; k++) locals.push(t);
    }
    const code = body.subarray(b.pos);
    return { type: funcTypes[i], locals, code, ...validate({ types, funcTypes, globals, hasMemory: true }, funcTypes[i], locals, code) };
  });
  const fn = (name, params, results) => {
    const e = exports.get(name);
    const f = e && e.kind === 0 ? funcs[e.index] : void 0;
    if (!f || f.type.params.join() !== params || f.type.results.join() !== results) fault(`no export ${name} of the profile's type`);
    return e.index;
  };
  return { funcs, memMin, globals, exports: /* @__PURE__ */ new Map([["alloc", fn("alloc", "i32", "i32")], ["decide", fn("decide", "i32,i32", "i64")]]), data };
}
var s64 = (x) => BigInt.asIntN(64, x);
var u64 = (x) => BigInt.asUintN(64, x);
var MIN32 = -(2 ** 31);
var MIN64 = -(1n << 63n);
var bits = (x) => u64(x).toString(2).replace(/0/g, "").length;
var Machine = class {
  mem;
  view;
  pages;
  globals;
  fuel = FUEL;
  depth = 0;
  m;
  constructor(m) {
    this.m = m;
    this.pages = m.memMin;
    this.mem = new Uint8Array(m.memMin * PAGE);
    this.view = new DataView(this.mem.buffer);
    for (const d of m.data) this.mem.set(d.bytes, d.offset);
    this.globals = m.globals.map((g) => g.init);
  }
  addr(base, offset, size) {
    const a = (base >>> 0) + offset;
    if (a + size > this.mem.length) fault("memory access out of bounds");
    return a;
  }
  call(fi, args2) {
    if (++this.depth > MAX_DEPTH2) fault("call depth exceeded");
    const f = this.m.funcs[fi];
    const locals = [...args2, ...f.locals.map((t) => t === "i32" ? 0 : 0n)];
    const st = [];
    const labels = [];
    const r = new Reader(f.code);
    const branch = (n2) => {
      if (n2 >= labels.length) {
        r.pos = f.code.length;
        return;
      }
      const l = labels[labels.length - 1 - n2];
      const keep = st.splice(st.length - l.arity, l.arity);
      st.length = l.height;
      st.push(...keep);
      labels.length -= l.loop ? n2 : n2 + 1;
      r.pos = l.cont;
    };
    const pop = () => st.pop();
    const i32 = () => st.pop();
    const i64 = () => st.pop();
    for (; ; ) {
      if (r.pos >= f.code.length) break;
      if (--this.fuel < 0) fault("out of fuel");
      const at = r.pos;
      const op = r.byte();
      switch (op) {
        case 0:
          fault("unreachable");
        case 1:
          break;
        case 2:
        case 3: {
          const bt = blocktype(r);
          labels.push(op === 3 ? { cont: r.pos, arity: 0, height: st.length, loop: true } : { cont: f.ends.get(at), arity: bt.length, height: st.length, loop: false });
          break;
        }
        case 4: {
          const bt = blocktype(r);
          const c = i32();
          labels.push({ cont: f.ends.get(at), arity: bt.length, height: st.length, loop: false });
          if (!c) {
            const e = f.elses.get(at);
            if (e !== void 0) r.pos = e;
            else {
              r.pos = f.ends.get(at);
              labels.pop();
            }
          }
          break;
        }
        case 5:
          branch(0);
          break;
        // the then-branch reached else: on to the end
        case 11:
          if (labels.length) labels.pop();
          else r.pos = f.code.length;
          break;
        case 12:
          branch(r.u32());
          break;
        case 13: {
          const l = r.u32();
          if (i32()) branch(l);
          break;
        }
        case 14: {
          const n2 = r.u32();
          const ts = Array.from({ length: n2 + 1 }, () => r.u32());
          const i = i32() >>> 0;
          branch(ts[Math.min(i, n2)]);
          break;
        }
        case 15:
          r.pos = f.code.length;
          break;
        case 16: {
          const gi = r.u32();
          const a = st.splice(st.length - this.m.funcs[gi].type.params.length);
          const v = this.call(gi, a);
          if (v !== void 0) st.push(v);
          break;
        }
        case 26:
          pop();
          break;
        case 27: {
          const c = i32();
          const b = pop();
          const a = pop();
          st.push(c ? a : b);
          break;
        }
        case 32:
          st.push(locals[r.u32()]);
          break;
        case 33:
          locals[r.u32()] = pop();
          break;
        case 34:
          locals[r.u32()] = st.at(-1);
          break;
        case 35:
          st.push(this.globals[r.u32()]);
          break;
        case 36:
          this.globals[r.u32()] = pop();
          break;
        case 63:
          r.byte();
          st.push(this.pages);
          break;
        case 64: {
          r.byte();
          const n2 = i32() >>> 0;
          const old = this.pages;
          if (old + n2 > MAX_PAGES) st.push(-1);
          else {
            const grown = new Uint8Array((old + n2) * PAGE);
            grown.set(this.mem);
            this.mem = grown;
            this.view = new DataView(grown.buffer);
            this.pages = old + n2;
            st.push(old);
          }
          break;
        }
        case 65:
          st.push(Number(r.s(32)));
          break;
        case 66:
          st.push(r.s(64));
          break;
        default: {
          if (LOAD[op] || STORE[op]) {
            r.u32();
            const off = r.u32();
            const [, size] = LOAD[op] ?? STORE[op];
            if (STORE[op]) {
              const v = pop();
              const a = this.addr(i32(), off, size);
              const big = typeof v === "bigint" ? u64(v) : BigInt(v >>> 0);
              for (let k = 0; k < size; k++) this.mem[a + k] = Number(big >> BigInt(8 * k) & 0xffn);
            } else {
              const a = this.addr(i32(), off, size);
              let x = 0n;
              for (let k = size - 1; k >= 0; k--) x = x << 8n | BigInt(this.mem[a + k]);
              const signed = op === 40 || op === 41 || [44, 46, 48, 50, 52].includes(op);
              if (signed) x = BigInt.asIntN(size * 8, x);
              st.push(LOAD[op][0] === "i32" ? Number(BigInt.asIntN(32, x)) : s64(x));
            }
            break;
          }
          st.push(this.numeric(op, st));
        }
      }
    }
    this.depth--;
    return f.type.results.length ? st.pop() : void 0;
  }
  numeric(op, st) {
    const b1 = (f) => f(st.pop());
    const b2 = (f) => {
      const b = st.pop();
      return f(st.pop(), b);
    };
    const l1 = (f) => f(st.pop());
    const l2 = (f) => {
      const b = st.pop();
      return f(st.pop(), b);
    };
    const n2 = (x) => x ? 1 : 0;
    const u = (x) => x >>> 0;
    switch (op) {
      case 69:
        return b1((a) => n2(a === 0));
      case 70:
        return b2((a, b) => n2(a === b));
      case 71:
        return b2((a, b) => n2(a !== b));
      case 72:
        return b2((a, b) => n2(a < b));
      case 73:
        return b2((a, b) => n2(u(a) < u(b)));
      case 74:
        return b2((a, b) => n2(a > b));
      case 75:
        return b2((a, b) => n2(u(a) > u(b)));
      case 76:
        return b2((a, b) => n2(a <= b));
      case 77:
        return b2((a, b) => n2(u(a) <= u(b)));
      case 78:
        return b2((a, b) => n2(a >= b));
      case 79:
        return b2((a, b) => n2(u(a) >= u(b)));
      case 80:
        return l1((a) => n2(a === 0n));
      case 81:
        return l2((a, b) => n2(a === b));
      case 82:
        return l2((a, b) => n2(a !== b));
      case 83:
        return l2((a, b) => n2(a < b));
      case 84:
        return l2((a, b) => n2(u64(a) < u64(b)));
      case 85:
        return l2((a, b) => n2(a > b));
      case 86:
        return l2((a, b) => n2(u64(a) > u64(b)));
      case 87:
        return l2((a, b) => n2(a <= b));
      case 88:
        return l2((a, b) => n2(u64(a) <= u64(b)));
      case 89:
        return l2((a, b) => n2(a >= b));
      case 90:
        return l2((a, b) => n2(u64(a) >= u64(b)));
      case 103:
        return b1((a) => Math.clz32(a));
      case 104:
        return b1((a) => a === 0 ? 32 : 31 - Math.clz32(a & -a));
      case 105:
        return b1((a) => bits(BigInt(u(a))));
      case 106:
        return b2((a, b) => a + b | 0);
      case 107:
        return b2((a, b) => a - b | 0);
      case 108:
        return b2((a, b) => Math.imul(a, b));
      case 109:
        return b2((a, b) => b === 0 ? fault("integer divide by zero") : a === MIN32 && b === -1 ? fault("integer overflow") : Math.trunc(a / b) | 0);
      case 110:
        return b2((a, b) => b === 0 ? fault("integer divide by zero") : Math.trunc(u(a) / u(b)) | 0);
      case 111:
        return b2((a, b) => b === 0 ? fault("integer divide by zero") : a % b | 0);
      case 112:
        return b2((a, b) => b === 0 ? fault("integer divide by zero") : u(a) % u(b) | 0);
      case 113:
        return b2((a, b) => a & b);
      case 114:
        return b2((a, b) => a | b);
      case 115:
        return b2((a, b) => a ^ b);
      case 116:
        return b2((a, b) => a << (b & 31));
      case 117:
        return b2((a, b) => a >> (b & 31));
      case 118:
        return b2((a, b) => a >>> (b & 31) | 0);
      case 119:
        return b2((a, b) => b & 31 ? a << (b & 31) | a >>> 32 - (b & 31) | 0 : a);
      case 120:
        return b2((a, b) => b & 31 ? a >>> (b & 31) | a << 32 - (b & 31) | 0 : a);
      case 121:
        return l1((a) => BigInt(a === 0n ? 64 : 64 - u64(a).toString(2).length));
      case 122:
        return l1((a) => {
          if (a === 0n) return 64n;
          let c = 0n;
          let x = u64(a);
          while (!(x & 1n)) {
            x >>= 1n;
            c++;
          }
          return c;
        });
      case 123:
        return l1((a) => BigInt(bits(a)));
      case 124:
        return l2((a, b) => s64(a + b));
      case 125:
        return l2((a, b) => s64(a - b));
      case 126:
        return l2((a, b) => s64(a * b));
      case 127:
        return l2((a, b) => b === 0n ? fault("integer divide by zero") : a === MIN64 && b === -1n ? fault("integer overflow") : s64(a / b));
      case 128:
        return l2((a, b) => b === 0n ? fault("integer divide by zero") : s64(u64(a) / u64(b)));
      case 129:
        return l2((a, b) => b === 0n ? fault("integer divide by zero") : s64(a % b));
      case 130:
        return l2((a, b) => b === 0n ? fault("integer divide by zero") : s64(u64(a) % u64(b)));
      case 131:
        return l2((a, b) => a & b);
      case 132:
        return l2((a, b) => a | b);
      case 133:
        return l2((a, b) => a ^ b);
      case 134:
        return l2((a, b) => s64(a << (u64(b) & 63n)));
      case 135:
        return l2((a, b) => a >> (u64(b) & 63n));
      case 136:
        return l2((a, b) => s64(u64(a) >> (u64(b) & 63n)));
      case 137:
        return l2((a, b) => {
          const k = u64(b) & 63n;
          return k ? s64(u64(a) << k | u64(a) >> 64n - k) : a;
        });
      case 138:
        return l2((a, b) => {
          const k = u64(b) & 63n;
          return k ? s64(u64(a) >> k | u64(a) << 64n - k) : a;
        });
      case 167:
        return l1((a) => Number(BigInt.asIntN(32, a)));
      case 172:
        return BigInt(st.pop());
      case 173:
        return BigInt(st.pop() >>> 0);
    }
    return fault(`instruction 0x${op.toString(16)} is outside the profile`);
  }
};
function runDecoded(m, input) {
  const vm = new Machine(m);
  try {
    const ptr = vm.call(m.exports.get("alloc"), [input.length | 0]);
    vm.mem.set(input, vm.addr(ptr, 0, input.length));
    const r = u64(vm.call(m.exports.get("decide"), [ptr, input.length | 0]));
    const at = Number(r >> 32n);
    const len = Number(r & 0xffffffffn);
    if (at + len > vm.mem.length) return void 0;
    return vm.mem.slice(at, at + len);
  } catch (e) {
    if (e instanceof PolicyFault) return void 0;
    throw e;
  }
}

// ../packages/runrec/src/schema.ts
var GRANTS = ["author", "operate", "act", "observe", "authorize", "decide", "start", "review", "disclose"];
var DECISION_TYPES = ["release", "rework", "scrap", "accept", "reject", "waive", "stop"];
var ID_RE = /^[a-z0-9][a-z0-9._-]{0,127}$/;
var TIME_RE = /^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]{1,9})?Z$/;
var VERSION_RE = /^[0-9A-Za-z][0-9A-Za-z._+-]{0,63}$/;
var MAX_SEQ = 999999;
var MEDIA_RE = /^[a-z0-9][a-z0-9!#$&^_.+-]*\/[a-z0-9][a-z0-9!#$&^_.+-]*$/;
var MEDIA_PATTERN_RE = /^[a-z0-9][a-z0-9!#$&^_.+-]*\/([a-z0-9][a-z0-9!#$&^_.+-]*|\*)$/;
var Reader2 = class _Reader {
  step;
  path;
  constructor(step, path) {
    this.step = step;
    this.path = path;
  }
  at(sub) {
    return new _Reader(this.step, typeof sub === "number" ? `${this.path}[${sub}]` : `${this.path}.${sub}`);
  }
  fail(msg) {
    return fail(this.step, "schema", `${this.path}: ${msg}`);
  }
  /** An object with exactly these members. `ext` is allowed only where `allowExt` is set (predicate and event top level). */
  object(v, required, optional = [], allowExt = false) {
    if (!isObject(v)) this.fail("must be an object");
    const o = v;
    for (const k of required) if (!(k in o)) this.fail(`missing member ${k}`);
    const allowed = /* @__PURE__ */ new Set([...required, ...optional, ...allowExt ? ["ext"] : []]);
    for (const k of Object.keys(o)) if (!allowed.has(k)) this.fail(`unknown member ${k}`);
    if ("ext" in o && allowExt && !isObject(o.ext)) this.at("ext").fail("must be an object");
    return o;
  }
  string(v, nonEmpty = true) {
    if (typeof v !== "string" || nonEmpty && v.length === 0) this.fail("must be a non-empty string");
    return v;
  }
  id(v) {
    const s = this.string(v);
    if (!ID_RE.test(s)) this.fail(`invalid identifier ${JSON.stringify(s)}`);
    return s;
  }
  number(v) {
    if (typeof v !== "number" || !Number.isFinite(v)) this.fail("must be a number");
    return v;
  }
  int(v, min, max = Number.MAX_SAFE_INTEGER) {
    const n2 = this.number(v);
    if (!Number.isSafeInteger(n2) || n2 < min || n2 > max) this.fail(`must be an integer in [${min}, ${max === Number.MAX_SAFE_INTEGER ? "2^53-1" : max}]`);
    return n2;
  }
  version(v) {
    const s = this.string(v);
    if (!VERSION_RE.test(s)) this.fail(`invalid version ${JSON.stringify(s)}`);
    return s;
  }
  bool(v) {
    if (typeof v !== "boolean") this.fail("must be a boolean");
    return v;
  }
  oneOf(v, values) {
    if (typeof v !== "string" || !values.includes(v)) this.fail(`must be one of ${values.join(", ")}`);
    return v;
  }
  array(v, item, opts = {}) {
    if (!Array.isArray(v)) this.fail("must be an array");
    const arr = v;
    if (opts.nonEmpty && arr.length === 0) this.fail("must not be empty");
    const out = arr.map((x, i) => item(this.at(i), x));
    if (opts.unique) {
      const seen = /* @__PURE__ */ new Set();
      for (const x of out) {
        const key = canonicalize(x);
        if (seen.has(key)) this.fail(`duplicate entry ${key}`);
        seen.add(key);
      }
    }
    return out;
  }
  digest(v) {
    if (!isDigest(v)) this.fail("must be a sha256 digest");
    return v;
  }
  time(v) {
    const s = this.string(v);
    const m = TIME_RE.exec(s);
    if (!m) this.fail("must be an RFC 3339 UTC timestamp ending in Z");
    const [y, mo, d, h, mi, se] = [s.slice(0, 4), s.slice(5, 7), s.slice(8, 10), s.slice(11, 13), s.slice(14, 16), s.slice(17, 19)].map(Number);
    const t = /* @__PURE__ */ new Date(0);
    t.setUTCFullYear(y, mo - 1, d);
    t.setUTCHours(h, mi, se, 0);
    if (y < 1 || t.getUTCFullYear() !== y || t.getUTCMonth() !== mo - 1 || t.getUTCDate() !== d || t.getUTCHours() !== h || t.getUTCMinutes() !== mi || t.getUTCSeconds() !== se) {
      this.fail("is not a valid calendar date and time");
    }
    return s;
  }
  mediaType(v) {
    const s = this.string(v);
    if (!MEDIA_RE.test(s)) this.fail("must be a lowercase type/subtype media type without parameters");
    return s;
  }
  mediaPattern(v) {
    const s = this.string(v);
    if (!MEDIA_PATTERN_RE.test(s)) this.fail("must be a lowercase type/subtype or type/* pattern");
    return s;
  }
};
function mediaMatches(pattern, mediaType) {
  if (pattern.endsWith("/*")) return mediaType.startsWith(pattern.slice(0, -1));
  return pattern === mediaType;
}
function limitValue(l, inputs) {
  if (typeof l === "number") return l;
  const v = inputs?.[l.input];
  if (typeof v !== "number") throw new Error(`input ${l.input} is not bound to a number`);
  return v * (l.scale ?? 1) + (l.offset ?? 0);
}
function parseProcedure(v, r = new Reader2(4, "procedure")) {
  const o = r.object(v, ["procedure_id", "version", "title", "roles", "bounds", "steps"], ["purpose", "source", "parties", "supersedes", "change", "inputs", "subjects", "outputs"], true);
  if ("purpose" in o) r.at("purpose").string(o.purpose, false);
  if ("source" in o) {
    const so = r.at("source").object(o.source, ["title"], ["digest"]);
    r.at("source.title").string(so.title);
    if ("digest" in so) r.at("source.digest").digest(so.digest);
  }
  const p = {
    procedure_id: r.at("procedure_id").id(o.procedure_id),
    version: r.at("version").version(o.version),
    title: r.at("title").string(o.title),
    roles: r.at("roles").array(o.roles, (rr, x) => rr.id(x), { unique: true }),
    bounds: r.at("bounds").array(o.bounds, parseBound),
    steps: r.at("steps").array(o.steps, parseStep, { nonEmpty: true })
  };
  if ("parties" in o) {
    p.parties = r.at("parties").array(o.parties, (rr, x) => {
      const q = rr.object(x, ["party_id", "display_name"]);
      return { party_id: rr.at("party_id").id(q.party_id), display_name: rr.at("display_name").string(q.display_name) };
    }, { nonEmpty: true });
    if (new Set(p.parties.map((x) => x.party_id)).size !== p.parties.length) r.at("parties").fail("party_id values must be unique");
  }
  if ("supersedes" in o) {
    const q = r.at("supersedes").object(o.supersedes, ["procedure_id", "version", "digest"]);
    p.supersedes = { procedure_id: r.at("supersedes.procedure_id").id(q.procedure_id), version: r.at("supersedes.version").version(q.version), digest: r.at("supersedes.digest").digest(q.digest) };
    if (p.supersedes.procedure_id !== p.procedure_id) r.at("supersedes.procedure_id").fail("a version supersedes an earlier version of the same Procedure");
    if (p.supersedes.version === p.version) r.at("supersedes.version").fail("a version cannot supersede itself");
  }
  if ("change" in o) {
    const q = r.at("change").object(o.change, ["summary"], ["basis"]);
    p.change = { summary: r.at("change.summary").string(q.summary) };
    if ("basis" in q) p.change.basis = r.at("change.basis").array(q.basis, (rr, x) => rr.digest(x));
  }
  if ("change" in o !== "supersedes" in o) r.at("change").fail("change is present exactly when supersedes is");
  if ("inputs" in o) p.inputs = r.at("inputs").array(o.inputs, parseInput);
  if ("subjects" in o) {
    p.subjects = r.at("subjects").array(o.subjects, (rr, x) => {
      const q = rr.object(x, ["kind", "required"]);
      return { kind: rr.at("kind").id(q.kind), required: rr.at("required").bool(q.required) };
    });
  }
  if ("outputs" in o) {
    p.outputs = r.at("outputs").array(o.outputs, (rr, x) => {
      const q = rr.object(x, ["output_id", "step_id", "criterion_id"]);
      return { output_id: rr.at("output_id").id(q.output_id), step_id: rr.at("step_id").id(q.step_id), criterion_id: rr.at("criterion_id").id(q.criterion_id) };
    });
  }
  validateProcedure(p, r);
  return p;
}
function parseInput(r, v) {
  if (!isObject(v)) return r.fail("must be an object");
  const kind = r.at("kind").oneOf(v.kind, ["number", "text", "artifact", "output"]);
  if (kind === "number") {
    const q2 = r.object(v, ["input_id", "kind", "unit"], ["range"]);
    const i = { input_id: r.at("input_id").id(q2.input_id), kind, unit: r.at("unit").string(q2.unit) };
    if ("range" in q2) {
      const g = r.at("range").object(q2.range, ["min", "max"]);
      i.range = { min: r.at("range.min").number(g.min), max: r.at("range.max").number(g.max) };
      if (i.range.min > i.range.max) r.at("range").fail("min must not exceed max");
    }
    return i;
  }
  if (kind === "text") return { input_id: r.at("input_id").id(r.object(v, ["input_id", "kind"]).input_id), kind };
  if (kind === "artifact") {
    const q2 = r.object(v, ["input_id", "kind", "media_types"]);
    return { input_id: r.at("input_id").id(q2.input_id), kind, media_types: r.at("media_types").array(q2.media_types, (rr, x) => rr.mediaPattern(x), { nonEmpty: true, unique: true }) };
  }
  const q = r.object(v, ["input_id", "kind", "from"]);
  const f = r.at("from").object(q.from, ["procedure_id", "output_id"]);
  return { input_id: r.at("input_id").id(q.input_id), kind, from: { procedure_id: r.at("from.procedure_id").id(f.procedure_id), output_id: r.at("from.output_id").id(f.output_id) } };
}
function parseLimit(r, v) {
  if (typeof v === "number") return r.number(v);
  const q = r.object(v, ["input"], ["scale", "offset"]);
  return { input: r.at("input").id(q.input), ..."scale" in q ? { scale: r.at("scale").number(q.scale) } : {}, ..."offset" in q ? { offset: r.at("offset").number(q.offset) } : {} };
}
function parseBound(r, v) {
  const o = r.object(v, ["bound_id", "action_type", "parameter", "min", "max"], ["max_count_per_run", "when"]);
  const b = {
    bound_id: r.at("bound_id").id(o.bound_id),
    action_type: r.at("action_type").id(o.action_type),
    parameter: r.at("parameter").id(o.parameter),
    min: parseLimit(r.at("min"), o.min),
    max: parseLimit(r.at("max"), o.max)
  };
  if (typeof b.min === "number" && typeof b.max === "number" && b.min > b.max) r.fail("min must not exceed max");
  if ("max_count_per_run" in o) b.max_count_per_run = r.at("max_count_per_run").int(o.max_count_per_run, 1);
  if ("when" in o) {
    const wr = r.at("when");
    const w = wr.object(o.when, ["quantity", "unit", "min", "max"]);
    b.when = { quantity: wr.at("quantity").id(w.quantity), unit: wr.at("unit").string(w.unit), min: wr.at("min").number(w.min), max: wr.at("max").number(w.max) };
    if (b.when.min > b.when.max) wr.fail("min must not exceed max");
  }
  return b;
}
function parseCriterion(r, v) {
  if (!isObject(v)) r.fail("must be an object");
  const t = v.type;
  if (t === "measurement") {
    const o = r.object(v, ["criterion_id", "type", "quantity", "unit", "tolerance", "consecutive", "max_observations"]);
    const tol = r.at("tolerance").object(o.tolerance, ["min", "max"]);
    const c = {
      criterion_id: r.at("criterion_id").id(o.criterion_id),
      type: "measurement",
      quantity: r.at("quantity").id(o.quantity),
      unit: r.at("unit").string(o.unit),
      tolerance: { min: r.at("tolerance.min").number(tol.min), max: r.at("tolerance.max").number(tol.max) },
      consecutive: r.at("consecutive").int(o.consecutive, 1),
      max_observations: r.at("max_observations").int(o.max_observations, 1)
    };
    if (c.tolerance.min > c.tolerance.max) r.fail("tolerance.min must not exceed tolerance.max");
    if (c.max_observations < c.consecutive) r.fail("max_observations must be >= consecutive");
    return c;
  }
  if (t === "artifact") {
    const o = r.object(v, ["criterion_id", "type", "media_types"]);
    return {
      criterion_id: r.at("criterion_id").id(o.criterion_id),
      type: "artifact",
      media_types: r.at("media_types").array(o.media_types, (rr, x) => rr.mediaPattern(x), { nonEmpty: true, unique: true })
    };
  }
  if (t === "confirmation") {
    const o = r.object(v, ["criterion_id", "type", "statement", "roles"]);
    return {
      criterion_id: r.at("criterion_id").id(o.criterion_id),
      type: "confirmation",
      statement: r.at("statement").string(o.statement),
      roles: r.at("roles").array(o.roles, (rr, x) => rr.id(x), { nonEmpty: true, unique: true })
    };
  }
  if (t === "derived") {
    const o = r.object(v, ["criterion_id", "type", "policy", "inputs", "result"]);
    const p = r.at("policy").object(o.policy, ["digest", "media_type", "size"], ["title"]);
    if (p.media_type !== "application/wasm") r.at("policy.media_type").fail("must be application/wasm");
    const policy = { digest: r.at("policy.digest").digest(p.digest), media_type: "application/wasm", size: r.at("policy.size").int(p.size, 1) };
    if ("title" in p) policy.title = r.at("policy.title").string(p.title);
    const inputs = r.at("inputs").array(o.inputs, (rr, x) => {
      if (isObject(x) && "quantity" in x) {
        const q = rr.object(x, ["name", "quantity", "unit", "last"]);
        return { name: rr.at("name").id(q.name), quantity: rr.at("quantity").id(q.quantity), unit: rr.at("unit").string(q.unit), last: rr.at("last").int(q.last, 1) };
      }
      if (isObject(x) && "actions" in x) {
        const q = rr.object(x, ["name", "actions"]);
        return { name: rr.at("name").id(q.name), actions: rr.at("actions").id(q.actions) };
      }
      if (isObject(x) && "input" in x) {
        const q = rr.object(x, ["name", "input"]);
        return { name: rr.at("name").id(q.name), input: rr.at("input").id(q.input) };
      }
      if (isObject(x) && "derived" in x) {
        const q = rr.object(x, ["name", "derived"]);
        return { name: rr.at("name").id(q.name), derived: rr.at("derived").id(q.derived) };
      }
      return rr.fail("must read a quantity, actions, an input or a derived criterion");
    }, { nonEmpty: true });
    if (new Set(inputs.map((i) => i.name)).size !== inputs.length) r.at("inputs").fail("input names must be unique");
    let result;
    if (o.result === "conforming") result = "conforming";
    else {
      const b = r.at("result").object(o.result, ["min", "max"]);
      result = { min: r.at("result.min").number(b.min), max: r.at("result.max").number(b.max) };
      if (result.min > result.max) r.at("result").fail("min must not exceed max");
    }
    return { criterion_id: r.at("criterion_id").id(o.criterion_id), type: "derived", policy, inputs, result };
  }
  return r.at("type").fail("must be measurement, artifact, confirmation or derived");
}
function parseDecisionReq(r, v) {
  const o = r.object(v, ["decision_id", "types", "decider_roles", "required"]);
  return {
    decision_id: r.at("decision_id").id(o.decision_id),
    types: r.at("types").array(o.types, (rr, x) => rr.oneOf(x, DECISION_TYPES), { nonEmpty: true, unique: true }),
    decider_roles: r.at("decider_roles").array(o.decider_roles, (rr, x) => rr.id(x), { nonEmpty: true, unique: true }),
    required: r.at("required").bool(o.required)
  };
}
function parseStep(r, v) {
  const o = r.object(v, ["step_id", "title", "requires", "performers", "evidence", "decisions"], ["instructions", "proposals", "actions", "children"]);
  if ("instructions" in o) r.at("instructions").string(o.instructions, false);
  const s = {
    step_id: r.at("step_id").id(o.step_id),
    title: r.at("title").string(o.title),
    requires: r.at("requires").array(o.requires, (rr, x) => rr.id(x), { unique: true }),
    performers: r.at("performers").array(
      o.performers,
      (rr, x) => {
        const po = rr.object(x, ["kind", "role"]);
        return {
          kind: rr.at("kind").oneOf(po.kind, ["human", "system"]),
          role: po.role === null ? null : rr.at("role").id(po.role)
        };
      },
      { unique: true }
    ),
    evidence: r.at("evidence").array(o.evidence, parseCriterion),
    decisions: r.at("decisions").array(o.decisions, parseDecisionReq)
  };
  if ("proposals" in o) {
    const rr = r.at("proposals");
    const po = rr.object(o.proposals, ["allowed_kinds", "bound_ids", "fallback_roles"]);
    s.proposals = {
      allowed_kinds: rr.at("allowed_kinds").array(po.allowed_kinds, (q, x) => q.oneOf(x, ["human", "agent"]), { nonEmpty: true, unique: true }),
      bound_ids: rr.at("bound_ids").array(po.bound_ids, (q, x) => q.id(x), { unique: true }),
      fallback_roles: rr.at("fallback_roles").array(po.fallback_roles, (q, x) => q.id(x), { unique: true })
    };
  }
  if ("actions" in o) {
    const rr = r.at("actions");
    const ao = rr.object(o.actions, ["types", "requires_authorization"]);
    s.actions = {
      types: rr.at("types").array(ao.types, (q, x) => q.id(x), { nonEmpty: true, unique: true }),
      requires_authorization: rr.at("requires_authorization").bool(ao.requires_authorization)
    };
  }
  if ("children" in o) {
    const rr = r.at("children");
    const co = rr.object(o.children, ["procedure_id", "starters", "min", "require"], ["max"]);
    s.children = {
      procedure_id: rr.at("procedure_id").id(co.procedure_id),
      starters: rr.at("starters").array(co.starters, (q, x) => {
        const so = q.object(x, ["kind", "role"]);
        return { kind: q.at("kind").oneOf(so.kind, ["human", "agent"]), role: so.role === null ? null : q.at("role").id(so.role) };
      }, { nonEmpty: true }),
      min: rr.at("min").int(co.min, 1),
      require: rr.at("require").oneOf(co.require, ["all_complete", "min_complete"])
    };
    if ("max" in co) s.children.max = rr.at("max").int(co.max, 1);
  }
  return s;
}
function validateProcedure(p, r) {
  const roles = new Set(p.roles);
  const stepIds = /* @__PURE__ */ new Set();
  const criterionIds = /* @__PURE__ */ new Set();
  const decisionIds = /* @__PURE__ */ new Set();
  const bounds = /* @__PURE__ */ new Map();
  for (const b of p.bounds) {
    if (bounds.has(b.bound_id)) r.fail(`duplicate bound_id ${b.bound_id}`);
    bounds.set(b.bound_id, b);
  }
  for (const s of p.steps) {
    if (stepIds.has(s.step_id)) r.fail(`duplicate step_id ${s.step_id}`);
    stepIds.add(s.step_id);
  }
  const inputs = /* @__PURE__ */ new Map();
  for (const i of p.inputs ?? []) {
    if (inputs.has(i.input_id)) r.at("inputs").fail(`duplicate input_id ${i.input_id}`);
    inputs.set(i.input_id, i);
  }
  for (const b of p.bounds) {
    for (const l of [b.min, b.max]) {
      if (typeof l !== "number" && inputs.get(l.input)?.kind !== "number") r.at(`bounds.${b.bound_id}`).fail(`a limit reads ${l.input}, which is not a number input of this Procedure`);
    }
  }
  if (new Set((p.subjects ?? []).map((x) => x.kind)).size !== (p.subjects ?? []).length) r.at("subjects").fail("subject kinds must be unique");
  const outputIds = /* @__PURE__ */ new Set();
  for (const o of p.outputs ?? []) {
    if (outputIds.has(o.output_id)) r.at("outputs").fail(`duplicate output_id ${o.output_id}`);
    outputIds.add(o.output_id);
    const st = p.steps.find((x) => x.step_id === o.step_id);
    if (!st || !st.evidence.some((c) => c.criterion_id === o.criterion_id && c.type === "artifact")) r.at("outputs").fail(`output ${o.output_id} does not name an artifact criterion of a step`);
  }
  for (const s of p.steps) {
    const sr = r.at(`steps.${s.step_id}`);
    for (const q of s.requires) {
      if (!stepIds.has(q)) sr.fail(`requires unknown step ${q}`);
      if (q === s.step_id) sr.fail("requires itself");
    }
    for (const pf of s.performers) if (pf.role !== null && !roles.has(pf.role)) sr.fail(`performer role ${pf.role} not in roles`);
    if (s.children) {
      if (s.actions || s.proposals) sr.fail("a step with children has no actions and no proposals");
      if (s.children.max !== void 0 && s.children.min > s.children.max) sr.fail("children.min must not exceed children.max");
      for (const st of s.children.starters) if (st.role !== null && !roles.has(st.role)) sr.fail(`starter role ${st.role} not in roles`);
      if (s.children.procedure_id === p.procedure_id) sr.fail("a step cannot start Runs of its own Procedure");
    }
    for (const c of s.evidence) {
      if (criterionIds.has(c.criterion_id)) sr.fail(`duplicate criterion_id ${c.criterion_id}`);
      criterionIds.add(c.criterion_id);
      if (c.type === "confirmation") {
        for (const role of c.roles) if (!roles.has(role)) sr.fail(`confirmation role ${role} not in roles`);
      }
      if (c.type === "derived") {
        for (const i of c.inputs) {
          if ("quantity" in i && !p.steps.some((x) => x.evidence.some((m) => m.type === "measurement" && m.quantity === i.quantity && m.unit === i.unit))) sr.fail(`${c.criterion_id}: no measurement criterion measures ${i.quantity} in ${i.unit}`);
          if ("actions" in i && !p.steps.some((x) => x.actions?.types.includes(i.actions))) sr.fail(`${c.criterion_id}: no step allows ${i.actions} actions`);
          if ("input" in i && !p.inputs?.some((x) => x.input_id === i.input)) sr.fail(`${c.criterion_id}: no input ${i.input} is declared`);
          if ("derived" in i) {
            const at = s.evidence.findIndex((x) => x.criterion_id === i.derived);
            if (at < 0 || at >= s.evidence.indexOf(c) || s.evidence[at].type !== "derived") sr.fail(`${c.criterion_id}: ${i.derived} is not a derived criterion listed earlier on this step`);
          }
        }
        if (!c.inputs.some((i) => "quantity" in i || "actions" in i)) sr.fail(`${c.criterion_id}: reads no quantity and no actions, so nothing would ever decide it`);
      }
    }
    for (const d of s.decisions) {
      if (decisionIds.has(d.decision_id)) sr.fail(`duplicate decision_id ${d.decision_id}`);
      decisionIds.add(d.decision_id);
      for (const role of d.decider_roles) if (!roles.has(role)) sr.fail(`decider role ${role} not in roles`);
    }
    if (s.proposals) {
      if (!s.actions || !s.actions.requires_authorization) sr.fail("proposals require actions with requires_authorization: true");
      for (const bid of s.proposals.bound_ids) {
        const b = bounds.get(bid);
        if (!b) sr.fail(`unknown bound ${bid}`);
        if (!s.actions.types.includes(b.action_type)) sr.fail(`bound ${bid} action_type not in actions.types`);
      }
      for (const bid of s.proposals.bound_ids) {
        const w = bounds.get(bid).when;
        if (w && !p.steps.some((x) => x.evidence.some((c) => c.type === "measurement" && c.quantity === w.quantity && c.unit === w.unit))) {
          sr.fail(`bound ${bid}: no criterion measures ${w.quantity} in ${w.unit}, so nothing can supply the reading its condition needs`);
        }
      }
      const plain2 = /* @__PURE__ */ new Map();
      for (const bid of s.proposals.bound_ids) {
        const b = bounds.get(bid);
        const k = `${b.action_type}\0${b.parameter}`;
        const before = plain2.get(k);
        if (before !== void 0) sr.fail(`bound ${bid} is listed after ${before}, which has no condition, so it could never govern ${b.parameter}`);
        if (!b.when) plain2.set(k, bid);
      }
      for (const role of s.proposals.fallback_roles) if (!roles.has(role)) sr.fail(`fallback role ${role} not in roles`);
    } else if (s.actions?.requires_authorization) {
      sr.fail("requires_authorization: true needs proposals");
    }
  }
  const state = /* @__PURE__ */ new Map();
  const byId = new Map(p.steps.map((s) => [s.step_id, s]));
  const visit = (id) => {
    const st = state.get(id) ?? 0;
    if (st === 2) return;
    if (st === 1) r.fail(`requires graph has a cycle through ${id}`);
    state.set(id, 1);
    for (const q of byId.get(id).requires) visit(q);
    state.set(id, 2);
  };
  for (const s of p.steps) visit(s.step_id);
}
function parseEnrollment(v, r = new Reader2(3, "enrollment")) {
  const o = r.object(v, ["workspace_id", "participant_id", "display_name", "kind", "public_key", "key_id", "grants", "roles", "status"], ["granted_by", "party"], true);
  if ("granted_by" in o) r.at("granted_by").string(o.granted_by);
  const e = {
    workspace_id: r.at("workspace_id").id(o.workspace_id),
    participant_id: r.at("participant_id").id(o.participant_id),
    display_name: r.at("display_name").string(o.display_name),
    kind: r.at("kind").oneOf(o.kind, ["human", "agent", "system"]),
    public_key: r.at("public_key").string(o.public_key),
    key_id: r.at("key_id").digest(o.key_id),
    grants: r.at("grants").array(o.grants, (rr, x) => rr.oneOf(x, GRANTS), { unique: true }),
    roles: r.at("roles").array(o.roles, (rr, x) => rr.id(x), { unique: true }),
    status: r.at("status").oneOf(o.status, ["active", "revoked"])
  };
  if ("party" in o) e.party = r.at("party").id(o.party);
  if (e.participant_id === "runtime") r.at("participant_id").fail("runtime is reserved");
  return e;
}
var OPEN_MATTER_KINDS = ["step", "criterion", "decision", "proposal", "action", "observation", "child"];
var OPEN_MATTER_STATES = ["blocked", "undetermined", "nonconforming", "missing", "against", "denied", "pending", "failed", "unknown_uncertainty"];
function parseOpenMatters(r, v) {
  return r.array(v, (rr, x) => {
    const o = rr.object(x, ["step_id", "kind", "ref", "state"]);
    rr.at("step_id").id(o.step_id);
    rr.at("kind").oneOf(o.kind, OPEN_MATTER_KINDS);
    if (!isDigest(o.ref)) rr.at("ref").id(o.ref);
    rr.at("state").oneOf(o.state, OPEN_MATTER_STATES);
    return x;
  });
}
function parseDisclosure(v, r = new Reader2(6, "disclosure")) {
  const o = r.object(v, ["run_id", "workspace_id", "head", "withheld", "ordered_by", "ordered_time"], [], true);
  return {
    run_id: r.at("run_id").id(o.run_id),
    workspace_id: r.at("workspace_id").id(o.workspace_id),
    head: r.at("head").digest(o.head),
    withheld: r.at("withheld").array(o.withheld, (rr, x) => {
      const w = rr.object(x, ["digest"], ["reason"]);
      return { digest: rr.at("digest").digest(w.digest), ..."reason" in w ? { reason: rr.at("reason").string(w.reason, false) } : {} };
    }, { nonEmpty: true }),
    ordered_by: r.at("ordered_by").id(o.ordered_by),
    ordered_time: r.at("ordered_time").time(o.ordered_time)
  };
}
function parseManifest(v, r = new Reader2(1, "manifest")) {
  const o = r.object(v, ["format", "workspace", "run_id", "sequence", "procedure", "events", "participants", "evidence", "outcome", "open_matters"], ["published_by", "published_time", "outputs", "related"], true);
  if (o.format !== "runrec/0.1") r.at("format").fail(`unsupported format ${JSON.stringify(o.format)}`);
  const w = r.at("workspace").object(o.workspace, ["workspace_id", "key_id", "public_key", "display_name"]);
  const pr = r.at("procedure").object(o.procedure, ["procedure_id", "version", "digest"]);
  const ev = r.at("events").object(o.events, ["count", "head"]);
  if ("published_by" in o) r.at("published_by").string(o.published_by);
  if ("published_time" in o) r.at("published_time").time(o.published_time);
  return {
    format: "runrec/0.1",
    workspace: {
      workspace_id: r.at("workspace.workspace_id").id(w.workspace_id),
      key_id: r.at("workspace.key_id").digest(w.key_id),
      public_key: r.at("workspace.public_key").string(w.public_key),
      display_name: r.at("workspace.display_name").string(w.display_name)
    },
    run_id: r.at("run_id").id(o.run_id),
    sequence: r.at("sequence").int(o.sequence, 1),
    procedure: {
      procedure_id: r.at("procedure.procedure_id").id(pr.procedure_id),
      version: r.at("procedure.version").version(pr.version),
      digest: r.at("procedure.digest").digest(pr.digest)
    },
    events: { count: r.at("events.count").int(ev.count, 2, MAX_SEQ), head: r.at("events.head").digest(ev.head) },
    participants: r.at("participants").array(o.participants, (rr, x) => {
      const po = rr.object(x, ["participant_id", "digest"]);
      return { participant_id: rr.at("participant_id").id(po.participant_id), digest: rr.at("digest").digest(po.digest) };
    }),
    evidence: r.at("evidence").array(o.evidence, (rr, x) => {
      const eo = rr.object(x, ["digest", "media_type", "size"], ["external"]);
      const e = { digest: rr.at("digest").digest(eo.digest), media_type: rr.at("media_type").mediaType(eo.media_type), size: rr.at("size").int(eo.size, 0) };
      if ("external" in eo) e.external = { location: rr.at("external.location").string(rr.at("external").object(eo.external, ["location"]).location) };
      return e;
    }),
    outcome: r.at("outcome").oneOf(o.outcome, ["complete", "incomplete", "failed"]),
    open_matters: parseOpenMatters(r.at("open_matters"), o.open_matters),
    ..."outputs" in o ? { outputs: r.at("outputs").array(o.outputs, (rr, x) => {
      const q = rr.object(x, ["output_id", "digest", "media_type", "size"]);
      return { output_id: rr.at("output_id").id(q.output_id), digest: rr.at("digest").digest(q.digest), media_type: rr.at("media_type").mediaType(q.media_type), size: rr.at("size").int(q.size, 0) };
    }) } : {},
    ..."related" in o ? { related: r.at("related").array(o.related, (rr, x) => {
      const q = rr.object(x, ["kind", "run_id"], ["record", "step_id"]);
      return { kind: rr.at("kind").oneOf(q.kind, ["parent", "child", "retry_of", "input"]), run_id: rr.at("run_id").id(q.run_id), ..."record" in q ? { record: rr.at("record").digest(q.record) } : {}, ..."step_id" in q ? { step_id: rr.at("step_id").id(q.step_id) } : {} };
    }) } : {}
  };
}
function parseWorkspace(r, v) {
  const w = r.object(v, ["workspace_id", "key_id", "public_key", "display_name"]);
  return {
    workspace_id: r.at("workspace_id").id(w.workspace_id),
    key_id: r.at("key_id").digest(w.key_id),
    public_key: r.at("public_key").string(w.public_key),
    display_name: r.at("display_name").string(w.display_name)
  };
}
function parseRegister(v, r = new Reader2(1, "register")) {
  const o = r.object(v, ["format", "workspace", "through", "previous", "issued_time", "runs"], ["successor", "former_keys", "revoked", "published", "journal", "procedures", "reviews"], true);
  if (o.format !== "runrec-register/0.1") r.at("format").fail(`unsupported format ${JSON.stringify(o.format)}`);
  const key = (rr, x, extra) => {
    const k = rr.object(x, ["key_id", "public_key", ...extra]);
    return { k, key_id: rr.at("key_id").digest(k.key_id), public_key: rr.at("public_key").string(k.public_key) };
  };
  const reg = {
    format: "runrec-register/0.1",
    workspace: parseWorkspace(r.at("workspace"), o.workspace),
    through: r.at("through").int(o.through, 0),
    previous: o.previous === null ? null : r.at("previous").digest(o.previous),
    issued_time: r.at("issued_time").time(o.issued_time),
    runs: r.at("runs").array(o.runs, (rr, x) => {
      const e = rr.object(x, ["sequence", "run_id", "status", "procedure", "head"], ["outcome"]);
      const pr = rr.at("procedure").object(e.procedure, ["procedure_id", "version", "digest"]);
      const out = {
        sequence: rr.at("sequence").int(e.sequence, 1),
        run_id: rr.at("run_id").id(e.run_id),
        status: rr.at("status").oneOf(e.status, ["open", "closed"]),
        procedure: {
          procedure_id: rr.at("procedure.procedure_id").id(pr.procedure_id),
          version: rr.at("procedure.version").version(pr.version),
          digest: rr.at("procedure.digest").digest(pr.digest)
        },
        head: rr.at("head").digest(e.head)
      };
      if ("outcome" in e) out.outcome = rr.at("outcome").oneOf(e.outcome, ["complete", "incomplete", "failed"]);
      return out;
    })
  };
  if ("successor" in o) {
    const { key_id, public_key } = key(r.at("successor"), o.successor, []);
    reg.successor = { key_id, public_key };
  }
  if ("former_keys" in o) {
    reg.former_keys = r.at("former_keys").array(o.former_keys, (rr, x) => {
      const { k, key_id, public_key } = key(rr, x, ["through"]);
      return { key_id, public_key, through: rr.at("through").int(k.through, 0) };
    });
  }
  if ("revoked" in o) {
    reg.revoked = r.at("revoked").array(o.revoked, (rr, x) => {
      const k = rr.object(x, ["key_id", "as_of", "reason"]);
      return { key_id: rr.at("key_id").digest(k.key_id), as_of: rr.at("as_of").int(k.as_of, 0), reason: rr.at("reason").string(k.reason) };
    });
  }
  if ("published" in o) {
    const p = r.at("published").object(o.published, ["log", "entry"]);
    reg.published = { log: r.at("published.log").string(p.log), entry: r.at("published.entry").string(p.entry) };
  }
  if ("journal" in o) {
    const j = r.at("journal").object(o.journal, ["head", "length"]);
    reg.journal = { head: r.at("journal.head").digest(j.head), length: r.at("journal.length").int(j.length, 0) };
  }
  if ("procedures" in o) {
    reg.procedures = r.at("procedures").array(o.procedures, (rr, x) => {
      const q = rr.object(x, ["procedure_id", "version", "digest", "status", "since"]);
      return { procedure_id: rr.at("procedure_id").id(q.procedure_id), version: rr.at("version").version(q.version), digest: rr.at("digest").digest(q.digest), status: rr.at("status").oneOf(q.status, ["draft", "agreed", "active", "retired"]), since: rr.at("since").time(q.since) };
    });
  }
  if ("reviews" in o) {
    reg.reviews = r.at("reviews").array(o.reviews, (rr, x) => {
      const q = rr.object(x, ["run_id", "review"]);
      return { run_id: rr.at("run_id").id(q.run_id), review: rr.at("review").digest(q.review) };
    });
  }
  return reg;
}
var EVENT_KINDS = [
  "RunStarted",
  "StepOpened",
  "Proposal",
  "Authorization",
  "Action",
  "Observation",
  "Evaluation",
  "Decision",
  "Note",
  "ChildStarted",
  "ChildSealed",
  "StepClosed",
  "RunClosed"
];
var SIGNERS = {
  RunStarted: ["runtime"],
  StepOpened: ["runtime"],
  Proposal: ["human", "agent"],
  Authorization: ["runtime", "human"],
  Action: ["human", "system"],
  Observation: ["human", "system"],
  Evaluation: ["runtime"],
  Decision: ["human"],
  Note: ["human", "agent", "system", "runtime"],
  ChildStarted: ["human", "agent"],
  ChildSealed: ["runtime"],
  StepClosed: ["runtime"],
  RunClosed: ["runtime"]
};
var HEADER = ["run_id", "workspace_id", "seq", "previous", "kind", "actor", "declared_time"];
var BODY = {
  RunStarted: { req: ["procedure_id", "version", "procedure_digest"], opt: ["title", "site", "started_by", "inputs", "subjects", "related"] },
  StepOpened: { req: ["step_id"], opt: [] },
  Proposal: { req: ["step_id", "action", "cites"], opt: ["rationale", "trace"] },
  Authorization: { req: ["step_id", "proposal", "result", "basis"], opt: ["reason"] },
  Action: { req: ["step_id", "action", "result"], opt: ["authorization", "device", "trace"] },
  Observation: { req: ["step_id", "source"], opt: ["measurement", "artifact", "confirmation", "uncertainty", "observed_time"] },
  Evaluation: { req: ["step_id", "criterion_id", "result"], opt: ["inputs", "explanation"] },
  Decision: { req: ["type", "reason", "cites"], opt: ["step_id", "decision_id", "scope"] },
  Note: { req: ["text"], opt: ["step_id"] },
  ChildStarted: { req: ["step_id", "child_run_id", "procedure"], opt: ["inputs", "trace"] },
  ChildSealed: { req: ["step_id", "child_run_id", "record", "outcome"], opt: [] },
  StepClosed: { req: ["step_id", "outcome"], opt: ["reason"] },
  RunClosed: { req: ["outcome", "open_matters"], opt: ["closed_by"] }
};
function parseActionSpec(r, v) {
  const o = r.object(v, ["type", "parameters"]);
  const pr = r.at("parameters");
  if (!isObject(o.parameters)) pr.fail("must be an object");
  const params = o.parameters;
  for (const [k, val] of Object.entries(params)) {
    pr.id(k);
    if (!(typeof val === "number" || typeof val === "string" || typeof val === "boolean")) pr.at(k).fail("must be a number, string or boolean");
  }
  return { type: r.at("type").id(o.type), parameters: params };
}
function parseArtifact(r, v) {
  const art = r.object(v, ["digest", "media_type", "size"]);
  r.at("digest").digest(art.digest);
  r.at("media_type").mediaType(art.media_type);
  r.at("size").int(art.size, 0);
}
function parseBoundInputs(r, v) {
  if (!isObject(v)) r.fail("must be an object");
  for (const [k, x] of Object.entries(v)) {
    r.id(k);
    if (typeof x === "number" || typeof x === "string") continue;
    if (isObject(x) && "record" in x) {
      const q = r.at(k).object(x, ["run_id", "record", "output_id", "digest"]);
      r.at(`${k}.run_id`).id(q.run_id);
      r.at(`${k}.record`).digest(q.record);
      r.at(`${k}.output_id`).id(q.output_id);
      r.at(`${k}.digest`).digest(q.digest);
    } else parseArtifact(r.at(k), x);
  }
}
function parseEvent(v, r = new Reader2(5, "event")) {
  if (!isObject(v)) r.fail("must be an object");
  const kind = r.at("kind").oneOf(v.kind, EVENT_KINDS);
  const spec = BODY[kind];
  const o = r.object(v, [...HEADER, ...spec.req], spec.opt, true);
  r.at("run_id").id(o.run_id);
  r.at("workspace_id").id(o.workspace_id);
  r.at("seq").int(o.seq, 1, MAX_SEQ);
  if (o.previous !== null) r.at("previous").digest(o.previous);
  const a = r.at("actor").object(o.actor, ["participant_id", "kind", "key_id"]);
  r.at("actor.participant_id").string(a.participant_id);
  r.at("actor.kind").oneOf(a.kind, ["human", "agent", "system", "runtime"]);
  r.at("actor.key_id").digest(a.key_id);
  r.at("declared_time").time(o.declared_time);
  if ("step_id" in o) r.at("step_id").id(o.step_id);
  switch (kind) {
    case "RunStarted":
      r.at("procedure_id").id(o.procedure_id);
      r.at("version").version(o.version);
      r.at("procedure_digest").digest(o.procedure_digest);
      for (const k of ["title", "site", "started_by"]) if (k in o) r.at(k).string(o[k], false);
      if ("inputs" in o) parseBoundInputs(r.at("inputs"), o.inputs);
      if ("subjects" in o) r.at("subjects").array(o.subjects, (rr, x) => {
        const q = rr.object(x, ["kind", "id"]);
        rr.at("kind").id(q.kind);
        rr.at("id").string(q.id);
      });
      if ("related" in o) r.at("related").array(o.related, (rr, x) => {
        const q = rr.object(x, ["kind", "run_id"], ["step_id"]);
        rr.at("kind").oneOf(q.kind, ["parent", "retry_of"]);
        rr.at("run_id").id(q.run_id);
        if ("step_id" in q) rr.at("step_id").id(q.step_id);
      });
      break;
    case "Proposal":
      parseActionSpec(r.at("action"), o.action);
      r.at("cites").array(o.cites, (rr, x) => rr.digest(x), { unique: true });
      if ("rationale" in o) r.at("rationale").string(o.rationale, false);
      if ("trace" in o) parseArtifact(r.at("trace"), o.trace);
      break;
    case "Authorization": {
      r.at("proposal").digest(o.proposal);
      r.at("result").oneOf(o.result, ["allow", "deny"]);
      if (!isObject(o.basis)) r.at("basis").fail("must be an object");
      const bk = r.at("basis.kind").oneOf(o.basis.kind, ["bound", "human"]);
      if (bk === "bound") {
        const b = r.at("basis").object(o.basis, ["kind", "bounds", "inputs"]);
        r.at("basis.bounds").array(b.bounds, (rr, x) => rr.id(x));
        r.at("basis.inputs").array(b.inputs, (rr, x) => rr.digest(x));
      } else {
        r.at("basis").object(o.basis, ["kind"]);
      }
      if ("reason" in o) r.at("reason").string(o.reason, false);
      break;
    }
    case "Action": {
      parseActionSpec(r.at("action"), o.action);
      const res = r.at("result").object(o.result, ["status"], ["detail"]);
      r.at("result.status").oneOf(res.status, ["success", "failure"]);
      if ("detail" in res) r.at("result.detail").string(res.detail, false);
      if ("authorization" in o) r.at("authorization").digest(o.authorization);
      if ("trace" in o) parseArtifact(r.at("trace"), o.trace);
      if ("device" in o) {
        const dv = r.at("device").object(o.device, [], ["action_time", "status", "server_id", "client_audit_entry_id", "client_user_id"]);
        for (const k of Object.keys(dv)) {
          if (k === "action_time") r.at("device.action_time").time(dv[k]);
          else r.at(`device.${k}`).string(dv[k], false);
        }
      }
      break;
    }
    case "Observation": {
      const hasM = "measurement" in o;
      const hasA = "artifact" in o;
      const hasC = "confirmation" in o;
      if (Number(hasM) + Number(hasA) + Number(hasC) !== 1) r.fail("must carry exactly one of measurement, artifact or confirmation");
      const src = r.at("source").object(o.source, [], ["device_id", "method"]);
      for (const k of Object.keys(src)) if (k !== "ext") r.at(`source.${k}`).string(src[k], false);
      if (hasM) {
        const m = r.at("measurement").object(o.measurement, ["quantity", "unit", "value"]);
        r.at("measurement.quantity").id(m.quantity);
        r.at("measurement.unit").string(m.unit);
        r.at("measurement.value").number(m.value);
        const u = r.at("uncertainty").object(o.uncertainty, ["kind"], ["value", "unit", "note"]);
        const uk = r.at("uncertainty.kind").oneOf(u.kind, ["stated", "unknown"]);
        if (uk === "stated" || "value" in u) r.at("uncertainty.value").number(u.value);
        if (uk === "stated" || "unit" in u) r.at("uncertainty.unit").string(u.unit);
        if ("note" in u) r.at("uncertainty.note").string(u.note, false);
      } else {
        if ("uncertainty" in o) r.fail("uncertainty applies to measurements only");
        if (hasA) parseArtifact(r.at("artifact"), o.artifact);
        else r.at("confirmation.criterion_id").id(r.at("confirmation").object(o.confirmation, ["criterion_id"]).criterion_id);
      }
      if ("observed_time" in o) r.at("observed_time").time(o.observed_time);
      break;
    }
    case "Evaluation":
      r.at("criterion_id").id(o.criterion_id);
      r.at("result").oneOf(o.result, ["conforming", "nonconforming", "undetermined"]);
      if ("inputs" in o) r.at("inputs").array(o.inputs, (rr, x) => rr.digest(x));
      if ("explanation" in o) r.at("explanation").string(o.explanation, false);
      break;
    case "Decision":
      r.at("type").oneOf(o.type, DECISION_TYPES);
      r.at("reason").string(o.reason);
      r.at("cites").array(o.cites, (rr, x) => rr.digest(x), { unique: true });
      if ("decision_id" in o) {
        r.at("decision_id").id(o.decision_id);
        if (!("step_id" in o)) r.fail("decision_id requires step_id");
      }
      if ("scope" in o && !isObject(o.scope)) r.at("scope").fail("must be an object");
      break;
    case "Note":
      r.at("text").string(o.text);
      break;
    case "ChildStarted": {
      r.at("child_run_id").id(o.child_run_id);
      const pr = r.at("procedure").object(o.procedure, ["procedure_id", "version", "digest"]);
      r.at("procedure.procedure_id").id(pr.procedure_id);
      r.at("procedure.version").version(pr.version);
      r.at("procedure.digest").digest(pr.digest);
      if ("inputs" in o) parseBoundInputs(r.at("inputs"), o.inputs);
      if ("trace" in o) parseArtifact(r.at("trace"), o.trace);
      break;
    }
    case "ChildSealed":
      r.at("child_run_id").id(o.child_run_id);
      r.at("record").digest(o.record);
      r.at("outcome").oneOf(o.outcome, ["complete", "incomplete", "failed"]);
      break;
    case "StepClosed":
      r.at("outcome").oneOf(o.outcome, ["complete", "failed"]);
      if ("reason" in o) r.at("reason").string(o.reason, false);
      break;
    case "RunClosed":
      r.at("outcome").oneOf(o.outcome, ["complete", "incomplete", "failed"]);
      parseOpenMatters(r.at("open_matters"), o.open_matters);
      if ("closed_by" in o) r.at("closed_by").string(o.closed_by, false);
      break;
    case "StepOpened":
      break;
  }
  return o;
}
function policiesOf(p) {
  return p.steps.flatMap((s) => s.evidence.flatMap((c) => c.type === "derived" ? [{ digest: c.policy.digest, media_type: c.policy.media_type, size: c.policy.size }] : []));
}
function citationsOf(ev) {
  if (ev.kind === "RunStarted") {
    const inputs = ev.inputs ?? {};
    return Object.keys(inputs).sort().flatMap((k) => isObject(inputs[k]) && "media_type" in inputs[k] ? [inputs[k]] : []);
  }
  const a = ev.kind === "Observation" ? ev.artifact : ev.kind === "Proposal" || ev.kind === "Action" || ev.kind === "ChildStarted" ? ev.trace : void 0;
  return a ? [a] : [];
}
var JOURNAL_KINDS = [
  "WorkspaceCreated",
  "KeyRotated",
  "KeyRevoked",
  "ProcedureDrafted",
  "ProcedureAgreed",
  "ProcedureRetired",
  "ParticipantEnrolled",
  "ParticipantRetired",
  "RunStarted",
  "RecordSealed",
  "RegisterIssued",
  "EditionMade",
  "PackExported",
  "ReviewSigned",
  "SessionOpened"
];
function parseJournalEntry(v, r = new Reader2(1, "journal")) {
  const o = r.object(v, ["workspace_id", "seq", "previous", "kind", "actor", "declared_time", "refs"], ["key", "trace", "note"], true);
  const a = r.at("actor").object(o.actor, ["participant_id", "kind", "key_id"], ["on_behalf_of"]);
  const kind = r.at("actor.kind").oneOf(a.kind, ["human", "agent", "runtime"]);
  const pid = r.at("actor.participant_id").string(a.participant_id);
  if (pid === "runtime" !== (kind === "runtime")) r.at("actor").fail("participant_id is runtime exactly when kind is runtime");
  const e = {
    workspace_id: r.at("workspace_id").id(o.workspace_id),
    seq: r.at("seq").int(o.seq, 1),
    previous: o.previous === null ? null : r.at("previous").digest(o.previous),
    kind: r.at("kind").oneOf(o.kind, JOURNAL_KINDS),
    actor: { participant_id: kind === "runtime" ? pid : r.at("actor.participant_id").id(pid), kind, key_id: r.at("actor.key_id").digest(a.key_id) },
    declared_time: r.at("declared_time").time(o.declared_time),
    refs: r.at("refs").array(o.refs, (rr, x) => rr.digest(x))
  };
  if ("on_behalf_of" in a) e.actor.on_behalf_of = r.at("actor.on_behalf_of").id(a.on_behalf_of);
  if ("key" in o) {
    const k = r.at("key").object(o.key, ["key_id", "public_key"]);
    e.key = { key_id: r.at("key.key_id").digest(k.key_id), public_key: r.at("key.public_key").string(k.public_key) };
  }
  if (e.key !== void 0 !== (e.kind === "WorkspaceCreated" || e.kind === "KeyRotated")) r.at("key").fail("is present exactly on WorkspaceCreated and KeyRotated");
  if ("trace" in o) {
    parseArtifact(r.at("trace"), o.trace);
    const t = o.trace;
    e.trace = { digest: t.digest, media_type: t.media_type, size: t.size };
  }
  if ("note" in o) e.note = r.at("note").string(o.note, false);
  return e;
}

// ../packages/runrec/src/engine.ts
var AGAINST = /* @__PURE__ */ new Set(["reject", "stop"]);
var byCodePoint = (a, b) => a < b ? -1 : a > b ? 1 : 0;
var RunEngine = class {
  procedure;
  enrollments;
  steps = /* @__PURE__ */ new Map();
  order;
  seen = /* @__PURE__ */ new Set();
  authorizations = /* @__PURE__ */ new Map();
  successCount = /* @__PURE__ */ new Map();
  readings = /* @__PURE__ */ new Map();
  governing = /* @__PURE__ */ new Map();
  /** (draft 11) every Action in the Run, in chain order, for sealed policies */
  actionLog = [];
  policies = /* @__PURE__ */ new Map();
  policyBytes;
  pending = [];
  pendingProposal = null;
  /** (draft 11) the inputs RunStarted bound (§4.2) */
  bound = {};
  started = false;
  closed = false;
  constructor(opts) {
    this.procedure = opts.procedure;
    this.enrollments = opts.enrollments;
    this.order = opts.procedure.steps.map((s) => s.step_id);
    this.policyBytes = opts.policy ?? (() => void 0);
    for (const def of opts.procedure.steps) {
      this.steps.set(def.step_id, {
        def,
        opened: false,
        closed: false,
        criteria: new Map(def.evidence.map((c) => [c.criterion_id, { def: c, result: "undetermined", values: [], inputs: [] }])),
        succeededActions: 0,
        failedActions: [],
        decisionsSatisfied: /* @__PURE__ */ new Set(),
        decisionsAgainst: /* @__PURE__ */ new Set(),
        proposals: /* @__PURE__ */ new Map(),
        unknownObservations: [],
        stated: [],
        children: /* @__PURE__ */ new Map()
      });
    }
  }
  /** Runtime events still owed before the next Participant event. */
  get owed() {
    return this.pending;
  }
  // ------------------------------------------------------------ lifecycle
  /** Apply RunStarted; returns the runtime events that must follow it. */
  start(digest, ev) {
    check(!this.started, 7, "sequencing", "RunStarted appears more than once");
    this.started = true;
    if (isObject(ev?.inputs)) this.bound = ev.inputs;
    this.seen.add(digest);
    this.pending = this.settle();
    return [...this.pending];
  }
  /** Confirm the next runtime event against what the rules require (§6.3). */
  confirmRuntime(ev, digest) {
    const exp = this.pending.shift();
    if (!exp) fail(7, "sequencing", `unexpected runtime ${ev.kind} at seq ${ev.seq}`);
    if (ev.kind !== exp.kind || ev.step_id !== exp.step_id) {
      fail(7, "sequencing", `seq ${ev.seq}: expected ${exp.kind} on ${exp.step_id}, found ${ev.kind}${ev.step_id ? ` on ${ev.step_id}` : ""}`);
    }
    switch (exp.kind) {
      case "Authorization":
        if (ev.proposal !== exp.proposal) fail(7, "sequencing", `seq ${ev.seq}: Authorization rules on the wrong Proposal`);
        if (ev.basis.kind !== "bound") fail(7, "sequencing", `seq ${ev.seq}: expected a bound Authorization`);
        if (ev.result !== exp.result) fail(8, "recompute", `seq ${ev.seq}: bound Authorization recorded ${String(ev.result)}, rules give ${exp.result}`);
        {
          const got = ev.basis;
          if (canonicalize(got.bounds) !== canonicalize(exp.basis.bounds)) {
            fail(8, "recompute", `seq ${ev.seq}: bound Authorization names governing Bounds ${JSON.stringify(got.bounds)}, rules give ${JSON.stringify(exp.basis.bounds)}`);
          }
          if (canonicalize(got.inputs) !== canonicalize(exp.basis.inputs)) {
            fail(8, "recompute", `seq ${ev.seq}: bound Authorization cites readings ${JSON.stringify(got.inputs)}, rules give ${JSON.stringify(exp.basis.inputs)}`);
          }
        }
        this.authorizations.set(digest, { proposal: exp.proposal, basis: "bound", result: exp.result, governing: this.governing.get(exp.proposal) ?? [] });
        this.proposalByDigest(exp.proposal).rulings.at(-1).digest = digest;
        break;
      case "Evaluation":
        if (ev.criterion_id !== exp.criterion_id) fail(7, "sequencing", `seq ${ev.seq}: expected Evaluation of ${exp.criterion_id}, found ${String(ev.criterion_id)}`);
        if (ev.result !== exp.result) fail(8, "recompute", `seq ${ev.seq}: Evaluation of ${exp.criterion_id} recorded ${String(ev.result)}, rules give ${exp.result}`);
        break;
      case "StepClosed":
        if (ev.outcome !== exp.outcome) fail(8, "recompute", `seq ${ev.seq}: ${exp.step_id} closed ${String(ev.outcome)}, rules give ${exp.outcome}`);
        break;
      case "StepOpened":
        break;
    }
    this.seen.add(digest);
  }
  /** Test-only: drop owed runtime events (used when forging invalid Records). */
  discardOwed() {
    this.pending = [];
  }
  /** A runtime Note may appear only where no runtime events are owed. */
  applyRuntimeNote(ev, digest) {
    check(this.pending.length === 0, 7, "sequencing", `seq ${ev.seq}: runtime Note interrupts owed runtime events`);
    if (ev.step_id !== void 0) check(this.steps.has(ev.step_id), 7, "reference", `seq ${ev.seq}: unknown step ${ev.step_id}`);
    this.seen.add(digest);
  }
  /**
   * (draft 11, §6.3) ChildSealed: the runtime records that a child Run's Record was sealed. It answers no
   * Participant event here, so it may come whenever nothing is owed, and is followed by the settle.
   */
  applyChildSealed(ev, digest) {
    check(this.started && !this.closed && this.pending.length === 0, 7, "sequencing", `seq ${ev.seq}: ChildSealed interrupts owed runtime events`);
    const s = this.steps.get(ev.step_id);
    check(s, 7, "reference", `seq ${ev.seq}: unknown step ${ev.step_id}`);
    const child = s.children.get(String(ev.child_run_id));
    check(child && !child.sealed, 7, "reference", `seq ${ev.seq}: ${String(ev.child_run_id)} is not an unsealed child of ${s.def.step_id}`);
    check(s.opened && !s.closed, 7, "sequencing", `seq ${ev.seq}: ChildSealed on ${s.def.step_id}, which is not open`);
    child.sealed = { record: ev.record, outcome: ev.outcome };
    this.seen.add(digest);
    this.pending = this.settle();
    return [...this.pending];
  }
  /** Check (§6.2) and apply a Participant event; returns owed runtime events. */
  applyParticipant(ev, digest, opts = {}) {
    check(this.started && !this.closed, 7, "sequencing", `seq ${ev.seq}: Participant event outside an open Run`);
    check(this.pending.length === 0, 7, "sequencing", `seq ${ev.seq}: ${ev.kind} arrives while runtime events are owed (${this.pending.map((p) => p.kind).join(", ")})`);
    const enr = this.enrollments.get(ev.actor.participant_id);
    check(enr, 7, "authority", `seq ${ev.seq}: actor ${ev.actor.participant_id} is not enrolled`);
    const step = ev.step_id === void 0 ? void 0 : this.steps.get(ev.step_id);
    if (ev.step_id !== void 0) check(step, 7, "reference", `seq ${ev.seq}: unknown step ${ev.step_id}`);
    const out = [];
    const strict = !opts.skipChecks;
    switch (ev.kind) {
      case "Proposal": {
        const s = step;
        const action2 = ev.action;
        if (strict) {
          this.requireOpen(s, ev);
          check(s.def.proposals, 7, "authority", `seq ${ev.seq}: ${s.def.step_id} accepts no Proposals`);
          check(s.def.proposals.allowed_kinds.includes(ev.actor.kind), 7, "authority", `seq ${ev.seq}: ${ev.actor.kind} may not propose on ${s.def.step_id}`);
          check(enr.grants.includes("operate"), 7, "authority", `seq ${ev.seq}: ${enr.participant_id} lacks the operate grant`);
          check(s.def.actions.types.includes(action2.type), 7, "authority", `seq ${ev.seq}: action type ${action2.type} not allowed on ${s.def.step_id}`);
          for (const c of ev.cites) check(this.seen.has(c), 7, "reference", `seq ${ev.seq}: cites unknown event ${c}`);
        }
        const ps = { digest, seq: ev.seq, proposer: ev.actor.participant_id, action: action2, rulings: [] };
        s.proposals.set(digest, ps);
        if (s.def.proposals && s.def.proposals.bound_ids.length > 0) {
          const ruling = this.ruleOnBounds(s.def, action2);
          ps.rulings.push({ basis: "bound", result: ruling.result, bounds: ruling.governing.map((b) => b.bound_id) });
          this.governing.set(digest, ruling.governing);
          out.push({ kind: "Authorization", step_id: s.def.step_id, proposal: digest, result: ruling.result, basis: { kind: "bound", bounds: ruling.governing.map((b) => b.bound_id), inputs: ruling.inputs }, reason: ruling.reason });
        }
        break;
      }
      case "Authorization": {
        const s = step;
        const basis = ev.basis.kind;
        const prop = s.proposals.get(ev.proposal);
        if (strict) {
          check(basis === "human", 7, "authority", `seq ${ev.seq}: only the runtime records bound Authorizations`);
          this.requireOpen(s, ev);
          check(prop, 7, "reference", `seq ${ev.seq}: Authorization names no Proposal on ${s.def.step_id}`);
          check(enr.grants.includes("authorize"), 7, "authority", `seq ${ev.seq}: ${enr.participant_id} lacks the authorize grant`);
          check(s.def.proposals.fallback_roles.some((r) => enr.roles.includes(r)), 7, "authority", `seq ${ev.seq}: ${enr.participant_id} has no fallback role on ${s.def.step_id}`);
          check(!prop.rulings.some((r) => r.result === "allow"), 7, "authority", `seq ${ev.seq}: Proposal is already allowed`);
          check(!prop.rulings.some((r) => r.basis === "human"), 7, "authority", `seq ${ev.seq}: Proposal already has a human ruling`);
          check(prop.proposer !== ev.actor.participant_id, 7, "authority", `seq ${ev.seq}: ${enr.participant_id} may not authorize their own Proposal`);
        }
        if (prop) prop.rulings.push({ digest, basis: "human", result: ev.result });
        this.authorizations.set(digest, { proposal: ev.proposal, basis: "human", result: ev.result });
        break;
      }
      case "Action": {
        const s = step;
        const action2 = ev.action;
        const status = ev.result.status;
        if (strict) {
          this.requireOpen(s, ev);
          this.requirePerformer(s, enr, ev);
          check(enr.grants.includes("act"), 7, "authority", `seq ${ev.seq}: ${enr.participant_id} lacks the act grant`);
          check(s.def.actions, 7, "authority", `seq ${ev.seq}: ${s.def.step_id} accepts no Actions`);
          check(s.def.actions.types.includes(action2.type), 7, "authority", `seq ${ev.seq}: action type ${action2.type} not allowed on ${s.def.step_id}`);
          if (s.def.actions.requires_authorization) {
            const authDigest = ev.authorization;
            check(authDigest, 7, "authority", `seq ${ev.seq}: Action requires an Authorization`);
            const auth = this.authorizations.get(authDigest);
            check(auth, 7, "reference", `seq ${ev.seq}: authorization names no earlier Authorization`);
            check(auth.result === "allow", 7, "authority", `seq ${ev.seq}: Action cites an Authorization that does not allow it`);
            const prop = s.proposals.get(auth.proposal);
            check(prop, 7, "reference", `seq ${ev.seq}: Authorization is for a Proposal on another Step`);
            check(canonicalize(prop.action) === canonicalize(action2), 7, "authority", `seq ${ev.seq}: Action differs from the authorized Proposal`);
            check(!auth.usedBy, 7, "authority", `seq ${ev.seq}: Authorization was already used by another Action`);
            if (auth.basis === "bound") {
              for (const b of auth.governing ?? []) {
                if (b.when) {
                  const w = b.when;
                  const rd = this.readings.get(`${w.quantity}\0${w.unit}`);
                  check(!!rd && rd.stated && rd.value >= w.min && rd.value <= w.max, 7, "authority", `seq ${ev.seq}: ${b.bound_id} applied when the proposal was allowed, but the latest ${w.quantity} reading no longer meets its condition`);
                }
                if (b.max_count_per_run === void 0) continue;
                const used = this.successCount.get(action2.type) ?? 0;
                check(used < b.max_count_per_run, 7, "authority", `seq ${ev.seq}: ${b.bound_id} allows ${b.max_count_per_run} successful ${action2.type} actions per Run; ${used} already succeeded`);
              }
            }
          } else {
            check(!("authorization" in ev), 7, "authority", `seq ${ev.seq}: Action cites an Authorization the Step does not require`);
          }
        }
        if (ev.authorization) {
          const auth = this.authorizations.get(ev.authorization);
          if (auth) auth.usedBy = digest;
        }
        if (status === "success") {
          s.succeededActions++;
          this.successCount.set(action2.type, (this.successCount.get(action2.type) ?? 0) + 1);
        } else {
          s.failedActions.push({ digest, seq: ev.seq });
        }
        this.actionLog.push({ digest, seq: ev.seq, type: action2.type, parameters: action2.parameters, status, declared_time: ev.declared_time });
        for (const id of this.order) {
          const st = this.steps.get(id);
          if (!st.opened || st.closed) continue;
          for (const c of st.criteria.values()) if (c.def.type === "derived" && c.def.inputs.some((i) => "actions" in i && i.actions === action2.type)) out.push(this.derive(st, c));
        }
        break;
      }
      case "Observation": {
        const s = step;
        if (strict) {
          this.requireOpen(s, ev);
          this.requirePerformer(s, enr, ev);
          check(enr.grants.includes("observe"), 7, "authority", `seq ${ev.seq}: ${enr.participant_id} lacks the observe grant`);
          const conf = ev.confirmation;
          if (conf) {
            check(enr.kind === "human", 7, "authority", `seq ${ev.seq}: only a person confirms`);
            const c = s.def.evidence.find((x) => x.criterion_id === conf.criterion_id && x.type === "confirmation");
            check(c?.type === "confirmation", 7, "reference", `seq ${ev.seq}: ${conf.criterion_id} is not a confirmation on step ${s.def.step_id}`);
            check(c.roles.some((r) => enr.roles.includes(r)), 7, "authority", `seq ${ev.seq}: ${enr.participant_id} holds none of the roles that confirm ${c.criterion_id} (${c.roles.join(", ")})`);
          }
        }
        out.push(...this.observe(s, ev, digest));
        const m = ev.measurement;
        if (m && s.def.evidence.some((c) => c.type === "measurement" && c.quantity === m.quantity && c.unit === m.unit)) {
          this.readings.set(`${m.quantity}\0${m.unit}`, { digest, stated: ev.uncertainty.kind === "stated", value: m.value });
        }
        break;
      }
      case "Decision": {
        if (strict) {
          check(enr.kind === "human", 7, "authority", `seq ${ev.seq}: only Humans decide`);
          check(enr.grants.includes("decide"), 7, "authority", `seq ${ev.seq}: ${enr.participant_id} lacks the decide grant`);
          for (const c of ev.cites) check(this.seen.has(c), 7, "reference", `seq ${ev.seq}: cites unknown event ${c}`);
        }
        if (ev.decision_id !== void 0) {
          const s = step;
          const req = s.def.decisions.find((d) => d.decision_id === ev.decision_id);
          if (strict) {
            check(req, 7, "reference", `seq ${ev.seq}: decision ${String(ev.decision_id)} is not defined on ${s.def.step_id}`);
            check(req.types.includes(ev.type), 7, "authority", `seq ${ev.seq}: decision type ${String(ev.type)} not allowed for ${req.decision_id}`);
            check(req.decider_roles.some((r) => enr.roles.includes(r)), 7, "authority", `seq ${ev.seq}: ${enr.participant_id} has no decider role for ${req.decision_id}`);
          }
          if (req && s.opened && !s.closed) (AGAINST.has(String(ev.type)) ? s.decisionsAgainst : s.decisionsSatisfied).add(req.decision_id);
        }
        break;
      }
      case "Note":
        break;
      case "ChildStarted": {
        const s = step;
        const pr = ev.procedure;
        if (strict) {
          this.requireOpen(s, ev);
          const ch = s.def.children;
          check(ch, 7, "authority", `seq ${ev.seq}: ${s.def.step_id} starts no child Runs`);
          check(ch.starters.some((x) => x.kind === enr.kind && (x.role === null || enr.roles.includes(x.role))), 7, "authority", `seq ${ev.seq}: ${enr.participant_id} is not a starter on ${s.def.step_id}`);
          check(enr.grants.includes("start"), 7, "authority", `seq ${ev.seq}: ${enr.participant_id} lacks the start grant`);
          check(pr.procedure_id === ch.procedure_id, 7, "reference", `seq ${ev.seq}: a child of ${s.def.step_id} runs ${ch.procedure_id}, not ${pr.procedure_id}`);
          check(ch.max === void 0 || s.children.size < ch.max, 7, "authority", `seq ${ev.seq}: ${s.def.step_id} allows at most ${ch.max} children`);
          check(![...this.steps.values()].some((x) => x.children.has(String(ev.child_run_id))), 7, "reference", `seq ${ev.seq}: ${String(ev.child_run_id)} is already a child of this Run`);
        }
        s.children.set(String(ev.child_run_id), { seq: ev.seq });
        break;
      }
      default:
        fail(7, "authority", `seq ${ev.seq}: ${ev.kind} cannot be recorded by a Participant`);
    }
    this.seen.add(digest);
    out.push(...this.settle());
    this.pending = [...out];
    return out;
  }
  /** Compute the Run outcome and open matters (§6.6). */
  /**
   * (draft 11) The Run's outputs (§4.3), in the Procedure's order: each the artifact of the first Observation that met
   * its criterion. An output whose criterion was never met is absent. Undefined when the Procedure declares none.
   */
  outputs() {
    if (!this.procedure.outputs) return void 0;
    return this.procedure.outputs.flatMap((o) => {
      const a = this.steps.get(o.step_id)?.criteria.get(o.criterion_id)?.artifact;
      return a ? [{ output_id: o.output_id, digest: a.digest, media_type: a.media_type, size: a.size }] : [];
    });
  }
  conclude() {
    const matters = [];
    let anyFailed = false;
    let allComplete = true;
    for (const id of this.order) {
      const s = this.steps.get(id);
      if (s.outcome === "failed") anyFailed = true;
      if (s.outcome === "complete") continue;
      allComplete = false;
      if (!s.opened) {
        matters.push({ step_id: id, kind: "step", ref: id, state: "blocked" });
        continue;
      }
      for (const c of s.criteria.values()) {
        if (c.result !== "conforming") matters.push({ step_id: id, kind: "criterion", ref: c.def.criterion_id, state: c.result });
      }
      for (const d of s.def.decisions) {
        if (s.decisionsAgainst.has(d.decision_id)) matters.push({ step_id: id, kind: "decision", ref: d.decision_id, state: "against" });
        else if (d.required && !s.decisionsSatisfied.has(d.decision_id)) matters.push({ step_id: id, kind: "decision", ref: d.decision_id, state: "missing" });
      }
      const props = [...s.proposals.values()].sort((a, b) => a.seq - b.seq);
      for (const p of props) {
        if (p.rulings.some((r) => r.result === "allow")) continue;
        matters.push({ step_id: id, kind: "proposal", ref: p.digest, state: p.rulings.length === 0 ? "pending" : "denied" });
      }
      if (s.def.actions && s.succeededActions === 0 && s.failedActions.length === 0) matters.push({ step_id: id, kind: "action", ref: id, state: "missing" });
      for (const a of s.failedActions) matters.push({ step_id: id, kind: "action", ref: a.digest, state: "failed" });
      for (const o of s.unknownObservations) {
        if (!o.superseded) matters.push({ step_id: id, kind: "observation", ref: o.digest, state: "unknown_uncertainty" });
      }
      if (s.def.children) {
        const kids = [...s.children.entries()].sort((a, b) => a[1].seq - b[1].seq);
        for (const [run_id, k] of kids) if (!k.sealed) matters.push({ step_id: id, kind: "child", ref: run_id, state: "pending" });
        if (kids.every(([, k]) => k.sealed) && kids.filter(([, k]) => k.sealed.outcome === "complete").length < s.def.children.min) matters.push({ step_id: id, kind: "child", ref: id, state: "missing" });
      }
    }
    const outcome = allComplete ? "complete" : anyFailed ? "failed" : "incomplete";
    return { outcome, open_matters: matters };
  }
  /** Close the Run; RunClosed may only follow when no runtime events are owed. */
  close() {
    check(this.started && !this.closed, 7, "sequencing", "RunClosed outside an open Run");
    check(this.pending.length === 0, 7, "sequencing", `RunClosed while runtime events are owed (${this.pending.map((p) => p.kind).join(", ")})`);
    this.closed = true;
    return this.conclude();
  }
  stepStates() {
    return this.order.map((id) => {
      const s = this.steps.get(id);
      return { step_id: id, state: s.outcome ?? (s.opened ? "open" : "blocked") };
    });
  }
  /** A read-only snapshot of Run state for runtimes and user interfaces. */
  view() {
    const steps = this.order.map((id) => {
      const s = this.steps.get(id);
      return {
        step_id: id,
        state: s.outcome ?? (s.opened ? "open" : "blocked"),
        criteria: [...s.criteria.values()].map((c) => ({
          criterion_id: c.def.criterion_id,
          type: c.def.type,
          result: c.result,
          readings: c.def.type === "measurement" ? c.values.length : c.inputs.length
        })),
        decisions: s.def.decisions.map((d) => ({ decision_id: d.decision_id, required: d.required, satisfied: s.decisionsSatisfied.has(d.decision_id) })),
        proposals: [...s.proposals.values()].sort((a, b) => a.seq - b.seq).map((p) => {
          const allow = p.rulings.find((r) => r.result === "allow");
          const used = allow?.digest ? this.authorizations.get(allow.digest)?.usedBy : void 0;
          return {
            digest: p.digest,
            seq: p.seq,
            proposer: p.proposer,
            action: p.action,
            status: allow ? "allowed" : p.rulings.length ? "denied" : "pending",
            rulings: p.rulings.map((r) => ({ basis: r.basis, result: r.result, ...r.digest ? { digest: r.digest } : {}, ...r.bounds ? { bounds: r.bounds } : {} })),
            ...allow?.digest ? { authorization: allow.digest } : {},
            ...used ? { used_by: used } : {}
          };
        }),
        succeeded_actions: s.succeededActions,
        failed_actions: s.failedActions.map((a) => a.digest)
      };
    });
    return { started: this.started, closed: this.closed, steps, success_counts: Object.fromEntries(this.successCount) };
  }
  // ------------------------------------------------------------ internals
  requireOpen(s, ev) {
    check(s.opened && !s.closed, 7, "authority", `seq ${ev.seq}: ${ev.kind} on ${s.def.step_id}, which is ${s.closed ? "closed" : "not open"}`);
  }
  requirePerformer(s, enr, ev) {
    const ok = s.def.performers.some((p) => p.kind === enr.kind && (p.role === null || enr.roles.includes(p.role)));
    check(ok, 7, "authority", `seq ${ev.seq}: ${enr.participant_id} is not a performer on ${s.def.step_id}`);
  }
  proposalByDigest(d) {
    for (const s of this.steps.values()) {
      const p = s.proposals.get(d);
      if (p) return p;
    }
    return void 0;
  }
  /** The Step's listed Bounds that apply to an action type, in listed order. */
  boundsFor(def, actionType) {
    return (def.proposals?.bound_ids ?? []).map((bid) => this.procedure.bounds.find((x) => x.bound_id === bid)).filter((b) => b.action_type === actionType);
  }
  /**
   * §6.3 item 1. Applicable Bounds are those for the proposed action type, in
   * listed order. For each parameter (code point order) the first applicable
   * Bound on it whose condition holds governs; conditions read the latest
   * reading of their quantity in the Run. The ruling records the governing
   * Bounds and the readings consulted, so the Record says why the limit was
   * what it was.
   */
  ruleOnBounds(def, action2) {
    const applicable = this.boundsFor(def, action2.type);
    const governing = [];
    const inputs = [];
    const why = [];
    const params = Object.keys(action2.parameters).sort(byCodePoint);
    for (const p of params) {
      for (const b of applicable.filter((x) => x.parameter === p)) {
        if (!b.when) {
          governing.push(b);
          break;
        }
        const w = b.when;
        const rd = this.readings.get(`${w.quantity}\0${w.unit}`);
        if (rd && !inputs.includes(rd.digest)) inputs.push(rd.digest);
        const holds = !!rd && rd.stated && rd.value >= w.min && rd.value <= w.max;
        if (holds) {
          why.push(`${b.bound_id} applies: ${w.quantity} is ${rd.value} ${w.unit}, within ${w.min} to ${w.max}`);
          governing.push(b);
          break;
        }
        if (rd && !rd.stated) {
          why.push(`the latest ${w.quantity} reading has unknown uncertainty, so no limit on ${p} can be chosen`);
          break;
        }
        why.push(!rd ? `${b.bound_id} does not apply: no ${w.quantity} reading yet` : `${b.bound_id} does not apply: ${w.quantity} is ${rd.value} ${w.unit}, outside ${w.min} to ${w.max}`);
      }
    }
    const done = (result, last) => ({ result, reason: [...why, last].join("; "), governing, inputs });
    if (applicable.length === 0) return done("deny", `${action2.type} has no limits on ${def.step_id}`);
    for (const p of params) {
      if (!governing.some((b) => b.parameter === p)) {
        return done("deny", applicable.some((b) => b.parameter === p) ? `no limit on ${p} applies` : `${p} has no limit`);
      }
    }
    for (const b of applicable) {
      if (!Object.hasOwn(action2.parameters, b.parameter)) return done("deny", `${b.bound_id}: ${b.parameter} is missing`);
    }
    const ok = [];
    for (const b of governing) {
      const bid = b.bound_id;
      const v = action2.parameters[b.parameter];
      if (typeof v !== "number") return done("deny", `${bid}: ${b.parameter} is not a number`);
      const min = limitValue(b.min, this.bound);
      const max = limitValue(b.max, this.bound);
      if (v < min || v > max) return done("deny", `${bid}: ${b.parameter} ${v} is outside ${min} to ${max}`);
      if (b.max_count_per_run !== void 0) {
        const used = this.successCount.get(b.action_type) ?? 0;
        if (used >= b.max_count_per_run) return done("deny", `${bid}: all ${b.max_count_per_run} successful ${b.action_type} actions this run are used`);
        ok.push(`${bid}: ${b.parameter} ${v} is within ${min} to ${max}, use ${used + 1} of ${b.max_count_per_run}`);
      } else {
        ok.push(`${bid}: ${b.parameter} ${v} is within ${min} to ${max}`);
      }
    }
    return done("allow", ok.join("; "));
  }
  observe(s, ev, digest) {
    const out = [];
    const m = ev.measurement;
    const a = ev.artifact;
    const stated = m ? ev.uncertainty.kind === "stated" : false;
    if (m && stated) s.stated.push({ digest, seq: ev.seq, quantity: m.quantity, unit: m.unit, value: m.value, declared_time: ev.declared_time });
    if (m) {
      const matters = [...s.criteria.values()].some((c) => c.def.type === "measurement" && c.def.quantity === m.quantity && c.def.unit === m.unit);
      if (stated) {
        for (const u of s.unknownObservations) if (u.quantity === m.quantity && u.unit === m.unit) u.superseded = true;
      } else if (matters) {
        s.unknownObservations.push({ digest, seq: ev.seq, quantity: m.quantity, unit: m.unit, superseded: false });
      }
    }
    for (const c of s.criteria.values()) {
      if (c.def.type === "derived") {
        if (m && stated && c.def.inputs.some((i) => "quantity" in i && i.quantity === m.quantity && i.unit === m.unit)) out.push(this.derive(s, c));
      } else if (c.def.type === "measurement") {
        if (!m || m.quantity !== c.def.quantity || m.unit !== c.def.unit) continue;
        if (stated && c.result === "undetermined") this.walk(c, c.def, m.value, digest);
        out.push(this.evaluation(s, c));
      } else {
        const met = c.def.type === "artifact" ? a !== void 0 && c.def.media_types.some((p) => mediaMatches(p, a.media_type)) : ev.confirmation?.criterion_id === c.def.criterion_id;
        if (!met) continue;
        if (c.result === "undetermined") {
          c.result = "conforming";
          c.inputs = [digest];
          if (a) c.artifact = a;
        }
        out.push(this.evaluation(s, c));
      }
    }
    return out;
  }
  /**
   * (draft 11) Run a derived criterion's sealed policy on its inputs, while it is undetermined, and owe its
   * Evaluation (Appendix L). Whatever goes wrong in the policy gives nonconforming: it did not show the evidence conforms.
   */
  derive(s, c) {
    const def = c.def;
    if (c.result === "undetermined") {
      const consulted = [];
      const inputs = {};
      for (const i of def.inputs) {
        if ("quantity" in i) {
          const rows = s.stated.filter((x) => x.quantity === i.quantity && x.unit === i.unit).slice(-i.last);
          inputs[i.name] = rows.map((x) => ({ digest: x.digest, declared_time: x.declared_time, value: x.value }));
          consulted.push(...rows);
        } else if ("actions" in i) {
          const rows = this.actionLog.filter((x) => x.type === i.actions);
          inputs[i.name] = rows.map((x) => ({ digest: x.digest, declared_time: x.declared_time, parameters: x.parameters, status: x.status }));
          consulted.push(...rows);
        } else if ("input" in i) {
          inputs[i.name] = this.bound[i.input];
        } else {
          const d = s.criteria.get(i.derived);
          inputs[i.name] = { result: d.result, ...d.value !== void 0 ? { value: d.value } : {} };
        }
      }
      const got = this.runPolicy(def, canonicalBytes({ criterion_id: def.criterion_id, inputs, step_id: s.def.step_id }));
      c.result = got.result;
      if (got.value !== void 0) c.value = got.value;
      c.inputs = [...new Map(consulted.sort((a, b) => a.seq - b.seq).map((x) => [x.digest, x.digest])).values()];
    }
    return this.evaluation(s, c);
  }
  runPolicy(def, input) {
    let m = this.policies.get(def.policy.digest);
    if (m === void 0) {
      const bytes3 = this.policyBytes(def.policy.digest);
      try {
        m = bytes3 ? decodePolicy(bytes3) : null;
      } catch (e) {
        if (!(e instanceof PolicyFault)) throw e;
        m = null;
      }
      this.policies.set(def.policy.digest, m);
    }
    const no = { result: "nonconforming" };
    const out = m ? runDecoded(m, input) : void 0;
    if (!out) return no;
    let o;
    try {
      o = parseCanonical(out);
    } catch {
      return no;
    }
    if (!isObject(o) || Object.keys(o).length !== 1) return no;
    if (def.result === "conforming") return o.result === "conforming" || o.result === "nonconforming" || o.result === "undetermined" ? { result: o.result } : no;
    return typeof o.value === "number" ? { result: o.value >= def.result.min && o.value <= def.result.max ? "conforming" : "undetermined", value: o.value } : no;
  }
  walk(c, def, value2, digest) {
    c.values.push(value2);
    c.inputs.push(digest);
    const tail = c.values.slice(-def.consecutive);
    if (tail.length === def.consecutive && tail.every((v) => v >= def.tolerance.min && v <= def.tolerance.max)) {
      c.result = "conforming";
    } else if (c.values.length >= def.max_observations) {
      c.result = "nonconforming";
    }
  }
  evaluation(s, c) {
    let explanation;
    if (c.def.type === "measurement") {
      const def = c.def;
      explanation = `${c.values.length} of at most ${def.max_observations} readings; needs ${def.consecutive} in a row within ${def.tolerance.min} to ${def.tolerance.max} ${def.unit}`;
    } else {
      explanation = c.def.type === "derived" ? `sealed policy ${c.def.policy.title ?? c.def.policy.digest}: ${c.result}` : c.def.type === "confirmation" ? c.result === "conforming" ? "confirmed by a person in a named role" : "not yet confirmed" : c.result === "conforming" ? "file present and its hash checked" : "no matching file yet";
    }
    return { kind: "Evaluation", step_id: s.def.step_id, criterion_id: c.def.criterion_id, result: c.result, inputs: [...c.inputs], explanation };
  }
  terminal(s) {
    if (!s.opened || s.closed) return null;
    if (s.failedActions.length > 0 || s.decisionsAgainst.size > 0) return "failed";
    const ch = s.def.children;
    if (ch) {
      const kids = [...s.children.values()];
      if (ch.require === "all_complete" && kids.some((k) => k.sealed && k.sealed.outcome !== "complete")) return "failed";
      if (kids.some((k) => !k.sealed) || kids.filter((k) => k.sealed.outcome === "complete").length < ch.min) return null;
    }
    for (const c of s.criteria.values()) if (c.result === "nonconforming") return "failed";
    for (const c of s.criteria.values()) if (c.result !== "conforming") return null;
    for (const d of s.def.decisions) if (d.required && !s.decisionsSatisfied.has(d.decision_id)) return null;
    if (s.def.actions && s.succeededActions === 0) return null;
    return "complete";
  }
  /**
   * Close Steps that became terminal and open Steps that became ready,
   * scanning in Procedure order until nothing changes (§6.3 items 3–4).
   */
  settle() {
    const out = [];
    let changed = true;
    while (changed) {
      changed = false;
      for (const id of this.order) {
        const s = this.steps.get(id);
        if (!s.opened && s.def.requires.every((q) => this.steps.get(q).outcome === "complete")) {
          s.opened = true;
          out.push({ kind: "StepOpened", step_id: id });
          changed = true;
        }
        const t = this.terminal(s);
        if (t) {
          s.closed = true;
          s.outcome = t;
          out.push({ kind: "StepClosed", step_id: id, outcome: t });
          changed = true;
        }
      }
    }
    return out;
  }
};
function bindingProblem(p, ev) {
  const declared = new Map((p.inputs ?? []).map((i) => [i.input_id, i]));
  const inputs = ev.inputs ?? {};
  if (!isObject(inputs)) return "inputs must be an object";
  for (const k of Object.keys(inputs).sort(byCodePoint)) if (!declared.has(k)) return `input ${k} is not declared by the Procedure`;
  for (const [id, i] of declared) {
    if (!Object.hasOwn(inputs, id)) return `input ${id} is not bound`;
    const v = inputs[id];
    if (i.kind === "number") {
      if (typeof v !== "number") return `input ${id} must be a number`;
      if (i.range && (v < i.range.min || v > i.range.max)) return `input ${id} is ${v}, outside ${i.range.min} to ${i.range.max}`;
    } else if (i.kind === "text") {
      if (typeof v !== "string") return `input ${id} must be text`;
    } else if (i.kind === "artifact") {
      if (!isObject(v) || Object.keys(v).sort().join() !== "digest,media_type,size") return `input ${id} must be a file { digest, media_type, size }`;
      if (!i.media_types.some((m) => mediaMatches(m, String(v.media_type)))) return `input ${id} is ${String(v.media_type)}, not ${i.media_types.join(" or ")}`;
    } else if (!isObject(v) || Object.keys(v).sort().join() !== "digest,output_id,record,run_id" || v.output_id !== i.from.output_id) {
      return `input ${id} must name the output ${i.from.output_id} of a sealed Record { run_id, record, output_id, digest }`;
    }
  }
  const subjects = ev.subjects ?? [];
  const kinds = new Set((p.subjects ?? []).map((x) => x.kind));
  for (const x of subjects) if (!kinds.has(String(x.kind))) return `subject kind ${String(x.kind)} is not declared by the Procedure`;
  for (const k of p.subjects ?? []) if (k.required && !subjects.some((x) => x.kind === k.kind)) return `the Run names no ${k.kind}, which the Procedure requires`;
  const related = ev.related ?? [];
  if (related.filter((x) => x.kind === "parent").length > 1) return "a Run has at most one parent";
  for (const x of related) if (x.kind === "parent" && x.step_id === void 0) return "a parent relation names the parent Step";
  return null;
}
function relatedOf(started, childSealed = []) {
  const out = [...(started.related ?? []).map((x) => ({ ...x }))];
  const inputs = started.inputs ?? {};
  for (const k of Object.keys(inputs).sort(byCodePoint)) {
    const v = inputs[k];
    if (isObject(v) && "record" in v) out.push({ kind: "input", run_id: v.run_id, record: v.record });
  }
  for (const c of childSealed) out.push({ kind: "child", run_id: c.child_run_id, record: c.record });
  return out.length ? out : void 0;
}

// ../packages/runrec/src/trust.ts
function provenanceOf(keyId, pin, published, warnings, what) {
  let provenance = "unpinned";
  if (pin !== void 0) {
    const pins = typeof pin === "string" ? [pin] : pin;
    if (pins.includes(keyId)) provenance = "pinned";
    else {
      provenance = "mismatch";
      warnings.push(`workspace key ${keyId} does not match the pinned key ${pins.join(" or ")}: this ${what} was not issued by the workspace you expected`);
    }
  }
  if (!published) return { provenance };
  if (published.keyIds === null) {
    warnings.push(`could not look up the keys ${published.domain} publishes, so this ${what} was not shown to be issued by a key it publishes`);
    return { provenance: "mismatch" };
  }
  if (!published.keyIds.includes(keyId)) {
    warnings.push(`${published.domain} does not publish workspace key ${keyId}: this ${what} was not issued by a key ${published.domain} vouches for`);
    return { provenance: "mismatch" };
  }
  return { provenance, finding: { kind: "published", domain: published.domain } };
}

// ../packages/runrec/src/zip.ts
var CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n2 = 0; n2 < 256; n2++) {
    let c = n2;
    for (let k = 0; k < 8; k++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
    t[n2] = c >>> 0;
  }
  return t;
})();
function crc32(data) {
  let c = 4294967295;
  for (let i = 0; i < data.length; i++) c = CRC_TABLE[(c ^ data[i]) & 255] ^ c >>> 8;
  return (c ^ 4294967295) >>> 0;
}
var VERSION = 20;
var FLAGS = 2048;
var DOS_TIME = 0;
var DOS_DATE = 0 << 9 | 1 << 5 | 1;
var MAX_U32 = 4294967295;
var ZipLimitError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "ZipLimitError";
  }
};
var ZipError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "ZipError";
  }
};
function isSafeName(name) {
  if (name.length === 0 || name.startsWith("/") || name.endsWith("/") || name.includes("\\") || name.includes("\0")) return false;
  return name.split("/").every((s) => s !== "" && s !== "." && s !== "..");
}
function writeZip(entries) {
  const enc2 = new TextEncoder();
  const parts = [];
  const central = [];
  const seen = /* @__PURE__ */ new Set();
  let offset = 0;
  for (const e of entries) {
    if (!isSafeName(e.name)) throw new ZipError(`unsafe entry name ${JSON.stringify(e.name)}`);
    if (seen.has(e.name)) throw new ZipError(`duplicate entry name ${e.name}`);
    seen.add(e.name);
    const name = Buffer.from(enc2.encode(e.name));
    const crc = crc32(e.data);
    if (e.data.length >= MAX_U32 || offset >= MAX_U32) throw new ZipError("archive too large for the canonical profile");
    const local = Buffer.alloc(30);
    local.writeUInt32LE(67324752, 0);
    local.writeUInt16LE(VERSION, 4);
    local.writeUInt16LE(FLAGS, 6);
    local.writeUInt16LE(0, 8);
    local.writeUInt16LE(DOS_TIME, 10);
    local.writeUInt16LE(DOS_DATE, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(e.data.length, 18);
    local.writeUInt32LE(e.data.length, 22);
    local.writeUInt16LE(name.length, 26);
    local.writeUInt16LE(0, 28);
    parts.push(local, name, Buffer.from(e.data));
    const c = Buffer.alloc(46);
    c.writeUInt32LE(33639248, 0);
    c.writeUInt16LE(VERSION, 4);
    c.writeUInt16LE(VERSION, 6);
    c.writeUInt16LE(FLAGS, 8);
    c.writeUInt16LE(0, 10);
    c.writeUInt16LE(DOS_TIME, 12);
    c.writeUInt16LE(DOS_DATE, 14);
    c.writeUInt32LE(crc, 16);
    c.writeUInt32LE(e.data.length, 20);
    c.writeUInt32LE(e.data.length, 24);
    c.writeUInt16LE(name.length, 28);
    c.writeUInt32LE(offset, 42);
    central.push(c, name);
    offset += 30 + name.length + e.data.length;
  }
  const cd = Buffer.concat(central);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(101010256, 0);
  end.writeUInt16LE(entries.length, 8);
  end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(cd.length, 12);
  end.writeUInt32LE(offset, 16);
  return new Uint8Array(Buffer.concat([...parts, cd, end]));
}
function readZip(bytes3, limits = {}) {
  const maxEntries = limits.maxEntries ?? 1e5;
  const maxEntryBytes = limits.maxEntryBytes ?? 256 * 1024 * 1024;
  const maxTotal = limits.maxTotalBytes ?? 2 * 1024 * 1024 * 1024;
  const view = new DataView(bytes3.buffer, bytes3.byteOffset, bytes3.byteLength);
  const buf = { length: bytes3.length, readUInt16LE: (o) => view.getUint16(o, true), readUInt32LE: (o) => view.getUint32(o, true), subarray: (a, b) => bytes3.subarray(a, b) };
  const bad = (msg) => {
    throw new ZipError(msg);
  };
  if (buf.length < 22) bad("not a zip archive");
  const eocd = buf.length - 22;
  if (buf.readUInt32LE(eocd) !== 101010256) bad("the end of central directory record must end the file (no comment, no trailing data)");
  if (buf.readUInt16LE(eocd + 4) !== 0 || buf.readUInt16LE(eocd + 6) !== 0) bad("multi-disk archives are not allowed");
  const count = buf.readUInt16LE(eocd + 8);
  if (buf.readUInt16LE(eocd + 10) !== count) bad("entry counts disagree");
  const cdSize = buf.readUInt32LE(eocd + 12);
  const cdOffset = buf.readUInt32LE(eocd + 16);
  if (buf.readUInt16LE(eocd + 20) !== 0) bad("archive comments are not allowed");
  if (count === 65535 || cdSize === MAX_U32 || cdOffset === MAX_U32) bad("zip64 is not allowed");
  if (cdOffset + cdSize !== eocd) bad("the central directory must end exactly where the end record begins");
  if (count > maxEntries) throw new ZipLimitError(`too many entries (${count} > ${maxEntries})`);
  const dec = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true });
  const out = [];
  const names = /* @__PURE__ */ new Set();
  let total = 0;
  let p = cdOffset;
  let expectedLocal = 0;
  for (let k = 0; k < count; k++) {
    if (p + 46 > eocd || buf.readUInt32LE(p) !== 33639248) bad("malformed central directory");
    const made = buf.readUInt16LE(p + 4);
    const needed = buf.readUInt16LE(p + 6);
    const flags = buf.readUInt16LE(p + 8);
    const method = buf.readUInt16LE(p + 10);
    const time = buf.readUInt16LE(p + 12);
    const date = buf.readUInt16LE(p + 14);
    const crc = buf.readUInt32LE(p + 16);
    const compSize = buf.readUInt32LE(p + 20);
    const size = buf.readUInt32LE(p + 24);
    const nameLen = buf.readUInt16LE(p + 28);
    const extraLen = buf.readUInt16LE(p + 30);
    const commentLen = buf.readUInt16LE(p + 32);
    const disk = buf.readUInt16LE(p + 34);
    const internalAttrs = buf.readUInt16LE(p + 36);
    const externalAttrs = buf.readUInt32LE(p + 38);
    const localOff = buf.readUInt32LE(p + 42);
    if (p + 46 + nameLen > eocd) bad("malformed central directory");
    const nameBytes = buf.subarray(p + 46, p + 46 + nameLen);
    let name;
    try {
      name = dec.decode(nameBytes);
    } catch {
      return bad("entry name is not valid UTF-8");
    }
    if (flags !== FLAGS) bad(`${JSON.stringify(name)}: flags must be ${FLAGS} (UTF-8, no encryption, no data descriptor)`);
    if (made !== VERSION || needed !== VERSION) bad(`${JSON.stringify(name)}: version made by and version needed must both be ${VERSION}`);
    if (internalAttrs !== 0 || externalAttrs !== 0) bad(`${JSON.stringify(name)}: file attributes must be 0`);
    if (time !== DOS_TIME || date !== DOS_DATE) bad(`${JSON.stringify(name)}: modification time and date must be 1980-01-01 00:00`);
    if (size === MAX_U32 || compSize === MAX_U32 || localOff === MAX_U32) bad(`${JSON.stringify(name)}: zip64 sentinel values are not allowed`);
    if (method !== 0) bad(`${JSON.stringify(name)}: only stored entries are allowed`);
    if (extraLen !== 0 || commentLen !== 0) bad(`${JSON.stringify(name)}: extra fields and entry comments are not allowed`);
    if (disk !== 0) bad(`${JSON.stringify(name)}: multi-disk archives are not allowed`);
    if (compSize !== size) bad(`${JSON.stringify(name)}: stored size mismatch`);
    if (!isSafeName(name)) bad(`unsafe entry name ${JSON.stringify(name)}`);
    if (names.has(name)) bad(`duplicate entry name ${JSON.stringify(name)}`);
    names.add(name);
    if (size > maxEntryBytes) throw new ZipLimitError(`entry ${JSON.stringify(name)} exceeds the size limit`);
    total += size;
    if (total > maxTotal) throw new ZipLimitError("archive exceeds the total size limit");
    if (localOff !== expectedLocal) bad(`${JSON.stringify(name)}: entries must be laid out back to back in central-directory order`);
    const l = localOff;
    if (l + 30 > cdOffset || buf.readUInt32LE(l) !== 67324752) bad(`${JSON.stringify(name)}: bad local header`);
    if (buf.readUInt16LE(l + 4) !== needed || buf.readUInt16LE(l + 6) !== flags || buf.readUInt16LE(l + 8) !== method || buf.readUInt16LE(l + 10) !== time || buf.readUInt16LE(l + 12) !== date || buf.readUInt32LE(l + 14) !== crc || buf.readUInt32LE(l + 18) !== compSize || buf.readUInt32LE(l + 22) !== size || buf.readUInt16LE(l + 26) !== nameLen || buf.readUInt16LE(l + 28) !== 0) bad(`${JSON.stringify(name)}: local header differs from the central directory`);
    if (!sameBytes(buf.subarray(l + 30, l + 30 + nameLen), nameBytes)) bad(`${JSON.stringify(name)}: local header name differs from the central directory`);
    const start = l + 30 + nameLen;
    const end = start + size;
    if (end > cdOffset) bad(`${JSON.stringify(name)}: entry runs into the central directory`);
    const data = new Uint8Array(buf.subarray(start, end));
    if (crc32(data) !== crc) bad(`CRC mismatch for ${JSON.stringify(name)}`);
    out.push({ name, data });
    expectedLocal = end;
    p += 46 + nameLen;
  }
  if (expectedLocal !== cdOffset) bad("unreferenced bytes before the central directory");
  if (p !== eocd) bad("unreferenced bytes in the central directory");
  return out;
}
function sameBytes(a, b) {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
  return true;
}

// ../packages/runrec/src/verify.ts
var LAYOUT = [
  /^manifest\.dsse\.json$/,
  /^procedure\.dsse\.json$/,
  /^participants\/[a-z0-9][a-z0-9._-]{0,127}\.dsse\.json$/,
  /^events\/[0-9]{6}-[A-Za-z]+\.dsse\.json$/,
  /^evidence\/sha256\/[0-9a-f]{64}$/,
  /^README\.txt$/,
  /^disclosure\.dsse\.json$/,
  // (draft 11, §7.4)
  /^timestamps\/[0-9]+\.tsr$/
  // (draft 11, reserved)
];
function read(step, name, bytes3, expected) {
  try {
    return parseAttestation(bytes3, expected);
  } catch (e) {
    if (e instanceof AttestationError) return fail(step, e.code, `${name}: ${e.message}`);
    throw e;
  }
}
var byName = (a, b) => a < b ? -1 : a > b ? 1 : 0;
function summarize(r) {
  const parts = [`integrity: ${r.integrity}`, `provenance: ${r.provenance}`];
  const pub = r.findings?.find((f) => f.kind === "published");
  if (pub) parts.push(`published by ${pub.domain}`);
  if (r.integrity === "pass" && r.outcome) {
    const n2 = r.open_matters?.length ?? 0;
    parts.push(`outcome: ${r.outcome}${n2 ? ` (${n2} open matter${n2 === 1 ? "" : "s"})` : ""}`);
  }
  if (r.failure) parts.push(`step ${r.failure.step} ${r.failure.code}: ${r.failure.message}`);
  if (r.workspace) parts.push(`workspace ${r.workspace.key_id}`);
  return parts.join(" \xB7 ");
}
function verifyRecord(bundle, opts = {}) {
  return openRecord(bundle, opts).report;
}
function openRecord(bundle, opts = {}) {
  const expecting = opts.pin !== void 0 || opts.published !== void 0;
  const partial = { integrity: "fail", provenance: expecting ? "mismatch" : "unpinned", warnings: [] };
  let contents;
  try {
    contents = run(bundle, opts, partial);
    partial.integrity = "pass";
  } catch (e) {
    contents = void 0;
    if (e instanceof RecordError) partial.failure = { step: e.step, code: e.code, message: e.message };
    else partial.failure = { step: 1, code: "internal", message: e.message };
    delete partial.outcome;
    delete partial.open_matters;
    delete partial.steps;
    delete partial.human_authorizations;
    delete partial.decisions;
    delete partial.agreed_by;
    delete partial.inputs;
    delete partial.subjects;
    delete partial.outputs;
    delete partial.related;
    delete partial.findings;
  }
  if (partial.provenance === "mismatch" && !partial.workspace) {
    partial.warnings.push(`the workspace key could not be established, so this Record was not shown to be issued by ${opts.pin !== void 0 ? `the pinned key ${[opts.pin].flat().join(" or ")}` : `a key ${opts.published.domain} publishes`}`);
  }
  return { report: { ...partial, summary: summarize(partial) }, ...contents ? { contents } : {} };
}
function run(bundle, opts, report) {
  let entries;
  try {
    entries = readZip(bundle, opts.limits);
  } catch (e) {
    return fail(1, e instanceof ZipLimitError ? "limit" : "archive", e.message);
  }
  const files = new Map(entries.map((e) => [e.name, e.data]));
  for (const name of files.keys()) check(LAYOUT.some((re) => re.test(name)), 1, "layout", `entry outside the bundle layout: ${JSON.stringify(name)}`);
  check(files.has("manifest.dsse.json"), 1, "missing", "manifest.dsse.json is missing");
  check(files.has("procedure.dsse.json"), 1, "missing", "procedure.dsse.json is missing");
  const mAtt = read(1, "manifest.dsse.json", files.get("manifest.dsse.json"), "manifest");
  check(mAtt.statement.predicate.format === "runrec/0.1", 1, "format", `unsupported format ${JSON.stringify(mAtt.statement.predicate.format)}`);
  const manifest = parseManifest(mAtt.statement.predicate);
  report.run_id = manifest.run_id;
  report.procedure = { ...manifest.procedure };
  report.event_count = manifest.events.count;
  let wsKey;
  try {
    wsKey = b64urlDecode(manifest.workspace.public_key);
  } catch {
    return fail(2, "key", "workspace public_key is not canonical base64url");
  }
  check(isStrictPublicKey(wsKey), 2, "key", "workspace public_key is not a strict Ed25519 public key");
  const wsKeyId = keyIdOf(wsKey);
  check(wsKeyId === manifest.workspace.key_id, 2, "key", "workspace key_id does not match its public key");
  report.workspace = { key_id: wsKeyId, workspace_id: manifest.workspace.workspace_id, display_name: manifest.workspace.display_name };
  const prov = provenanceOf(wsKeyId, opts.pin, opts.published, report.warnings, "Record");
  report.provenance = prov.provenance;
  check(mAtt.keyid === wsKeyId, 2, "keyid", "manifest keyid is not the workspace key_id");
  check(verifySignature(mAtt, wsKey), 2, "signature", "manifest signature does not verify");
  check(mAtt.statement.subject[0].name === `runrec:run:${manifest.run_id}` && subjectDigest(mAtt.statement) === manifest.events.head, 2, "subject", "manifest subject is not this Run and its chain head");
  const boundPid = /* @__PURE__ */ new Set();
  const bound = /* @__PURE__ */ new Map();
  for (const p of manifest.participants) {
    check(!boundPid.has(p.participant_id) && !bound.has(p.digest), 3, "manifest", `manifest.participants lists ${p.participant_id} or its digest twice`);
    boundPid.add(p.participant_id);
    bound.set(p.digest, p.participant_id);
  }
  const enrollments = /* @__PURE__ */ new Map();
  const byKey = /* @__PURE__ */ new Map();
  const present = /* @__PURE__ */ new Set();
  for (const name of [...files.keys()].filter((n2) => n2.startsWith("participants/")).sort(byName)) {
    const a = read(3, name, files.get(name), "enrollment");
    check(bound.has(a.digest), 3, "unbound", `${name} is not among the enrollments the manifest binds`);
    check(a.keyid === wsKeyId, 3, "keyid", `${name}: keyid is not the workspace key_id`);
    check(verifySignature(a, wsKey), 3, "signature", `${name} is not signed by the workspace key`);
    const e = parseEnrollment(a.statement.predicate, new Reader2(3, name));
    check(bound.get(a.digest) === e.participant_id, 3, "manifest", `${name}: the manifest binds this enrollment to ${bound.get(a.digest)}`);
    check(e.workspace_id === manifest.workspace.workspace_id, 3, "workspace", `${name}: workspace_id differs from the manifest`);
    let pk;
    try {
      pk = b64urlDecode(e.public_key);
    } catch {
      return fail(3, "key", `${name}: public_key is not canonical base64url`);
    }
    check(isStrictPublicKey(pk), 3, "key", `${name}: public_key is not a strict Ed25519 public key`);
    check(keyIdOf(pk) === e.key_id, 3, "key", `${name}: key_id does not match public_key`);
    check(a.statement.subject[0].name === `runrec:participant:${e.participant_id}` && subjectDigest(a.statement) === e.key_id, 3, "subject", `${name}: subject is not this Participant and key`);
    check(name === `participants/${e.participant_id}.dsse.json`, 3, "layout", `${name} must be named participants/${e.participant_id}.dsse.json`);
    check(!enrollments.has(e.participant_id), 3, "duplicate", `participant ${e.participant_id} enrolled twice`);
    check(!byKey.has(e.key_id) && e.key_id !== wsKeyId, 3, "duplicate", `key ${e.key_id} enrolled twice or is the workspace key`);
    enrollments.set(e.participant_id, e);
    byKey.set(e.key_id, e.participant_id);
    present.add(a.digest);
  }
  for (const p of manifest.participants) check(present.has(p.digest), 3, "missing", `the enrollment of ${p.participant_id} that the manifest binds is missing`);
  const pAtt = read(4, "procedure.dsse.json", files.get("procedure.dsse.json"), "procedure");
  const pDigest = digestOf(canonicalBytes(pAtt.statement.predicate));
  check(pDigest === manifest.procedure.digest, 4, "digest", "Procedure digest differs from the manifest");
  check(subjectDigest(pAtt.statement) === pDigest, 4, "subject", "Procedure subject digest differs from its predicate digest");
  const rawParties = pAtt.statement.predicate.parties;
  const parties = Array.isArray(rawParties) && rawParties.length > 0 && rawParties.every((x) => isObject(x) && typeof x.party_id === "string") ? rawParties.map((x) => x.party_id) : null;
  const signers = [];
  for (const sg of pAtt.signatures) {
    const id = byKey.get(sg.keyid);
    const e = id ? enrollments.get(id) : void 0;
    check(e && e.status === "active" && e.kind === "human" && e.grants.includes("author"), 4, "signer", "Procedure is not signed by an active Human holding the author grant");
    if (parties) check(e.party !== void 0 && parties.includes(e.party), 4, "signer", `Procedure is signed by ${e.participant_id}, who signs for no party it names`);
    signers.push(e);
  }
  if (parties) {
    for (const party of parties) {
      const n2 = signers.filter((e) => e.party === party).length;
      check(n2 === 1, 4, "signer", n2 === 0 ? `party ${party} has not signed the Procedure` : `party ${party} signed the Procedure ${n2} times`);
    }
  } else {
    check(signers.length === 1, 4, "signer", "a Procedure without parties carries exactly one signature");
  }
  pAtt.signatures.forEach((sg, i) => check(verifySignature(pAtt, b64urlDecode(signers[i].public_key), sg.sig), 4, "signature", `Procedure signature by ${signers[i].participant_id} does not verify`));
  const procedure = parseProcedure(pAtt.statement.predicate);
  const subjectName = `runrec:procedure:${procedure.procedure_id}@${procedure.version}`;
  check(pAtt.statement.subject[0].name === subjectName, 4, "subject", "Procedure subject name is not its id and version");
  check(procedure.procedure_id === manifest.procedure.procedure_id && procedure.version === manifest.procedure.version, 4, "manifest", "Procedure id or version differs from the manifest");
  const parsed = [];
  for (const name of [...files.keys()].filter((n2) => n2.startsWith("events/")).sort(byName)) {
    const a = read(5, name, files.get(name), "event");
    const seq = a.statement.predicate.seq;
    check(typeof seq === "number" && Number.isSafeInteger(seq) && seq >= 1, 5, "schema", `${name}: seq must be an integer of at least 1`);
    parsed.push({ att: a, name, seq });
  }
  parsed.sort((x, y) => x.seq - y.seq);
  for (let k = 0; k < parsed.length; k++) {
    const seq = parsed[k].seq;
    check(seq === k + 1, 5, "chain", seq <= k ? `duplicate seq ${seq}` : `seq gap: expected ${k + 1}, found ${seq}`);
  }
  check(parsed.length === manifest.events.count, 5, "chain", `bundle has ${parsed.length} events, manifest says ${manifest.events.count}`);
  let previous = null;
  const events = [];
  for (const { att: a, name, seq } of parsed) {
    const actor = a.statement.predicate.actor;
    check(isObject(actor) && typeof actor.participant_id === "string" && typeof actor.kind === "string" && typeof actor.key_id === "string", 5, "schema", `seq ${seq}: actor must have string participant_id, kind and key_id`);
    let key;
    if (actor.participant_id === "runtime") {
      check(actor.kind === "runtime" && actor.key_id === wsKeyId, 5, "actor", `seq ${seq}: runtime actor must use the workspace key`);
      key = wsKey;
    } else {
      const e = enrollments.get(actor.participant_id);
      check(e && e.status === "active" && e.kind === actor.kind && e.key_id === actor.key_id, 5, "enrollment", `seq ${seq}: actor ${actor.participant_id} is not an active enrollment with this kind and key`);
      key = b64urlDecode(e.public_key);
    }
    check(a.keyid === actor.key_id, 5, "keyid", `seq ${seq}: signature keyid differs from the actor key`);
    check(verifySignature(a, key), 5, "signature", `seq ${seq}: signature does not verify`);
    const ev = parseEvent(a.statement.predicate, new Reader2(5, `seq ${seq}`));
    const canonicalName = `events/${String(ev.seq).padStart(6, "0")}-${ev.kind}.dsse.json`;
    check(name === canonicalName, 5, "layout", `${name} must be named ${canonicalName}`);
    check(ev.run_id === manifest.run_id && ev.workspace_id === manifest.workspace.workspace_id, 5, "splice", `seq ${seq}: run_id or workspace_id differs from the manifest`);
    check(a.statement.subject[0].name === subjectName && subjectDigest(a.statement) === pDigest, 5, "subject", `seq ${seq}: subject is not this Procedure`);
    check(ev.previous === previous, 5, "chain", `seq ${seq}: previous does not link to the prior event`);
    check(SIGNERS[ev.kind].includes(ev.actor.kind), 5, "signer", `seq ${seq}: ${ev.kind} may not be signed by ${ev.actor.kind}`);
    previous = a.digest;
    events.push({ ev, digest: a.digest });
  }
  check(events[0].ev.kind === "RunStarted", 5, "chain", "first event is not RunStarted");
  check(events.at(-1).ev.kind === "RunClosed", 5, "chain", "last event is not RunClosed");
  for (const { ev } of events.slice(1, -1)) {
    check(ev.kind !== "RunStarted" && ev.kind !== "RunClosed", 5, "chain", `seq ${ev.seq}: ${ev.kind} in the middle of the chain`);
  }
  check(previous === manifest.events.head, 5, "chain", "last event digest is not the manifest head");
  const first = events[0].ev;
  check(first.procedure_digest === pDigest && first.procedure_id === procedure.procedure_id && first.version === procedure.version, 5, "chain", "RunStarted names a different Procedure");
  const binding = bindingProblem(procedure, first);
  check(binding === null, 5, "reference", `RunStarted: ${binding}`);
  const cited2 = /* @__PURE__ */ new Map();
  for (const a of policiesOf(procedure)) if (!cited2.has(a.digest)) cited2.set(a.digest, { media_type: a.media_type, size: a.size, seq: 0 });
  for (const { ev } of events) {
    for (const a of citationsOf(ev)) {
      const prior = cited2.get(a.digest);
      if (prior) check(prior.media_type === a.media_type && prior.size === a.size, 6, "alias", `seq ${ev.seq}: evidence ${a.digest} is cited as ${a.media_type}/${a.size} bytes, earlier as ${prior.media_type}/${prior.size} bytes`);
      else cited2.set(a.digest, { media_type: a.media_type, size: a.size, seq: ev.seq });
    }
  }
  const manifestEvidence = new Map(manifest.evidence.map((e) => [e.digest, e]));
  check(manifestEvidence.size === manifest.evidence.length, 6, "manifest", "manifest.evidence lists a digest twice");
  const withheld = /* @__PURE__ */ new Map();
  let orderedBy;
  if (files.has("disclosure.dsse.json")) {
    const dAtt = read(6, "disclosure.dsse.json", files.get("disclosure.dsse.json"), "disclosure");
    const disc = parseDisclosure(dAtt.statement.predicate, new Reader2(6, "disclosure.dsse.json"));
    const by = enrollments.get(disc.ordered_by);
    check(by && by.status === "active" && by.kind === "human" && by.grants.includes("disclose"), 6, "signer", `the disclosure is ordered by ${disc.ordered_by}, who is not an active Human holding disclose in this Record`);
    check(dAtt.keyid === by.key_id, 6, "keyid", "the disclosure keyid is not its orderer's key_id");
    check(verifySignature(dAtt, b64urlDecode(by.public_key)), 6, "signature", "the disclosure signature does not verify");
    check(dAtt.statement.subject[0].name === `runrec:run:${manifest.run_id}` && subjectDigest(dAtt.statement) === manifest.events.head && disc.run_id === manifest.run_id && disc.workspace_id === manifest.workspace.workspace_id && disc.head === manifest.events.head, 6, "subject", "the disclosure is not about this Run and its chain head");
    const policies = new Set(policiesOf(procedure).map((a) => a.digest));
    for (const w of disc.withheld) {
      check(cited2.has(w.digest) && !policies.has(w.digest), 6, "reference", policies.has(w.digest) ? `a sealed policy (${w.digest}) is withheld, so its Evaluations cannot be re-run` : `the disclosure withholds ${w.digest}, which nothing cites`);
      check(!withheld.has(w.digest), 6, "reference", `the disclosure lists ${w.digest} twice`);
      check(!files.has(`evidence/sha256/${w.digest.slice(7)}`), 6, "reference", `the disclosure withholds ${w.digest}, but the file is in this edition`);
      withheld.set(w.digest, w.reason !== void 0 ? { reason: w.reason } : {});
    }
    orderedBy = disc.ordered_by;
  }
  const findings = [];
  for (const [d, a] of cited2) {
    const blob = files.get(`evidence/sha256/${d.slice(7)}`);
    if (!blob && (withheld.has(d) || manifestEvidence.get(d)?.external)) {
      findings.push(withheld.has(d) ? { kind: "withheld", digest: d, ordered_by: orderedBy, ...withheld.get(d) } : { kind: "external", digest: d });
      continue;
    }
    check(blob, 6, "missing", `${a.seq ? `seq ${a.seq}` : "the Procedure"}: evidence ${d} is missing from the bundle`);
    check(digestOf(blob) === d, 6, "digest", `evidence ${d} does not hash to its name`);
    check(blob.length === a.size, 6, "size", `evidence ${d} is ${blob.length} bytes, cited as ${a.size}`);
    const m = manifestEvidence.get(d);
    check(m && m.media_type === a.media_type && m.size === a.size, 6, "manifest", `evidence ${d} differs from its manifest entry`);
  }
  for (const d of manifestEvidence.keys()) check(cited2.has(d), 6, "uncited", `manifest lists evidence ${d} that no event cites`);
  for (const name of [...files.keys()].filter((n2) => n2.startsWith("evidence/")).sort(byName)) {
    check(cited2.has(`sha256:${name.slice("evidence/sha256/".length)}`), 6, "uncited", `${name} is not cited by any event`);
  }
  const engine = new RunEngine({ procedure, enrollments, policy: (d) => files.get(`evidence/sha256/${d.slice(7)}`) });
  engine.start(events[0].digest, first);
  const humanAuth = [];
  const decisions = [];
  for (const { ev, digest } of events.slice(1, -1)) {
    if (ev.actor.kind === "runtime") {
      if (ev.kind === "Note" && engine.owed.length === 0) engine.applyRuntimeNote(ev, digest);
      else if (ev.kind === "ChildSealed" && engine.owed.length === 0) engine.applyChildSealed(ev, digest);
      else engine.confirmRuntime(ev, digest);
      continue;
    }
    const before = engine.stepStates();
    engine.applyParticipant(ev, digest);
    if (ev.kind === "Authorization") humanAuth.push({ seq: ev.seq, step_id: ev.step_id, result: String(ev.result), by: ev.actor.participant_id });
    if (ev.kind === "Decision") {
      const st = before.find((s) => s.step_id === ev.step_id)?.state;
      decisions.push({ seq: ev.seq, ...ev.step_id !== void 0 ? { step_id: ev.step_id } : {}, type: String(ev.type), by: ev.actor.participant_id, counted: ev.decision_id !== void 0 && st === "open" });
      if (ev.decision_id !== void 0 && st !== "open") report.warnings.push(`seq ${ev.seq}: ${String(ev.type)} Decision by ${ev.actor.participant_id} on ${ev.step_id} was recorded while the Step was ${st}; it satisfies nothing`);
    }
  }
  check(engine.owed.length === 0, 7, "sequencing", `the Run closes while runtime events are owed (${engine.owed.map((e) => e.kind).join(", ")})`);
  const concluded = engine.close();
  const last = events.at(-1).ev;
  check(last.outcome === concluded.outcome, 8, "recompute", `RunClosed records outcome ${String(last.outcome)}, rules give ${concluded.outcome}`);
  check(canonicalize(last.open_matters) === canonicalize(concluded.open_matters), 8, "recompute", "RunClosed open_matters differ from the recomputed list");
  check(manifest.outcome === concluded.outcome, 8, "recompute", "manifest outcome differs from the recomputed outcome");
  check(canonicalize(manifest.open_matters) === canonicalize(concluded.open_matters), 8, "recompute", "manifest open_matters differ from the recomputed list");
  const outputs = engine.outputs();
  check(canonicalize(manifest.outputs ?? null) === canonicalize(outputs ?? null), 8, "recompute", "manifest outputs differ from those the events give");
  const related = relatedOf(first, events.filter(({ ev }) => ev.kind === "ChildSealed").map(({ ev }) => ev));
  check(canonicalize(manifest.related ?? null) === canonicalize(related ?? null), 8, "recompute", "manifest related differs from what the events give");
  report.outcome = concluded.outcome;
  report.open_matters = concluded.open_matters;
  report.steps = engine.stepStates();
  report.human_authorizations = humanAuth;
  report.decisions = decisions;
  report.agreed_by = parties ? parties.map((party) => ({ party_id: party, participant_id: signers.find((e) => e.party === party).participant_id })) : [{ participant_id: signers[0].participant_id }];
  report.inputs = first.inputs ?? {};
  report.subjects = first.subjects ?? [];
  report.outputs = outputs ?? [];
  report.related = related ?? [];
  report.event_count = events.length;
  report.findings = [...prov.finding ? [prov.finding] : [], ...findings, ...[...files.keys()].some((n2) => n2.startsWith("timestamps/")) ? [{ kind: "timestamps" }] : []];
  if (report.provenance === "unpinned" && !prov.finding) {
    report.warnings.push("provenance unpinned: the workspace name, participant names and every other label in this Record are chosen by the issuer; only the workspace key_id identifies it");
  }
  const evidence = /* @__PURE__ */ new Map();
  for (const [d, a] of cited2) {
    const bytes3 = files.get(`evidence/sha256/${d.slice(7)}`);
    evidence.set(d, { media_type: a.media_type, size: a.size, ...bytes3 ? { bytes: bytes3 } : {} });
  }
  return { manifest, procedure: pAtt.statement.predicate, enrollments: [...enrollments.values()], events, evidence };
}

// ../packages/runrec/src/scope.ts
var SCOPE_STATEMENT = "Verification of this Run Record establishes that its contents have not been altered since it was sealed; that each recorded event was signed by a key the issuing workspace had enrolled for that Participant; that every recorded action stayed within the authority the Procedure granted; and that the recorded outcome and open matters follow from the recorded events by published rules. It does not establish that any observation was true, that the Procedure was adequate, that any decision was correct, that the system was safe, or that every action taken was recorded. It establishes who held the enrolled keys only to the extent the workspace's key custody did.";

// ../packages/runrec/src/bundle.ts
function lastEvent(input) {
  const last = input.events.at(-1);
  if (!last || last.event.kind !== "RunClosed") throw new Error("close the Run before sealing");
  return last;
}
function cited(input) {
  const out = /* @__PURE__ */ new Map();
  const procedure = parseProcedure(parseAttestation(input.procedure.bytes).statement.predicate);
  for (const a of policiesOf(procedure)) if (!out.has(a.digest)) out.set(a.digest, { media_type: a.media_type, size: a.size });
  for (const r of input.events) {
    for (const a of citationsOf(r.event)) if (!out.has(a.digest)) out.set(a.digest, { media_type: a.media_type, size: a.size });
  }
  return out;
}
function manifestStatement(input) {
  const ws = input.workspace;
  const last = lastEvent(input);
  const related = relatedOf(input.events[0].event, input.events.filter((r) => r.event.kind === "ChildSealed").map((r) => r.event));
  const manifest = {
    format: "runrec/0.1",
    workspace: { workspace_id: ws.workspace_id, key_id: ws.keyId, public_key: ws.publicKeyB64u, display_name: ws.display_name },
    run_id: input.run_id,
    sequence: input.sequence,
    procedure: { procedure_id: input.procedure.procedure_id, version: input.procedure.version, digest: input.procedure.digest },
    events: { count: input.events.length, head: last.digest },
    participants: input.enrollments.map((e) => ({ participant_id: e.participant_id, digest: e.digest })),
    evidence: [...cited(input).entries()].map(([digest, v]) => ({ digest, media_type: v.media_type, size: v.size, ...input.external?.has(digest) ? { external: { location: input.external.get(digest) } } : {} })),
    ...input.outputs ? { outputs: input.outputs.map((o) => ({ ...o })) } : {},
    ...related ? { related } : {},
    outcome: input.closed.outcome,
    open_matters: input.closed.open_matters,
    ...input.published_by ? { published_by: input.published_by } : {},
    published_time: input.published_time
  };
  return makeStatement("manifest", `runrec:run:${input.run_id}`, last.digest, manifest);
}
function bundleEntries(input, manifest) {
  const last = lastEvent(input);
  const m = manifest.statement.predicate;
  if (manifest.statement.subject[0]?.digest.sha256 !== last.digest.slice(7) || m.events?.head !== last.digest) {
    throw new Error("the signed manifest does not belong to this chain");
  }
  const entries = [
    { name: "manifest.dsse.json", data: manifest.bytes },
    { name: "procedure.dsse.json", data: input.procedure.bytes }
  ];
  for (const e of input.enrollments) entries.push({ name: `participants/${e.participant_id}.dsse.json`, data: e.bytes });
  for (const r of input.events) {
    entries.push({ name: `events/${String(r.event.seq).padStart(6, "0")}-${r.event.kind}.dsse.json`, data: r.bytes });
  }
  for (const d of cited(input).keys()) {
    if (input.external?.has(d)) continue;
    const b = input.blob(d);
    if (!b) throw new Error(`evidence ${d} is cited but not available`);
    entries.push({ name: `evidence/sha256/${d.slice(7)}`, data: b });
  }
  entries.push({ name: "README.txt", data: new TextEncoder().encode(readme(m, input.closed)) });
  return entries;
}
function disclosureStatement(record, withheld, ordered_by, ordered_time) {
  const predicate = { run_id: record.run_id, workspace_id: record.workspace_id, head: record.head, withheld: withheld.map((w) => ({ digest: w.digest, ...w.reason ? { reason: w.reason } : {} })), ordered_by, ordered_time };
  return makeStatement("disclosure", `runrec:run:${record.run_id}`, record.head, predicate);
}
function editionEntries(entries, disclosure) {
  const withheld = new Set((disclosure.statement.predicate.withheld ?? []).map((w) => `evidence/sha256/${String(w.digest).slice(7)}`));
  if (entries.some((e) => e.name === "disclosure.dsse.json")) throw new Error("this is already an edition: make editions from the master Record");
  return [...entries.filter((e) => !withheld.has(e.name)), { name: "disclosure.dsse.json", data: disclosure.bytes }];
}
function readme(manifest, closed) {
  const ws = manifest.workspace;
  const pr = manifest.procedure;
  const lines = [
    SCOPE_STATEMENT,
    "",
    "Run Record",
    `Procedure: ${String(pr.procedure_id)} ${String(pr.version)}`,
    `Run: ${String(manifest.run_id)} (number ${String(manifest.sequence)} in its workspace)`,
    `Issued by workspace key ${String(ws.key_id)} (named "${String(ws.display_name)}" by the issuer)`,
    `Outcome: ${closed.outcome}`,
    `Open matters: ${closed.open_matters.length}`,
    ...closed.open_matters.map((m) => `  - ${m.step_id}: ${m.kind} ${m.ref} ${m.state}`),
    "",
    "Verify with: runrec verify <this file> --pin <workspace key id obtained from the issuer>",
    ""
  ];
  return lines.join("\n");
}
function registerStatement(input) {
  const ws = input.workspace;
  input.runs.forEach((e, i) => {
    if (e.sequence !== i + 1) throw new Error(`register runs must be numbered 1 to ${input.runs.length} in order`);
    if (e.status === "closed" !== (e.outcome !== void 0)) throw new Error(`run ${e.sequence}: a closed Run has an outcome and an open one does not`);
  });
  const predicate = {
    format: "runrec-register/0.1",
    workspace: { workspace_id: ws.workspace_id, key_id: ws.keyId, public_key: ws.publicKeyB64u, display_name: ws.display_name },
    through: input.runs.length,
    previous: input.previous,
    issued_time: input.issued_time,
    runs: input.runs.map((e) => ({
      sequence: e.sequence,
      run_id: e.run_id,
      status: e.status,
      procedure: { ...e.procedure },
      head: e.head,
      ...e.outcome !== void 0 ? { outcome: e.outcome } : {}
    }))
  };
  if (input.successor) predicate.successor = { ...input.successor };
  if (input.former_keys?.length) predicate.former_keys = input.former_keys.map((f) => ({ ...f }));
  if (input.revoked?.length) predicate.revoked = input.revoked.map((x) => ({ ...x }));
  if (input.published) predicate.published = { ...input.published };
  if (input.journal) predicate.journal = { ...input.journal };
  if (input.reviews?.length) predicate.reviews = input.reviews.map((x) => ({ ...x }));
  return makeStatement("register", `runrec:register:${ws.workspace_id}`, digestOf(canonicalBytes(predicate)), predicate);
}

// ../packages/runrec/src/review.ts
var VERDICTS = ["concur", "do_not_concur", "more_examination"];
function parseReview(v, r = new Reader2(3, "review")) {
  const o = r.object(v, ["workspace_id", "run_id", "head", "verdict", "basis", "previous", "reviewed_time"], ["terms", "note"], true);
  const out = {
    workspace_id: r.at("workspace_id").id(o.workspace_id),
    run_id: r.at("run_id").id(o.run_id),
    head: r.at("head").digest(o.head),
    verdict: r.at("verdict").oneOf(o.verdict, VERDICTS),
    basis: r.at("basis").array(o.basis, (rr, x) => rr.digest(x)),
    previous: o.previous === null ? null : r.at("previous").digest(o.previous),
    reviewed_time: r.at("reviewed_time").time(o.reviewed_time)
  };
  if ("terms" in o) out.terms = r.at("terms").digest(o.terms);
  if ("note" in o) out.note = r.at("note").string(o.note, false);
  return out;
}
function reviewStatement(review) {
  const p = { ...review };
  return makeStatement("review", `runrec:review:${review.run_id}`, digestOf(canonicalBytes(p)), p);
}
function reviewFile(workspace, enrollment, review) {
  const env = (b) => parseStrict(decodeUtf8(b));
  return canonicalBytes({ workspace: { workspace_id: workspace.workspace_id, key_id: workspace.key_id, public_key: workspace.public_key }, enrollment: env(enrollment), review: env(review instanceof Uint8Array ? review : review.bytes) });
}
var ReviewError = class extends Error {
  step;
  code;
  constructor(step, code, message) {
    super(message);
    this.step = step;
    this.code = code;
  }
};
function check2(cond, step, code, message) {
  if (!cond) throw new ReviewError(step, code, message);
}
function read2(name, v, type) {
  try {
    return parseAttestation(canonicalBytes(v), type);
  } catch (e) {
    if (e instanceof AttestationError) throw new ReviewError("V1", e.code, `${name}: ${e.message}`);
    throw e;
  }
}
function schema(f) {
  try {
    return f();
  } catch (e) {
    if (e instanceof RecordError) throw new ReviewError("V1", "schema", e.message);
    throw e;
  }
}
function verifyReview(bytes3, opts = {}) {
  const expecting = opts.pin !== void 0 || opts.published !== void 0;
  const r = { integrity: "fail", provenance: expecting ? "mismatch" : "unpinned", warnings: [] };
  try {
    let file;
    try {
      file = parseStrict(decodeUtf8(bytes3));
    } catch (e2) {
      throw new ReviewError("V1", "json", e2.message);
    }
    check2(canonicalize(file) === decodeUtf8(bytes3), "V1", "canonical", "the review file is not its RFC 8785 (JCS) serialization");
    check2(isObject(file) && Object.keys(file).sort().join() === "enrollment,review,workspace" && isObject(file.workspace) && isObject(file.enrollment) && isObject(file.review), "V1", "layout", "a review file is an object of exactly workspace, enrollment and review");
    const w = schema(() => {
      const rd = new Reader2(1, "workspace");
      const o = rd.object(file.workspace, ["workspace_id", "key_id", "public_key"]);
      return { workspace_id: rd.at("workspace_id").id(o.workspace_id), key_id: rd.at("key_id").digest(o.key_id), public_key: rd.at("public_key").string(o.public_key) };
    });
    const eAtt = read2("enrollment", file.enrollment, "enrollment");
    const rAtt = read2("review", file.review, "review");
    const e = schema(() => parseEnrollment(eAtt.statement.predicate, new Reader2(1, "enrollment")));
    const rv = schema(() => parseReview(rAtt.statement.predicate, new Reader2(1, "review")));
    let wsKey;
    try {
      wsKey = b64urlDecode(w.public_key);
    } catch {
      throw new ReviewError("V2", "key", "workspace public_key is not canonical base64url");
    }
    check2(isStrictPublicKey(wsKey) && keyIdOf(wsKey) === w.key_id, "V2", "key", "workspace public_key is not a strict key with this key_id");
    r.workspace = { key_id: w.key_id, workspace_id: w.workspace_id };
    const prov = provenanceOf(w.key_id, opts.pin, opts.published, r.warnings, "review");
    r.provenance = prov.provenance;
    check2(eAtt.keyid === w.key_id, "V2", "keyid", "the enrollment keyid is not the workspace key_id");
    check2(verifySignature(eAtt, wsKey), "V2", "signature", "the enrollment is not signed by the workspace key");
    check2(e.workspace_id === w.workspace_id, "V2", "workspace", "the enrollment is for another workspace");
    let pk;
    try {
      pk = b64urlDecode(e.public_key);
    } catch {
      throw new ReviewError("V2", "key", "the reviewer public_key is not canonical base64url");
    }
    check2(isStrictPublicKey(pk) && keyIdOf(pk) === e.key_id && e.key_id !== w.key_id, "V2", "key", "the reviewer key is not a strict key with this key_id, or is the workspace key");
    check2(eAtt.statement.subject[0].name === `runrec:participant:${e.participant_id}` && subjectDigest(eAtt.statement) === e.key_id, "V2", "subject", "the enrollment subject is not this Participant and key");
    check2(e.status === "active" && e.kind === "human" && e.grants.includes("review"), "V2", "signer", `${e.participant_id} is not an active Human holding review`);
    r.reviewer = { participant_id: e.participant_id, display_name: e.display_name, ...e.party !== void 0 ? { party: e.party } : {} };
    check2(rAtt.keyid === e.key_id, "V3", "keyid", "the review keyid is not the reviewer's key_id");
    check2(verifySignature(rAtt, pk), "V3", "signature", "the review signature does not verify");
    check2(rAtt.statement.subject[0].name === `runrec:review:${rv.run_id}` && subjectDigest(rAtt.statement) === digestOf(canonicalBytes(rAtt.statement.predicate)), "V3", "subject", "the review subject is not runrec:review:<run_id> with its predicate digest");
    check2(rv.workspace_id === w.workspace_id, "V3", "workspace", "the review is about a Run of another workspace");
    r.digest = rAtt.digest;
    r.review = rv;
    if (opts.record) {
      const rec = openRecord(opts.record, { pin: [w.key_id, ...opts.pin === void 0 ? [] : [opts.pin].flat()] });
      r.record = { integrity: rec.report.integrity, summary: rec.report.summary };
      check2(rec.report.integrity === "pass" && rec.contents, "V4", "record", `the reviewed Record does not verify: ${rec.report.summary}`);
      const m = rec.contents.manifest;
      check2(m.run_id === rv.run_id && m.events.head === rv.head, "V4", "record", "the review is about another Record: its run_id or head differs");
      check2(m.workspace.workspace_id === w.workspace_id && rec.report.provenance === "pinned", "V4", "workspace", "the Record was not issued by the review's workspace key, nor by a key the recipient pinned");
    }
    r.findings = prov.finding ? [prov.finding] : [];
    r.integrity = "pass";
  } catch (e) {
    if (e instanceof ReviewError) r.failure = { step: e.step, code: e.code, message: e.message };
    else if (e instanceof JsonError) r.failure = { step: "V1", code: "json", message: e.message };
    else throw e;
    delete r.review;
    delete r.findings;
  }
  const parts = [`review: ${r.integrity}`, `provenance: ${r.provenance}`];
  if (r.review) parts.push(`${r.review.verdict.replace(/_/g, " ")} on ${r.review.run_id} by ${r.reviewer.participant_id}`);
  if (r.failure) parts.push(`${r.failure.step} ${r.failure.code}: ${r.failure.message}`);
  if (r.workspace) parts.push(`workspace ${r.workspace.key_id}`);
  return { ...r, summary: parts.join(" \xB7 ") };
}

// ../packages/runrec/src/register.ts
var RegisterError = class extends Error {
  step;
  code;
  constructor(step, code, message) {
    super(message);
    this.name = "RegisterError";
    this.step = step;
    this.code = code;
  }
};
function fail2(step, code, message) {
  throw new RegisterError(step, code, message);
}
function check3(cond, step, code, message) {
  if (!cond) fail2(step, code, message);
}
function checkRegister(first, name, bytes3, onKey) {
  const step = (s) => first === "R1" ? s : first;
  let att;
  try {
    att = parseAttestation(bytes3, "register");
  } catch (e) {
    if (e instanceof AttestationError) return fail2(step("R1"), e.code, `${name}: ${e.message}`);
    throw e;
  }
  check3(att.statement.predicate.format === "runrec-register/0.1", step("R1"), "format", `${name}: unsupported format ${JSON.stringify(att.statement.predicate.format)}`);
  let reg;
  try {
    reg = parseRegister(att.statement.predicate);
  } catch (e) {
    if (e instanceof RecordError) return fail2(step("R1"), "schema", `${name}: ${e.message}`);
    throw e;
  }
  let wsKey;
  try {
    wsKey = b64urlDecode(reg.workspace.public_key);
  } catch {
    return fail2(step("R2"), "key", `${name}: workspace public_key is not canonical base64url`);
  }
  check3(isStrictPublicKey(wsKey), step("R2"), "key", `${name}: workspace public_key is not a strict Ed25519 public key`);
  const keyId = keyIdOf(wsKey);
  check3(keyId === reg.workspace.key_id, step("R2"), "key", `${name}: workspace key_id does not match its public key`);
  onKey?.(keyId, reg);
  check3(att.keyid === keyId, step("R2"), "keyid", `${name}: keyid is not the workspace key_id`);
  check3(verifySignature(att, wsKey), step("R2"), "signature", `${name}: the signature does not verify with the workspace key`);
  const own = digestOf(canonicalBytes(att.statement.predicate));
  check3(att.statement.subject[0].name === `runrec:register:${reg.workspace.workspace_id}` && subjectDigest(att.statement) === own, step("R2"), "subject", `${name}: the subject is not this workspace's register with its predicate digest`);
  const strict = (b64, id) => {
    try {
      const k = b64urlDecode(b64);
      return isStrictPublicKey(k) && keyIdOf(k) === id;
    } catch {
      return false;
    }
  };
  check3(reg.runs.length === reg.through && reg.runs.every((e, i) => e.sequence === i + 1), step("R3"), "sequence", `${name}: runs are not exactly 1 to ${reg.through}, in order, each once`);
  const ids = /* @__PURE__ */ new Set();
  for (const e of reg.runs) {
    check3(!ids.has(e.run_id), step("R3"), "duplicate", `${name}: run_id ${e.run_id} appears twice`);
    ids.add(e.run_id);
    check3(e.status === "closed" === (e.outcome !== void 0), step("R3"), "status", `${name}: run ${e.sequence} is ${e.status} but ${e.outcome === void 0 ? "has no" : "has an"} outcome`);
  }
  const former = reg.former_keys ?? [];
  const keys = /* @__PURE__ */ new Set([keyId]);
  let last = 0;
  for (const f of former) {
    check3(strict(f.public_key, f.key_id), step("R3"), "former", `${name}: former key ${f.key_id} is not a strict key with that key_id`);
    check3(!keys.has(f.key_id), step("R3"), "former", `${name}: key ${f.key_id} appears twice among the workspace's keys`);
    check3(f.through >= last && f.through <= reg.through, step("R3"), "former", `${name}: former key ${f.key_id} retired at ${f.through}, out of order or beyond ${reg.through}`);
    keys.add(f.key_id);
    last = f.through;
  }
  if (reg.successor) {
    check3(strict(reg.successor.public_key, reg.successor.key_id), step("R3"), "successor", `${name}: the successor is not a strict key with that key_id`);
    check3(!keys.has(reg.successor.key_id), step("R3"), "successor", `${name}: the successor is this register's key or a former key`);
  }
  const revokedIds = /* @__PURE__ */ new Set();
  for (const x of reg.revoked ?? []) {
    check3(!revokedIds.has(x.key_id), step("R3"), "revoked", `${name}: key ${x.key_id} is revoked twice`);
    check3(x.as_of <= reg.through, step("R3"), "revoked", `${name}: key ${x.key_id} is revoked as of Run ${x.as_of}, beyond ${reg.through}`);
    check3(x.key_id !== keyId, step("R3"), "revoked", `${name}: a register cannot revoke the key that signs it`);
    revokedIds.add(x.key_id);
  }
  return { att, reg, keyId };
}
var sameProcedure = (a, b) => a.procedure.procedure_id === b.procedure.procedure_id && a.procedure.version === b.procedure.version && a.procedure.digest === b.procedure.digest;
function summarize2(r) {
  const parts = [`register: ${r.integrity}`, `provenance: ${r.provenance}`];
  if (r.failure) parts.push(`step ${r.failure.step} ${r.failure.code}: ${r.failure.message}`);
  else if (r.through !== void 0) {
    const n2 = (k, w) => `${k} ${w}${k === 1 ? "" : "s"}`;
    parts.push(`${n2(r.through, "run")} through issue`, `${n2(r.records.length, "record")} supplied`, `${r.missing.length} missing`, `${r.open.length} open`);
    if (r.later.length) parts.push(`${r.later.length} closed since`);
  }
  const pub = r.findings?.find((f) => f.kind === "published");
  if (pub) parts.splice(2, 0, `published by ${pub.domain}`);
  if (r.workspace) parts.push(`workspace ${r.workspace.key_id}`);
  return parts.join(" \xB7 ");
}
function verifyRegister(bytes3, records, opts = {}) {
  const expecting = opts.pin !== void 0 || opts.published !== void 0;
  const r = { integrity: "fail", provenance: expecting ? "mismatch" : "unpinned", records: [], missing: [], open: [], later: [], warnings: [] };
  let found;
  try {
    const { reg, keyId } = checkRegister("R1", "register", bytes3, (keyId2, reg2) => {
      r.workspace = { key_id: keyId2, workspace_id: reg2.workspace.workspace_id, display_name: reg2.workspace.display_name };
      const p = provenanceOf(keyId2, opts.pin, opts.published, r.warnings, "register");
      r.provenance = p.provenance;
      found = p.finding;
    });
    r.through = reg.through;
    r.issued_time = reg.issued_time;
    r.entries = reg.runs;
    for (const k of ["successor", "former_keys", "revoked", "published", "journal"]) if (reg[k] !== void 0) r[k] = reg[k];
    const sealers = new Map([[keyId, Infinity], ...(reg.former_keys ?? []).map((f) => [f.key_id, f.through])]);
    const revoked = new Map((reg.revoked ?? []).map((x) => [x.key_id, x]));
    const byId = new Map(reg.runs.map((e) => [e.run_id, e]));
    const seen = /* @__PURE__ */ new Map();
    const supplied = /* @__PURE__ */ new Set();
    const closedLater = [];
    const passed = [];
    for (const rec of records) {
      const recordTrust = r.provenance === "pinned" ? { pin: [...sealers.keys()] } : { ...opts.pin !== void 0 ? { pin: opts.pin } : {}, ...opts.published ? { published: opts.published } : {} };
      const { report, contents } = openRecord(rec.bytes, { ...recordTrust, ...opts.limits ? { limits: opts.limits } : {} });
      const row = { name: rec.name, report };
      r.records.push(row);
      if (!contents) continue;
      const m = contents.manifest;
      row.sequence = m.sequence;
      const sealer = report.workspace.key_id;
      check3(sealers.has(sealer), "R4", "workspace", `${rec.name}: issued by workspace key ${sealer}, which is not the register's ${keyId} or a former key`);
      check3(m.sequence <= sealers.get(sealer), "R4", "workspace", `${rec.name}: run ${m.sequence} is sealed by former key ${sealer}, retired at run ${sealers.get(sealer)}`);
      for (const k of [.../* @__PURE__ */ new Set([sealer, ...contents.events.map((x) => x.ev.actor.key_id)])].sort()) {
        const x = revoked.get(k);
        if (!x) continue;
        check3(m.sequence <= x.as_of, "R4", "revoked", `${rec.name}: run ${m.sequence} carries key ${k}, revoked as of run ${x.as_of} (${x.reason})`);
        (report.findings ??= []).push({ kind: "revoked_later", key_id: k, reason: x.reason });
      }
      const e = byId.get(m.run_id);
      check3(e !== void 0 && e.sequence === m.sequence, "R4", "unlisted", `${rec.name}: run ${m.run_id} (number ${m.sequence}) is not in the register`);
      check3(sameProcedure(e, { procedure: m.procedure }), "R4", "mismatch", `${rec.name}: the register lists run ${e.sequence} under a different Procedure`);
      if (e.status === "closed") check3(e.head === m.events.head && e.outcome === m.outcome, "R4", "mismatch", `${rec.name}: the register's entry for run ${e.sequence} ends differently from this Record`);
      else closedLater.push(e.sequence);
      check3(!seen.has(m.run_id), "R4", "duplicate", `${rec.name} and ${seen.get(m.run_id)} are both run ${m.run_id}`);
      seen.set(m.run_id, rec.name);
      supplied.add(e.sequence);
      passed.push(contents);
    }
    const byRun = new Map(passed.map((c) => [c.manifest.run_id, c]));
    for (const c of passed) {
      for (const { ev } of c.events.filter((x) => x.ev.kind === "ChildSealed")) {
        const child = byRun.get(String(ev.child_run_id));
        if (child) check3(child.manifest.events.head === ev.record && child.manifest.outcome === ev.outcome, "R4", "child", `run ${c.manifest.run_id} records child ${String(ev.child_run_id)} as sealed ${String(ev.outcome)} at ${String(ev.record)}; its Record ends ${child.manifest.outcome} at ${child.manifest.events.head}`);
      }
      const inputs = c.events[0].ev.inputs ?? {};
      for (const k of Object.keys(inputs).sort()) {
        const v = inputs[k];
        if (!isObject(v) || !("record" in v)) continue;
        const src = byRun.get(String(v.run_id));
        if (src) check3(src.manifest.events.head === v.record && (src.manifest.outputs ?? []).some((o) => o.output_id === v.output_id && o.digest === v.digest), "R4", "input", `run ${c.manifest.run_id} binds ${k} to the output ${String(v.output_id)} of run ${String(v.run_id)}, which that Record does not hold`);
      }
    }
    if (opts.previous) {
      const prev = checkRegister("R5", "previous register", opts.previous);
      check3(sealers.has(prev.keyId), "R5", "workspace", "the previous register is from another workspace");
      check3(reg.previous === prev.att.digest, "R5", "previous", `this register does not name the previous one (${prev.att.digest}) as the register it extends`);
      const same2 = (a, b) => JSON.stringify(a) === JSON.stringify(b);
      for (const x of prev.reg.revoked ?? []) check3(same2(x, revoked.get(x.key_id)), "R5", "continuity", `the revocation of ${x.key_id} differs between the previous register and this one`);
      (prev.reg.former_keys ?? []).forEach((f, i) => check3(same2(f, reg.former_keys?.[i]), "R5", "continuity", `former key ${f.key_id} differs between the previous register and this one`));
      for (const old of prev.reg.runs) {
        const now = reg.runs[old.sequence - 1];
        const unchanged = now !== void 0 && now.run_id === old.run_id && sameProcedure(now, old);
        const sameEnd = now !== void 0 && now.status === old.status && (old.status === "open" || now.head === old.head && now.outcome === old.outcome);
        check3(unchanged && (sameEnd || old.status === "open" && now.status === "closed"), "R5", "continuity", `run ${old.sequence} differs between the previous register and this one`);
      }
      if (prev.keyId === keyId) check3(!prev.reg.successor || prev.reg.successor.key_id === reg.successor?.key_id, "R5", "succession", `the previous register committed to successor ${prev.reg.successor?.key_id}; this one, signed by the same key, does not`);
      else check3(prev.reg.successor?.key_id === keyId, "R5", "succession", `this register is signed by ${keyId}, which the previous register did not name as its successor`);
    }
    for (const e of reg.runs) {
      if (e.status === "open") r.open.push(e.sequence);
      else if (!supplied.has(e.sequence)) r.missing.push(e.sequence);
    }
    r.later = closedLater.sort((a, b) => a - b);
    r.findings = found ? [found] : [];
    r.integrity = "pass";
  } catch (e) {
    if (e instanceof RegisterError) r.failure = { step: e.step, code: e.code, message: e.message };
    else r.failure = { step: "R1", code: "internal", message: e.message };
    r.missing = [];
    r.open = [];
    r.later = [];
  }
  return { ...r, summary: summarize2(r) };
}

// ../packages/runrec/src/journal.ts
var JournalError = class extends Error {
  step;
  code;
  constructor(step, code, message) {
    super(message);
    this.step = step;
    this.code = code;
  }
};
function check4(cond, step, code, message) {
  if (!cond) throw new JournalError(step, code, message);
}
function journalStatement(entry) {
  const p = { ...entry };
  return makeStatement("journal", `runrec:journal:${entry.workspace_id}#${entry.seq}`, digestOf(canonicalBytes(p)), p);
}
var journalEntryName = (e) => `entries/${String(e.seq).padStart(6, "0")}-${e.kind}.dsse.json`;
var LAYOUT2 = [/^entries\/[0-9]{6}-[A-Za-z]+\.dsse\.json$/, /^enrollments\/[0-9a-f]{64}\.dsse\.json$/, /^evidence\/sha256\/[0-9a-f]{64}$/];
function read3(step, name, bytes3, type) {
  try {
    return parseAttestation(bytes3, type);
  } catch (e) {
    if (e instanceof AttestationError) throw new JournalError(step, e.code, `${name}: ${e.message}`);
    throw e;
  }
}
function verifyJournal(bytes3, opts = {}) {
  const expecting = opts.pin !== void 0 || opts.published !== void 0;
  const r = { integrity: "fail", provenance: expecting ? "mismatch" : "unpinned", warnings: [] };
  try {
    let files;
    try {
      files = new Map(readZip(bytes3, opts.limits).map((e) => [e.name, e.data]));
    } catch (e) {
      throw new JournalError("J1", e instanceof ZipLimitError ? "limit" : "archive", e.message);
    }
    for (const name of files.keys()) check4(LAYOUT2.some((re) => re.test(name)), "J1", "layout", `entry outside the journal layout: ${JSON.stringify(name)}`);
    const schema2 = (name, f) => {
      try {
        return f();
      } catch (e) {
        if (e instanceof RecordError) throw new JournalError("J1", "schema", `${name}: ${e.message}`);
        throw e;
      }
    };
    const entries = [];
    const enrollments = /* @__PURE__ */ new Map();
    for (const name of [...files.keys()].sort()) {
      if (name.startsWith("entries/")) {
        const att = read3("J1", name, files.get(name), "journal");
        entries.push({ att, e: schema2(name, () => parseJournalEntry(att.statement.predicate)), name });
      } else if (name.startsWith("enrollments/")) {
        const att = read3("J1", name, files.get(name), "enrollment");
        check4(name === `enrollments/${att.digest.slice(7)}.dsse.json`, "J1", "layout", `${name} is not named by its attestation digest`);
        enrollments.set(att.digest, { att, en: schema2(name, () => parseEnrollment(att.statement.predicate)) });
      }
    }
    entries.sort((a, b) => a.e.seq - b.e.seq);
    check4(entries.length > 0, "J2", "chain", "the journal has no entries");
    let previous = null;
    const ws = entries[0].e.workspace_id;
    entries.forEach(({ att, e, name }, i) => {
      check4(e.seq === i + 1, "J2", "chain", e.seq <= i ? `entry ${e.seq} appears twice` : `entries jump from ${i} to ${e.seq}`);
      check4(e.previous === previous, "J2", "chain", `entry ${e.seq} does not link to the entry before it`);
      check4(name === journalEntryName(e), "J2", "layout", `${name} must be named ${journalEntryName(e)}`);
      check4(e.workspace_id === ws, "J2", "splice", `entry ${e.seq} belongs to workspace ${e.workspace_id}, not ${ws}`);
      check4(att.statement.subject[0].name === `runrec:journal:${ws}#${e.seq}` && subjectDigest(att.statement) === digestOf(canonicalBytes(att.statement.predicate)), "J2", "subject", `entry ${e.seq}: the subject is not this entry with its predicate digest`);
      previous = att.digest;
    });
    r.workspace_id = ws;
    const strict = (k) => {
      try {
        const b = b64urlDecode(k.public_key);
        return isStrictPublicKey(b) && keyIdOf(b) === k.key_id ? b : void 0;
      } catch {
        return void 0;
      }
    };
    const first = entries[0].e;
    check4(first.kind === "WorkspaceCreated" && first.actor.kind === "runtime", "J3", "key", "entry 1 is not WorkspaceCreated by the runtime");
    const keyAt = [];
    const chain = [];
    for (const { e } of entries) {
      if (e.kind === "WorkspaceCreated" && e.seq !== 1) throw new JournalError("J3", "key", `entry ${e.seq}: WorkspaceCreated after the first entry`);
      const signing = chain.at(-1);
      if (e.key) {
        const pub = strict(e.key);
        check4(pub, "J3", "key", `entry ${e.seq}: its key is not a strict key with that key_id`);
        check4(!chain.some((k) => k.key_id === e.key.key_id), "J3", "key", `entry ${e.seq}: key ${e.key.key_id} was already used`);
        check4(e.actor.kind === "runtime", "J3", "key", `entry ${e.seq}: only the runtime names a workspace key`);
        chain.push({ key_id: e.key.key_id, pub });
      }
      keyAt.push(e.kind === "WorkspaceCreated" ? chain.at(-1) : signing);
    }
    r.keys = chain.map((k) => k.key_id);
    const pins = opts.pin === void 0 ? void 0 : [opts.pin].flat();
    const current = chain.at(-1).key_id;
    const prov = provenanceOf(current, pins?.some((p) => r.keys.includes(p)) ? current : pins, opts.published, r.warnings, "journal");
    r.provenance = prov.provenance;
    const enrolledBy = /* @__PURE__ */ new Map();
    const gone = /* @__PURE__ */ new Set();
    const revokedKeys = /* @__PURE__ */ new Set();
    entries.forEach(({ att, e }, i) => {
      const ws_key = keyAt[i];
      if (e.actor.kind === "runtime") {
        check4(att.keyid === ws_key.key_id && e.actor.key_id === ws_key.key_id, "J4", "keyid", `entry ${e.seq}: the runtime signs with workspace key ${ws_key.key_id}`);
        check4(verifySignature(att, ws_key.pub), "J4", "signature", `entry ${e.seq}: the signature does not verify`);
      } else {
        const en = enrolledBy.get(e.actor.participant_id);
        check4(en && en.kind === e.actor.kind && en.key_id === e.actor.key_id && !gone.has(e.actor.participant_id) && !revokedKeys.has(en.key_id), "J4", "enrollment", `entry ${e.seq}: ${e.actor.participant_id} is not an enrolled, active ${e.actor.kind} with this key`);
        check4(att.keyid === e.actor.key_id, "J4", "keyid", `entry ${e.seq}: signed with ${att.keyid}, not the actor's key`);
        check4(verifySignature(att, b64urlDecode(en.public_key)), "J4", "signature", `entry ${e.seq}: the signature does not verify`);
      }
      if (e.kind === "ParticipantEnrolled") {
        const ref2 = enrollments.get(e.refs[0] ?? "");
        check4(ref2, "J4", "missing", `entry ${e.seq}: the enrollment it names is not in the file`);
        const signer = chain.slice(0, chain.indexOf(ws_key) + 1).find((k) => k.key_id === ref2.att.keyid);
        check4(signer && verifySignature(ref2.att, signer.pub), "J4", "signature", `entry ${e.seq}: the enrollment is not signed by a workspace key of this journal`);
        check4(ref2.en.workspace_id === ws, "J4", "splice", `entry ${e.seq}: the enrollment is for workspace ${ref2.en.workspace_id}`);
        enrolledBy.set(ref2.en.participant_id, ref2.en);
        gone.delete(ref2.en.participant_id);
      }
      if (e.kind === "ParticipantRetired") {
        const ref2 = enrollments.get(e.refs[0] ?? "");
        if (ref2) gone.add(ref2.en.participant_id);
      }
      if (e.kind === "KeyRevoked") for (const k of e.refs) revokedKeys.add(k);
    });
    const cited2 = /* @__PURE__ */ new Set();
    for (const { e } of entries) {
      if (!e.trace) continue;
      const blob = files.get(`evidence/sha256/${e.trace.digest.slice(7)}`);
      check4(blob, "J5", "missing", `entry ${e.seq}: its trace ${e.trace.digest} is not in the file`);
      check4(digestOf(blob) === e.trace.digest, "J5", "digest", `trace ${e.trace.digest} does not hash to its name`);
      check4(blob.length === e.trace.size, "J5", "size", `trace ${e.trace.digest} is ${blob.length} bytes, cited as ${e.trace.size}`);
      cited2.add(e.trace.digest);
    }
    for (const name of files.keys()) if (name.startsWith("evidence/")) check4(cited2.has(`sha256:${name.slice(16)}`), "J5", "uncited", `${name} is not cited by any entry`);
    if (opts.register) {
      const reg = verifyRegister(opts.register, [], { pin: r.keys });
      check4(reg.integrity === "pass", "J6", "register", `the register failed its check: ${reg.summary}`);
      check4(reg.workspace && r.keys.includes(reg.workspace.key_id), "J6", "workspace", `the register is signed by ${reg.workspace?.key_id}, not one of this journal's workspace keys`);
      const j = reg.journal;
      if (j) {
        check4(entries.length >= j.length && (j.length === 0 || entries[j.length - 1].att.digest === j.head), "J6", "head", `the register's journal (length ${j.length}, head ${j.head}) is not this journal's`);
      }
    }
    r.length = entries.length;
    r.head = entries.at(-1).att.digest;
    r.entries = entries.map(({ e }) => ({
      seq: e.seq,
      kind: e.kind,
      actor: e.actor.participant_id,
      actor_kind: e.actor.kind,
      ...e.actor.on_behalf_of ? { on_behalf_of: e.actor.on_behalf_of } : {},
      declared_time: e.declared_time,
      refs: e.refs,
      ...e.note !== void 0 ? { note: e.note } : {}
    }));
    r.findings = prov.finding ? [prov.finding] : [];
    r.integrity = "pass";
  } catch (e) {
    if (e instanceof JournalError) r.failure = { step: e.step, code: e.code, message: e.message };
    else r.failure = { step: "J1", code: "internal", message: e.message };
    delete r.entries;
  }
  const parts = [`journal: ${r.integrity}`, `provenance: ${r.provenance}`];
  if (r.failure) parts.push(`step ${r.failure.step} ${r.failure.code}: ${r.failure.message}`);
  else parts.push(`${r.length} entr${r.length === 1 ? "y" : "ies"}`, `${r.keys.length} workspace key${r.keys.length === 1 ? "" : "s"}`);
  if (r.workspace_id) parts.push(`workspace ${r.workspace_id}`);
  return { ...r, summary: parts.join(" \xB7 ") };
}

// ../packages/runrec/src/describe.ts
function plainNumber(n2) {
  if (Number.isInteger(n2) && Math.abs(n2) <= 2 ** 53) return n2.toFixed(0);
  if (Math.abs(n2) >= 1e-6 && Math.abs(n2) < 1e21) return String(Number(n2.toPrecision(15)));
  return String(n2);
}
function andList(xs, word = "and") {
  if (xs.length <= 1) return xs[0] ?? "";
  return `${xs.slice(0, -1).join(", ")} ${word} ${xs.at(-1)}`;
}
var limitWords = (l) => {
  if (typeof l === "number") return plainNumber(l);
  const scale = l.scale !== void 0 && l.scale !== 1 ? ` \xD7 ${plainNumber(l.scale)}` : "";
  const offset = l.offset ? ` ${l.offset < 0 ? "\u2212" : "+"} ${plainNumber(Math.abs(l.offset))}` : "";
  return `the input ${l.input}${scale}${offset}`;
};
var range = (min, max, unit = "") => {
  const u = unit ? ` ${plain(unit, 40)}` : "";
  return typeof min === "number" && min === max ? `exactly ${plainNumber(min)}${u}` : `${limitWords(min)} to ${limitWords(max)}${u}`;
};
function plain(v, max = 600) {
  const s = typeof v === "string" ? v : typeof v === "number" ? plainNumber(v) : v === void 0 || v === null ? "" : String(v);
  const out = s.replace(/[\u0000-\u001f\u007f-\u009f\u061c\u200e\u200f\u2028\u2029\u202a-\u202e\u2066-\u2069]+/g, " ").replace(/ {2,}/g, " ").trim();
  return out.length > max ? `${out.slice(0, max - 1)}\u2026` : out;
}
var quoted = (v, max = 600) => `\u201C${plain(v, max)}\u201D`;
var quotedEnd = (v, max = 600) => {
  const q = quoted(v, max);
  return /[.!?]”$/.test(q) ? q : `${q}.`;
};
var value = (v) => typeof v === "number" ? plainNumber(v) : typeof v === "string" ? JSON.stringify(plain(v, 200)) : typeof v === "boolean" ? String(v) : "?";
function describeAction(a) {
  const o = a && typeof a === "object" ? a : {};
  const params = o.parameters && typeof o.parameters === "object" ? o.parameters : {};
  const shown = Object.keys(params).sort().map((k) => `${k} ${value(params[k])}`);
  return `${String(o.type)}${shown.length ? ` (${shown.join(", ")})` : ""}`;
}
function performerText(p) {
  const who = p.kind === "human" ? "a person" : "a system";
  return p.role ? `${who} in the ${p.role} role` : `any ${p.kind === "human" ? "person" : "system"}`;
}
function limitText(b) {
  return `${range(b.min, b.max)}${b.max_count_per_run !== void 0 ? `, up to ${b.max_count_per_run} successful ${b.action_type} action${b.max_count_per_run === 1 ? "" : "s"} per run, however approved` : ""}`;
}
function criterionText(c) {
  if (c.type === "artifact") return `a file of type ${andList(c.media_types, "or")} (${c.criterion_id})`;
  if (c.type === "derived") {
    const reads = c.inputs.map((i) => "quantity" in i ? `the last ${i.last === 1 ? "reading" : `${i.last} readings`} of ${i.quantity}` : "actions" in i ? `every ${i.actions} action` : "input" in i ? `the input ${i.input}` : `the result of ${i.derived}`);
    const result = c.result === "conforming" ? "says the evidence conforms" : `computes a value within ${range(c.result.min, c.result.max)}`;
    return `the sealed policy ${c.policy.title ? quoted(c.policy.title, 120) : c.policy.digest.slice(0, 19)} ${result}, from ${andList(reads)} (${c.criterion_id})`;
  }
  if (c.type === "confirmation") return `${andList(c.roles, "or")} confirms, signed: ${quoted(c.statement, 300)} (${c.criterion_id})`;
  const run2 = c.consecutive === 1 ? "one reading" : `${c.consecutive} readings in a row`;
  const within = c.max_observations === c.consecutive ? "" : `, within ${c.max_observations} readings`;
  return `${c.quantity} ${range(c.tolerance.min, c.tolerance.max, c.unit)}: ${run2}${within} (${c.criterion_id})`;
}
function stepText(p, s, raw) {
  const lines = [];
  const title = (id) => plain(p.steps.find((x) => x.step_id === id)?.title ?? id, 200);
  lines.push({ text: s.requires.length ? `Starts after ${andList(s.requires.map(title))}.` : "Starts when the run starts." });
  if (s.performers.length) lines.push({ text: `Done by ${andList(s.performers.map(performerText), "or")}.` });
  if (s.proposals) {
    const kinds = s.proposals.allowed_kinds.map((k) => k === "agent" ? "an agent" : "a person");
    const types = s.actions.types;
    const bounds = s.proposals.bound_ids.map((id) => p.bounds.find((b) => b.bound_id === id));
    const fallback = s.proposals.fallback_roles;
    const askers = fallback.length ? `a person in the ${andList(fallback, "or")} role` : "nobody (it is refused)";
    const limited = types.some((t) => bounds.some((b) => b.action_type === t));
    lines.push({
      text: limited ? `${capital(andList(kinds, "or"))} may propose ${andList(types, "or")}. A proposal within the limits below is approved automatically; anything else waits for ${askers}.` : `${capital(andList(kinds, "or"))} may propose ${andList(types, "or")}. Every proposal waits for ${askers}.`
    });
    for (const t of types) {
      const own = bounds.filter((b) => b.action_type === t);
      if (!own.length) {
        if (limited) lines.push({ text: `${t} has no limits: every proposal of it waits for ${askers}.` });
        continue;
      }
      for (const param of [...new Set(own.map((b) => b.parameter))]) {
        const chain = own.filter((b) => b.parameter === param);
        const sub = chain.map((b, k) => `${k === 0 ? b.when ? "If" : "Always" : b.when ? "Else if" : "Else"}${b.when ? ` ${b.when.quantity} is ${range(b.when.min, b.when.max, b.when.unit)}` : ""}: ${limitText(b)} (${b.bound_id})`);
        if (chain.at(-1).when) sub.push(`Else, including before any such reading: no limit applies, so it waits for ${askers}.`);
        lines.push({ text: chain.length > 1 ? `${t}, ${param}: the first of these that applies is used.` : `${t}, ${param}:`, sub });
      }
    }
  } else if (s.actions) {
    lines.push({ text: `Actions allowed: ${andList(s.actions.types, "or")}${s.actions.requires_authorization ? "" : ", with no approval needed"}.` });
  }
  if (s.evidence.length) lines.push({ text: "Must show:", sub: s.evidence.map(criterionText) });
  for (const d of s.decisions) {
    const who = `a person in the ${andList(d.decider_roles, "or")} role`;
    const against = d.types.filter((t) => t === "reject" || t === "stop");
    const fails = against.length ? ` ${capital(andList(against, "or"))} fails the step.` : "";
    lines.push({ text: `${capital(who)} ${d.required ? "must" : "may"} decide ${andList(d.types, "or")} (${d.decision_id}).${fails}` });
  }
  if (!s.evidence.length && !s.decisions.some((d) => d.required) && !s.actions) lines.push({ text: "Nothing to show or decide: it completes as soon as it starts." });
  else if (s.actions && !s.evidence.length && !s.decisions.some((d) => d.required)) lines.push({ text: "Completes after one successful action." });
  else if (s.actions) lines.push({ text: `Takes any number of actions until ${andList([...s.evidence.length ? ["every check is met"] : [], ...s.decisions.some((d) => d.required) ? ["every required decision is made"] : []])}; at least one action must succeed.` });
  const instructions = raw && typeof raw.instructions === "string" && raw.instructions ? plain(raw.instructions, 2e3) : void 0;
  return { step_id: s.step_id, title: plain(s.title, 200), ...instructions ? { instructions } : {}, lines };
}
var capital = (s) => s ? s[0].toUpperCase() + s.slice(1) : s;
function renderProcedure(raw) {
  const p = parseProcedure(raw);
  const o = raw;
  const rawSteps = o.steps;
  const src = o.source;
  return {
    title: plain(p.title, 200),
    procedure_id: p.procedure_id,
    version: p.version,
    ...typeof o.purpose === "string" && o.purpose ? { purpose: plain(o.purpose, 2e3) } : {},
    ...src ? { source: { title: plain(src.title, 200), ...typeof src.digest === "string" ? { digest: src.digest } : {} } } : {},
    ...p.parties ? { parties: p.parties.map((x) => ({ party_id: x.party_id, display_name: plain(x.display_name, 120) })) } : {},
    ...p.supersedes && p.change ? { supersedes: { version: p.supersedes.version, digest: p.supersedes.digest, summary: plain(p.change.summary, 2e3), basis: p.change.basis ?? [] } } : {},
    ...p.inputs?.length ? { inputs: p.inputs.map(inputText) } : {},
    ...p.subjects?.length ? { subjects: p.subjects.map((x) => `${x.kind}${x.required ? "" : " (optional)"}`) } : {},
    ...p.outputs?.length ? { outputs: p.outputs.map((x) => `${x.output_id}: the file that meets ${x.criterion_id} on ${p.steps.find((st) => st.step_id === x.step_id)?.title ?? x.step_id}`) } : {},
    roles: p.roles,
    steps: p.steps.map((s, i) => stepText(p, s, rawSteps[i]))
  };
}
function inputText(i) {
  if (i.kind === "number") return `${i.input_id}: a number in ${plain(i.unit, 40)}${i.range ? `, ${range(i.range.min, i.range.max)}` : ""}`;
  if (i.kind === "text") return `${i.input_id}: text`;
  if (i.kind === "artifact") return `${i.input_id}: a file of type ${andList(i.media_types, "or")}`;
  return `${i.input_id}: the output ${i.from.output_id} of a sealed Record of ${i.from.procedure_id}`;
}
function procedureToText(t) {
  const out = [`${t.title} (${t.procedure_id}, version ${t.version})`];
  if (t.purpose) out.push(t.purpose);
  if (t.source) out.push(`Written from: ${t.source.title}`);
  if (t.parties) out.push(`Parties, each of which signs: ${andList(t.parties.map((x) => x.display_name))}`);
  if (t.supersedes) out.push(`Replaces version ${t.supersedes.version}: ${t.supersedes.summary}`);
  if (t.inputs) out.push(`Each Run binds: ${t.inputs.join("; ")}`);
  if (t.subjects) out.push(`Done to: ${t.subjects.join(", ")}`);
  if (t.outputs) out.push(`Produces: ${t.outputs.join("; ")}`);
  out.push(`Roles: ${t.roles.length ? t.roles.join(", ") : "none"}`);
  t.steps.forEach((s, i) => {
    out.push("", `${i + 1}. ${s.title} (${s.step_id})`);
    if (s.instructions) out.push(`   ${s.instructions}`);
    for (const l of s.lines) {
      out.push(`   - ${l.text}`);
      for (const x of l.sub ?? []) out.push(`       ${x}`);
    }
  });
  return out.join("\n") + "\n";
}
function contextFor(procedure, events) {
  const p = parseProcedure(procedure);
  const titles = new Map(p.steps.map((s) => [s.step_id, plain(s.title, 200)]));
  const bounds = new Map(p.bounds.map((b) => [b.bound_id, b]));
  const bySeq = new Map(events.map((e) => [e.digest, e.ev]));
  const statements = new Map(p.steps.flatMap((s) => s.evidence.flatMap((c) => c.type === "confirmation" ? [[c.criterion_id, c.statement]] : [])));
  return {
    statement: (id) => statements.get(id),
    seqOf: (d) => bySeq.get(d)?.seq,
    stepTitle: (id) => titles.get(id),
    bound: (id) => bounds.get(id),
    event: (d) => bySeq.get(d)
  };
}
var ref = (ctx, d, what = "event") => {
  const seq = typeof d === "string" ? ctx.seqOf?.(d) : void 0;
  return seq !== void 0 ? `${what} ${seq}` : `an unknown ${what}`;
};
var fileText = (a) => `${plain(a.media_type, 100)}, ${plainNumber(Number(a.size))} bytes`;
function describeEvent(ev, ctx = {}) {
  const p = ev;
  const step = typeof p.step_id === "string" ? ctx.stepTitle?.(p.step_id) ?? p.step_id : void 0;
  const on = step ? ` on ${step}` : "";
  switch (ev.kind) {
    case "RunStarted":
      return `Started the run of ${String(p.procedure_id)} version ${String(p.version)}${typeof p.title === "string" ? `, titled ${quoted(p.title, 200)}` : ""}.`;
    case "StepOpened":
      return `Opened ${step}.`;
    case "StepClosed":
      return `Closed ${step}: ${p.outcome === "complete" ? "complete" : "failed"}.`;
    case "Proposal": {
      const trace = p.trace ? " Its own trace is attached." : "";
      const why = typeof p.rationale === "string" && p.rationale ? ` Reason given: ${quotedEnd(p.rationale)}` : "";
      return `Proposed ${describeAction(p.action)}${on}.${why}${trace}`;
    }
    case "Authorization": {
      const basis = p.basis;
      const verb = p.result === "allow" ? "Approved" : "Refused";
      const which = ref(ctx, p.proposal, "proposal at event");
      if (basis.kind === "human") return `${verb} the ${which} by hand.${typeof p.reason === "string" && p.reason ? ` Reason given: ${quotedEnd(p.reason)}` : ""}`;
      const gov = basis.bounds.map((id) => {
        const b = ctx.bound?.(String(id));
        return b ? `${b.bound_id} (${b.parameter} ${range(b.min, b.max)})` : String(id);
      });
      const readings = basis.inputs.map((d) => {
        const e = ctx.event?.(String(d));
        const m = e?.measurement;
        return m ? `the reading at event ${e.seq} (${String(m.quantity)} ${plainNumber(Number(m.value))} ${plain(m.unit, 40)}${e.uncertainty.kind === "unknown" ? ", uncertainty unknown" : ""})` : `the ${ref(ctx, d, "reading at event")}`;
      });
      const limits = gov.length ? `${andList(gov)} governed` : "no limit applied";
      return `${verb} the ${which} by its limits: ${limits}${readings.length ? `, as set by ${andList(readings)}` : ""}.`;
    }
    case "Action": {
      const res = p.result;
      const how = res.status === "success" ? "Did" : "Tried and failed to do";
      const auth = p.authorization ? `, approved at ${ref(ctx, p.authorization)}` : "";
      const detail = typeof res.detail === "string" && res.detail ? `, reporting ${quoted(res.detail, 300)}` : "";
      return `${how} ${describeAction(p.action)}${on}${auth}${detail}.${p.trace ? " Its own trace is attached." : ""}`;
    }
    case "Observation": {
      if (p.measurement) {
        const m = p.measurement;
        const u = p.uncertainty;
        const pm = u.kind === "stated" ? ` \xB1 ${plainNumber(Number(u.value))} ${plain(u.unit, 40)}` : " (uncertainty unknown)";
        return `Read ${String(m.quantity)} ${plainNumber(Number(m.value))} ${plain(m.unit, 40)}${pm}${on}.`;
      }
      if (p.confirmation) {
        const id = String(p.confirmation.criterion_id);
        const st = ctx.statement?.(id);
        return `Confirmed ${st ? quoted(st, 300) : id}${on}.`;
      }
      return `Attached a file (${fileText(p.artifact)})${on}.`;
    }
    case "Evaluation": {
      const r = p.result === "conforming" ? "met" : p.result === "nonconforming" ? "not met" : "not yet decided";
      return `Checked ${String(p.criterion_id)}${on}: ${r}.`;
    }
    case "Decision": {
      const scope = p.scope && typeof p.scope === "object" ? ` Scope: ${Object.entries(p.scope).slice(0, 12).map(([k, v]) => `${plain(k, 40)} ${value(v)}`).join(", ")}.` : "";
      const forWhat = typeof p.decision_id === "string" ? ` (${p.decision_id})` : step ? "" : " for the whole run";
      return `Decided ${String(p.type)}${forWhat}${on}. Reason given: ${quotedEnd(p.reason)}${scope}`;
    }
    case "Note":
      return `Noted${on}: ${quotedEnd(p.text)}`;
    case "RunClosed": {
      const n2 = p.open_matters.length;
      return `Closed the run: ${String(p.outcome)}${n2 ? `, ${n2} open matter${n2 === 1 ? "" : "s"}` : ""}.`;
    }
    default:
      return `Recorded ${String(ev.kind)}.`;
  }
}
function describeOpenMatter(m, ctx = {}) {
  const step = ctx.stepTitle?.(m.step_id) ?? m.step_id;
  switch (`${m.kind}/${m.state}`) {
    case "step/blocked":
      return `${step} never started: a step before it did not complete.`;
    case "criterion/undetermined":
      return `${step}: ${m.ref} was not shown either way.`;
    case "criterion/nonconforming":
      return `${step}: ${m.ref} was not met.`;
    case "decision/against":
      return `${step}: the decision ${m.ref} went against continuing, so the step failed.`;
    case "decision/missing":
      return `${step}: the required decision ${m.ref} was not made.`;
    case "proposal/denied":
      return `${step}: the ${ref(ctx, m.ref, "proposal at event")} was refused and nothing took its place.`;
    case "proposal/pending":
      return `${step}: the ${ref(ctx, m.ref, "proposal at event")} was never ruled on.`;
    case "action/missing":
      return `${step}: no action was done.`;
    case "action/failed":
      return `${step}: the ${ref(ctx, m.ref, "action at event")} failed.`;
    case "observation/unknown_uncertainty":
      return `${step}: the ${ref(ctx, m.ref, "reading at event")} has unknown uncertainty and no later reading replaced it.`;
    default:
      return `${step}: ${m.kind} ${m.ref} is ${m.state}.`;
  }
}
function lineDiff(a, b) {
  const n2 = a.length;
  const m = b.length;
  const L2 = Array.from({ length: n2 + 1 }, () => new Array(m + 1).fill(0));
  for (let i2 = n2 - 1; i2 >= 0; i2--) for (let j2 = m - 1; j2 >= 0; j2--) L2[i2][j2] = a[i2] === b[j2] ? L2[i2 + 1][j2 + 1] + 1 : Math.max(L2[i2 + 1][j2], L2[i2][j2 + 1]);
  const out = [];
  let i = 0;
  let j = 0;
  while (i < n2 && j < m) {
    if (a[i] === b[j]) {
      out.push({ op: " ", text: a[i] });
      i++;
      j++;
    } else if (L2[i + 1][j] >= L2[i][j + 1]) out.push({ op: "-", text: a[i++] });
    else out.push({ op: "+", text: b[j++] });
  }
  while (i < n2) out.push({ op: "-", text: a[i++] });
  while (j < m) out.push({ op: "+", text: b[j++] });
  return out;
}

// ../packages/runrec/src/report.ts
var esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var short = (d) => d.startsWith("sha256:") ? d.slice(7, 19) : d.slice(0, 12);
function bytes(n2) {
  if (n2 < 1024) return `${n2} bytes`;
  if (n2 < 1024 * 1024) return `${plainNumber(Math.round(n2 / 102.4) / 10)} KB`;
  return `${plainNumber(Math.round(n2 / (1024 * 102.4)) / 10)} MB`;
}
var EXT = {
  "application/json": "json",
  "application/x-ndjson": "ndjson",
  "application/pdf": "pdf",
  "text/plain": "txt",
  "text/csv": "csv",
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/webp": "webp",
  "video/mp4": "mp4"
};
var KIND = { human: "Person", agent: "Agent", system: "System", runtime: "OpsProof" };
function outcomeSentence(r) {
  const n2 = r.open_matters?.length ?? 0;
  const open = n2 ? ` ${n2} matter${n2 === 1 ? " is" : "s are"} still open.` : "";
  if (r.outcome === "complete") return `The run completed: every step was done and shown.${open}`;
  if (r.outcome === "failed") return `The run failed: a step did not meet what the Procedure asked for.${open}`;
  return `The run is incomplete: it was closed before every step was done.${open}`;
}
function provenanceSentence(r) {
  const pub = r.findings?.find((f) => f.kind === "published");
  const vouched = pub ? ` It is a key <strong>${esc(pub.domain)}</strong> publishes, so whoever controls ${esc(pub.domain)} vouches for it.` : "";
  if (r.provenance === "pinned") return `It was issued by the workspace key you expected, <code>${esc(r.workspace.key_id)}</code>.${vouched}`;
  if (r.provenance === "mismatch") return `Its workspace key is <code>${esc(r.workspace?.key_id ?? "unknown")}</code>.`;
  if (pub) return `Its workspace key is <code>${esc(r.workspace.key_id)}</code>.${vouched} The names in it are still the issuer's own.`;
  return `No expected workspace key was given, so the names in it are the issuer's own. Its workspace key is <code>${esc(r.workspace?.key_id ?? "unknown")}</code>: compare it with one you trust.`;
}
var STEP_STATE = { complete: "complete", failed: "failed", open: "open", blocked: "never started" };
function css() {
  return `
:root{--paper:#fff;--ink:#17202b;--quiet:#5b6672;--rule:#d5d9de;--pass:#17603f;--pass-bg:#e8f3ec;--fail:#a1261d;--fail-bg:#fbeae8;--open:#8a5a00;--open-bg:#fbf2df;--person:#2d4fa3;--agent:#6b4fa0;--system:#5b6672;
--serif:Charter,'Bitstream Charter','Sitka Text',Cambria,Georgia,serif;--sans:system-ui,-apple-system,'Segoe UI',Roboto,'Noto Sans',sans-serif}
@media (prefers-color-scheme:dark){:root{--paper:#14181d;--ink:#e6e9ed;--quiet:#9aa4ae;--rule:#2f363e;--pass:#6cc59a;--pass-bg:#16281f;--fail:#f08a80;--fail-bg:#2e1715;--open:#e0b45a;--open-bg:#2b2312;--person:#8fa8ec;--agent:#b9a3e6;--system:#9aa4ae}}
*{box-sizing:border-box}
body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.55 var(--sans);font-variant-numeric:tabular-nums}
main{max-width:46rem;margin:0 auto;padding:2.5rem 1rem 4rem}
h1,h2,h3{font-family:var(--serif);font-weight:600;line-height:1.2;margin:0}
h1{font-size:2rem;margin:.25rem 0 .5rem}
h2{font-size:1.35rem;margin:3rem 0 1rem;padding-top:1rem;border-top:1px solid var(--rule)}
h3{font-size:1.05rem;margin:1.5rem 0 .4rem}
p{margin:.4rem 0}
code{font-size:.85em;overflow-wrap:anywhere}
.meta{color:var(--quiet);margin:0}
.verdict{margin:2rem 0 0;padding:1.25rem 1.4rem;border-left:6px solid}
.verdict.pass{border-color:var(--pass);background:var(--pass-bg)}
.verdict.fail{border-color:var(--fail);background:var(--fail-bg)}
.verdict p{overflow-wrap:anywhere}
.verdict h2{border:0;margin:0 0 .4rem;padding:0;font-size:1.6rem}
.verdict.pass h2{color:var(--pass)}.verdict.fail h2{color:var(--fail)}
.open{list-style:none;padding:0;margin:0}
.open li{padding:.55rem .8rem;margin:.4rem 0;background:var(--open-bg);border-left:3px solid var(--open)}
ol.timeline{list-style:none;padding:0;margin:0}
.timeline li{display:grid;grid-template-columns:2.5rem 11rem 1fr;gap:.75rem;padding:.45rem 0;border-bottom:1px solid var(--rule);break-inside:avoid}
.timeline .seq{color:var(--quiet);text-align:right}
.timeline .who{font-weight:600;overflow-wrap:anywhere;border-left:3px solid var(--system);padding-left:.5rem}
.timeline .human .who{border-color:var(--person);color:var(--person)}
.timeline .agent .who{border-color:var(--agent);color:var(--agent)}
.timeline .runtime{color:var(--quiet);font-size:.92rem}
.timeline .runtime .who{border-color:transparent;font-weight:400}
.timeline .step-start{padding-top:1.4rem}
.calls{padding-left:1.1rem}.calls li{margin:.5rem 0}
.timeline .name,.timeline .id{display:block}.timeline .id{font-weight:400;font-size:.8rem;color:var(--quiet)}
.timeline time{display:block;color:var(--quiet);font-size:.8rem;font-weight:400}
.steps{list-style:none;padding:0;counter-reset:s}
.steps>li{counter-increment:s;margin:0 0 1.25rem;padding-left:2rem;position:relative}
.steps>li::before{content:counter(s);position:absolute;left:0;top:0;font-family:var(--serif);font-weight:600;color:var(--quiet)}
.steps ul{margin:.3rem 0;padding-left:1.1rem}
.state{font-size:.85rem;color:var(--quiet);font-weight:400}
.state.failed{color:var(--fail)}.state.complete{color:var(--pass)}
table{border-collapse:collapse;width:100%;font-size:.92rem}
th,td{text-align:left;padding:.4rem .5rem .4rem 0;border-bottom:1px solid var(--rule);vertical-align:top}
th{font-weight:600;color:var(--quiet)}
.scroll{overflow-x:auto}
.scope{color:var(--quiet);font-size:.92rem}
.verdict.open{border-color:var(--open);background:var(--open-bg)}.verdict.open h2{color:var(--open)}
.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(9rem,1fr));gap:.75rem;margin:1.25rem 0}
.tile{padding:.7rem .9rem;border:1px solid var(--rule)}.tile b{display:block;font-family:var(--serif);font-size:1.6rem;line-height:1.1}.tile span{color:var(--quiet);font-size:.85rem}
.tile.fail b{color:var(--fail)}.tile.open b{color:var(--open)}.tile.pass b{color:var(--pass)}
td.fail{color:var(--fail)}td.pass{color:var(--pass)}td.open{color:var(--open)}
a{color:var(--person)}
a:focus-visible{outline:2px solid var(--person);outline-offset:2px}
@media (max-width:36rem){.timeline li{grid-template-columns:2rem 1fr}.timeline .what{grid-column:2}h1{font-size:1.6rem}}
@media print{main{max-width:none;padding:0}h2{break-after:avoid}.verdict{border-width:4px}}`;
}
function page(title, body) {
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src data:">
<title>${esc(title)}</title>
<style>${css()}</style>
</head>
<body><main>
${body}
</main></body>
</html>
`;
}
function failureWords(step, code) {
  if (code === "limit") return "It is larger than a Record may be, so it was not checked.";
  switch (step) {
    case 1:
      return "It is not a well-formed Record file: it is damaged, or something was added to or removed from it.";
    case 2:
      return "Its seal does not hold: the summary signed by the issuing workspace was changed, or its key is not valid.";
    case 3:
      return "The list of who could take part was changed, or names a key that does not belong to the workspace.";
    case 4:
      return "The Procedure it ran under was changed, was not signed by someone allowed to, or breaks the format's rules.";
    case 5:
      return code === "chain" ? "An event is missing, added or out of order." : "An event was changed after it was signed, or was signed by a key not enrolled for whoever it names.";
    case 6:
      return "A file it relies on (a photo, a log, a trace) is missing or was changed.";
    case 7:
      return "It records something the Procedure did not allow, or something out of order.";
    case 8:
      return "A ruling, result or outcome it records is not what the rules give from its own events.";
    default:
      return "It failed its check.";
  }
}
function failedPage(r) {
  const f = r.failure;
  return page("Record failed its check", `
<p class="meta">Run Record report</p>
<h1>${r.procedure ? esc(r.procedure.procedure_id) : "Run Record"}${r.run_id ? `, run ${esc(r.run_id)}` : ""}</h1>
<section class="verdict fail" aria-labelledby="verdict">
<h2 id="verdict">This Record failed its check.</h2>
<p>It was altered, is incomplete, or records something the Procedure did not allow. Nothing in it can be relied on.</p>
<p><strong>${esc(failureWords(f.step, f.code))}</strong></p>
<p class="meta">The check stopped at step ${f.step} of 8 (<code>${esc(f.code)}</code>): ${esc(plain(f.message, 1e3))}</p>
${r.workspace ? `<p>Its workspace key is <code>${esc(r.workspace.key_id)}</code>.</p>` : ""}
</section>
${r.warnings.map((w) => `<p class="meta">${esc(w)}</p>`).join("\n")}
<h2>What a passing check would prove</h2>
<p class="scope">${esc(SCOPE_STATEMENT)}</p>`);
}
function procedureSection(t, states, agreed) {
  const steps = t.steps.map((s) => {
    const st = states.get(s.step_id) ?? "open";
    const lines = s.lines.map((l) => `<li>${esc(l.text)}${l.sub?.length ? `<ul>${l.sub.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>` : ""}</li>`).join("");
    return `<li><h3>${esc(s.title)} <span class="state ${esc(st)}">${esc(STEP_STATE[st] ?? st)}</span></h3>${s.instructions ? `<p>${esc(s.instructions)}</p>` : ""}<ul>${lines}</ul></li>`;
  });
  return `
<h2 id="agreed">What was agreed</h2>
<p>The signed Procedure: <strong>${esc(t.title)}</strong>, ${esc(t.procedure_id)} version ${esc(t.version)}.${t.source ? ` Written from ${esc(t.source.title)}.` : ""} ${esc(agreed)}</p>
${t.supersedes ? `<p>It replaces version ${esc(t.supersedes.version)}. What changed, as signed: ${esc(t.supersedes.summary)}${t.supersedes.basis.length ? ` The note cites ${t.supersedes.basis.length === 1 ? "one item" : `${t.supersedes.basis.length} items`} as its basis, by digest.` : ""}</p>` : ""}
${t.purpose ? `<p>${esc(t.purpose)}</p>` : ""}
<ol class="steps">${steps.join("\n")}</ol>`;
}
function agreedText(t, agreed, names) {
  const who = (id) => `${names.get(id) ?? id} (${id})`;
  if (!t.parties) return agreed[0] ? `Signed by ${who(agreed[0].participant_id)}.` : "";
  const party = new Map(t.parties.map((x) => [x.party_id, x.display_name]));
  return `Agreed by every party it names, each signing the same text: ${andList(agreed.map((a) => `${party.get(a.party_id) ?? a.party_id}, by ${who(a.participant_id)}`))}.`;
}
function renderReport(bundle, opts = {}) {
  const { report: r, contents: c } = openRecord(bundle, opts);
  if (r.integrity !== "pass" || !c) return failedPage(r);
  const t = renderProcedure(c.procedure);
  const ctx = contextFor(c.procedure, c.events);
  const names = new Map(c.enrollments.map((e) => [e.participant_id, plain(e.display_name, 80)]));
  const whoHtml = (actor) => actor.kind === "runtime" ? '<span class="name">OpsProof runtime</span><span class="id">the rules</span>' : `<span class="name">${esc(names.get(actor.participant_id) ?? actor.participant_id)}</span><span class="id">${esc(KIND[actor.kind] ?? actor.kind)}, ${esc(actor.participant_id)}</span>`;
  const states = new Map((r.steps ?? []).map((s) => [s.step_id, s.state]));
  const days = new Set(c.events.map(({ ev }) => String(ev.declared_time).slice(0, 10)));
  const oneDay = days.size === 1;
  const rows = c.events.map(({ ev }) => {
    const kind = ev.actor.kind;
    const startsStep = ev.kind === "StepOpened";
    return `<li class="${esc(kind)}${startsStep ? " step-start" : ""}"><span class="seq">${ev.seq}</span><span class="who">${whoHtml(ev.actor)}<time datetime="${esc(ev.declared_time)}">${esc(oneDay ? String(ev.declared_time).slice(11, -1) : String(ev.declared_time).replace("T", " ").replace("Z", ""))}</time></span><span class="what">${esc(describeEvent(ev, ctx))}</span></li>`;
  });
  const citedBy = /* @__PURE__ */ new Map();
  for (const { ev } of c.events) {
    const a = ev.kind === "Observation" ? ev.artifact : ev.trace;
    if (a) citedBy.set(a.digest, [...citedBy.get(a.digest) ?? [], ev.seq]);
  }
  let budget = opts.embedLimit ?? 2 * 1024 * 1024;
  const absent = new Map((r.findings ?? []).filter((f) => f.digest).map((f) => [f.digest, f]));
  const files = [...c.evidence.entries()].map(([d, f]) => {
    const name = `${short(d)}.${EXT[f.media_type] ?? "bin"}`;
    let link = esc(name);
    const gone = absent.get(d);
    if (!f.bytes) {
      link = gone?.kind === "withheld" ? `${esc(name)}<br><span class="meta">withheld from this copy on the order of ${esc(names.get(gone.ordered_by) ?? gone.ordered_by)} (${esc(gone.ordered_by)})${gone.reason ? `: ${esc(plain(gone.reason, 200))}` : ""}</span>` : `${esc(name)}<br><span class="meta">kept elsewhere, not in this file</span>`;
    } else if (f.size <= budget) {
      budget -= f.size;
      link = `<a download="${esc(name)}" href="data:application/octet-stream;base64,${b64Encode(f.bytes)}">${esc(name)}</a>`;
    }
    const by = citedBy.get(d) ?? [];
    return `<tr><td>${link}</td><td>${esc(f.media_type)}</td><td>${bytes(f.size)}</td><td>${by.map((n2) => `event ${n2}`).join(", ")}</td><td><code>${esc(d)}</code></td></tr>`;
  });
  const people = c.enrollments.map((e) => `<tr><td>${esc(plain(e.display_name, 80))}<br><span class="meta">${esc(e.participant_id)}</span></td><td>${esc(KIND[e.kind] ?? e.kind)}</td><td>${esc(e.roles.join(", ") || "\u2014")}</td><td>${esc(e.grants.join(", "))}${e.status === "revoked" ? " (retired)" : ""}</td><td><code title="${esc(e.key_id)}">${esc(short(e.key_id))}</code></td></tr>`);
  const open = r.open_matters ?? [];
  const bySeq = new Map(c.events.map(({ ev }) => [ev.seq, ev]));
  const refused = new Set(c.events.filter(({ ev }) => ev.kind === "Authorization" && ev.result === "deny").map(({ ev }) => String(ev.proposal)));
  const calls = [
    ...(r.human_authorizations ?? []).map((a) => {
      const ev = bySeq.get(a.seq);
      const after = a.result === "allow" && refused.has(String(ev.proposal)) ? " The limits had refused it." : "";
      return { seq: a.seq, html: `${esc(describeEvent(ev, ctx))}${esc(after)}` };
    }),
    ...(r.decisions ?? []).map((d) => ({
      seq: d.seq,
      html: `${esc(describeEvent(bySeq.get(d.seq), ctx))}${d.counted ? "" : ` <span class="meta">This is on the record but does not complete a required decision${d.step_id ? ", because its step was not open" : ""}.</span>`}`
    }))
  ].sort((a, b) => a.seq - b.seq);
  const callItems = calls.map((x) => {
    const ev = bySeq.get(x.seq);
    return `<li><strong>${esc(names.get(ev.actor.participant_id) ?? ev.actor.participant_id)}</strong> (${esc(KIND[ev.actor.kind] ?? ev.actor.kind)}, ${esc(ev.actor.participant_id)}), event ${x.seq}: ${x.html}</li>`;
  });
  const pinNote = r.provenance === "pinned" ? "" : " The names here are the issuer's own.";
  const body = `
<p class="meta">Run Record report for ${esc(plain(r.workspace.display_name, 120))}.${pinNote}</p>
<h1>${esc(t.title)}</h1>
<p class="meta">Run ${esc(r.run_id)}, ${r.event_count} events.</p>
${r.provenance === "mismatch" ? `<section class="verdict fail" aria-labelledby="verdict">
<h2 id="verdict">This Record is not from the workspace you expected.</h2>
<p>It is intact, but it was not shown to be issued under the workspace key you expected, so do not rely on it as theirs. Everything below, names included, is whoever issued it speaking.</p>
<p>${provenanceSentence(r)} You expected ${[opts.pin !== void 0 ? `<code>${esc([opts.pin].flat().join(" or "))}</code>` : "", opts.published ? `a key ${esc(opts.published.domain)} publishes` : ""].filter(Boolean).join(", and ")}.</p>
</section>` : `<section class="verdict pass" aria-labelledby="verdict">
<h2 id="verdict">This Record checks out.</h2>
<p>Nothing in it was changed after it was sealed, every event was signed by a key enrolled for whoever did it, and every action stayed inside what the Procedure allowed.</p>
<p><strong>${esc(outcomeSentence(r))}</strong></p>
<p>${provenanceSentence(r)}</p>
</section>`}
${open.length ? `<h2 id="open">Still open</h2>
<ul class="open">${open.map((m) => `<li>${esc(describeOpenMatter(m, ctx))}</li>`).join("")}</ul>` : ""}
${callItems.length ? `<h2 id="calls">Calls people made</h2>
<ul class="calls">${callItems.join("")}</ul>` : ""}
<h2 id="happened">What happened</h2>
<p class="meta">Every event, in the order it was recorded. Lines from the OpsProof runtime are its rulings and checks, which the check above recomputed; quoted text is what a participant wrote. Times are UTC${oneDay ? ` on ${esc([...days][0])}` : ""}, as each signer declared them.</p>
<ol class="timeline">
${rows.join("\n")}
</ol>
${procedureSection(t, states, agreedText(t, r.agreed_by ?? [], names))}
<h2 id="who">Who took part</h2>
<div class="scroll"><table>
<thead><tr><th scope="col">Name</th><th scope="col">Kind</th><th scope="col">Roles</th><th scope="col">May</th><th scope="col">Key</th></tr></thead>
<tbody>${people.join("")}</tbody>
</table></div>
${files.length ? `<h2 id="files">Files</h2>
<p class="meta">Readings' files and the traces agents and machines attached. Each is checked against its fingerprint.</p>
<div class="scroll"><table>
<thead><tr><th scope="col">File</th><th scope="col">Type</th><th scope="col">Size</th><th scope="col">Cited by</th><th scope="col">Fingerprint</th></tr></thead>
<tbody>${files.join("")}</tbody>
</table></div>` : ""}
<h2 id="scope">What this check proves</h2>
<p class="scope">${esc(SCOPE_STATEMENT)}</p>
<p class="scope">To check it yourself, run <code>runrec verify record.runrec --pin &lt;the workspace key you expect&gt;</code> with the free OpsProof checker. The key must come from the issuer through another channel, not from this page.</p>
${r.warnings.map((w) => `<p class="scope">${esc(w)}</p>`).join("\n")}`;
  return page(`${t.title}: Record report`, body);
}

// ../packages/runrec/src/shift.ts
var when = (t, oneDay) => t ? oneDay ? t.slice(11, 16) : t.slice(0, 16).replace("T", " ") : "\u2014";
function rowOf(name, bytes3, opts) {
  const { report, contents: c } = openRecord(bytes3, opts);
  const row = { name, report, calls: [], decisions: [], open: [], proposals: { agent: 0, allowed: 0, refused: 0 }, actions: { done: 0, failed: 0 } };
  if (!c) return row;
  row.sequence = c.manifest.sequence;
  row.title = plain(String(c.procedure.title ?? report.procedure.procedure_id), 80);
  row.started = String(c.events[0].ev.declared_time);
  row.closed = String(c.events.at(-1).ev.declared_time);
  const ctx = contextFor(c.procedure, c.events);
  const names = new Map(c.enrollments.map((e) => [e.participant_id, plain(e.display_name, 60)]));
  const who = (a) => `${names.get(a.participant_id) ?? a.participant_id} (${KIND[a.kind] ?? a.kind})`;
  const refused = /* @__PURE__ */ new Set();
  for (const { ev } of c.events) {
    const e = ev;
    if (e.kind === "Proposal" && e.actor.kind === "agent") row.proposals.agent++;
    if (e.kind === "Authorization") {
      const human = e.basis.kind === "human";
      if (!human) {
        if (e.result === "allow") row.proposals.allowed++;
        else {
          row.proposals.refused++;
          refused.add(String(e.proposal));
        }
      } else row.calls.push({ who: who(e.actor), text: describeEvent(e, ctx), override: e.result === "allow" && refused.has(String(e.proposal)) });
    }
    if (e.kind === "Action") e.result.status === "success" ? row.actions.done++ : row.actions.failed++;
    if (e.kind === "Decision") row.decisions.push({ who: who(e.actor), text: describeEvent(e, ctx) });
  }
  row.open = (report.open_matters ?? []).map((m) => describeOpenMatter(m, ctx));
  return row;
}
var n = (k, w, pl = `${w}s`) => `${k} ${k === 1 ? w : pl}`;
function renderShift(records, opts = {}) {
  const base = { ...opts.pin !== void 0 ? { pin: opts.pin } : {}, ...opts.published ? { published: opts.published } : {}, ...opts.limits ? { limits: opts.limits } : {} };
  let reg;
  if (opts.register) reg = verifyRegister(opts.register, records, { ...base, ...opts.previous ? { previous: opts.previous } : {} });
  const former = reg?.integrity === "pass" && reg.provenance === "pinned" ? (reg.former_keys ?? []).map((f) => f.key_id) : [];
  const verify = former.length && opts.pin !== void 0 ? { ...base, pin: [opts.pin, ...former].flat() } : base;
  const rows = records.map((r) => rowOf(r.name, r.bytes, verify));
  rows.sort((a, b) => (a.started ?? "~").localeCompare(b.started ?? "~") || a.name.localeCompare(b.name));
  const passed = rows.filter((r) => r.report.integrity === "pass");
  const failedCheck = rows.filter((r) => r.report.integrity !== "pass");
  const foreign = passed.filter((r) => r.report.provenance === "mismatch");
  const outcomes = { complete: 0, incomplete: 0, failed: 0 };
  for (const r of passed) outcomes[r.report.outcome]++;
  const calls = passed.flatMap((r) => r.calls.map((c) => ({ run: r, ...c })));
  const overrides = calls.filter((c) => c.override).length;
  const withOpen = passed.filter((r) => r.open.length);
  const days = [...new Set(passed.flatMap((r) => [r.started.slice(0, 10), r.closed.slice(0, 10)]))].sort();
  const oneDay = days.length === 1;
  const span = days.length === 0 ? "" : oneDay ? `on ${days[0]}` : `from ${days[0]} to ${days.at(-1)}`;
  const workspaces = /* @__PURE__ */ new Map();
  for (const r of passed) workspaces.set(r.report.workspace.key_id, plain(r.report.workspace.display_name, 80));
  const problems = [];
  if (failedCheck.length) problems.push(`${n(failedCheck.length, "Record")} failed ${failedCheck.length === 1 ? "its" : "their"} check and ${failedCheck.length === 1 ? "is" : "are"} left out of everything below.`);
  if (foreign.length) problems.push(`${n(foreign.length, "Record")} ${foreign.length === 1 ? "is" : "are"} not from the workspace you expected.`);
  if (reg && reg.integrity !== "pass") problems.push(`The register failed its check (${reg.failure.step} ${reg.failure.code}): what is here cannot be shown to be complete.`);
  if (reg?.integrity === "pass" && reg.missing.length) problems.push(`${n(reg.missing.length, "closed Run")} in the register ${reg.missing.length === 1 ? "is" : "are"} not here: ${reg.missing.map((s) => `#${s}`).join(", ")}.`);
  const tone = problems.length || outcomes.failed ? "fail" : withOpen.length || outcomes.incomplete ? "open" : "pass";
  const headline = passed.length ? `${n(passed.length, "run")} checked: ${outcomes.complete} completed, ${outcomes.failed} failed, ${outcomes.incomplete} incomplete.` : rows.length ? "No Record here passed its check." : "No Records were given.";
  const tiles = [
    ["pass", outcomes.complete, "completed"],
    ["fail", outcomes.failed, "failed"],
    ["open", outcomes.incomplete, "incomplete"],
    ["open", withOpen.length, "with open matters"],
    ["", calls.length, "times a person stepped in"],
    ["fail", overrides, "limits overridden by hand"],
    ...reg?.integrity === "pass" ? [["fail", reg.missing.length, "closed runs not here"], ["open", reg.open.length, "still open at issue"]] : []
  ].map(([cls, k, label2]) => `<div class="tile ${k ? cls : ""}"><b>${k}</b><span>${esc(label2)}</span></div>`);
  const attention = [
    ...failedCheck.map((r) => `<li><strong>${esc(r.name)}</strong> failed its check: ${esc(failureWords(Number(r.report.failure.step), r.report.failure.code))} <span class="meta">(step ${r.report.failure.step}, <code>${esc(r.report.failure.code)}</code>)</span></li>`),
    ...foreign.map((r) => `<li><strong>${esc(r.name)}</strong> was issued by workspace key <code>${esc(r.report.workspace.key_id)}</code>, not the one you expected.</li>`),
    ...passed.filter((r) => r.report.outcome === "failed").map((r) => `<li><strong>${esc(label(r))}</strong> failed. ${r.open.map((o) => esc(o)).join(" ")}</li>`),
    ...withOpen.filter((r) => r.report.outcome !== "failed").map((r) => `<li><strong>${esc(label(r))}</strong> has ${n(r.open.length, "matter")} still open. ${r.open.map((o) => esc(o)).join(" ")}</li>`),
    ...reg?.integrity === "pass" ? reg.missing.map((s) => `<li>Run <strong>#${s}</strong> is in the register as closed but its Record is not here.</li>`) : [],
    ...reg?.integrity === "pass" ? reg.records.flatMap((x) => (x.report.findings ?? []).filter((f) => f.kind === "revoked_later").map((f) => `<li><strong>${esc(x.name)}</strong> was signed with a key the workspace has since revoked (${esc(plain(f.reason ?? "", 200))}). It stands, since the revocation applies only to later runs, but read it knowing that. <span class="meta"><code>${esc(f.key_id ?? "")}</code></span></li>`)) : []
  ];
  const table = rows.map((r) => {
    if (r.report.integrity !== "pass") return `<tr><td>${r.sequence ?? "\u2014"}</td><td>${esc(r.name)}</td><td colspan="6" class="fail">failed its check (step ${r.report.failure.step}, ${esc(r.report.failure.code)})</td></tr>`;
    const o = r.report.outcome;
    const stepped = r.calls.length ? `${r.calls.length}${r.calls.some((c) => c.override) ? " (override)" : ""}` : "\u2014";
    const agents = r.proposals.agent ? `${r.proposals.agent} proposed, ${r.proposals.allowed} within limits, ${r.proposals.refused} refused` : "\u2014";
    return `<tr><td>${r.sequence}</td><td>${esc(label(r))}<br><span class="meta">${esc(r.report.run_id)}</span></td><td>${esc(when(r.started, oneDay))}</td><td>${esc(when(r.closed, oneDay))}</td><td class="${o === "complete" ? "pass" : o === "failed" ? "fail" : "open"}">${esc(o)}</td><td>${esc(agents)}</td><td>${esc(stepped)}</td><td>${r.open.length || "\u2014"}</td></tr>`;
  });
  const callItems = calls.map((c) => `<li><strong>${esc(c.who)}</strong> on ${esc(label(c.run))}: ${esc(c.text)}${c.override ? ' <span class="meta">The limits had refused it.</span>' : ""}</li>`);
  const decisionItems = passed.flatMap((r) => r.decisions.map((d) => `<li><strong>${esc(d.who)}</strong> on ${esc(label(r))}: ${esc(d.text)}</li>`));
  const regSection = reg ? reg.integrity === "pass" ? `<h2 id="register">Are these all of them?</h2>
<p>The workspace's register, issued ${esc(reg.issued_time ?? "")} and signed by its key, lists <strong>${n(reg.through, "run")}</strong> started so far. ${reg.missing.length ? `<strong>${n(reg.missing.length, "closed run")} ${reg.missing.length === 1 ? "is" : "are"} not here</strong>: ${reg.missing.map((s) => `#${s}`).join(", ")}.` : "Every closed run it lists is here."}${reg.open.length ? ` ${n(reg.open.length, "run")} ${reg.open.length === 1 ? "was" : "were"} still open when it was issued: ${reg.open.map((s) => `#${s}`).join(", ")}.` : ""}${reg.later.length ? ` ${n(reg.later.length, "run")} ${reg.later.length === 1 ? "has" : "have"} closed since: ${reg.later.map((s) => `#${s}`).join(", ")}.` : ""}${opts.previous ? " It extends the earlier register you gave without contradicting it." : ""}</p>${keyLines(reg)}` : `<h2 id="register">Are these all of them?</h2>
<p class="fail">The register failed its check at step ${esc(reg.failure.step)} (<code>${esc(reg.failure.code)}</code>): ${esc(plain(reg.failure.message, 400))}. Without it, nothing says whether other Runs exist.</p>` : `<h2 id="register">Are these all of them?</h2>
<p class="meta">No register was given. These Records check out on their own, but only the workspace's signed register can say whether Runs are missing. Ask the issuer for it.</p>`;
  const body = `
<p class="meta">Shift view \xB7 ${n(rows.length, "Record")}${workspaces.size ? ` from ${[...workspaces.values()].map((w) => esc(w)).join(", ")}` : ""}${opts.pin ? "" : ". Names are the issuers' own."}</p>
<h1>${esc(opts.title ?? (span ? `Runs ${span}` : "Runs"))}</h1>
<section class="verdict ${tone}" aria-labelledby="verdict">
<h2 id="verdict">${esc(headline)}</h2>
${problems.map((p) => `<p><strong>${esc(p)}</strong></p>`).join("\n")}
${passed.length ? `<p>People stepped in ${n(calls.length, "time")}${overrides ? `, overriding a limit ${n(overrides, "time")}` : ""}. ${workspaces.size === 1 ? `Issued by workspace key <code>${esc([...workspaces.keys()][0])}</code>.` : `Issued by ${n(workspaces.size, "workspace")}.`}</p>` : ""}
</section>
<div class="tiles">${tiles.join("")}</div>
${attention.length ? `<h2 id="attention">Needs attention</h2>
<ul class="open">${attention.join("")}</ul>` : ""}
<h2 id="runs">Every run</h2>
<p class="meta">In the order they started. Times are UTC${oneDay ? ` on ${esc(days[0])}` : ""}, as the signers declared them.</p>
<div class="scroll"><table>
<thead><tr><th scope="col">#</th><th scope="col">Run</th><th scope="col">Started</th><th scope="col">Closed</th><th scope="col">Outcome</th><th scope="col">Agents</th><th scope="col">People stepped in</th><th scope="col">Open</th></tr></thead>
<tbody>${table.join("\n")}</tbody>
</table></div>
${callItems.length ? `<h2 id="calls">Where a person stepped in</h2>
<ul class="calls">${callItems.join("")}</ul>` : ""}
${decisionItems.length ? `<h2 id="decisions">Decisions</h2>
<ul class="calls">${decisionItems.join("")}</ul>` : ""}
${regSection}
<h2 id="scope">What this check proves</h2>
<p class="scope">For each Record: ${esc(SCOPE_STATEMENT)}</p>
<p class="scope">Counts and findings on this page are computed from the checked Records alone; nothing is taken from any summary the issuer supplied.</p>`;
  return page(opts.title ?? "Shift view", body);
}
function keyLines(reg) {
  const items = [
    ...(reg.former_keys ?? []).map((f) => `<li>Earlier workspace key <code>${esc(f.key_id)}</code>, retired after run #${f.through}: Records it sealed up to then count as this workspace's.</li>`),
    ...(reg.revoked ?? []).map((x) => `<li>Revoked: <code>${esc(x.key_id)}</code>, for runs after #${x.as_of} (${esc(plain(x.reason, 200))}).</li>`),
    ...reg.successor ? [`<li>The workspace has committed to its next key, <code>${esc(reg.successor.key_id)}</code>, in advance: if this one is lost, only that key can take over.</li>`] : [],
    ...reg.published ? [`<li>The issuer says it published the register before this one at ${esc(plain(reg.published.log, 200))} (${esc(plain(reg.published.entry, 200))}).</li>`] : []
  ];
  return items.length ? `
<ul class="calls">${items.join("")}</ul>` : "";
}
var label = (r) => `${r.title ?? r.report.procedure?.procedure_id ?? r.name}${r.sequence !== void 0 ? ` #${r.sequence}` : ""}`;

// ../packages/runrec/src/pdf.ts
var PAGE2 = { w: 595, h: 842, margin: 50 };
var ASCII = { "\xB7": "-", "\u2013": "-", "\u2014": "-", "\u2018": "'", "\u2019": "'", "\u201C": '"', "\u201D": '"', "\u2026": "...", "\xD7": "x", "\u2212": "-", "\xB1": "+/-", "\u2192": "->", "\u2264": "<=", "\u2265": ">=" };
function clean(s) {
  return [...s].map((c) => ASCII[c] ?? (c.charCodeAt(0) < 32 ? " " : c.charCodeAt(0) > 255 ? "?" : c)).join("");
}
function escape(s) {
  return clean(s).replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
}
function wrap(s, width) {
  const out = [];
  for (const para of clean(s).split("\n")) {
    let line = "";
    for (const word of para.split(" ")) {
      if (!line) line = word;
      else if (line.length + 1 + word.length <= width) line += ` ${word}`;
      else {
        out.push(line);
        line = word;
      }
      while (line.length > width) {
        out.push(line.slice(0, width));
        line = line.slice(width);
      }
    }
    out.push(line);
  }
  return out;
}
function textPdf(title, blocks) {
  const pages = [[]];
  let y = PAGE2.h - PAGE2.margin;
  const line = (font, size, text, lead) => {
    if (y - lead < PAGE2.margin) {
      pages.push([]);
      y = PAGE2.h - PAGE2.margin;
    }
    y -= lead;
    pages.at(-1).push(`BT /${font} ${size} Tf ${PAGE2.margin} ${y} Td (${escape(text)}) Tj ET`);
  };
  line("F2", 16, title, 20);
  y -= 6;
  for (const b of blocks) {
    if ("h" in b) {
      y -= 8;
      for (const l of wrap(b.h, 70)) line("F2", 12, l, 16);
    } else if ("p" in b) {
      for (const l of wrap(b.p, 95)) line("F1", 10, l, 13);
      y -= 4;
    } else if ("mono" in b) {
      for (const l of wrap(b.mono, 82)) line("F3", 8.5, l, 11);
    } else {
      if (y - 10 < PAGE2.margin) continue;
      y -= 6;
      pages.at(-1).push(`${PAGE2.margin} ${y} m ${PAGE2.w - PAGE2.margin} ${y} l 0.5 w S`);
      y -= 6;
    }
  }
  const objs = [];
  const kids = pages.map((_, i) => `${6 + 2 * i} 0 R`).join(" ");
  objs.push("<< /Type /Catalog /Pages 2 0 R >>");
  objs.push(`<< /Type /Pages /Kids [${kids}] /Count ${pages.length} >>`);
  for (const f of ["Helvetica", "Helvetica-Bold", "Courier"]) objs.push(`<< /Type /Font /Subtype /Type1 /BaseFont /${f} /Encoding /WinAnsiEncoding >>`);
  pages.forEach((ops, i) => {
    const footer = `BT /F1 8 Tf ${PAGE2.margin} 30 Td (${escape(`${title} - page ${i + 1} of ${pages.length}`)}) Tj ET`;
    const stream = [...ops, footer].join("\n");
    objs.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PAGE2.w} ${PAGE2.h}] /Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R >> >> /Contents ${7 + 2 * i} 0 R >>`);
    objs.push(`<< /Length ${latin1(stream).length} >>
stream
${stream}
endstream`);
  });
  let body = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
  const offsets = [];
  objs.forEach((o, i) => {
    offsets.push(latin1(body).length);
    body += `${i + 1} 0 obj
${o}
endobj
`;
  });
  const xref = latin1(body).length;
  body += `xref
0 ${objs.length + 1}
0000000000 65535 f 
${offsets.map((o) => `${String(o).padStart(10, "0")} 00000 n 
`).join("")}`;
  body += `trailer
<< /Size ${objs.length + 1} /Root 1 0 R >>
startxref
${xref}
%%EOF
`;
  return latin1(body);
}
function latin1(s) {
  const b = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) b[i] = s.charCodeAt(i) & 255;
  return b;
}

// ../packages/runrec/src/pack.ts
var enc = new TextEncoder();
var OUTCOME = { complete: "complete", incomplete: "incomplete", failed: "failed" };
var VERDICT = { concur: "concurs", do_not_concur: "does not concur", more_examination: "asks for more examination" };
function csvCell(v) {
  let s = v === void 0 || v === null ? "" : String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
var csv = (rows) => rows.map((r) => r.map(csvCell).join(",")).join("\r\n") + "\r\n";
function recordPdf(bundle, opts = {}) {
  const { report: r, contents: c } = openRecord(bundle, opts);
  if (r.integrity !== "pass" || !c) {
    return textPdf("Run Record: this Record does not check", [
      { p: `It failed at step ${r.failure.step} (${r.failure.code}): ${plain(r.failure.message, 400)}. Nothing in it can be relied on.` },
      { mono: r.summary }
    ]);
  }
  const t = renderProcedure(c.procedure);
  const ctx = contextFor(c.procedure, c.events);
  const names = new Map(c.enrollments.map((e) => [e.participant_id, plain(e.display_name, 80)]));
  const who = (id) => id === "runtime" ? "OpsProof runtime" : `${names.get(id) ?? id} (${id})`;
  const blocks = [
    { p: `${t.title}, Run ${c.manifest.run_id} (number ${c.manifest.sequence} of ${plain(c.manifest.workspace.display_name, 80)}).` },
    { p: `This Record checks: nothing in it was changed after it was sealed, every event was signed by a key enrolled for whoever did it, and every action stayed inside what the Procedure allowed. Outcome: ${OUTCOME[r.outcome]}.` },
    { p: r.provenance === "pinned" ? `Issued by the workspace key you expected: ${r.workspace.key_id}.` : `Workspace key ${r.workspace.key_id}. ${r.provenance === "mismatch" ? "It is NOT the key you expected." : "No expected key was given: compare it with one you trust; the names in it are the issuer's own."}` },
    ...r.agreed_by?.length ? [{ p: `Procedure signed by ${r.agreed_by.map((a) => `${who(a.participant_id)}${a.party_id ? ` for ${a.party_id}` : ""}`).join(" and ")}.` }] : [],
    ...Object.keys(r.inputs ?? {}).length ? [{ p: `Inputs: ${Object.entries(r.inputs).map(([k, v]) => `${k} ${typeof v === "object" ? String(v.digest ?? "") : plain(v, 80)}`).join("; ")}.` }] : [],
    ...r.subjects?.length ? [{ p: `Done to: ${r.subjects.map((x) => `${x.kind} ${plain(x.id, 80)}`).join(", ")}.` }] : [],
    ...r.outputs?.length ? [{ p: `Produced: ${r.outputs.map((o) => `${o.output_id} ${o.digest}`).join("; ")}.` }] : [],
    ...r.related?.length ? [{ p: `Related Runs: ${r.related.map((x) => `${x.kind} ${x.run_id}`).join(", ")}.` }] : [],
    { rule: true },
    { h: "Steps" },
    ...(r.steps ?? []).map((s) => ({ p: `${t.steps.find((x) => x.step_id === s.step_id)?.title ?? s.step_id}: ${s.state === "blocked" ? "never started" : s.state}` }))
  ];
  if (r.open_matters?.length) blocks.push({ h: "Open matters" }, ...r.open_matters.map((m) => ({ p: describeOpenMatter(m, ctx) })));
  const calls = c.events.filter(({ ev }) => ev.kind === "Authorization" && ev.basis.kind === "human" || ev.kind === "Decision");
  if (calls.length) blocks.push({ h: "Calls people made" }, ...calls.map(({ ev }) => ({ p: `${who(ev.actor.participant_id)}, event ${ev.seq}: ${describeEvent(ev, ctx)}` })));
  for (const f of r.findings ?? []) {
    if (f.kind === "withheld") blocks.push({ p: `File ${f.digest} was withheld from this copy on the order of ${who(f.ordered_by)}${f.reason ? `: ${plain(f.reason, 200)}` : ""}.` });
    if (f.kind === "external") blocks.push({ p: `File ${f.digest} is kept elsewhere; this Record binds its digest and size.` });
  }
  blocks.push({ h: "What happened" }, ...c.events.map(({ ev }) => ({ mono: `${String(ev.seq).padStart(3)} ${String(ev.declared_time).replace("T", " ").replace("Z", "")}  ${who(ev.actor.participant_id)}: ${describeEvent(ev, ctx)}` })));
  blocks.push({ rule: true }, { p: SCOPE_STATEMENT });
  return textPdf(`Run Record: ${t.title}`, blocks);
}
function packEntries(input) {
  const trust = input.pin !== void 0 ? { pin: input.pin } : {};
  const register = input.register ? verifyRegister(input.register.bytes, input.records, trust) : void 0;
  const reports = input.records.map((r) => ({ name: r.name, report: openRecord(r.bytes, trust).report }));
  const reviews = (input.reviews ?? []).map((x) => ({ name: x.name, rep: verifyReview(x.bytes, trust) })).filter((x) => x.rep.integrity === "pass");
  const replaced = new Set(reviews.map((x) => x.rep.review.previous));
  const standing = reviews.filter((x) => !replaced.has(x.rep.digest));
  const standingFor = (run_id) => standing.filter((x) => x.rep.review.run_id === run_id).map((x) => `${x.rep.reviewer.participant_id} ${VERDICT[x.rep.review.verdict]}`).join("; ");
  const rows = reports.map(({ name, report: r }, i) => ({ name, r, bytes: input.records[i].bytes }));
  const table = csv([
    ["file", "sha256", "run_id", "procedure_id", "version", "integrity", "provenance", "outcome", "open_matters", "findings", "standing_reviews", "failure"],
    ...rows.map(({ name, r, bytes: bytes3 }) => [name, digestOf(bytes3), r.run_id, r.procedure?.procedure_id, r.procedure?.version, r.integrity, r.provenance, r.outcome, r.open_matters?.length, (r.findings ?? []).map((f) => f.kind).join(" "), standingFor(r.run_id), r.failure ? `${r.failure.step} ${r.failure.code}` : ""])
  ]);
  const matters = csv([["run_id", "step_id", "kind", "ref", "state"], ...rows.flatMap(({ r }) => (r.open_matters ?? []).map((m) => [r.run_id, m.step_id, m.kind, m.ref, m.state]))]);
  const decisions = csv([["run_id", "seq", "step_id", "type", "by", "counted"], ...rows.flatMap(({ r }) => (r.decisions ?? []).map((d) => [r.run_id, d.seq, d.step_id, d.type, d.by, d.counted]))]);
  const passed = rows.filter((x) => x.r.integrity === "pass");
  const summary = [
    { p: `${rows.length} Record${rows.length === 1 ? "" : "s"} checked: ${passed.length} pass, ${rows.length - passed.length} fail. Of those that pass, ${["complete", "incomplete", "failed"].map((o) => `${passed.filter((x) => x.r.outcome === o).length} ${o}`).join(", ")}.` }
  ];
  if (register) {
    summary.push(register.integrity === "pass" ? { p: `The register (${input.register.name}) checks, through Run ${register.through}. ${register.missing.length ? `Closed Runs it lists that are not in this pack: ${register.missing.map((s) => `#${s}`).join(", ")}.` : "Every closed Run it lists is in this pack."}${register.open.length ? ` Still open when it was issued: ${register.open.map((s) => `#${s}`).join(", ")}.` : ""}` } : { p: `The register does NOT check (${register.failure.step} ${register.failure.code}): this pack cannot be shown to be complete.` });
  } else summary.push({ p: "No register is included, so this pack cannot show whether these are all the Runs there are." });
  summary.push({ h: "Records" }, ...rows.map(({ name, r }) => ({ p: r.integrity === "pass" ? `${name}: ${r.procedure.procedure_id} ${r.procedure.version}, ${OUTCOME[r.outcome]}${r.open_matters.length ? `, ${r.open_matters.length} open` : ""}${r.provenance === "mismatch" ? ", NOT from the expected workspace" : ""}${standingFor(r.run_id) ? `; reviews: ${standingFor(r.run_id)}` : ""}` : `${name}: FAILS its check (${r.failure.step} ${r.failure.code})` })));
  summary.push({ rule: true }, { p: SCOPE_STATEMENT });
  const entries = [
    { name: "README.txt", data: enc.encode(readme2(input, register !== void 0)) },
    { name: "shift.html", data: enc.encode(renderShift(input.records, { ...trust, ...input.register ? { register: input.register.bytes } : {} })) },
    { name: "summary.pdf", data: textPdf(input.title ?? "Handover pack", summary) },
    { name: "records.csv", data: enc.encode(table) },
    { name: "open-matters.csv", data: enc.encode(matters) },
    { name: "decisions.csv", data: enc.encode(decisions) },
    ...input.records.map((r) => ({ name: `records/${r.name}`, data: r.bytes })),
    ...input.records.map((r) => ({ name: `records/${r.name.replace(/\.runrec$/, "")}.pdf`, data: recordPdf(r.bytes, trust) })),
    ...input.register ? [{ name: `register/${input.register.name}`, data: input.register.bytes }] : [],
    ...input.journal ? [{ name: `journal/${input.journal.name}`, data: input.journal.bytes }] : [],
    ...(input.reviews ?? []).map((x) => ({ name: `reviews/${x.name}`, data: x.bytes })),
    ...input.reader ? [{ name: "reader.html", data: input.reader }] : []
  ];
  return { entries, reports, ...register ? { register } : {} };
}
function buildPack(input) {
  return writeZip(packEntries(input).entries);
}
function readme2(input, hasRegister) {
  return [
    input.title ?? "Handover pack",
    "",
    "This pack holds Run Records and what explains them. The Records (records/*.runrec) are the evidence; everything else is computed from them and can be computed again by anyone.",
    "",
    hasRegister ? "register/ holds the workspace's signed list of every Run it started, so you can tell whether these are all the Records there are." : "There is no register in this pack, so it cannot show whether these are all the Runs there are.",
    input.journal ? "journal/ holds the workspace journal: everything done to the workspace outside a Run, by whom." : "",
    input.reviews?.length ? "reviews/ holds signed reviews of these Records." : "",
    "",
    input.reader ? "Check it yourself: open reader.html in a browser and drop the records folder and the register on it. Nothing is uploaded." : "Check it yourself with the free reader (https://opsproof.systems/check) or the runrec command line: runrec register register/*.register.json records/",
    "shift.html, summary.pdf and the CSV tables show what was checked when this pack was made; check again rather than trusting them.",
    "",
    SCOPE_STATEMENT,
    ""
  ].filter((l, i, a) => l !== "" || a[i - 1] !== "").join("\n");
}

// src/keys.ts
var NAME_RE = /^[a-z0-9][a-z0-9._/-]{0,300}$/;
function checkName(name) {
  if (!NAME_RE.test(name)) throw new Error(`invalid key name ${JSON.stringify(name)}`);
}
function generateSeed() {
  for (; ; ) {
    const seed = new Uint8Array(randomBytes(32));
    if (isStrictPublicKey(keyPairFromSeed(seed).publicKey)) return seed;
  }
}
var MemoryKeyStore = class {
  backend = "memory";
  #seeds = /* @__PURE__ */ new Map();
  async create(name, _opts) {
    checkName(name);
    if (this.#seeds.has(name)) throw new Error(`key ${name} already exists`);
    const seed = generateSeed();
    this.#seeds.set(name, seed);
    return keyPairFromSeed(seed).publicKey;
  }
  async has(name) {
    return this.#seeds.has(name);
  }
  async sign(name, message) {
    const seed = this.#seeds.get(name);
    if (!seed) throw new Error(`no key ${name}`);
    return ed25519Sign(seed, message);
  }
  async remove(name) {
    this.#seeds.delete(name);
  }
};
var DevKeyStore = class {
  backend = "development";
  #dir;
  constructor(dir) {
    this.#dir = dir;
  }
  #file(name) {
    checkName(name);
    return join(this.#dir, `${name.replaceAll("/", "~")}.seed`);
  }
  async create(name, _opts) {
    const f = this.#file(name);
    if (existsSync(f)) throw new Error(`key ${name} already exists`);
    mkdirSync(this.#dir, { recursive: true, mode: 448 });
    const seed = generateSeed();
    writeFileSync(f, b64urlEncode(seed) + "\n", { mode: 384, flag: "wx" });
    return keyPairFromSeed(seed).publicKey;
  }
  async has(name) {
    return existsSync(this.#file(name));
  }
  #seed(name) {
    const f = this.#file(name);
    if (!existsSync(f)) throw new Error(`no key ${name}`);
    const seed = b64urlDecode(readFileSync(f, "utf8").trim());
    if (seed.length !== 32) throw new Error(`${f} is not a development key file`);
    return seed;
  }
  async sign(name, message) {
    return ed25519Sign(this.#seed(name), message);
  }
  async remove(name) {
    rmSync(this.#file(name), { force: true });
  }
};
var Custody = class {
  store;
  prefix;
  constructor(store, workspace_id) {
    this.store = store;
    this.prefix = workspace_id;
  }
  /** The workspace key of a generation (spec §5, key succession): the first is `workspace`, later ones `workspace-<n>`. */
  workspaceName(generation = 1) {
    return generation === 1 ? `${this.prefix}/workspace` : `${this.prefix}/workspace-${generation}`;
  }
  participantName(participant_id) {
    return `${this.prefix}/participant/${participant_id}`;
  }
  signer(name, publicKey) {
    return signerFor(publicKey, (m) => this.store.sign(name, m));
  }
  hasWorkspaceKey(generation = 1) {
    return this.store.has(this.workspaceName(generation));
  }
  /** Make a workspace key. A successor is made the same way, long before it is used, and stays locked until then. */
  async createWorkspaceKey(generation = 1) {
    const name = this.workspaceName(generation);
    return this.signer(name, await this.store.create(name, { unlock: "session" }));
  }
  /** Unlock the workspace key for this session, where the store asks the person. */
  async unlockWorkspaceKey(generation = 1) {
    await this.store.unlock?.(this.workspaceName(generation));
  }
  workspaceSigner(publicKey, generation = 1) {
    return this.signer(this.workspaceName(generation), publicKey);
  }
  /** Remove a workspace key: one never used, or one retired, whose private half should not outlive its use. */
  discardWorkspaceKey(generation = 1) {
    return this.store.remove(this.workspaceName(generation));
  }
  hasParticipantKey(participant_id) {
    return this.store.has(this.participantName(participant_id));
  }
  async createParticipantKey(participant_id) {
    const name = this.participantName(participant_id);
    return this.signer(name, await this.store.create(name, { unlock: "each" }));
  }
  participantSigner(participant_id, publicKey) {
    return this.signer(this.participantName(participant_id), publicKey);
  }
  discardParticipantKey(participant_id) {
    return this.store.remove(this.participantName(participant_id));
  }
};

// src/vault.ts
import { createHash as createHash3, randomBytes as randomBytes2 } from "node:crypto";
import { closeSync, existsSync as existsSync3, fsyncSync, mkdirSync as mkdirSync2, openSync, readFileSync as readFileSync2, renameSync, rmSync as rmSync2, writeSync } from "node:fs";
import { join as join3 } from "node:path";

// src/presence.ts
import { spawn, spawnSync } from "node:child_process";
import { existsSync as existsSync2 } from "node:fs";
import { dirname, join as join2 } from "node:path";
import { fileURLToPath } from "node:url";
var PresenceDeclined = class extends Error {
  constructor(message = "the presence check was cancelled or failed; nothing was signed") {
    super(message);
    this.name = "PresenceDeclined";
  }
};
var PresenceUnavailable = class extends Error {
  constructor(message) {
    super(message);
    this.name = "PresenceUnavailable";
  }
};
var PresenceLocked = class extends Error {
  constructor(message) {
    super(message);
    this.name = "PresenceLocked";
  }
};
var PROMPT_TIMEOUT_MS = 18e4;
var MAX_LINE = 4 << 20;
var PresenceHelper = class _PresenceHelper {
  command;
  info;
  timeoutMs;
  #proc;
  #next = 1;
  #pending = /* @__PURE__ */ new Map();
  #queue = Promise.resolve();
  /** bumps whenever the process is (re)started, so callers know open session keys were lost */
  generation = 0;
  constructor(command, info, opts = {}) {
    this.command = command;
    this.info = info;
    this.timeoutMs = opts.timeoutMs ?? PROMPT_TIMEOUT_MS;
  }
  /** Ask a helper what it offers; undefined if it cannot run or the check is unavailable here. */
  static detect(command, opts = {}) {
    const r = spawnSync(command[0], [...command.slice(1), "info"], { encoding: "utf8", timeout: 3e4, windowsHide: true });
    if (r.status !== 0) return void 0;
    try {
      const info = JSON.parse(r.stdout);
      if (info.available !== true || typeof info.id !== "string" || typeof info.label !== "string") return void 0;
      return new _PresenceHelper(command, { id: info.id, label: info.label }, opts);
    } catch {
      return void 0;
    }
  }
  #start() {
    if (this.#proc) return this.#proc;
    const p = spawn(this.command[0], [...this.command.slice(1), "serve"], { stdio: ["pipe", "pipe", "pipe"], windowsHide: true });
    this.generation++;
    let buf = "";
    p.stdout.setEncoding("utf8");
    p.stdout.on("data", (chunk) => {
      buf += chunk;
      if (buf.length > MAX_LINE) return this.#fail(p, new Error("presence helper sent an over-long line"));
      for (let i = buf.indexOf("\n"); i >= 0; i = buf.indexOf("\n")) {
        const line = buf.slice(0, i);
        buf = buf.slice(i + 1);
        let msg;
        try {
          msg = JSON.parse(line);
        } catch {
          return this.#fail(p, new Error("presence helper sent malformed output"));
        }
        const pending = this.#pending.get(msg.id);
        if (!pending) return this.#fail(p, new Error("presence helper answered a request that was not asked"));
        this.#pending.delete(msg.id);
        clearTimeout(pending.timer);
        pending.resolve(msg);
      }
    });
    let stderr = "";
    p.stderr.on("data", (c) => stderr = (stderr + c.toString()).slice(-2e3));
    p.on("error", (e) => this.#fail(p, new PresenceUnavailable(`presence helper could not run: ${e.message}`)));
    p.on("exit", (code) => this.#fail(p, new Error(`presence helper exited (${code ?? "killed"})${stderr ? `: ${stderr.trim().split("\n").at(-1)}` : ""}`)));
    this.#proc = p;
    return p;
  }
  #fail(p, e) {
    if (this.#proc !== p) return;
    this.#proc = void 0;
    p.kill();
    for (const [, pending] of this.#pending) {
      clearTimeout(pending.timer);
      pending.reject(e);
    }
    this.#pending.clear();
  }
  /** Send one request; resolves with the response's members, or rejects with the mapped error. */
  request(op, fields = {}) {
    const run2 = async () => {
      const p = this.#start();
      const id = this.#next++;
      const msg = await new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          this.#fail(p, new PresenceDeclined("no one answered the presence check in time; nothing was signed"));
        }, this.timeoutMs);
        this.#pending.set(id, { resolve, reject, timer });
        p.stdin.write(JSON.stringify({ id, op, ...fields }) + "\n");
      });
      if (msg.ok === true) return msg;
      const text = typeof msg.message === "string" ? msg.message : String(msg.error);
      switch (msg.error) {
        case "declined":
          throw new PresenceDeclined(text);
        case "unavailable":
          throw new PresenceUnavailable(text);
        case "locked":
          throw new PresenceLocked(text);
        default:
          throw new Error(`presence helper ${op}: ${text}`);
      }
    };
    const next = this.#queue.then(run2, run2);
    this.#queue = next.catch(() => void 0);
    return next;
  }
  /** Whether the helper process is running now. */
  get running() {
    return this.#proc !== void 0;
  }
  /** End the helper process; it forgets every open key. */
  stop() {
    const p = this.#proc;
    if (!p) return;
    this.#proc = void 0;
    p.stdin.end();
    setTimeout(() => p.kill(), 2e3).unref();
  }
};
function helperCommand() {
  const env = process.env.OPSPROOF_PRESENCE_HELPER;
  if (env) {
    if (/\.ts$/.test(env)) return [process.execPath, "--experimental-strip-types", "--no-warnings", env];
    return /\.m?js$/.test(env) ? [process.execPath, env] : [env];
  }
  const root = join2(dirname(fileURLToPath(import.meta.url)), "..", "..", "native");
  const candidates = {
    darwin: join2(root, "macos", ".build", "release", "opsproof-presence"),
    win32: join2(root, "rust", "target", "release", "opsproof-presence.exe"),
    linux: join2(root, "rust", "target", "release", "opsproof-presence")
  };
  const p = candidates[process.platform];
  return p && existsSync2(p) ? [p] : void 0;
}

// src/prompt.ts
import { createHash as createHash2 } from "node:crypto";
var MAX_EXACT = 2 ** 53;
function num(n2) {
  if (Number.isInteger(n2) && Math.abs(n2) <= MAX_EXACT) return n2 === 0 ? "0" : n2.toFixed(0);
  return String(n2);
}
function clean2(v, n2) {
  const s = typeof v === "string" ? v : typeof v === "number" ? num(v) : typeof v === "boolean" ? String(v) : "?";
  let out = "";
  for (const ch of s) {
    const c = ch.codePointAt(0);
    out += c >= 32 && c <= 126 ? ch : "?";
  }
  return out.length > n2 ? `${out.slice(0, n2 - 3)}...` : out;
}
var sha256 = (b) => createHash2("sha256").update(b).digest("hex");
function fp(d) {
  return typeof d === "string" && /^sha256:[0-9a-f]{12}/.test(d) ? d.slice(7, 19) : clean2(d, 12);
}
function keyFp(k) {
  if (typeof k !== "string" || !/^[A-Za-z0-9_-]+$/.test(k)) return "?";
  try {
    return sha256(b64urlDecode(k)).slice(0, 12);
  } catch {
    return "?";
  }
}
function confirmationCode(bytes3) {
  const h = sha256(bytes3).slice(0, 8).toUpperCase();
  return `${h.slice(0, 4)}-${h.slice(4)}`;
}
function statementOfPae(message) {
  const text = Buffer.from(message).toString("latin1");
  const m = /^DSSEv1 ([1-9][0-9]{0,8}|0) /.exec(text);
  if (!m) return void 0;
  let i = m[0].length;
  const tlen = Number(m[1]);
  const type = text.slice(i, i + tlen);
  i += tlen;
  const m2 = /^ ([1-9][0-9]{0,9}|0) /.exec(text.slice(i));
  if (type !== PAYLOAD_TYPE || !m2) return void 0;
  i += m2[0].length;
  if (Number(m2[1]) !== message.length - i) return void 0;
  try {
    const st = JSON.parse(Buffer.from(message.subarray(i)).toString("utf8"));
    if (!st || typeof st !== "object" || Array.isArray(st)) return void 0;
    const { predicateType, predicate } = st;
    if (typeof predicateType !== "string" || !predicate || typeof predicate !== "object" || Array.isArray(predicate)) return void 0;
    return { predicateType, predicate };
  } catch {
    return void 0;
  }
}
var DSSE = new TextEncoder().encode("DSSEv1 ");
function sessionAsks(message) {
  if (message.length < DSSE.length || DSSE.some((b, i) => message[i] !== b)) return false;
  const st = statementOfPae(message);
  return !st || st.predicateType === `${PREDICATE_BASE}enrollment`;
}
var obj = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var list = (v, none) => Array.isArray(v) && v.length ? v.map((x) => clean2(x, 30)).join(", ") : none;
var quoted2 = (v, n2) => `"${clean2(v, n2).replaceAll('"', "'")}"`;
function action(a) {
  const o = obj(a);
  const params = obj(o.parameters);
  const names = Object.keys(params).sort((x, y) => Buffer.compare(Buffer.from(x), Buffer.from(y)));
  const shown = names.slice(0, 12).map((k) => {
    const v = params[k];
    return `${clean2(k, 30)}=${typeof v === "string" ? quoted2(v, 60) : clean2(v, 60)}`;
  });
  if (names.length > 12) shown.push("...");
  return `${clean2(o.type, 40)}(${shown.join(", ")})`;
}
function describe(name, message) {
  const st = statementOfPae(message);
  if (!st) return `sign data that is not an OpsProof statement with key ${clean2(name, 80)}`;
  const p = st.predicate;
  const i = name.indexOf("/participant/");
  const AS = i >= 0 ? ` as ${clean2(name.slice(i + "/participant/".length), 40)}` : "";
  const ON = typeof p.step_id === "string" ? ` on ${clean2(p.step_id, 40)}` : "";
  const RUN = typeof p.run_id === "string" ? ` in run ${clean2(p.run_id, 40)}` : "";
  const tail = `${ON}${AS}${RUN}`;
  switch (st.predicateType) {
    case `${PREDICATE_BASE}procedure`:
      return `sign Procedure ${clean2(p.procedure_id, 60)} version ${clean2(p.version, 30)}${AS}`;
    case `${PREDICATE_BASE}enrollment`:
      return `enroll ${clean2(p.kind, 10)} ${clean2(p.participant_id, 60)} with ${list(p.grants, "no grants")}; roles ${list(p.roles, "none")}; key ${keyFp(p.public_key)}; named ${quoted2(p.display_name, 40)}`;
    case `${PREDICATE_BASE}manifest`:
      return `seal the Record of run ${clean2(p.run_id, 60)}`;
    case `${PREDICATE_BASE}event`:
      switch (p.kind) {
        case "Authorization":
          return `${p.result === "allow" ? "allow" : "deny"} proposal ${fp(p.proposal)}${tail}`;
        case "Decision":
          return `decide ${clean2(p.type, 20)}${typeof p.decision_id === "string" ? ` (${clean2(p.decision_id, 40)})` : ""}${tail}, reason ${quoted2(p.reason, 60)}`;
        case "Proposal":
          return `propose ${action(p.action)}${tail}`;
        case "Action":
          return `record ${action(p.action)} as ${clean2(obj(p.result).status, 10)}${tail}`;
        case "Observation": {
          if (p.measurement !== void 0) {
            const m = obj(p.measurement);
            return `record ${clean2(m.quantity, 40)} = ${clean2(m.value, 30)} ${clean2(m.unit, 20)}${tail}`;
          }
          const a = obj(p.artifact);
          return `record ${clean2(a.media_type, 40)} evidence ${fp(a.digest)}${tail}`;
        }
        case "Note":
          return `add the note ${quoted2(p.text, 60)}${tail}`;
        default:
          return `record ${clean2(p.kind, 20)}${tail}`;
      }
    default:
      return `sign an unknown statement with key ${clean2(name, 80)}`;
  }
}
function openDescription(name) {
  return `open workspace ${clean2(name.split("/")[0], 60)}`;
}

// src/vault.ts
var KEY_FORMAT = "opsproof-key/2";
var B64U = /^[A-Za-z0-9_-]+$/;
function parseKeyFile(v, name) {
  const bad = (m) => {
    throw new Error(`key file for ${name}: ${m}`);
  };
  if (!v || typeof v !== "object" || Array.isArray(v)) bad("not an object");
  const o = v;
  const keys = Object.keys(o).sort().join(",");
  if (keys !== "format,name,nonce,params,provider,public_key,sealed,unlock") bad(`unexpected members ${keys}`);
  if (o.format !== KEY_FORMAT) bad(`unsupported format ${JSON.stringify(o.format)}`);
  if (o.name !== name) bad(`names ${JSON.stringify(o.name)}`);
  if (o.unlock !== "each" && o.unlock !== "session") bad("unlock must be each or session");
  for (const k of ["public_key", "provider", "nonce", "sealed"]) if (typeof o[k] !== "string" || !o[k]) bad(`${k} must be a string`);
  if (!B64U.test(o.public_key) || !isStrictPublicKey(b64urlDecode(o.public_key))) bad("public_key is not a strict Ed25519 key");
  const params = o.params;
  if (!params || typeof params !== "object" || Array.isArray(params)) bad("params must be an object");
  for (const [k, x] of Object.entries(params)) {
    if (!/^[a-z_]{1,32}$/.test(k) || typeof x !== "string" || !B64U.test(x)) bad(`params.${k} is not allowed`);
  }
  return o;
}
function keyFileName(name) {
  checkName(name);
  const plain2 = `k-${name.replaceAll("/", "~")}.key`;
  return plain2.length <= 200 ? plain2 : `k-h${createHash3("sha256").update(name).digest("hex").slice(0, 40)}.key`;
}
function writeDurably(dir, file, data) {
  const path = join3(dir, file);
  const tmp = `${path}.${process.pid}.tmp`;
  const fd = openSync(tmp, "wx", 384);
  try {
    writeSync(fd, data);
    fsyncSync(fd);
  } finally {
    closeSync(fd);
  }
  renameSync(tmp, path);
  if (process.platform !== "win32") {
    const d = openSync(dir, "r");
    try {
      fsyncSync(d);
    } finally {
      closeSync(d);
    }
  }
}
var VaultKeyStore = class {
  backend;
  presence;
  dir;
  /** Human keys */
  helper;
  /** the workspace key */
  sessionHelper;
  onPrompt;
  /** session keys opened in the session helper, with the helper generation they were opened in */
  #open = /* @__PURE__ */ new Map();
  constructor(dir, helper) {
    this.dir = dir;
    this.helper = helper;
    this.sessionHelper = new PresenceHelper(helper.command, helper.info, { timeoutMs: helper.timeoutMs });
    this.backend = `vault:${helper.info.id}`;
    this.presence = helper.info.label;
  }
  #helperFor(unlock) {
    return unlock === "session" ? this.sessionHelper : this.helper;
  }
  #tell(key, description, code) {
    try {
      this.onPrompt?.({ key, description, code });
    } catch {
    }
  }
  #read(name) {
    const path = join3(this.dir, keyFileName(name));
    if (!existsSync3(path)) throw new Error(`no key ${name} in ${this.dir}`);
    let v;
    try {
      v = JSON.parse(readFileSync2(path, "utf8"));
    } catch {
      throw new Error(`key file for ${name} is not JSON`);
    }
    const f = parseKeyFile(v, name);
    if (f.provider !== this.helper.info.id) throw new Error(`key ${name} is protected by ${f.provider}, but this machine offers ${this.helper.info.id}`);
    return f;
  }
  async create(name, opts = {}) {
    const file = keyFileName(name);
    if (existsSync3(join3(this.dir, file))) throw new Error(`key ${name} already exists`);
    const unlock = opts.unlock ?? "each";
    const helper = this.#helperFor(unlock);
    const r = await helper.request("create", { name, unlock });
    const key = parseKeyFile(r.key, name);
    if (key.unlock !== unlock || key.provider !== this.helper.info.id) throw new Error(`presence helper returned a different key than asked for ${name}`);
    mkdirSync2(this.dir, { recursive: true, mode: 448 });
    try {
      writeDurably(this.dir, file, JSON.stringify(key, null, 2) + "\n");
    } catch (e) {
      await helper.request("forget", { key }).catch(() => void 0);
      throw e;
    }
    if (unlock === "session") this.#open.set(name, helper.generation);
    return b64urlDecode(key.public_key);
  }
  async has(name) {
    return existsSync3(join3(this.dir, keyFileName(name)));
  }
  /** Open a session key in the session helper, asking the person once. Only ever called on the person's request. */
  async unlock(name) {
    if (this.#open.get(name) === this.sessionHelper.generation) return;
    const key = this.#read(name);
    if (key.unlock !== "session") throw new Error(`key ${name} asks for each signature; it is never opened for a session`);
    const challenge = new Uint8Array(randomBytes2(16));
    this.#tell(name, openDescription(name), confirmationCode(challenge));
    await this.sessionHelper.request("open", { key, challenge: b64urlEncode(challenge) });
    this.#open.set(name, this.sessionHelper.generation);
  }
  /** Whether a session key is open now. */
  isOpen(name) {
    return this.#open.get(name) === this.sessionHelper.generation && this.sessionHelper.running;
  }
  async sign(name, message) {
    const key = this.#read(name);
    if (key.unlock === "session" && !this.isOpen(name)) {
      this.#open.delete(name);
      throw new PresenceLocked(`the workspace key is closed; open the workspace again to continue`);
    }
    if (key.unlock === "each" || sessionAsks(message)) this.#tell(name, describe(name, message), confirmationCode(message));
    const r = await this.#helperFor(key.unlock).request("sign", { key, message: b64urlEncode(message) });
    if (typeof r.signature !== "string") throw new Error("presence helper returned no signature");
    const sig = b64urlDecode(r.signature);
    if (!ed25519Verify(b64urlDecode(key.public_key), message, sig)) throw new Error(`presence helper returned a signature that does not verify for ${name}`);
    return sig;
  }
  async remove(name) {
    const path = join3(this.dir, keyFileName(name));
    this.#open.delete(name);
    if (!existsSync3(path)) return;
    try {
      const key = this.#read(name);
      await this.#helperFor(key.unlock).request("forget", { key });
    } finally {
      rmSync2(path, { force: true });
    }
  }
  /** Close every open key and end the helper processes. */
  lock() {
    this.#open.clear();
    this.helper.stop();
    this.sessionHelper.stop();
  }
};
function platformKeyStore(dir) {
  const command = helperCommand();
  const helper = command ? PresenceHelper.detect(command) : void 0;
  return helper ? new VaultKeyStore(join3(dir, "keys"), helper) : void 0;
}

// src/workspace.ts
import { mkdirSync as mkdirSync3, existsSync as existsSync4, readFileSync as readFileSync3, renameSync as renameSync2, rmSync as rmSync3, writeFileSync as writeFileSync2 } from "node:fs";
import { join as join4 } from "node:path";
import { randomBytes as randomBytes3 } from "node:crypto";

// src/errors.ts
var KernelError = class extends Error {
  status;
  code;
  constructor(status, code, message) {
    super(message);
    this.name = "KernelError";
    this.status = status;
    this.code = code;
  }
};
var invalid = (m) => new KernelError(400, "invalid", m);
var forbidden = (m) => new KernelError(403, "forbidden", m);
var notFound = (m) => new KernelError(404, "not_found", m);

// src/run.ts
var PARTICIPANT_KINDS = ["Proposal", "Authorization", "Action", "Observation", "Decision", "Note", "ChildStarted"];
var HEADER_KEYS = ["run_id", "workspace_id", "seq", "previous", "kind", "actor", "declared_time"];
var DEFAULT_LIMITS = {
  maxEntries: 6e4,
  maxBytes: 1536 * 1024 * 1024,
  maxEventBytes: 256 * 1024,
  maxRefusalNotes: 20
};
function dispatchOf(ev, owed) {
  if (ev.actor.kind !== "runtime") return "participant";
  if (ev.kind === "RunStarted") return "start";
  if (ev.kind === "RunClosed") return "close";
  if (ev.kind === "Note" && owed === 0) return "note";
  if (ev.kind === "ChildSealed" && owed === 0) return "child";
  return "runtime";
}
var RunSession = class _RunSession {
  ctx;
  entries = [];
  limits;
  enrollments;
  engine;
  /** evidence cited so far, by digest */
  evidence = /* @__PURE__ */ new Map();
  /** bytes the Record would hold so far */
  bytes;
  /** reserve for the runtime events one Participant event can trigger, plus RunClosed */
  reserveEntries;
  constructor(ctx) {
    this.ctx = ctx;
    this.limits = { ...DEFAULT_LIMITS, ...ctx.limits };
    this.enrollments = new Map([...ctx.participants].map(([id, p]) => [id, p.enrollment]));
    this.engine = this.freshEngine();
    const criteria = ctx.procedure.steps.reduce((n2, st) => n2 + st.evidence.length, 0);
    this.reserveEntries = criteria + 2 * ctx.procedure.steps.length + 2;
    this.bytes = 64 * 1024 + ctx.procedureBytes.length + [...ctx.participants.values()].reduce((n2, p) => n2 + p.bytes.length, 0);
  }
  push(entry) {
    this.entries.push(entry);
    this.bytes += entry.bytes.length;
    for (const a of citationsOf(entry.event)) {
      if (this.evidence.has(a.digest)) continue;
      this.evidence.set(a.digest, { media_type: a.media_type, size: a.size });
      this.bytes += a.size;
    }
  }
  /** Files the Record would hold now. */
  get recordEntries() {
    return 3 + this.ctx.participants.size + this.entries.length + this.evidence.size;
  }
  freshEngine() {
    return new RunEngine({ procedure: this.ctx.procedure, enrollments: this.enrollments, ...this.ctx.policy ? { policy: this.ctx.policy } : {} });
  }
  get run_id() {
    return this.ctx.run_id;
  }
  get head() {
    return this.entries.at(-1)?.digest ?? null;
  }
  get nextSeq() {
    return this.entries.length + 1;
  }
  get started() {
    return this.engine.started;
  }
  get closed() {
    return this.engine.closed;
  }
  get subjectName() {
    return `runrec:procedure:${this.ctx.procedure.procedure_id}@${this.ctx.procedure.version}`;
  }
  // ------------------------------------------------------------ rebuilding
  /**
   * Rebuild a Run from stored envelopes. Every envelope is checked as the
   * verifier would check it (signature, chain, signer, rules), so a tampered
   * store is refused rather than built upon.
   */
  static replay(ctx, envelopes) {
    const s = new _RunSession(ctx);
    for (const bytes3 of envelopes) {
      const { att, event } = s.checkEnvelope(bytes3);
      s.apply(s.engine, event, att.digest);
      s.push({ event, digest: att.digest, bytes: bytes3 });
    }
    return s;
  }
  /** Apply one already-checked event to an engine, the way the verifier does (spec §8 steps 7–8). */
  apply(engine, ev, digest) {
    switch (dispatchOf(ev, engine.owed.length)) {
      case "start":
        engine.start(digest, ev);
        return;
      case "runtime":
        engine.confirmRuntime(ev, digest);
        return;
      case "note":
        engine.applyRuntimeNote(ev, digest);
        return;
      case "child":
        engine.applyChildSealed(ev, digest);
        return;
      case "close": {
        const c = engine.close();
        if (ev.outcome !== c.outcome || canonicalize(ev.open_matters) !== canonicalize(c.open_matters)) {
          throw new RecordError(8, "recompute", `seq ${ev.seq}: RunClosed differs from the recomputed outcome`);
        }
        return;
      }
      case "participant":
        engine.applyParticipant(ev, digest);
        return;
    }
  }
  /** A copy of the engine, for checking an event without changing the Run. */
  trialEngine() {
    const e = this.freshEngine();
    for (const x of this.entries) this.apply(e, x.event, x.digest);
    return e;
  }
  /**
   * Envelope, chain position and signer checks (spec §8 step 5). Throws
   * KernelError: 400 malformed, 409 stale chain position, 403 wrong signer.
   */
  checkEnvelope(bytes3) {
    let att;
    try {
      att = parseAttestation(bytes3);
    } catch (e) {
      throw invalid(`envelope: ${e.message}`);
    }
    if (att.predicateType !== "event") throw invalid("envelope does not carry an event");
    const sub = att.statement.subject[0];
    if (sub.name !== this.subjectName || `sha256:${sub.digest.sha256}` !== this.ctx.procedureDigest) {
      throw invalid("event subject is not this Run's Procedure");
    }
    let event;
    try {
      event = parseEvent(att.statement.predicate);
    } catch (e) {
      throw invalid(e.message);
    }
    if (event.run_id !== this.ctx.run_id || event.workspace_id !== this.ctx.workspace.workspace_id) {
      throw invalid("event names another Run or workspace");
    }
    if (event.seq !== this.nextSeq || event.previous !== this.head) {
      throw new KernelError(409, "conflict", `the chain is at seq ${this.nextSeq - 1}; this event was prepared for seq ${event.seq}. Prepare it again.`);
    }
    let key;
    if (event.actor.participant_id === "runtime") {
      if (event.actor.kind !== "runtime" || event.actor.key_id !== this.ctx.workspace.key.keyId) {
        throw new KernelError(403, "signature", "runtime events must be signed by the workspace key");
      }
      key = this.ctx.workspace.key.publicKey;
    } else {
      const enr = this.enrollments.get(event.actor.participant_id);
      if (!enr) throw new KernelError(403, "signature", `${event.actor.participant_id} is not enrolled in this Run`);
      if (enr.status !== "active" || enr.kind !== event.actor.kind || enr.key_id !== event.actor.key_id) {
        throw new KernelError(403, "signature", `actor kind or key differs from the enrollment of ${enr.participant_id}`);
      }
      key = b64urlDecode(enr.public_key);
    }
    if (att.keyid !== event.actor.key_id || !verifySignature(att, key)) {
      throw new KernelError(403, "signature", `signature does not verify for ${event.actor.participant_id}`);
    }
    if (!SIGNERS[event.kind].includes(event.actor.kind)) {
      throw new KernelError(403, "signature", `${event.kind} may not be signed by ${event.actor.kind}`);
    }
    return { att, event };
  }
  // ------------------------------------------------------------ writing
  /** The kernel clock, never earlier than the previous event (the system clock can step backwards). */
  now() {
    const now = this.ctx.clock();
    const prev = this.entries.at(-1)?.event.declared_time;
    return prev !== void 0 && Date.parse(now) < Date.parse(prev) ? prev : now;
  }
  header(kind, actor) {
    return {
      run_id: this.ctx.run_id,
      workspace_id: this.ctx.workspace.workspace_id,
      seq: this.nextSeq,
      previous: this.head,
      kind,
      actor,
      declared_time: this.now()
    };
  }
  runtimeActor() {
    return { participant_id: "runtime", kind: "runtime", key_id: this.ctx.workspace.key.keyId };
  }
  statementFor(body) {
    return makeStatement("event", this.subjectName, this.ctx.procedureDigest, body);
  }
  /** Have the workspace key sign a runtime event the rules already accounted for, and append it. */
  async appendRuntime(body) {
    const event = parseEvent(body);
    const att = await signStatementWith(this.statementFor(body), this.ctx.workspace.key);
    const entry = { event, digest: att.digest, bytes: att.bytes };
    this.push(entry);
    return entry;
  }
  async emitRuntime(expected) {
    for (const e of expected) {
      const entry = await this.appendRuntime({ ...this.header(e.kind, this.runtimeActor()), ...e });
      this.engine.confirmRuntime(entry.event, entry.digest);
    }
  }
  /** Record RunStarted and the Step openings that follow it. */
  async start(fields) {
    if (this.entries.length) throw new KernelError(409, "conflict", "the Run has already started");
    const problem = bindingProblem(this.ctx.procedure, fields);
    if (problem) throw new KernelError(400, "invalid", problem);
    for (const v of Object.values(fields.inputs ?? {})) {
      if (isObject(v) && "media_type" in v && !this.ctx.blob(v.digest)) throw new KernelError(400, "invalid", `upload ${String(v.digest)} before binding it as an input`);
    }
    const entry = await this.appendRuntime({
      ...this.header("RunStarted", this.runtimeActor()),
      procedure_id: this.ctx.procedure.procedure_id,
      version: this.ctx.procedure.version,
      procedure_digest: this.ctx.procedureDigest,
      ...fields
    });
    await this.emitRuntime(this.engine.start(entry.digest, entry.event));
  }
  requireOpen() {
    if (!this.started) throw new KernelError(409, "conflict", "the Run has not started");
    if (this.closed) throw new KernelError(409, "closed", "the Run is closed");
  }
  /**
   * Build the next Participant event for `participant_id` and check it
   * against the rules without changing the Run. The caller signs the PAE of
   * `payload` and returns it to `commit`.
   */
  async prepare(participant_id, kind, fields) {
    this.requireOpen();
    if (!PARTICIPANT_KINDS.includes(kind)) throw invalid(`${kind} is not recorded by Participants`);
    const enr = this.enrollments.get(participant_id);
    if (!enr) throw new KernelError(403, "forbidden", `${participant_id} is not enrolled in this Run`);
    for (const k of Object.keys(fields)) if (HEADER_KEYS.includes(k)) throw invalid(`${k} is set by the kernel`);
    const body = {
      ...this.header(kind, { participant_id, kind: enr.kind, key_id: enr.key_id }),
      ...fields
    };
    let event;
    try {
      event = parseEvent(body);
    } catch (e) {
      throw invalid(e.message);
    }
    const statement = this.statementFor(body);
    let payload;
    try {
      payload = canonicalBytes(statement);
    } catch (e) {
      if (e instanceof JsonError) throw invalid(e.message);
      throw e;
    }
    const digest = digestOf(payload);
    this.checkCapacity(event, payload.length + 512);
    this.checkEvidence(event);
    try {
      this.trialEngine().applyParticipant(event, digest);
    } catch (e) {
      throw await this.refuse(event, e);
    }
    return { run_id: this.ctx.run_id, seq: event.seq, previous: event.previous, digest, payload_type: PAYLOAD_TYPE, payload: b64Encode(payload), statement };
  }
  /**
   * Accept a signed Participant event. `onlyFor` restricts the signer (a
   * participant session may commit only its own events).
   */
  async commit(envelopeBytes, onlyFor) {
    this.requireOpen();
    const { att, event } = this.checkEnvelope(envelopeBytes);
    if (event.actor.kind === "runtime") throw new KernelError(403, "forbidden", "runtime events are recorded by the kernel only");
    if (onlyFor !== void 0 && event.actor.participant_id !== onlyFor) {
      throw new KernelError(403, "forbidden", `this session may only record events for ${onlyFor}`);
    }
    this.checkDeclaredTime(event);
    this.checkCapacity(event, envelopeBytes.length);
    this.checkEvidence(event);
    let expected;
    try {
      expected = this.engine.applyParticipant(event, att.digest);
    } catch (e) {
      throw await this.refuse(event, e);
    }
    const start = this.entries.length;
    this.push({ event, digest: att.digest, bytes: envelopeBytes });
    await this.emitRuntime(expected);
    return this.entries.slice(start);
  }
  /** Prepare, have `signer` sign (a custodial Human's key in the KeyStore), and commit. */
  async submitWith(signer, participant_id, kind, fields) {
    const p = await this.prepare(participant_id, kind, fields);
    return this.commit(await signPrepared(p, signer));
  }
  /**
   * A declared time must not precede the previous event and must be within
   * the skew of the kernel clock (measured from the previous event if the
   * system clock has stepped backwards, so a Run is never wedged by it).
   */
  checkDeclaredTime(ev) {
    const skew = this.ctx.maxSkewMs ?? 5 * 6e4;
    const now = Date.parse(this.ctx.clock());
    const t = Date.parse(ev.declared_time);
    const priorText = this.entries.at(-1)?.event.declared_time;
    const prior = priorText === void 0 ? -Infinity : Date.parse(priorText);
    if (t < prior) throw invalid(`declared_time ${ev.declared_time} is earlier than the previous event's`);
    if (t === prior) return;
    if (t < now - skew) throw invalid(`declared_time ${ev.declared_time} is more than ${skew / 1e3} s behind the kernel clock`);
    if (t > now + skew) throw invalid(`declared_time ${ev.declared_time} is more than ${skew / 1e3} s ahead of the kernel clock`);
  }
  /**
   * Turn a rule failure into a 403 and record the refusal as a runtime Note.
   * Repeating the same refused attempt does not add another Note.
   */
  async refuse(ev, e) {
    if (!(e instanceof RecordError)) throw e;
    const reason = e.message.replace(/^seq \d+: /, "");
    const who = ev.actor.participant_id;
    const text = `Refused ${ev.kind} from ${who}: ${reason}`;
    const capText = `Further refused attempts from ${who} are not recorded in this Run`;
    if (this.engine.owed.length === 0 && !this.closed) {
      const prefix = new RegExp(`^Refused [A-Za-z]+ from ${who.replace(/[.]/g, "\\.")}: `);
      let count = 0;
      let seen = false;
      let capped = false;
      for (const x of this.entries) {
        if (x.event.kind !== "Note" || x.event.actor.kind !== "runtime") continue;
        const t = String(x.event.text);
        if (t === capText) capped = true;
        else if (prefix.test(t)) {
          count++;
          if (t === text) seen = true;
        }
      }
      const room = this.recordEntries + 1 + this.reserveEntries <= this.limits.maxEntries;
      if (!seen && !capped && room) {
        if (count < this.limits.maxRefusalNotes) await this.note(text, ev.step_id);
        else await this.note(capText);
      }
    }
    return new KernelError(403, "rejected", reason);
  }
  /** Refuse an event that would make the Record too large to issue. Closing is always possible. */
  checkCapacity(ev, envelopeBytes) {
    if (envelopeBytes > this.limits.maxEventBytes) throw new KernelError(413, "too_large", `events are limited to ${this.limits.maxEventBytes} bytes`);
    const fresh = citationsOf(ev).filter((a) => !this.evidence.has(a.digest));
    const newEvidence = fresh.length;
    const newBytes = envelopeBytes + fresh.reduce((n2, a) => n2 + a.size, 0);
    const reserveBytes = this.reserveEntries * 4096;
    if (this.recordEntries + 1 + newEvidence + this.reserveEntries > this.limits.maxEntries || this.bytes + newBytes + reserveBytes > this.limits.maxBytes) {
      throw new KernelError(409, "full", "this Run has reached the size a Record can hold; close it and continue in a new Run");
    }
  }
  /** Cited evidence (an artifact or a trace) must be stored, with the cited size and media type (spec §8 step 6). */
  checkEvidence(ev) {
    for (const a of citationsOf(ev)) this.checkCited(a);
  }
  checkCited(a) {
    const stored = this.ctx.blob(a.digest);
    if (!stored) throw invalid(`evidence ${a.digest} has not been uploaded; upload it before citing it`);
    if (stored.size !== a.size) throw invalid(`evidence ${a.digest} is ${stored.size} bytes, cited as ${a.size}`);
    if (stored.media_type !== a.media_type) throw invalid(`evidence ${a.digest} was uploaded as ${stored.media_type}, cited as ${a.media_type}`);
    const prior = this.evidence.get(a.digest);
    if (prior && (prior.media_type !== a.media_type || prior.size !== a.size)) throw invalid(`evidence ${a.digest} is cited differently earlier in this Run`);
  }
  /** A runtime Note. */
  async note(text, step_id) {
    this.requireOpen();
    const known = step_id !== void 0 && this.ctx.procedure.steps.some((s) => s.step_id === step_id);
    const entry = await this.appendRuntime({ ...this.header("Note", this.runtimeActor()), text, ...known ? { step_id } : {} });
    this.engine.applyRuntimeNote(entry.event, entry.digest);
  }
  /** Close the Run with the recomputed outcome (spec §6.6). */
  /** (draft 11, spec §4.4) Record that a child Run's Record was sealed, and the settle that follows. */
  async childSealed(step_id, child_run_id, record, outcome) {
    this.requireOpen();
    const body = { ...this.header("ChildSealed", this.runtimeActor()), step_id, child_run_id, record, outcome };
    const trial = parseEvent(body);
    try {
      this.trialEngine().applyChildSealed(trial, digestOf(canonicalBytes(this.statementFor(body))));
    } catch (e) {
      if (e instanceof RecordError) throw new KernelError(409, "conflict", e.message);
      throw e;
    }
    const start = this.entries.length;
    const entry = await this.appendRuntime(body);
    await this.emitRuntime(this.engine.applyChildSealed(entry.event, entry.digest));
    return this.entries.slice(start);
  }
  async close(closed_by) {
    this.requireOpen();
    const c = this.engine.close();
    await this.appendRuntime({
      ...this.header("RunClosed", this.runtimeActor()),
      outcome: c.outcome,
      open_matters: c.open_matters,
      ...closed_by ? { closed_by } : {}
    });
    return c;
  }
  // ------------------------------------------------------------ reading
  state() {
    const v = this.engine.view();
    const last = this.entries.at(-1)?.event;
    const closed = last?.kind === "RunClosed";
    const c = closed ? { outcome: String(last.outcome), open_matters: last.open_matters } : this.engine.conclude();
    const titles = new Map(this.ctx.procedure.steps.map((s) => [s.step_id, s.title]));
    return {
      run_id: this.ctx.run_id,
      status: closed ? "closed" : "open",
      procedure: { procedure_id: this.ctx.procedure.procedure_id, version: this.ctx.procedure.version, digest: this.ctx.procedureDigest, title: this.ctx.procedure.title },
      event_count: this.entries.length,
      head: this.head,
      outcome: c.outcome,
      open_matters: c.open_matters,
      steps: v.steps.map((s) => ({ ...s, title: titles.get(s.step_id) ?? s.step_id })),
      success_counts: v.success_counts
    };
  }
  view() {
    return this.engine.view();
  }
  /** The inputs for bundle assembly; the Run must be closed. */
  sealInput(blob, published_time, published_by) {
    const last = this.entries.at(-1)?.event;
    if (!last || last.kind !== "RunClosed") throw new KernelError(409, "conflict", "close the Run before sealing");
    const ws = this.ctx.workspace;
    return {
      workspace: { workspace_id: ws.workspace_id, display_name: ws.display_name, keyId: ws.key.keyId, publicKeyB64u: ws.key.publicKeyB64u },
      run_id: this.ctx.run_id,
      sequence: this.ctx.sequence,
      procedure: { procedure_id: this.ctx.procedure.procedure_id, version: this.ctx.procedure.version, digest: this.ctx.procedureDigest, bytes: this.ctx.procedureBytes },
      enrollments: [...this.ctx.participants.values()].map((p) => ({ participant_id: p.enrollment.participant_id, digest: p.digest, bytes: p.bytes })),
      events: this.entries,
      blob,
      closed: { outcome: String(last.outcome), open_matters: last.open_matters },
      published_time,
      ...published_by ? { published_by } : {},
      ...this.engine.outputs() ? { outputs: this.engine.outputs() } : {}
    };
  }
};
async function signPrepared(p, signer) {
  const payload = new Uint8Array(Buffer.from(p.payload, "base64"));
  const sig = await signer.sign(pae(PAYLOAD_TYPE, payload));
  return canonicalBytes({ payloadType: PAYLOAD_TYPE, payload: p.payload, signatures: [{ keyid: signer.keyId, sig: b64Encode(sig) }] });
}

// src/store.ts
import { DatabaseSync } from "node:sqlite";
var SCHEMA_VERSION = 2;
var TABLES = ["meta", "enrollments", "retirements", "procedures", "runs", "events", "blobs", "records", "registers", "workspace_keys", "rotations", "resignatures", "revocations", "journal", "cosignatures", "reviews"];
var SCHEMA = `
create table if not exists meta (key text primary key, value text not null) strict;
create table if not exists enrollments (
  participant_id text primary key,
  digest text not null unique,
  key_id text not null unique,
  custodial integer not null check (custodial in (0, 1)),
  envelope blob not null,
  enrolled_at text not null
) strict;
create table if not exists retirements (
  participant_id text primary key references enrollments (participant_id),
  retired_at text not null,
  reason text not null
) strict;
create table if not exists procedures (
  digest text primary key,
  procedure_id text not null,
  version text not null,
  author text not null references enrollments (participant_id),
  envelope blob not null,
  added_at text not null,
  unique (procedure_id, version)
) strict;
create table if not exists runs (
  run_id text primary key,
  sequence integer not null unique check (sequence >= 1),
  procedure_digest text not null references procedures (digest),
  enrollments text not null,
  created_at text not null
) strict;
create table if not exists events (
  run_id text not null references runs (run_id),
  seq integer not null check (seq >= 1),
  digest text not null unique,
  kind text not null,
  envelope blob not null,
  primary key (run_id, seq)
) strict;
create table if not exists blobs (
  digest text primary key,
  media_type text not null,
  size integer not null,
  bytes blob not null
) strict;
create table if not exists records (
  run_id text primary key references runs (run_id),
  digest text not null,
  bytes blob not null,
  sealed_at text not null
) strict;
create table if not exists registers (
  digest text primary key,
  through integer not null,
  bytes blob not null,
  issued_at text not null
) strict;
-- Key succession (spec \xA75): the workspace's later keys, each made before it is needed (generation 1 is in meta),
-- the rotations that put them in use, every enrollment re-signed by each, and the keys the workspace revoked.
-- Added tables only, so a store made before them opens unchanged.
create table if not exists workspace_keys (
  generation integer primary key check (generation >= 2),
  key_id text not null unique,
  public_key text not null,
  created_at text not null
) strict;
create table if not exists rotations (
  generation integer primary key references workspace_keys (generation),
  through integer not null,
  rotated_at text not null
) strict;
create table if not exists resignatures (
  participant_id text not null references enrollments (participant_id),
  generation integer not null references rotations (generation),
  digest text not null,
  envelope blob not null,
  primary key (participant_id, generation)
) strict;
-- The workspace journal (spec \xA77.6): everything done to the workspace outside a Run, signed by whoever did it.
create table if not exists journal (
  seq integer primary key check (seq >= 1),
  digest text not null unique,
  kind text not null,
  envelope blob not null
) strict;
create table if not exists reviews (
  digest text primary key,
  workspace_id text not null,
  run_id text not null,
  participant_id text not null,
  verdict text not null,
  previous text,
  envelope blob not null,
  file blob,
  reviewed_at text not null
) strict;
create table if not exists cosignatures (
  digest text not null references procedures (digest),
  participant_id text not null references enrollments (participant_id),
  sig blob not null,
  signed_at text not null,
  unique (digest, participant_id)
) strict;
create table if not exists revocations (
  key_id text primary key,
  as_of integer not null,
  reason text not null,
  revoked_at text not null
) strict;
`;
var TRIGGERS = TABLES.flatMap((t) => [
  `create trigger if not exists ${t}_no_update before update on ${t} begin select raise(abort, '${t} is append-only'); end;`,
  `create trigger if not exists ${t}_no_delete before delete on ${t} begin select raise(abort, '${t} is append-only'); end;`
]).join("\n");
var bytes2 = (v) => new Uint8Array(v);
var Store = class _Store {
  db;
  constructor(db) {
    this.db = db;
  }
  /** Open or create the store at `path` (':memory:' for a throwaway store). */
  static open(path) {
    const db = new DatabaseSync(path);
    try {
      db.exec("pragma foreign_keys = on; pragma journal_mode = wal; pragma synchronous = full; pragma locking_mode = exclusive;");
      db.exec(SCHEMA);
      db.exec(TRIGGERS);
      db.exec("begin immediate; commit;");
      const s = new _Store(db);
      const v = s.meta("schema_version");
      if (v === void 0) s.setMeta("schema_version", String(SCHEMA_VERSION));
      else if (v !== String(SCHEMA_VERSION)) throw new Error(`this workspace was made by an earlier build (store schema ${v}; this build writes ${SCHEMA_VERSION}); make a new workspace`);
      return s;
    } catch (e) {
      db.close();
      throw e;
    }
  }
  close() {
    this.db.close();
  }
  /** Run `fn` in one immediate transaction; roll back on any error. */
  transaction(fn) {
    this.db.exec("begin immediate");
    try {
      const out = fn();
      this.db.exec("commit");
      return out;
    } catch (e) {
      this.db.exec("rollback");
      throw e;
    }
  }
  meta(key) {
    const r = this.db.prepare("select value from meta where key = ?").get(key);
    return r ? String(r.value) : void 0;
  }
  setMeta(key, value2) {
    this.db.prepare("insert into meta (key, value) values (?, ?)").run(key, value2);
  }
  insertEnrollment(r) {
    this.db.prepare("insert into enrollments (participant_id, digest, key_id, custodial, envelope, enrolled_at) values (?, ?, ?, ?, ?, ?)").run(r.participant_id, r.digest, r.key_id, r.custodial ? 1 : 0, r.envelope, r.enrolled_at);
  }
  enrollments() {
    return this.db.prepare("select * from enrollments order by rowid").all().map((r) => ({
      participant_id: String(r.participant_id),
      digest: String(r.digest),
      key_id: String(r.key_id),
      custodial: r.custodial === 1,
      envelope: bytes2(r.envelope),
      enrolled_at: String(r.enrolled_at)
    }));
  }
  retire(participant_id, retired_at, reason) {
    this.db.prepare("insert into retirements (participant_id, retired_at, reason) values (?, ?, ?)").run(participant_id, retired_at, reason);
  }
  retired() {
    const rows = this.db.prepare("select * from retirements").all();
    return new Map(rows.map((r) => [String(r.participant_id), { retired_at: String(r.retired_at), reason: String(r.reason) }]));
  }
  insertProcedure(r) {
    this.db.prepare("insert into procedures (digest, procedure_id, version, author, envelope, added_at) values (?, ?, ?, ?, ?, ?)").run(r.digest, r.procedure_id, r.version, r.author, r.envelope, r.added_at);
  }
  procedures() {
    return this.db.prepare("select * from procedures order by rowid").all().map(procRow);
  }
  procedure(digest) {
    const r = this.db.prepare("select * from procedures where digest = ?").get(digest);
    return r ? procRow(r) : void 0;
  }
  procedureByVersion(procedure_id, version) {
    const r = this.db.prepare("select * from procedures where procedure_id = ? and version = ?").get(procedure_id, version);
    return r ? procRow(r) : void 0;
  }
  insertRun(r) {
    this.db.prepare("insert into runs (run_id, sequence, procedure_digest, enrollments, created_at) values (?, ?, ?, ?, ?)").run(r.run_id, r.sequence, r.procedure_digest, JSON.stringify(r.enrollments), r.created_at);
  }
  /** The number the next Run started here takes: one more than the last. */
  nextSequence() {
    const r = this.db.prepare("select coalesce(max(sequence), 0) as n from runs").get();
    return Number(r.n) + 1;
  }
  runs() {
    return this.db.prepare("select * from runs order by sequence").all().map(runRow);
  }
  run(run_id) {
    const r = this.db.prepare("select * from runs where run_id = ?").get(run_id);
    return r ? runRow(r) : void 0;
  }
  /** Append events to a Run. Their seqs must continue the stored chain without a gap. */
  appendEvents(run_id, events) {
    if (events.length === 0) return;
    const last = this.db.prepare("select coalesce(max(seq), 0) as n from events where run_id = ?").get(run_id);
    let next = Number(last.n) + 1;
    const ins = this.db.prepare("insert into events (run_id, seq, digest, kind, envelope) values (?, ?, ?, ?, ?)");
    for (const e of events) {
      if (e.seq !== next) throw new Error(`event seq ${e.seq} does not follow ${next - 1} in ${run_id}`);
      ins.run(run_id, e.seq, e.digest, e.kind, e.envelope);
      next++;
    }
  }
  events(run_id, afterSeq = 0) {
    return this.db.prepare("select seq, digest, kind, envelope from events where run_id = ? and seq > ? order by seq").all(run_id, afterSeq).map((r) => ({
      seq: Number(r.seq),
      digest: String(r.digest),
      kind: String(r.kind),
      envelope: bytes2(r.envelope)
    }));
  }
  /** Store a blob once. The same bytes may not be stored under two media types. */
  putBlob(digest, media_type, data) {
    const prior = this.db.prepare("select media_type from blobs where digest = ?").get(digest);
    if (prior) {
      if (prior.media_type !== media_type) throw new Error(`blob ${digest} is stored as ${String(prior.media_type)}; it cannot also be ${media_type}`);
      return;
    }
    this.db.prepare("insert into blobs (digest, media_type, size, bytes) values (?, ?, ?, ?)").run(digest, media_type, data.length, data);
  }
  /** A blob's media type and size, without reading its bytes. */
  blobMeta(digest) {
    const r = this.db.prepare("select media_type, size from blobs where digest = ?").get(digest);
    return r ? { media_type: String(r.media_type), size: Number(r.size) } : void 0;
  }
  /** Event count and the last event of a Run, without replaying it. */
  runTail(run_id) {
    const c = this.db.prepare("select count(*) as n from events where run_id = ?").get(run_id);
    const r = this.db.prepare("select seq, digest, kind, envelope from events where run_id = ? order by seq desc limit 1").get(run_id);
    return {
      count: Number(c.n),
      ...r ? { last: { seq: Number(r.seq), digest: String(r.digest), kind: String(r.kind), envelope: bytes2(r.envelope) } } : {}
    };
  }
  blob(digest) {
    const r = this.db.prepare("select media_type, bytes from blobs where digest = ?").get(digest);
    return r ? { media_type: String(r.media_type), bytes: bytes2(r.bytes) } : void 0;
  }
  insertRecord(run_id, digest, data, sealed_at) {
    this.db.prepare("insert into records (run_id, digest, bytes, sealed_at) values (?, ?, ?, ?)").run(run_id, digest, data, sealed_at);
  }
  record(run_id) {
    const r = this.db.prepare("select digest, bytes, sealed_at from records where run_id = ?").get(run_id);
    return r ? { digest: String(r.digest), bytes: bytes2(r.bytes), sealed_at: String(r.sealed_at) } : void 0;
  }
  insertRegister(digest, through, data, issued_at) {
    this.db.prepare("insert into registers (digest, through, bytes, issued_at) values (?, ?, ?, ?)").run(digest, through, data, issued_at);
  }
  workspaceKeys() {
    return this.db.prepare("select generation, key_id, public_key from workspace_keys order by generation").all().map((r) => ({ generation: Number(r.generation), key_id: String(r.key_id), public_key: String(r.public_key) }));
  }
  insertWorkspaceKey(generation, key_id, public_key, created_at) {
    this.db.prepare("insert into workspace_keys (generation, key_id, public_key, created_at) values (?, ?, ?, ?)").run(generation, key_id, public_key, created_at);
  }
  rotations() {
    return this.db.prepare("select * from rotations order by generation").all().map((r) => ({ generation: Number(r.generation), through: Number(r.through), rotated_at: String(r.rotated_at) }));
  }
  insertRotation(generation, through, rotated_at) {
    this.db.prepare("insert into rotations (generation, through, rotated_at) values (?, ?, ?)").run(generation, through, rotated_at);
  }
  resignatures() {
    return this.db.prepare("select * from resignatures order by generation, rowid").all().map((r) => ({ digest: String(r.digest), participant_id: String(r.participant_id), generation: Number(r.generation), envelope: bytes2(r.envelope) }));
  }
  insertResignature(digest, participant_id, generation, envelope) {
    this.db.prepare("insert into resignatures (digest, participant_id, generation, envelope) values (?, ?, ?, ?)").run(digest, participant_id, generation, envelope);
  }
  /** (draft 11) reviews made here or received (spec §7.5), oldest first; `file` is the review file, for this workspace's Runs */
  reviews() {
    return this.db.prepare("select * from reviews order by rowid").all().map((r) => ({
      digest: String(r.digest),
      workspace_id: String(r.workspace_id),
      run_id: String(r.run_id),
      participant_id: String(r.participant_id),
      verdict: String(r.verdict),
      previous: r.previous === null ? null : String(r.previous),
      envelope: new Uint8Array(r.envelope),
      ...r.file !== null ? { file: new Uint8Array(r.file) } : {},
      reviewed_at: String(r.reviewed_at)
    }));
  }
  insertReview(r) {
    this.db.prepare("insert into reviews (digest, workspace_id, run_id, participant_id, verdict, previous, envelope, file, reviewed_at) values (?, ?, ?, ?, ?, ?, ?, ?, ?)").run(r.digest, r.workspace_id, r.run_id, r.participant_id, r.verdict, r.previous, r.envelope, r.file ?? null, r.reviewed_at);
  }
  /** (draft 11) further signatures on a Procedure, one per party, in signing order (spec §4.1) */
  cosignatures(digest) {
    return this.db.prepare("select * from cosignatures where digest = ? order by rowid").all(digest).map((r) => ({ participant_id: String(r.participant_id), sig: new Uint8Array(r.sig), signed_at: String(r.signed_at) }));
  }
  insertCosignature(digest, participant_id, sig, signed_at) {
    this.db.prepare("insert into cosignatures (digest, participant_id, sig, signed_at) values (?, ?, ?, ?)").run(digest, participant_id, sig, signed_at);
  }
  revocations() {
    return this.db.prepare("select * from revocations order by rowid").all().map((r) => ({ key_id: String(r.key_id), as_of: Number(r.as_of), reason: String(r.reason), revoked_at: String(r.revoked_at) }));
  }
  insertRevocation(key_id, as_of, reason, revoked_at) {
    this.db.prepare("insert into revocations (key_id, as_of, reason, revoked_at) values (?, ?, ?, ?)").run(key_id, as_of, reason, revoked_at);
  }
  journal() {
    return this.db.prepare("select * from journal order by seq").all().map((r) => ({ seq: Number(r.seq), digest: String(r.digest), kind: String(r.kind), envelope: bytes2(r.envelope) }));
  }
  journalTail() {
    const r = this.db.prepare("select seq, digest from journal order by seq desc limit 1").get();
    return r ? { seq: Number(r.seq), digest: String(r.digest) } : void 0;
  }
  appendJournal(seq, digest, kind, envelope) {
    this.db.prepare("insert into journal (seq, digest, kind, envelope) values (?, ?, ?, ?)").run(seq, digest, kind, envelope);
  }
  /** The register issued last, which the next one extends. */
  lastRegister() {
    const r = this.db.prepare("select digest, through, bytes, issued_at from registers order by rowid desc limit 1").get();
    return r ? { digest: String(r.digest), through: Number(r.through), bytes: bytes2(r.bytes), issued_at: String(r.issued_at) } : void 0;
  }
};
function procRow(r) {
  return {
    digest: String(r.digest),
    procedure_id: String(r.procedure_id),
    version: String(r.version),
    author: String(r.author),
    envelope: bytes2(r.envelope),
    added_at: String(r.added_at)
  };
}
function runRow(r) {
  return {
    run_id: String(r.run_id),
    sequence: Number(r.sequence),
    procedure_digest: String(r.procedure_digest),
    enrollments: JSON.parse(String(r.enrollments)),
    created_at: String(r.created_at)
  };
}

// src/work.ts
function availableWork(procedure, view, enr) {
  if (!view.started || view.closed || enr.status !== "active") return [];
  const out = [];
  const has = (g) => enr.grants.includes(g);
  const anyRole = (roles) => roles.some((r) => enr.roles.includes(r));
  for (const sv of view.steps) {
    if (sv.state !== "open") continue;
    const def = procedure.steps.find((s) => s.step_id === sv.step_id);
    const performer = def.performers.some((p) => p.kind === enr.kind && (p.role === null || enr.roles.includes(p.role)));
    if (def.proposals && def.actions && has("operate") && def.proposals.allowed_kinds.includes(enr.kind)) {
      const bounds = def.proposals.bound_ids.map((id) => procedure.bounds.find((b) => b.bound_id === id));
      out.push({ type: "propose", step_id: def.step_id, action_types: def.actions.types, bounds, fallback_roles: def.proposals.fallback_roles });
    }
    if (performer && has("observe") && def.evidence.length > 0) {
      out.push({
        type: "observe",
        step_id: def.step_id,
        // A derived criterion is computed by its sealed policy, never submitted (Appendix L).
        criteria: def.evidence.flatMap((c) => c.type === "derived" ? [] : [c]).map((c) => {
          const cv = sv.criteria.find((x) => x.criterion_id === c.criterion_id);
          return c.type === "measurement" ? { criterion_id: c.criterion_id, type: c.type, result: cv.result, readings: cv.readings, quantity: c.quantity, unit: c.unit, tolerance: c.tolerance, consecutive: c.consecutive, max_observations: c.max_observations } : c.type === "artifact" ? { criterion_id: c.criterion_id, type: c.type, result: cv.result, readings: cv.readings, media_types: c.media_types } : { criterion_id: c.criterion_id, type: c.type, result: cv.result, readings: cv.readings, statement: c.statement, roles: c.roles };
        })
      });
    } else if (performer && has("observe") && def.actions) {
      out.push({ type: "observe", step_id: def.step_id, criteria: [] });
    }
    if (performer && has("act") && def.actions) {
      if (def.actions.requires_authorization) {
        for (const p of sv.proposals) {
          if (p.status !== "allowed" || p.used_by || !p.authorization) continue;
          const byBound = p.rulings.find((r) => r.basis === "bound" && r.result === "allow");
          if (byBound && countExhausted(procedure, byBound.bounds ?? [], p.action.type, view)) continue;
          out.push({ type: "act", step_id: def.step_id, action: p.action, authorization: p.authorization, proposal: p.digest });
        }
      } else {
        out.push({ type: "act", step_id: def.step_id, action_types: def.actions.types });
      }
    }
    if (enr.kind === "human" && has("authorize") && def.proposals && anyRole(def.proposals.fallback_roles)) {
      for (const p of sv.proposals) {
        if (p.status === "allowed" || p.rulings.some((r) => r.basis === "human") || p.proposer === enr.participant_id) continue;
        const bound = p.rulings.find((r) => r.basis === "bound");
        out.push({ type: "authorize", step_id: def.step_id, proposal: p.digest, proposer: p.proposer, action: p.action, ...bound ? { bound_ruling: bound.result } : {} });
      }
    }
    if (enr.kind === "human" && has("decide")) {
      for (const d of def.decisions) {
        const dv = sv.decisions.find((x) => x.decision_id === d.decision_id);
        if (dv.satisfied || !anyRole(d.decider_roles)) continue;
        out.push({ type: "decide", step_id: def.step_id, decision_id: d.decision_id, types: d.types, required: d.required });
      }
    }
  }
  return out;
}
function countExhausted(procedure, boundIds, actionType, view) {
  const used = view.success_counts[actionType] ?? 0;
  return boundIds.map((id) => procedure.bounds.find((b) => b.bound_id === id)).some((b) => b.action_type === actionType && b.max_count_per_run !== void 0 && used >= b.max_count_per_run);
}

// src/workspace.ts
var systemClock = () => (/* @__PURE__ */ new Date()).toISOString();
var ID = (v, what) => {
  try {
    return new Reader2(3, what).id(v);
  } catch (e) {
    throw invalid(e.message);
  }
};
var Workspace = class _Workspace {
  workspace_id;
  display_name;
  /** the workspace key in use, as a Signer: the KeyStore holds its private half */
  key;
  /** which of the workspace's keys is in use: 1 for the first, one more at each rotation (spec §5) */
  generation;
  custody;
  store;
  clock;
  maxBlobBytes;
  runLimits;
  readerPath;
  /** the archive folder, if any */
  archive;
  enrollments = /* @__PURE__ */ new Map();
  /**
   * Every enrollment version ever signed here, by digest. A re-signature after a rotation has the same digest
   * (the digest is of the statement, not the signature), so each digest holds one version per workspace key:
   * a Run takes the one signed by the key of its era.
   */
  history = /* @__PURE__ */ new Map();
  version(digest, keyId) {
    return this.history.get(digest)?.find((v) => parseAttestation(v.row.envelope).keyid === keyId);
  }
  remember(v) {
    this.history.set(v.row.digest, [...this.history.get(v.row.digest) ?? [], v]);
  }
  sessions = /* @__PURE__ */ new Map();
  listeners = /* @__PURE__ */ new Set();
  presenceListeners = /* @__PURE__ */ new Set();
  queues = /* @__PURE__ */ new Map();
  /** journal entries prepared for a Participant to sign, by their attestation digest */
  pendingJournal = /* @__PURE__ */ new Map();
  constructor(store, custody, key, generation, opts) {
    this.store = store;
    this.custody = custody;
    this.key = key;
    this.generation = generation;
    this.workspace_id = store.meta("workspace_id");
    this.display_name = store.meta("display_name");
    this.clock = opts.clock ?? systemClock;
    this.maxBlobBytes = opts.maxBlobBytes ?? 32 * 1024 * 1024;
    this.runLimits = opts.runLimits ?? {};
    this.readerPath = opts.reader;
    this.archive = opts.archive === false ? void 0 : opts.archive ?? (opts.dir ? join4(opts.dir, "Archive") : void 0);
    const keys = custody.store;
    const prior = keys.onPrompt;
    keys.onPrompt = (p) => {
      prior?.(p);
      for (const l of this.presenceListeners) l(p);
    };
    this.loadEnrollments();
  }
  /** The workspace's keys, oldest first: generation 1 in meta, the later ones made in advance (spec §5). */
  keyring() {
    return [
      { generation: 1, key_id: this.store.meta("key_id"), public_key: this.store.meta("public_key") },
      ...this.store.workspaceKeys().map((k) => ({ ...k, key_id: k.key_id }))
    ];
  }
  /** Keys retired by rotation, oldest first, each with the last Run number it may have sealed. */
  formerKeys() {
    const ring = this.keyring();
    return this.store.rotations().map((r) => {
      const k = ring.find((x) => x.generation === r.generation - 1);
      return { key_id: k.key_id, public_key: k.public_key, through: r.through };
    });
  }
  /** Every key this workspace has signed with, the one in use first: what its own Records may be pinned to. */
  keyIds() {
    return [this.key.keyId, ...this.formerKeys().map((f) => f.key_id)];
  }
  /** The key committed to take over from the one in use. */
  successor() {
    const k = this.keyring().find((x) => x.generation === this.generation + 1);
    return k ? { key_id: k.key_id, public_key: k.public_key } : void 0;
  }
  /**
   * Every stored enrollment version, re-checked against the workspace key that signed it, so an edited store is
   * refused; the current version of each must be signed by the key in use.
   */
  loadEnrollments() {
    this.enrollments.clear();
    this.history.clear();
    const ring = new Map(this.keyring().filter((k) => k.generation <= this.generation).map((k) => [k.key_id, b64urlDecode(k.public_key)]));
    const resigned = this.store.resignatures().filter((r) => r.generation <= this.generation);
    for (const row of this.store.enrollments()) {
      let current = { row, enrollment: this.checkEnrollment(row, ring) };
      this.remember(current);
      for (const r of resigned.filter((x) => x.participant_id === row.participant_id)) {
        const v = { ...row, digest: r.digest, envelope: r.envelope };
        current = { row: v, enrollment: this.checkEnrollment(v, ring) };
        this.remember(current);
      }
      if (parseAttestation(current.row.envelope).keyid !== this.key.keyId) throw new Error(`stored enrollment ${row.participant_id} failed its integrity check: not signed by the workspace key in use`);
      this.enrollments.set(row.participant_id, current);
    }
  }
  checkEnrollment(row, ring) {
    const fail3 = (why) => {
      throw new Error(`stored enrollment ${row.participant_id} failed its integrity check: ${why}`);
    };
    let att;
    try {
      att = parseAttestation(row.envelope);
    } catch (e2) {
      return fail3(e2.message);
    }
    const signer = ring.get(att.keyid);
    if (att.predicateType !== "enrollment" || !signer || !verifySignature(att, signer)) fail3("not signed by a workspace key");
    if (att.digest !== row.digest) fail3("digest differs");
    const e = parseEnrollment(att.statement.predicate);
    if (e.participant_id !== row.participant_id || e.key_id !== row.key_id || e.workspace_id !== this.workspace_id) fail3("content differs from its row");
    if (keyIdOf(b64urlDecode(e.public_key)) !== e.key_id) fail3("key_id does not match the key");
    return e;
  }
  static path(dir) {
    return join4(dir, "workspace.sqlite");
  }
  /** Create a workspace and its key. The key goes into the KeyStore, never a file. */
  static async create(opts) {
    ID(opts.workspace_id, "workspace_id");
    if (!opts.display_name.trim()) throw invalid("display_name must not be empty");
    let path = ":memory:";
    if (opts.dir) {
      path = _Workspace.path(opts.dir);
      if (existsSync4(path)) throw new KernelError(409, "conflict", `a workspace already exists at ${opts.dir}`);
    }
    const custody = new Custody(opts.keys, opts.workspace_id);
    if (await custody.hasWorkspaceKey()) {
      throw new KernelError(409, "conflict", `a key for workspace ${opts.workspace_id} already exists in the ${opts.keys.backend} key store; choose another workspace id`);
    }
    const key = await custody.createWorkspaceKey();
    let store;
    let next;
    try {
      if (opts.dir) mkdirSync3(opts.dir, { recursive: true, mode: 448 });
      store = Store.open(path);
      const now = (opts.clock ?? systemClock)();
      if (await custody.hasWorkspaceKey(2)) await custody.discardWorkspaceKey(2);
      next = await custody.createWorkspaceKey(2);
      const st = store;
      const succ = next;
      st.transaction(() => {
        st.setMeta("workspace_id", opts.workspace_id);
        st.setMeta("display_name", opts.display_name);
        st.setMeta("key_id", key.keyId);
        st.setMeta("public_key", key.publicKeyB64u);
        st.setMeta("key_store", opts.keys.backend === "development" ? "development" : "protected");
        st.setMeta("created_at", now);
        st.insertWorkspaceKey(2, succ.keyId, succ.publicKeyB64u, now);
      });
      const ws = new _Workspace(st, custody, key, 1, opts);
      await ws.journalNow("WorkspaceCreated", [], { note: `workspace ${opts.workspace_id} created` });
      return ws;
    } catch (e) {
      try {
        store?.close();
      } catch {
      }
      await custody.discardWorkspaceKey().catch(() => void 0);
      if (next) await custody.discardWorkspaceKey(2).catch(() => void 0);
      if (opts.dir) {
        for (const f of [path, `${path}-wal`, `${path}-shm`, `${path}-journal`]) {
          try {
            rmSync3(f, { force: true });
          } catch {
          }
        }
      }
      throw e;
    }
  }
  /** Open an existing workspace; its key must be in the KeyStore. */
  static async open(opts) {
    const path = _Workspace.path(opts.dir);
    if (!existsSync4(path)) throw notFound(`no workspace at ${opts.dir}`);
    const store = Store.open(path);
    try {
      const workspace_id = store.meta("workspace_id");
      const publicKey = store.meta("public_key");
      if (!workspace_id || !publicKey) throw new Error(`${path} is not an initialized workspace`);
      const made = store.meta("key_store");
      const dev = opts.keys.backend === "development";
      if (made === "development" && !dev) throw new Error(`${workspace_id} was made with development keys; open it with development keys (--dev-keys), or make a new workspace for Records anyone relies on`);
      if (made !== "development" && dev) throw new Error(`${workspace_id} keeps its keys behind the presence check; it cannot be opened with development keys`);
      const custody = new Custody(opts.keys, workspace_id);
      const generation = 1 + store.rotations().length;
      const row = generation === 1 ? { key_id: store.meta("key_id"), public_key: publicKey } : store.workspaceKeys().find((k) => k.generation === generation);
      if (!row || store.rotations().some((r, i) => r.generation !== i + 2)) throw new Error(`workspace ${workspace_id} has an inconsistent key record`);
      if (!await custody.hasWorkspaceKey(generation)) throw new Error(`the key for workspace ${workspace_id} is not in the ${opts.keys.backend} key store`);
      const key = custody.workspaceSigner(b64urlDecode(row.public_key), generation);
      if (key.keyId !== row.key_id) throw new Error(`workspace ${workspace_id} has an inconsistent key record`);
      await custody.unlockWorkspaceKey(generation);
      const probe = new Uint8Array(randomBytes3(32));
      const sig = await key.sign(probe);
      if (!ed25519Verify(key.publicKey, probe, sig)) throw new Error(`the ${opts.keys.backend} key for ${workspace_id} does not match this workspace`);
      for (let g = 1; g < generation; g++) if (await custody.hasWorkspaceKey(g)) await custody.discardWorkspaceKey(g);
      return new _Workspace(store, custody, key, generation, opts);
    } catch (e) {
      store.close();
      opts.keys.lock?.();
      throw e;
    }
  }
  /**
   * Run `fn` after every earlier call queued under `key` has finished. Each
   * Run has its own queue, so a slow signature (for example, waiting for a
   * person's presence check) holds up only that Run.
   */
  async exclusive(key, fn) {
    const prior = this.queues.get(key) ?? Promise.resolve();
    let release;
    const mine = new Promise((r) => release = r);
    const tail = prior.then(() => mine);
    this.queues.set(key, tail);
    await prior;
    try {
      return await fn();
    } finally {
      release();
      if (this.queues.get(key) === tail) this.queues.delete(key);
    }
  }
  close() {
    this.listeners.clear();
    this.sessions.clear();
    this.store.close();
    this.custody.store.lock?.();
  }
  on(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
  /** Listen for presence prompts: the description and code the person is shown, as they are asked. */
  onPresence(listener) {
    this.presenceListeners.add(listener);
    return () => this.presenceListeners.delete(listener);
  }
  /** Open the workspace key again after the presence helper ended (asks the person). */
  unlock() {
    return this.exclusive("workspace", () => this.custody.unlockWorkspaceKey(this.generation));
  }
  summary() {
    return {
      workspace_id: this.workspace_id,
      display_name: this.display_name,
      key_id: this.key.keyId,
      public_key: this.key.publicKeyB64u,
      key_store: this.custody.store.backend,
      generation: this.generation,
      successor: this.successor()?.key_id ?? null,
      former_keys: this.formerKeys().map((f) => ({ key_id: f.key_id, through: f.through }))
    };
  }
  // ------------------------------------------------------------ Participants
  /**
   * Enroll a Participant (spec §5). Agents and Systems bring their own public
   * key; a Human without one becomes custodial: the kernel creates the key
   * in the KeyStore and signs for them when they act through the app.
   * Enrollments are permanent in v0.1; retire one to keep it out of new Runs.
   */
  enroll(spec) {
    return this.exclusive("workspace", () => this.enrollNow(spec));
  }
  async enrollNow(spec) {
    const id = ID(spec.participant_id, "participant_id");
    if (this.enrollments.has(id)) throw new KernelError(409, "conflict", `${id} is already enrolled; enrollments are permanent in v0.1, so use a new id`);
    const draft = (public_key, key_id) => ({
      workspace_id: this.workspace_id,
      participant_id: id,
      display_name: spec.display_name,
      kind: spec.kind,
      public_key,
      key_id,
      grants: spec.grants,
      roles: spec.roles,
      status: "active",
      ...spec.granted_by !== void 0 ? { granted_by: spec.granted_by } : {},
      ...spec.party !== void 0 ? { party: spec.party } : {}
    });
    try {
      parseEnrollment(draft(this.key.publicKeyB64u, this.key.keyId));
    } catch (e) {
      throw invalid(e.message);
    }
    let pub;
    let custodial = false;
    const presence = this.custody.store.presence;
    if (spec.kind === "human" && spec.public_key !== void 0 && presence !== void 0 && spec.party === void 0) {
      throw invalid(`a Human's key is created on this machine, where every signature asks the person (${presence}); enroll ${id} without a public_key, or with the party they sign for if their own organization's app holds it`);
    }
    if (spec.public_key === void 0) {
      if (spec.kind !== "human") throw invalid("Agents and Systems hold their own keys: pass the public_key their SDK generated");
      if (await this.custody.hasParticipantKey(id)) throw new KernelError(409, "conflict", `a key for ${id} already exists in the key store`);
      pub = (await this.custody.createParticipantKey(id)).publicKey;
      custodial = true;
    } else {
      try {
        pub = b64urlDecode(spec.public_key);
      } catch {
        throw invalid("public_key must be base64url without padding");
      }
      if (!isStrictPublicKey(pub)) throw invalid("public_key is not a strict Ed25519 public key");
    }
    try {
      const key_id = keyIdOf(pub);
      if (this.keyring().some((k) => k.key_id === key_id) || [...this.enrollments.values()].some((e) => e.enrollment.key_id === key_id)) {
        throw new KernelError(409, "conflict", "this public key is already enrolled");
      }
      const body = draft(b64urlEncode(pub), key_id);
      const enrollment = parseEnrollment(body);
      const att = await signStatementWith(makeStatement("enrollment", `runrec:participant:${id}`, key_id, body), this.key);
      const row = { participant_id: id, digest: att.digest, key_id, custodial, envelope: att.bytes, enrolled_at: this.clock() };
      this.store.insertEnrollment(row);
      this.enrollments.set(id, { row, enrollment });
      this.remember({ row, enrollment });
      await this.journalNow("ParticipantEnrolled", [att.digest], { note: `${id}, ${spec.kind}, grants ${spec.grants.join(" ") || "none"}` });
    } catch (e) {
      if (custodial) await this.custody.discardParticipantKey(id).catch(() => void 0);
      throw e;
    }
    return this.participant(id);
  }
  /** Keep a Participant out of Runs started from now on. Revoke (below) when its key can no longer be trusted. */
  retire(participant_id, reason) {
    return this.exclusive("workspace", async () => {
      const e = this.enrollments.get(participant_id);
      if (!e) throw notFound(`${participant_id} is not enrolled`);
      if (this.store.retired().has(participant_id)) throw new KernelError(409, "conflict", `${participant_id} is already retired`);
      if (!reason.trim()) throw invalid("give a reason");
      this.store.retire(participant_id, this.clock(), reason);
      await this.journalNow("ParticipantRetired", [e.row.digest], { note: reason });
      return this.participant(participant_id);
    });
  }
  participant(participant_id) {
    const e = this.enrollments.get(participant_id);
    if (!e) throw notFound(`${participant_id} is not enrolled`);
    const retired = this.store.retired().get(participant_id);
    const en = e.enrollment;
    const revoked = this.store.revocations().find((r) => r.key_id === en.key_id);
    return {
      participant_id: en.participant_id,
      display_name: en.display_name,
      kind: en.kind,
      grants: en.grants,
      roles: en.roles,
      ...en.party !== void 0 ? { party: en.party } : {},
      key_id: en.key_id,
      public_key: en.public_key,
      custodial: e.row.custodial,
      enrolled_at: e.row.enrolled_at,
      ...retired ? { retired } : {},
      ...revoked ? { revoked: { as_of: revoked.as_of, reason: revoked.reason } } : {}
    };
  }
  participants() {
    return [...this.enrollments.keys()].map((id) => this.participant(id));
  }
  // ------------------------------------------------------------ Procedures
  /**
   * Store a Procedure signed by a custodial Human author. (draft 11) With parties, the author signs for their own
   * party and the version waits for the others (signProcedure, importProcedure); a new version of a stored
   * Procedure names the one it replaces and says what changed (spec §4, §4.1).
   */
  addProcedure(procedure, author) {
    return this.exclusive("workspace", () => this.addProcedureNow(procedure, author));
  }
  async addProcedureNow(procedure, author) {
    const parsed = this.parseProcedure(procedure);
    const a = this.enrollments.get(author);
    this.checkAuthor(a, author, parsed);
    if (!a.row.custodial) throw forbidden(`${author} holds their own key: sign the Procedure and import it`);
    const digest = digestOf(canonicalBytes(procedure));
    const prior = this.sameVersion(parsed, digest);
    if (prior) return parsed.parties && !this.signersOf(prior).includes(author) ? this.signProcedureNow(digest, author) : this.info(prior);
    this.checkSupersedes(parsed);
    const signer = this.custody.participantSigner(author, b64urlDecode(a.enrollment.public_key));
    const att = await signStatementWith(makeStatement("procedure", `runrec:procedure:${parsed.procedure_id}@${parsed.version}`, digest, procedure), signer);
    return this.storeProcedure(parsed, digest, author, att.bytes, []);
  }
  /** (draft 11) A custodial author signs a stored Procedure for their party (spec §4.1). */
  signProcedure(digest, participant_id) {
    return this.exclusive("workspace", () => this.signProcedureNow(digest, participant_id));
  }
  async signProcedureNow(digest, participant_id) {
    const row = this.store.procedure(digest);
    if (!row) throw notFound(`no Procedure ${digest}`);
    const att = parseAttestation(row.envelope);
    const p = parseProcedure(att.statement.predicate);
    const a = this.enrollments.get(participant_id);
    this.checkAuthor(a, participant_id, p);
    if (!p.parties) throw new KernelError(409, "conflict", `${p.procedure_id} ${p.version} names no parties: its one author has signed it`);
    if (!a.row.custodial) throw forbidden(`${participant_id} holds their own key: sign the Procedure and import it`);
    this.checkPartyOpen(row, a.enrollment);
    const sig = await this.custody.participantSigner(participant_id, b64urlDecode(a.enrollment.public_key)).sign(pae(PAYLOAD_TYPE, att.payload));
    if (!verifySignature(att, b64urlDecode(a.enrollment.public_key), sig)) throw new Error(`the key of ${participant_id} produced a signature that does not verify`);
    return this.addSignatures(row, p, [{ participant_id, sig }]);
  }
  /** (draft 11) Sign a Procedure from another workspace as this machine's person, without storing it here, for its issuer to import. */
  cosignForeign(envelope, participant_id) {
    return this.exclusive("workspace", async () => {
      let att;
      try {
        att = parseAttestation(envelope, "procedure");
      } catch (e) {
        throw invalid(`envelope: ${e.message}`);
      }
      const p = this.parseProcedure(att.statement.predicate, false);
      const a = this.enrollments.get(participant_id);
      if (!a?.row.custodial) throw forbidden(`${participant_id} has no key on this machine`);
      if (!p.parties || !a.enrollment.party || !p.parties.some((x) => x.party_id === a.enrollment.party)) throw forbidden(`${participant_id} signs for no party this Procedure names`);
      const signer = this.custody.participantSigner(participant_id, b64urlDecode(a.enrollment.public_key));
      if (att.signatures.some((x) => x.keyid === signer.keyId)) throw new KernelError(409, "conflict", `${participant_id} has already signed it`);
      return (await cosignWith({ envelope: att.envelope, bytes: envelope, digest: att.digest, statement: att.statement }, signer)).bytes;
    });
  }
  /** Store a Procedure, or more signatures on one, signed elsewhere (a DSSE envelope, spec §4, §4.1). */
  importProcedure(envelope) {
    return this.exclusive("workspace", () => this.importProcedureNow(envelope));
  }
  async importProcedureNow(envelope) {
    let att;
    try {
      att = parseAttestation(envelope);
    } catch (e) {
      throw invalid(`envelope: ${e.message}`);
    }
    if (att.predicateType !== "procedure") throw invalid("envelope does not carry a Procedure");
    const parsed = this.parseProcedure(att.statement.predicate);
    const digest = digestOf(canonicalBytes(att.statement.predicate));
    const sub = att.statement.subject[0];
    if (sub.name !== `runrec:procedure:${parsed.procedure_id}@${parsed.version}` || `sha256:${sub.digest.sha256}` !== digest) throw invalid("Procedure subject does not match its content");
    if (!parsed.parties && att.signatures.length !== 1) throw invalid("a Procedure without parties carries exactly one signature");
    const signed = [];
    for (const sg of att.signatures) {
      const found = [...this.enrollments.values()].find((e) => e.enrollment.key_id === sg.keyid);
      this.checkAuthor(found, sg.keyid, parsed);
      if (!verifySignature(att, b64urlDecode(found.enrollment.public_key), sg.sig)) throw new KernelError(403, "signature", `the signature by ${found.enrollment.participant_id} does not verify`);
      if (signed.some((x) => this.enrollments.get(x.participant_id).enrollment.party === found.enrollment.party && parsed.parties)) throw invalid(`two signatures for party ${found.enrollment.party}`);
      signed.push({ participant_id: found.enrollment.participant_id, sig: sg.sig });
    }
    const prior = this.sameVersion(parsed, digest);
    if (prior) {
      const have = this.signersOf(prior);
      const fresh = signed.filter((x) => !have.includes(x.participant_id));
      for (const x of fresh) this.checkPartyOpen(prior, this.enrollments.get(x.participant_id).enrollment);
      return fresh.length ? this.addSignatures(prior, parsed, fresh) : this.info(prior);
    }
    this.checkSupersedes(parsed);
    const first = { ...att.envelope, signatures: [att.envelope.signatures[0]] };
    return this.storeProcedure(parsed, digest, signed[0].participant_id, canonicalBytes(first), signed.slice(1));
  }
  parseProcedure(v, policies = true) {
    let p;
    try {
      p = parseProcedure(v);
    } catch (e) {
      throw invalid(e.message);
    }
    for (const a of policies ? policiesOf(p) : []) {
      const b = this.store.blob(a.digest);
      if (!b || b.bytes.length !== a.size) throw invalid(`upload the sealed policy ${a.digest} (${a.size} bytes) before the Procedure that cites it`);
      try {
        decodePolicy(b.bytes);
      } catch (e) {
        throw invalid(`the sealed policy ${a.digest} is outside the profile: ${e.message}`);
      }
    }
    return p;
  }
  checkAuthor(a, who, p) {
    if (!a) throw forbidden(`${who} is not an enrolled Participant`);
    const en = a.enrollment;
    if (en.kind !== "human" || !en.grants.includes("author")) throw forbidden(`${en.participant_id} is not a Human holding the author grant`);
    if (this.store.retired().has(en.participant_id)) throw forbidden(`${en.participant_id} is retired`);
    if (this.store.revocations().some((r) => r.key_id === en.key_id)) throw forbidden(`${en.participant_id}'s key is revoked`);
    if (p?.parties && !p.parties.some((x) => x.party_id === en.party)) throw forbidden(`${en.participant_id} signs for no party this Procedure names (${p.parties.map((x) => x.party_id).join(", ")})`);
  }
  /** (draft 11) A party signs once. */
  checkPartyOpen(row, en) {
    if (this.signersOf(row).some((id) => this.enrollments.get(id)?.enrollment.party === en.party)) throw new KernelError(409, "conflict", `party ${en.party} has already signed ${row.procedure_id} ${row.version}`);
  }
  /**
   * (draft 11) A lineage is a chain: once a version of a Procedure is stored, the next names it in `supersedes`,
   * by version and digest, with a note of what changed, and no two versions replace the same one.
   */
  checkSupersedes(p) {
    const lineage = this.store.procedures().filter((r) => r.procedure_id === p.procedure_id);
    if (!lineage.length) return;
    const replaced = new Set(lineage.flatMap((r) => this.predicateOf(r).supersedes?.digest ?? []));
    const tip = lineage.filter((r) => !replaced.has(r.digest)).at(-1);
    if (!p.supersedes) throw invalid(`${p.procedure_id} ${tip?.version ?? lineage.at(-1).version} is already here: a new version names it in supersedes and says what changed in change`);
    const prior = this.store.procedure(p.supersedes.digest);
    if (!prior || prior.procedure_id !== p.procedure_id || prior.version !== p.supersedes.version) throw invalid(`supersedes names ${p.supersedes.procedure_id} ${p.supersedes.version} ${p.supersedes.digest}, which is not stored here`);
    if (replaced.has(prior.digest)) throw new KernelError(409, "conflict", `${p.procedure_id} ${prior.version} has already been replaced${tip ? `; the latest is ${tip.version}` : ""}`);
  }
  sameVersion(p, digest) {
    const prior = this.store.procedureByVersion(p.procedure_id, p.version);
    if (!prior) return void 0;
    if (prior.digest !== digest) throw new KernelError(409, "conflict", `a different ${p.procedure_id} ${p.version} is already stored; change the version`);
    return prior;
  }
  async storeProcedure(p, digest, author, envelope, more) {
    const row = { digest, procedure_id: p.procedure_id, version: p.version, author, envelope, added_at: this.clock() };
    this.store.transaction(() => {
      this.store.insertProcedure(row);
      for (const x of more) this.store.insertCosignature(digest, x.participant_id, x.sig, row.added_at);
    });
    await this.journalAgreement(row, p);
    return this.info(row);
  }
  async addSignatures(row, p, more) {
    const at = this.clock();
    this.store.transaction(() => {
      for (const x of more) this.store.insertCosignature(row.digest, x.participant_id, x.sig, at);
    });
    await this.journalAgreement(row, p);
    return this.info(row);
  }
  /** ProcedureAgreed once every party has signed (or the one author); ProcedureDrafted while some have not. */
  async journalAgreement(row, p) {
    const ag = this.agreement(row, p);
    const by = ag.parties ? ag.parties.filter((x) => x.signed_by).map((x) => `${x.signed_by} for ${x.party_id}`).join(", ") : row.author;
    const waiting = ag.parties?.filter((x) => !x.signed_by).map((x) => x.party_id) ?? [];
    await this.journalNow(ag.agreed ? "ProcedureAgreed" : "ProcedureDrafted", [row.digest], { note: `${p.procedure_id} ${p.version}, signed by ${by}${waiting.length ? `; waiting for ${waiting.join(", ")}` : ""}` });
  }
  signersOf(row) {
    return [row.author, ...this.store.cosignatures(row.digest).map((c) => c.participant_id)];
  }
  predicateOf(row) {
    return parseProcedure(parseAttestation(row.envelope).statement.predicate);
  }
  /** (draft 11) Who has signed for each party, and whether the version is agreed (spec §4.1). */
  agreement(row, p = this.predicateOf(row)) {
    if (!p.parties) return { agreed: true };
    const signers = this.signersOf(row);
    const parties = p.parties.map((x) => {
      const by = signers.find((id) => this.enrollments.get(id)?.enrollment.party === x.party_id);
      return { party_id: x.party_id, display_name: x.display_name, ...by ? { signed_by: by } : {} };
    });
    return { agreed: parties.every((x) => x.signed_by), parties };
  }
  /** The envelope with every signature gathered so far, in signing order: what a Record carries (spec §3). */
  envelopeOf(row) {
    const cos = this.store.cosignatures(row.digest);
    if (!cos.length) return row.envelope;
    const env = parseAttestation(row.envelope).envelope;
    const signatures = [...env.signatures, ...cos.map((c) => ({ keyid: this.enrollments.get(c.participant_id).enrollment.key_id, sig: b64Encode(c.sig) }))];
    return canonicalBytes({ ...env, signatures });
  }
  info(r) {
    const p = this.predicateOf(r);
    const ag = this.agreement(r, p);
    return {
      procedure_id: r.procedure_id,
      version: r.version,
      title: p.title,
      digest: r.digest,
      author: r.author,
      added_at: r.added_at,
      agreed: ag.agreed,
      ...ag.parties ? { parties: ag.parties } : {},
      ...p.supersedes ? { supersedes: { version: p.supersedes.version, digest: p.supersedes.digest } } : {},
      ...p.change ? { change: p.change.summary } : {}
    };
  }
  procedures() {
    return this.store.procedures().map((r) => this.info(r));
  }
  procedure(digest) {
    const row = this.store.procedure(digest);
    if (!row) throw notFound(`no Procedure ${digest}`);
    const envelope = this.envelopeOf(row);
    return { info: this.info(row), procedure: parseAttestation(envelope).statement.predicate, envelope: parseStrict(decodeUtf8(envelope)) };
  }
  /** (draft 11) What changed from the version this one replaces, line by line in plain English. */
  procedureChanges(digest) {
    const row = this.store.procedure(digest);
    if (!row) throw notFound(`no Procedure ${digest}`);
    const p = this.predicateOf(row);
    const now = procedureToText(renderProcedure(parseAttestation(row.envelope).statement.predicate)).split("\n");
    const prior = p.supersedes ? this.store.procedure(p.supersedes.digest) : void 0;
    if (!prior) return { lines: now.map((text) => ({ op: "+", text })) };
    const before = procedureToText(renderProcedure(parseAttestation(prior.envelope).statement.predicate)).split("\n");
    return { from: { version: prior.version, digest: prior.digest }, change: p.change.summary, lines: lineDiff(before, now) };
  }
  // ------------------------------------------------------------ Runs
  /**
   * Start a Run of a stored Procedure. The Run's Participants are the
   * workspace's enrollments at this moment, minus retired ones; the Record
   * will carry exactly these.
   */
  startRun(req) {
    return this.exclusive("workspace", () => this.startRunNow(req));
  }
  async startRunNow(req, journal = true) {
    const row = this.resolveProcedure(req);
    const ag = this.agreement(row);
    if (!ag.agreed) throw new KernelError(409, "not_agreed", `${row.procedure_id} ${row.version} is not agreed yet: waiting for ${ag.parties.filter((x) => !x.signed_by).map((x) => x.display_name).join(", ")} to sign`);
    const run_id = req.run_id !== void 0 ? ID(req.run_id, "run_id") : newRunId(this.clock());
    if (this.store.run(run_id)) throw new KernelError(409, "conflict", `Run ${run_id} already exists`);
    const retired = this.store.retired();
    const snapshot = [...this.enrollments.values()].filter((e) => !retired.has(e.row.participant_id));
    for (const id of this.signersOf(row)) if (!snapshot.some((e) => e.row.participant_id === id)) throw forbidden(`${id}, who signed the Procedure, is retired`);
    if (req.started_by !== void 0 && !snapshot.some((e) => e.row.participant_id === req.started_by)) throw invalid(`started_by ${req.started_by} is not an active Participant`);
    const created_at = this.clock();
    const sequence = this.store.nextSequence();
    const session = new RunSession(this.context(run_id, sequence, row, snapshot));
    const fields = {};
    for (const k of ["title", "site", "started_by"]) if (req[k] !== void 0) fields[k] = req[k];
    if (req.inputs !== void 0) fields.inputs = this.resolveOutputInputs(this.predicateOf(row), req.inputs);
    if (req.subjects !== void 0) fields.subjects = req.subjects;
    if (req.related !== void 0) fields.related = req.related;
    try {
      await session.start(fields);
    } catch (e) {
      if (e instanceof RecordError) throw invalid(e.message);
      throw e;
    }
    this.store.transaction(() => {
      this.store.insertRun({ run_id, sequence, procedure_digest: row.digest, enrollments: snapshot.map((e) => ({ participant_id: e.row.participant_id, digest: e.row.digest })), created_at });
      this.store.appendEvents(run_id, session.entries.map(toRow));
    });
    this.sessions.set(run_id, session);
    for (const e of session.entries) this.emit(run_id, e);
    if (journal) await this.journalNow("RunStarted", [session.entries[0].digest], { note: `run ${run_id}, #${sequence}` });
    return session.state();
  }
  /**
   * (draft 11) An output input may be given as `{ run_id }` of a sealed Record here: the kernel fills in its chain head
   * and the output's digest from that Record, which must be of the Procedure the input names (spec §4.2).
   */
  resolveOutputInputs(p, inputs) {
    const out = { ...inputs };
    for (const i of p.inputs ?? []) {
      const v = inputs[i.input_id];
      if (i.kind !== "output" || !isObject(v) || Object.keys(v).join() !== "run_id") continue;
      const rec = this.store.record(String(v.run_id));
      if (!rec) throw invalid(`input ${i.input_id}: Run ${String(v.run_id)} has no sealed Record here`);
      const opened = openRecord(rec.bytes, { pin: this.keyIds() });
      const m = opened.contents?.manifest;
      if (!m || m.procedure.procedure_id !== i.from.procedure_id) throw invalid(`input ${i.input_id}: Run ${String(v.run_id)} is not a Run of ${i.from.procedure_id}`);
      const o = m.outputs?.find((x) => x.output_id === i.from.output_id);
      if (!o) throw invalid(`input ${i.input_id}: Run ${String(v.run_id)} produced no ${i.from.output_id}`);
      out[i.input_id] = { run_id: m.run_id, record: m.events.head, output_id: o.output_id, digest: o.digest };
    }
    return out;
  }
  /** The stored Procedure a request names: by digest, by id and version, or the latest version of an id. */
  procedureFor(req) {
    return this.info(this.resolveProcedure(req));
  }
  resolveProcedure(req) {
    if (req.digest) {
      const r = this.store.procedure(req.digest);
      if (!r) throw notFound(`no Procedure ${req.digest}`);
      return r;
    }
    if (!req.procedure_id) throw invalid("name a Procedure by digest or procedure_id");
    if (req.version) {
      const r = this.store.procedureByVersion(req.procedure_id, req.version);
      if (!r) throw notFound(`no Procedure ${req.procedure_id} ${req.version}`);
      return r;
    }
    const all = this.store.procedures().filter((p) => p.procedure_id === req.procedure_id);
    if (!all.length) throw notFound(`no Procedure ${req.procedure_id}`);
    return all.filter((r) => this.agreement(r).agreed).at(-1) ?? all.at(-1);
  }
  /** Re-check a stored Procedure: its digest and every signature it carries (spec §8 step 4). */
  checkProcedure(row) {
    const fail3 = (why) => {
      throw new Error(`stored Procedure ${row.procedure_id} ${row.version} failed its integrity check: ${why}`);
    };
    const att = parseAttestation(this.envelopeOf(row));
    if (att.predicateType !== "procedure") fail3("not a Procedure");
    const digest = digestOf(canonicalBytes(att.statement.predicate));
    const sub = att.statement.subject[0];
    if (digest !== row.digest || `sha256:${sub.digest.sha256}` !== digest) fail3("digest differs");
    const signers = this.signersOf(row);
    if (signers.length !== att.signatures.length) fail3("signatures differ from its rows");
    signers.forEach((id, i) => {
      const e = this.enrollments.get(id);
      const sg = att.signatures[i];
      if (!e || e.enrollment.key_id !== sg.keyid || !verifySignature(att, b64urlDecode(e.enrollment.public_key), sg.sig)) fail3(`not signed by ${id}`);
    });
    const p = parseProcedure(att.statement.predicate);
    if (p.procedure_id !== row.procedure_id || p.version !== row.version || sub.name !== `runrec:procedure:${p.procedure_id}@${p.version}`) fail3("content differs from its row");
    return p;
  }
  context(run_id, sequence, row, snapshot) {
    const participants = /* @__PURE__ */ new Map();
    for (const e of snapshot) participants.set(e.row.participant_id, { enrollment: e.enrollment, digest: e.row.digest, bytes: e.row.envelope });
    return {
      workspace: { workspace_id: this.workspace_id, display_name: this.display_name, key: this.keyForRun(sequence) },
      run_id,
      sequence,
      procedure: this.checkProcedure(row),
      procedureDigest: row.digest,
      procedureBytes: this.envelopeOf(row),
      participants,
      clock: this.clock,
      blob: (d) => this.store.blobMeta(d),
      policy: (d) => this.store.blob(d)?.bytes,
      limits: this.runLimits
    };
  }
  /** Make the key of a generation not yet on record; one left by an interrupted rotation was never used, so it goes first. */
  async freshWorkspaceKey(generation) {
    if (this.keyring().some((k) => k.generation === generation)) throw new Error(`workspace key generation ${generation} is already on record`);
    if (await this.custody.hasWorkspaceKey(generation)) await this.custody.discardWorkspaceKey(generation);
    return this.custody.createWorkspaceKey(generation);
  }
  /** The workspace key of a Run's era: a Run numbered up to a former key's through belongs to that key, read-only. */
  keyForRun(sequence) {
    const f = this.formerKeys().find((k) => sequence <= k.through);
    if (!f) return this.key;
    return signerFor(b64urlDecode(f.public_key), async () => {
      throw new KernelError(409, "conflict", `Run #${sequence} belongs to the retired workspace key ${f.key_id}: it can be read, not added to`);
    });
  }
  /** The live session for a Run, rebuilt from the store (and fully re-checked) when not cached. */
  session(run_id) {
    const hit = this.sessions.get(run_id);
    if (hit) return hit;
    const run2 = this.store.run(run_id);
    if (!run2) throw notFound(`no Run ${run_id}`);
    const row = this.store.procedure(run2.procedure_digest);
    const snapshot = run2.enrollments.map((s) => {
      const e = this.version(s.digest, this.keyForRun(run2.sequence).keyId);
      if (!e || e.row.participant_id !== s.participant_id) throw new Error(`Run ${run_id}: enrollment ${s.participant_id} is missing or changed in the store`);
      return e;
    });
    let session;
    try {
      session = RunSession.replay(this.context(run_id, run2.sequence, row, snapshot), this.store.events(run_id).map((e) => e.envelope));
    } catch (e) {
      throw new Error(`Run ${run_id} failed its integrity check on load: ${e.message}`);
    }
    this.sessions.set(run_id, session);
    return session;
  }
  /**
   * Run `fn` on a session and persist whatever it appended, in one
   * transaction, whether `fn` returned or was refused. An unexpected error
   * discards the cached session so the next call rebuilds it from the store.
   */
  mutate(run_id, fn) {
    return this.exclusive(`run:${run_id}`, () => this.mutateNow(run_id, fn));
  }
  async mutateNow(run_id, fn) {
    const s = this.session(run_id);
    const before = s.entries.length;
    let result;
    let refusal;
    try {
      result = await fn(s);
    } catch (e) {
      if (!(e instanceof KernelError)) {
        this.sessions.delete(run_id);
        throw e;
      }
      refusal = e;
    }
    const added = s.entries.slice(before);
    if (added.length) {
      try {
        this.store.transaction(() => this.store.appendEvents(run_id, added.map(toRow)));
      } catch (e) {
        this.sessions.delete(run_id);
        throw e;
      }
      for (const e of added) this.emit(run_id, e);
    }
    if (refusal) throw refusal;
    return result;
  }
  emit(run_id, e) {
    const msg = {
      run_id,
      seq: e.event.seq,
      kind: e.event.kind,
      digest: e.digest,
      actor: e.event.actor.participant_id,
      declared_time: e.event.declared_time,
      ...e.event.step_id !== void 0 ? { step_id: e.event.step_id } : {}
    };
    for (const l of this.listeners) {
      try {
        l(msg);
      } catch {
      }
    }
  }
  /** A revoked key signs nothing more here, in any Run (spec §5): what a Run holds from it predates the revocation. */
  refuseRevoked(participant_id) {
    const e = participant_id === void 0 ? void 0 : this.enrollments.get(participant_id);
    if (e && this.store.revocations().some((r) => r.key_id === e.enrollment.key_id)) throw forbidden(`${participant_id}'s key is revoked`);
  }
  prepare(run_id, participant_id, kind, fields) {
    this.refuseRevoked(participant_id);
    if (kind === "ChildStarted") this.checkChildStart(fields);
    return this.mutate(run_id, (s) => s.prepare(participant_id, kind, fields));
  }
  /**
   * (draft 11, spec §4.4) A child Run can start only under a stored, agreed version of the Procedure the parent names,
   * with an unused run_id and the inputs that Procedure declares, so a recorded ChildStarted always becomes a Run.
   */
  checkChildStart(fields) {
    const pr = fields.procedure;
    const row = typeof pr?.digest === "string" ? this.store.procedure(pr.digest) : void 0;
    if (!row || row.procedure_id !== pr.procedure_id || row.version !== pr.version) throw invalid("procedure must name a Procedure version stored here, by procedure_id, version and digest");
    if (!this.agreement(row).agreed) throw new KernelError(409, "not_agreed", `${row.procedure_id} ${row.version} is not agreed yet`);
    const id = ID(String(fields.child_run_id ?? ""), "child_run_id");
    if (this.store.run(id)) throw new KernelError(409, "conflict", `Run ${id} already exists`);
    const problem = bindingProblem(this.predicateOf(row), { ...fields.inputs !== void 0 ? { inputs: fields.inputs } : {} });
    if (problem) throw invalid(problem);
  }
  /** (draft 11) After ChildStarted, the child Run itself starts, naming its parent. */
  async startChildren(parent, entries) {
    for (const e of entries) {
      if (e.event.kind !== "ChildStarted") continue;
      const ev = e.event;
      await this.exclusive("workspace", () => this.startRunNow({
        digest: String(ev.procedure.digest),
        run_id: String(ev.child_run_id),
        started_by: ev.actor.participant_id,
        ...isObject(ev.inputs) ? { inputs: ev.inputs } : {},
        related: [{ kind: "parent", run_id: parent, step_id: ev.step_id }]
      }));
    }
  }
  async commit(run_id, envelope, onlyFor) {
    let actor;
    try {
      actor = String(parseAttestation(envelope).statement.predicate.actor.participant_id);
    } catch {
      actor = void 0;
    }
    this.refuseRevoked(actor);
    try {
      const pred = parseAttestation(envelope).statement.predicate;
      if (pred.kind === "ChildStarted") this.checkChildStart(pred);
    } catch (e) {
      if (e instanceof KernelError) throw e;
    }
    const entries = await this.mutate(run_id, (s) => s.commit(envelope, onlyFor));
    await this.startChildren(run_id, entries);
    return entries.map(viewOf);
  }
  /** Record an event for a custodial Human: the KeyStore signs it with that Human's key. */
  async submit(run_id, participant_id, kind, fields) {
    const e = this.enrollments.get(participant_id);
    if (!e) throw forbidden(`${participant_id} is not enrolled`);
    if (!e.row.custodial) throw forbidden(`${participant_id} holds their own key; prepare, sign and commit instead`);
    this.refuseRevoked(participant_id);
    const signer = this.custody.participantSigner(participant_id, b64urlDecode(e.enrollment.public_key));
    if (kind === "ChildStarted") this.checkChildStart(fields);
    const entries = await this.mutate(run_id, (s) => s.submitWith(signer, participant_id, kind, fields));
    await this.startChildren(run_id, entries);
    return entries.map(viewOf);
  }
  closeRun(run_id, closed_by) {
    return this.mutate(run_id, async (s) => {
      if (closed_by !== void 0 && !s.ctx.participants.has(closed_by)) throw invalid(`closed_by ${closed_by} is not a Participant in this Run`);
      await s.close(closed_by);
      return s.state();
    });
  }
  /**
   * Seal a closed Run into its Record. The kernel verifies the Record with
   * the reference verifier, pinned to its own key, before storing it; a
   * Record its own verifier rejects is never issued.
   */
  seal(run_id, published_by) {
    return this.exclusive(`run:${run_id}`, () => this.sealNow(run_id, published_by));
  }
  async sealNow(run_id, published_by) {
    const prior = this.store.record(run_id);
    if (prior) return { digest: prior.digest, size: prior.bytes.length, bytes: prior.bytes, sealed_at: prior.sealed_at };
    const s = this.session(run_id);
    if (published_by !== void 0 && !s.ctx.participants.has(published_by)) throw invalid(`published_by ${published_by} is not a Participant in this Run`);
    const sealed_at = this.clock();
    const input = s.sealInput((d) => this.store.blob(d)?.bytes, sealed_at, published_by);
    const manifest = await signStatementWith(manifestStatement(input), this.key);
    const bytes3 = writeZip(bundleEntries(input, manifest));
    const report = verifyRecord(bytes3, { pin: this.key.keyId });
    if (report.integrity !== "pass" || report.provenance !== "pinned") {
      throw new Error(`kernel produced a Record its verifier rejects: ${report.summary}`);
    }
    const digest = digestOf(bytes3);
    this.store.insertRecord(run_id, digest, bytes3, sealed_at);
    await this.journalNow("RecordSealed", [digest], { note: `run ${run_id}` });
    const sequence = this.store.run(run_id).sequence;
    this.archiveFile("Records", `${this.workspace_id}-${String(sequence).padStart(6, "0")}-${run_id}.runrec`, bytes3);
    const parent = (s.entries[0].event.related ?? []).find((x) => x.kind === "parent");
    if (parent && this.store.run(String(parent.run_id)) && !this.store.record(String(parent.run_id))) {
      try {
        await this.mutate(String(parent.run_id), (p) => p.childSealed(String(parent.step_id), run_id, input.events.at(-1).digest, input.closed.outcome));
      } catch (e) {
        if (!(e instanceof KernelError)) throw e;
      }
    }
    await this.register();
    return { digest, size: bytes3.length, bytes: bytes3, sealed_at };
  }
  record(run_id) {
    const r = this.store.record(run_id);
    if (!r) throw notFound(`Run ${run_id} has not been sealed`);
    return r.bytes;
  }
  /**
   * The handover pack (a plain control: no AI needed): every sealed Record, a register issued now, the journal and
   * the reviews, with the shift view, a PDF summary, a PDF per Record and CSV tables beside them, and the reader.
   */
  async pack(title) {
    const reg = await this.register();
    const journal = await this.journal();
    const records = this.store.runs().filter((r) => this.store.record(r.run_id)).map((r) => ({ name: `${this.workspace_id}-${String(r.sequence).padStart(6, "0")}-${r.run_id}.runrec`, bytes: this.store.record(r.run_id).bytes }));
    const reviews = this.store.reviews().filter((r) => r.workspace_id === this.workspace_id && r.file).map((r) => ({ name: `${r.run_id}-${r.digest.slice(7, 15)}.review.json`, bytes: r.file }));
    const readerPath = this.readerPath ?? process.env.OPSPROOF_READER;
    const reader = readerPath && existsSync4(readerPath) ? new Uint8Array(readFileSync3(readerPath)) : void 0;
    const bytes3 = buildPack({
      records,
      register: { name: `${this.workspace_id}-${String(reg.through).padStart(6, "0")}.register.json`, bytes: reg.bytes },
      journal: { name: `${this.workspace_id}-${journal.length}.journal`, bytes: journal.bytes },
      reviews,
      ...reader ? { reader } : {},
      pin: this.keyIds(),
      title: title?.trim() || `${this.display_name}: handover pack through Run ${reg.through}`
    });
    const digest = digestOf(bytes3);
    await this.journalNow("PackExported", [digest], { note: `${records.length} Records through Run ${reg.through}` });
    return { bytes: bytes3, digest, records: records.length };
  }
  // ------------------------------------------------------------ reviews (spec §7.5)
  /**
   * (draft 11) A person's signed judgment on a sealed Record of this workspace: concur, do not concur, or more
   * examination. Each reviewer's reviews of a Run chain through `previous`; the latest stands. Never blocking.
   */
  review(run_id, fields, reviewer) {
    return this.exclusive("workspace", async () => {
      const head = this.sealedHead(run_id);
      const a = this.enrollments.get(reviewer);
      this.checkReviewer(a, reviewer);
      if (!a.row.custodial) throw forbidden(`${reviewer} signs on their own machine: import their review`);
      const rv = this.reviewPredicate({ workspace_id: this.workspace_id, run_id, head }, fields, this.latestReview(this.workspace_id, run_id, reviewer));
      const att = await signStatementWith(reviewStatement(rv), this.custody.participantSigner(reviewer, b64urlDecode(a.enrollment.public_key)));
      return this.storeReview(att.bytes, rv, reviewer);
    });
  }
  /** (draft 11) A review signed elsewhere by a person enrolled here, who holds their own key (another party's inspector). */
  importReview(envelope) {
    return this.exclusive("workspace", async () => {
      let att;
      try {
        att = parseAttestation(envelope, "review");
      } catch (e) {
        throw invalid(`envelope: ${e.message}`);
      }
      let rv;
      try {
        rv = parseReview(att.statement.predicate);
      } catch (e) {
        throw invalid(e.message);
      }
      if (rv.workspace_id !== this.workspace_id) throw invalid(`the review is about a Run of ${rv.workspace_id}, not this workspace`);
      if (rv.head !== this.sealedHead(rv.run_id)) throw invalid(`the review is about another Record of ${rv.run_id}`);
      const a = [...this.enrollments.values()].find((e) => e.enrollment.key_id === att.keyid);
      this.checkReviewer(a, att.keyid);
      if (!verifySignature(att, b64urlDecode(a.enrollment.public_key))) throw new KernelError(403, "signature", "the review signature does not verify");
      const prior = this.store.reviews().find((r) => r.digest === att.digest);
      if (prior) return this.reviewInfo(prior);
      const latest = this.latestReview(this.workspace_id, rv.run_id, a.enrollment.participant_id);
      if (rv.previous !== latest) throw new KernelError(409, "conflict", latest ? `this review must name ${latest}, ${a.enrollment.participant_id}'s latest review of ${rv.run_id}, as previous` : "this review names a previous review this workspace does not hold");
      return this.storeReview(envelope, rv, a.enrollment.participant_id);
    });
  }
  /**
   * (draft 11) The person reviews another organization's Record, in which they are enrolled for their party: the
   * Record is checked, the review signed and kept here, and the envelope goes back to the issuer to import.
   */
  reviewForeign(record, fields, reviewer) {
    return this.exclusive("workspace", async () => {
      const opened = openRecord(record);
      if (opened.report.integrity !== "pass" || !opened.contents) throw invalid(`the Record does not check: ${opened.report.summary}`);
      const m = opened.contents.manifest;
      const a = this.enrollments.get(reviewer);
      if (!a?.row.custodial) throw forbidden(`${reviewer} has no key on this machine`);
      const rv = this.reviewPredicate({ workspace_id: m.workspace.workspace_id, run_id: m.run_id, head: m.events.head }, fields, this.latestReview(m.workspace.workspace_id, m.run_id, reviewer));
      const att = await signStatementWith(reviewStatement(rv), this.custody.participantSigner(reviewer, b64urlDecode(a.enrollment.public_key)));
      this.store.insertReview({ digest: att.digest, workspace_id: rv.workspace_id, run_id: rv.run_id, participant_id: reviewer, verdict: rv.verdict, previous: rv.previous, envelope: att.bytes, reviewed_at: rv.reviewed_time });
      return att.bytes;
    });
  }
  /** Every review of a Run of this workspace, oldest first. */
  reviews(run_id) {
    return this.store.reviews().filter((r) => r.workspace_id === this.workspace_id && (run_id === void 0 || r.run_id === run_id)).map((r) => this.reviewInfo(r));
  }
  /** A review file, as checked by `runrec review` (spec §8.2). */
  reviewFileOf(digest) {
    const r = this.store.reviews().find((x) => x.digest === digest && x.file);
    if (!r) throw notFound(`no review ${digest}`);
    return r.file;
  }
  /** The review that stands for each reviewer and Run: the one no later review of theirs names as previous. */
  standingReviews() {
    const all = this.reviews();
    const replaced = new Set(all.map((r) => r.previous).filter((x) => x !== null));
    return all.filter((r) => !replaced.has(r.digest)).reverse();
  }
  sealedHead(run_id) {
    const rec = this.store.record(run_id);
    if (!rec) throw new KernelError(409, "not_sealed", `Run ${run_id} has not been sealed: a review is of a sealed Record`);
    return this.store.runTail(run_id).last.digest;
  }
  checkReviewer(a, who) {
    if (!a) throw forbidden(`${who} is not an enrolled Participant`);
    const en = a.enrollment;
    if (en.kind !== "human" || !en.grants.includes("review")) throw forbidden(`${en.participant_id} is not a Human holding the review grant`);
    if (this.store.retired().has(en.participant_id)) throw forbidden(`${en.participant_id} is retired`);
    if (this.store.revocations().some((r) => r.key_id === en.key_id)) throw forbidden(`${en.participant_id}'s key is revoked`);
  }
  latestReview(workspace_id, run_id, reviewer) {
    const mine = this.store.reviews().filter((r) => r.workspace_id === workspace_id && r.run_id === run_id && r.participant_id === reviewer);
    const replaced = new Set(mine.map((r) => r.previous));
    return mine.find((r) => !replaced.has(r.digest))?.digest ?? null;
  }
  reviewPredicate(about, f, previous) {
    const raw = { ...about, verdict: f.verdict, basis: f.basis ?? [], previous, reviewed_time: this.clock(), ...f.terms !== void 0 ? { terms: f.terms } : {}, ...f.note?.trim() ? { note: f.note.trim() } : {} };
    try {
      return parseReview(raw);
    } catch (e) {
      throw invalid(e.message);
    }
  }
  async storeReview(envelope, rv, reviewer) {
    const digest = parseAttestation(envelope, "review").digest;
    const e = this.enrollments.get(reviewer);
    const file = reviewFile({ workspace_id: this.workspace_id, key_id: this.key.keyId, public_key: this.key.publicKeyB64u }, this.enrollmentFor(reviewer), envelope);
    const check5 = verifyReview(file, { pin: this.keyIds(), record: this.record(rv.run_id) });
    if (check5.integrity !== "pass") throw new Error(`the review does not check: ${check5.summary}`);
    const row = { digest, workspace_id: rv.workspace_id, run_id: rv.run_id, participant_id: e.enrollment.participant_id, verdict: rv.verdict, previous: rv.previous, envelope, file, reviewed_at: rv.reviewed_time };
    this.store.insertReview(row);
    await this.journalNow("ReviewSigned", [digest], { note: `${rv.verdict.replace(/_/g, " ")} on run ${rv.run_id} by ${reviewer}` });
    const seq = this.store.run(rv.run_id).sequence;
    this.archiveFile("Reviews", `${this.workspace_id}-${String(seq).padStart(6, "0")}-${rv.run_id}-${digest.slice(7, 15)}.review.json`, file);
    return this.reviewInfo(row);
  }
  /** The reviewer's enrollment as the current workspace key signs it, for a review file. */
  enrollmentFor(participant_id) {
    const e = this.enrollments.get(participant_id);
    return (this.version(e.row.digest, this.key.keyId) ?? e).row.envelope;
  }
  reviewInfo(r) {
    const p = parseAttestation(r.envelope, "review").statement.predicate;
    return { digest: r.digest, run_id: r.run_id, reviewer: r.participant_id, verdict: r.verdict, ...typeof p.note === "string" ? { note: p.note } : {}, reviewed_time: String(p.reviewed_time), previous: r.previous };
  }
  /**
   * (draft 11) An edition of a sealed Record for some audience: the same Record with chosen evidence files left out,
   * on the signed order of a person holding `disclose` who is in the Record (spec §7.4). The master is unchanged;
   * the journal says an edition was made, not for whom. Checked with the reference verifier before it is handed out.
   */
  edition(run_id, withheld, ordered_by) {
    return this.exclusive(`run:${run_id}`, async () => {
      const master = this.record(run_id);
      const opened = openRecord(master, { pin: this.keyIds() });
      if (opened.report.integrity !== "pass" || !opened.contents) throw new Error(`the stored Record of ${run_id} does not verify: ${opened.report.summary}`);
      const c = opened.contents;
      const by = c.enrollments.find((e) => e.participant_id === ordered_by);
      if (!by || by.kind !== "human" || !by.grants.includes("disclose")) throw forbidden(`${ordered_by} is not a person in this Record holding the disclose grant`);
      const a = this.enrollments.get(ordered_by);
      if (!a?.row.custodial) throw forbidden(`${ordered_by} signs on their own machine`);
      if (!withheld.length) throw invalid("name at least one file to withhold");
      for (const w of withheld) {
        if (!isDigest(w.digest) || !c.evidence.has(w.digest)) throw invalid(`${w.digest} is not a file this Record cites`);
        if (!c.evidence.get(w.digest).bytes) throw invalid(`${w.digest} is not in the master Record`);
      }
      const ordered_time = this.clock();
      const st = disclosureStatement({ run_id, workspace_id: this.workspace_id, head: c.manifest.events.head }, withheld, ordered_by, ordered_time);
      const disclosure = await signStatementWith(st, this.custody.participantSigner(ordered_by, b64urlDecode(by.public_key)));
      const bytes3 = writeZip(editionEntries(readZip(master), disclosure));
      const check5 = verifyRecord(bytes3, { pin: this.keyIds() });
      if (check5.integrity !== "pass") throw new Error(`the edition does not verify: ${check5.summary}`);
      await this.journalNow("EditionMade", [disclosure.digest], { note: `run ${run_id}: ${withheld.length} file${withheld.length === 1 ? "" : "s"} withheld on the order of ${ordered_by}` });
      return { bytes: bytes3, digest: digestOf(bytes3) };
    });
  }
  /**
   * Issue the workspace's register (spec §7.3): every Run started here, in
   * order, signed by the workspace key. Each register extends the one before,
   * and the kernel keeps every register it issued. Checked with the reference
   * verifier before it is handed out.
   */
  // ------------------------------------------------------------ the journal (spec §7.6)
  /** The journal's head and length, for the register. */
  journalHead() {
    const t = this.store.journalTail();
    return t ? { head: t.digest, length: t.seq } : void 0;
  }
  /**
   * Append a runtime entry, signed by the workspace key in use. A workspace made before the journal starts
   * one on its first change: WorkspaceCreated, then each current enrollment, so later entries can name them.
   * Appends take the journal's own queue, so a seal (on its Run's queue) and a workspace change never race.
   */
  journalNow(kind, refs, extra = {}) {
    return this.exclusive("journal", () => this.appendJournal(kind, refs, extra));
  }
  async appendJournal(kind, refs, extra) {
    if (!this.store.journalTail() && kind !== "WorkspaceCreated") {
      await this.appendJournal("WorkspaceCreated", [], { note: "journal started" });
      for (const e of this.enrollments.values()) await this.appendJournal("ParticipantEnrolled", [e.row.digest], { note: `${e.row.participant_id}, enrolled before the journal started` });
    }
    const tail = this.store.journalTail();
    const entry = {
      workspace_id: this.workspace_id,
      seq: (tail?.seq ?? 0) + 1,
      previous: tail?.digest ?? null,
      kind,
      actor: { participant_id: "runtime", kind: "runtime", key_id: this.key.keyId },
      declared_time: this.clock(),
      refs,
      ...kind === "WorkspaceCreated" ? { key: { key_id: this.key.keyId, public_key: this.key.publicKeyB64u } } : {},
      ...extra.key ? { key: extra.key } : {},
      ...extra.note !== void 0 ? { note: extra.note } : {}
    };
    const att = await signStatementWith(journalStatement(entry), this.key);
    this.store.appendJournal(entry.seq, att.digest, kind, att.bytes);
  }
  /**
   * Prepare a journal entry for a Participant to sign: what it is about to do to the workspace, in its own name
   * (spec §7.6). The Participant checks the Statement is what it asked for, signs it, and commits it with the
   * action; nothing happens until then.
   */
  prepareJournal(participant_id, kind, refs, extra = {}) {
    return this.exclusive("journal", () => {
      const e = this.enrollments.get(participant_id);
      if (!e || e.enrollment.kind === "system") throw forbidden(`${participant_id} is not a person or an agent enrolled here`);
      if (this.store.retired().has(participant_id)) throw forbidden(`${participant_id} is retired`);
      this.refuseRevoked(participant_id);
      if (extra.on_behalf_of !== void 0) {
        const h = this.enrollments.get(extra.on_behalf_of);
        if (!h || h.enrollment.kind !== "human") throw invalid(`on_behalf_of ${extra.on_behalf_of} is not a person enrolled here`);
      }
      if (extra.trace) {
        const b = this.store.blobMeta(extra.trace.digest);
        if (!b || b.size !== extra.trace.size || b.media_type !== extra.trace.media_type) throw invalid("the trace must be uploaded first, with this digest, size and media type");
      }
      const tail = this.store.journalTail();
      if (!tail) throw new KernelError(409, "conflict", "the journal has not started");
      const entry = {
        workspace_id: this.workspace_id,
        seq: tail.seq + 1,
        previous: tail.digest,
        kind,
        actor: { participant_id, kind: e.enrollment.kind, key_id: e.enrollment.key_id, ...extra.on_behalf_of !== void 0 ? { on_behalf_of: extra.on_behalf_of } : {} },
        declared_time: this.clock(),
        refs,
        ...extra.trace ? { trace: extra.trace } : {},
        ...extra.note !== void 0 ? { note: extra.note } : {}
      };
      const statement = journalStatement(entry);
      const payload = canonicalBytes(statement);
      const digest = digestOf(payload);
      const now = Date.now();
      for (const [k, v] of this.pendingJournal) if (v.expires < now) this.pendingJournal.delete(k);
      this.pendingJournal.set(digest, { entry, payload, expires: now + 12e4 });
      return { run_id: "", seq: entry.seq, previous: entry.previous, digest, payload_type: PAYLOAD_TYPE, payload: b64Encode(payload), statement };
    });
  }
  /**
   * Commit a journal entry a Participant signed, and do what it says, as one step: the workspace and the
   * journal are held throughout, so nothing lands between the entry's place in the chain and the action.
   * `perform` runs before the entry is appended; if it fails, nothing is appended.
   */
  commitJournal(envelope, participant_id, perform) {
    return this.exclusive("workspace", () => this.exclusive("journal", async () => {
      let att;
      try {
        att = parseAttestation(envelope, "journal");
      } catch (e2) {
        throw invalid(`envelope: ${e2.message}`);
      }
      const p = this.pendingJournal.get(att.digest);
      if (!p || p.expires < Date.now()) throw new KernelError(409, "conflict", "this entry was not prepared here, or it has expired; prepare it again");
      if (p.entry.actor.participant_id !== participant_id) throw forbidden(`this entry is ${p.entry.actor.participant_id}'s to sign`);
      const tail = this.store.journalTail();
      if (tail?.seq !== p.entry.seq - 1 || tail.digest !== p.entry.previous) throw new KernelError(409, "conflict", "the journal moved since this entry was prepared; prepare it again");
      const e = this.enrollments.get(participant_id);
      if (att.keyid !== e.enrollment.key_id || !verifySignature(att, b64urlDecode(e.enrollment.public_key))) throw new KernelError(403, "signature", "the entry is not signed by this Participant's key");
      this.refuseRevoked(participant_id);
      const out = await perform(p.entry);
      this.store.appendJournal(p.entry.seq, att.digest, p.entry.kind, envelope);
      this.pendingJournal.delete(att.digest);
      return out;
    }));
  }
  /** Start a Run as a Participant holding the start grant, with the journal entry it signed (spec §7.6). */
  startRunSigned(envelope, participant_id, req) {
    return this.commitJournal(envelope, participant_id, async (entry) => {
      const row = this.resolveProcedure(req);
      if (entry.kind !== "RunStarted" || entry.refs.length !== 1 || entry.refs[0] !== row.digest || entry.note !== `run ${req.run_id}`) throw invalid("the entry does not describe starting this Run of this Procedure");
      return this.startRunNow({ ...req, started_by: participant_id }, false);
    });
  }
  /** The journal as one file (spec §7.6), checked with the reference verifier before it is handed out. */
  journal() {
    return this.exclusive("journal", () => {
      const j = this.journalFile();
      const report = verifyJournal(j.bytes, { pin: this.key.keyId });
      if (report.integrity !== "pass" || report.provenance !== "pinned") throw new Error(`kernel produced a journal its verifier rejects: ${report.summary}`);
      return j;
    });
  }
  /** The journal file as stored, unchecked: for the archive, written often. */
  journalFile() {
    {
      const rows = this.store.journal();
      if (!rows.length) throw notFound("the journal has not started");
      const files = [];
      for (const r of rows) {
        const att = parseAttestation(r.envelope);
        const e = att.statement.predicate;
        files.push({ name: journalEntryName(e), data: r.envelope });
        if (e.kind === "ParticipantEnrolled") {
          const en = this.version(e.refs[0], e.actor.key_id);
          if (!en) throw new Error(`journal entry ${e.seq} names an enrollment the store does not hold`);
          files.push({ name: `enrollments/${e.refs[0].slice(7)}.dsse.json`, data: en.row.envelope });
        }
        if (e.trace) files.push({ name: `evidence/sha256/${e.trace.digest.slice(7)}`, data: this.store.blob(e.trace.digest).bytes });
      }
      const unique = [...new Map(files.map((f) => [f.name, f])).values()].sort((a, b) => a.name < b.name ? -1 : 1);
      return { bytes: writeZip(unique), length: rows.length, head: rows.at(-1).digest };
    }
  }
  /** Write a file into the archive, whole or not at all. */
  archiveFile(sub, name, bytes3) {
    if (!this.archive) return;
    const dir = join4(this.archive, sub);
    mkdirSync3(dir, { recursive: true });
    const tmp = join4(dir, `.${name}.tmp`);
    writeFileSync2(tmp, bytes3);
    renameSync2(tmp, join4(dir, name));
  }
  /** `published`: where the issuer published the register this one extends (spec §5), recorded in it. */
  register(published) {
    return this.exclusive("workspace", () => this.registerNow(published));
  }
  async registerNow(published) {
    const procs = new Map(this.store.procedures().map((p) => [p.digest, p]));
    const runs = this.store.runs().map((r) => {
      const tail = this.store.runTail(r.run_id);
      if (!tail.last) throw new Error(`Run ${r.run_id} has no events`);
      const p = procs.get(r.procedure_digest);
      const entry = {
        sequence: r.sequence,
        run_id: r.run_id,
        status: "open",
        procedure: { procedure_id: p.procedure_id, version: p.version, digest: p.digest },
        head: tail.last.digest
      };
      if (tail.last.kind === "RunClosed") {
        entry.status = "closed";
        entry.outcome = parseAttestation(tail.last.envelope).statement.predicate.outcome;
      }
      return entry;
    });
    if (!this.successor()) {
      const next = await this.freshWorkspaceKey(this.generation + 1);
      try {
        this.store.insertWorkspaceKey(this.generation + 1, next.keyId, next.publicKeyB64u, this.clock());
      } catch (e) {
        await this.custody.discardWorkspaceKey(this.generation + 1).catch(() => void 0);
        throw e;
      }
    }
    const previous = this.store.lastRegister();
    if (published && !previous) throw invalid("there is no earlier register to have published");
    if (published && (!published.log.trim() || !published.entry.trim())) throw invalid("published needs a log and an entry");
    const issued_at = this.clock();
    const att = await signStatementWith(registerStatement({
      workspace: { workspace_id: this.workspace_id, display_name: this.display_name, keyId: this.key.keyId, publicKeyB64u: this.key.publicKeyB64u },
      previous: previous ? previous.digest : null,
      issued_time: issued_at,
      runs,
      successor: this.successor(),
      former_keys: this.formerKeys(),
      revoked: this.store.revocations().map((r) => ({ key_id: r.key_id, as_of: r.as_of, reason: r.reason })),
      ...published ? { published } : {},
      ...this.journalHead() ? { journal: this.journalHead() } : {},
      reviews: this.reviews().map((r) => ({ run_id: r.run_id, review: r.digest }))
    }), this.key);
    const report = verifyRegister(att.bytes, [], { pin: this.key.keyId, ...previous ? { previous: previous.bytes } : {} });
    if (report.integrity !== "pass" || report.provenance !== "pinned") throw new Error(`kernel produced a register its verifier rejects: ${report.summary}`);
    this.store.insertRegister(att.digest, runs.length, att.bytes, issued_at);
    await this.journalNow("RegisterIssued", [att.digest], { note: `through run #${runs.length}` });
    this.archiveFile("Registers", `${this.workspace_id}-${String(runs.length).padStart(6, "0")}.register.json`, att.bytes);
    await this.exclusive("journal", () => this.archiveFile("", `${this.workspace_id}.journal`, this.journalFile().bytes));
    return { digest: att.digest, bytes: att.bytes, through: runs.length, issued_at };
  }
  /**
   * Retire the workspace key in favour of the successor it committed to (spec §5, key succession). Every Run
   * must be closed and sealed first, since a Record carries one workspace key. The successor re-signs every
   * enrollment, a new successor is made, the first register under the new key is issued, and the retired key's
   * private half is destroyed. With `revoke`, the retired key is also revoked as of a Run number (default: the
   * last one), for a key that was lost or exposed rather than simply retired.
   */
  rotate(reason, revoke) {
    return this.exclusive("workspace", async () => {
      if (!reason.trim()) throw invalid("give a reason");
      const runs = this.store.runs();
      for (const r of runs) {
        if (this.store.runTail(r.run_id).last?.kind !== "RunClosed") throw new KernelError(409, "conflict", `Run ${r.run_id} is open: close and seal every Run before changing the workspace key`);
        if (!this.store.record(r.run_id)) throw new KernelError(409, "conflict", `Run ${r.run_id} is closed but not sealed: seal it before changing the workspace key`);
      }
      const through = runs.length;
      const asOf = revoke ? revoke.as_of ?? through : void 0;
      if (asOf !== void 0 && (!Number.isSafeInteger(asOf) || asOf < 0 || asOf > through)) throw invalid(`as_of must be a Run number from 0 to ${through}`);
      const last = this.store.lastRegister();
      const named = last ? parseAttestation(last.bytes) : void 0;
      if (!named || named.keyid !== this.key.keyId || named.statement.predicate.successor?.key_id !== this.successor()?.key_id) await this.registerNow();
      const succ = this.successor();
      const gen = this.generation + 1;
      if (!await this.custody.hasWorkspaceKey(gen)) throw new Error(`the successor key is not in the ${this.custody.store.backend} key store`);
      const next = this.custody.workspaceSigner(b64urlDecode(succ.public_key), gen);
      await this.custody.unlockWorkspaceKey(gen);
      const probe = new Uint8Array(randomBytes3(32));
      if (!ed25519Verify(next.publicKey, probe, await next.sign(probe))) throw new Error("the successor key in the key store does not match the one committed to");
      const resigned = [];
      for (const [id, e] of this.enrollments) {
        const pred = parseAttestation(e.row.envelope).statement.predicate;
        const att = await signStatementWith(makeStatement("enrollment", `runrec:participant:${id}`, e.enrollment.key_id, pred), next);
        resigned.push({ participant_id: id, digest: att.digest, bytes: att.bytes });
      }
      const after = await this.freshWorkspaceKey(gen + 1);
      const old = { key: this.key, generation: this.generation };
      const now = this.clock();
      try {
        this.store.transaction(() => {
          this.store.insertRotation(gen, through, now);
          for (const r of resigned) this.store.insertResignature(r.digest, r.participant_id, gen, r.bytes);
          this.store.insertWorkspaceKey(gen + 1, after.keyId, after.publicKeyB64u, now);
          if (asOf !== void 0) this.store.insertRevocation(old.key.keyId, asOf, reason, now);
        });
      } catch (e) {
        await this.custody.discardWorkspaceKey(gen + 1).catch(() => void 0);
        throw e;
      }
      await this.journalNow("KeyRotated", [], { key: { key_id: next.keyId, public_key: next.publicKeyB64u }, note: reason });
      this.generation = gen;
      this.key = next;
      this.sessions.clear();
      this.loadEnrollments();
      if (asOf !== void 0) await this.journalNow("KeyRevoked", [old.key.keyId], { note: `${reason} (as of run #${asOf})` });
      const reg = await this.registerNow();
      await this.custody.discardWorkspaceKey(old.generation).catch(() => void 0);
      return { key_id: next.keyId, generation: gen, register: { digest: reg.digest, through: reg.through } };
    });
  }
  /**
   * Revoke a Participant's key (spec §5): the workspace no longer stands behind what it signs in Runs numbered
   * above the last one started. The Participant is retired too, so it signs nothing more here. The next register
   * carries the revocation, and every register after it.
   */
  revoke(participant_id, reason) {
    return this.exclusive("workspace", async () => {
      const e = this.enrollments.get(participant_id);
      if (!e) throw notFound(`${participant_id} is not enrolled`);
      if (!reason.trim()) throw invalid("give a reason");
      if (this.store.revocations().some((r) => r.key_id === e.enrollment.key_id)) throw new KernelError(409, "conflict", `${participant_id}'s key is already revoked`);
      const now = this.clock();
      this.store.transaction(() => {
        if (!this.store.retired().has(participant_id)) this.store.retire(participant_id, now, reason);
        this.store.insertRevocation(e.enrollment.key_id, this.store.runs().length, reason, now);
      });
      await this.journalNow("KeyRevoked", [e.enrollment.key_id], { note: `${participant_id}: ${reason}` });
      return this.participant(participant_id);
    });
  }
  // Reads wait their turn on the Run's queue, so they never see a call half done.
  state(run_id) {
    return this.exclusive(`run:${run_id}`, () => this.session(run_id).state());
  }
  events(run_id, afterSeq = 0) {
    return this.exclusive(`run:${run_id}`, () => this.session(run_id).entries.slice(Math.max(0, afterSeq)).map(viewOf));
  }
  work(run_id, participant_id) {
    return this.exclusive(`run:${run_id}`, () => {
      const s = this.session(run_id);
      const p = s.ctx.participants.get(participant_id);
      if (!p) throw forbidden(`${participant_id} is not a Participant in Run ${run_id}`);
      return availableWork(s.ctx.procedure, s.view(), p.enrollment);
    });
  }
  /** Run summaries read from the store, without loading or re-checking each Run. */
  runs() {
    const procs = new Map(this.store.procedures().map((p) => [p.digest, p]));
    const standing = /* @__PURE__ */ new Map();
    for (const r of this.standingReviews()) standing.set(r.run_id, [...standing.get(r.run_id) ?? [], r]);
    return this.store.runs().map((r) => {
      const tail = this.store.runTail(r.run_id);
      const closed = tail.last?.kind === "RunClosed";
      let outcome;
      if (closed) {
        try {
          outcome = String(parseAttestation(tail.last.envelope).statement.predicate.outcome);
        } catch {
          outcome = void 0;
        }
      }
      const p = procs.get(r.procedure_digest);
      return {
        run_id: r.run_id,
        sequence: r.sequence,
        procedure_id: p?.procedure_id ?? "?",
        version: p?.version ?? "?",
        status: closed ? "closed" : "open",
        ...outcome !== void 0 ? { outcome } : {},
        event_count: tail.count,
        created_at: r.created_at,
        sealed: this.store.record(r.run_id) !== void 0,
        ...standing.has(r.run_id) ? { reviews: standing.get(r.run_id) } : {}
      };
    });
  }
  // ------------------------------------------------------------ evidence
  /** Store evidence bytes by content address; returns the artifact object an Observation cites. */
  putBlob(bytes3, media_type) {
    try {
      new Reader2(5, "media_type").mediaType(media_type);
    } catch (e) {
      throw invalid(e.message);
    }
    if (bytes3.length > this.maxBlobBytes) throw new KernelError(413, "too_large", `evidence is limited to ${this.maxBlobBytes} bytes`);
    const digest = digestOf(bytes3);
    try {
      this.store.putBlob(digest, media_type, bytes3);
    } catch (e) {
      throw new KernelError(409, "conflict", e.message);
    }
    return { digest, media_type, size: bytes3.length };
  }
};
function toRow(e) {
  return { seq: e.event.seq, digest: e.digest, kind: e.event.kind, envelope: e.bytes };
}
function viewOf(e) {
  return { seq: e.event.seq, digest: e.digest, kind: e.event.kind, event: e.event };
}
function newRunId(now) {
  return `run-${now.slice(0, 10).replaceAll("-", "")}-${randomBytes3(4).toString("hex")}`;
}

// src/api.ts
import { createServer } from "node:http";
import { createHash as createHash4, randomBytes as randomBytes4, timingSafeEqual } from "node:crypto";

// src/person.ts
import { existsSync as existsSync5, mkdirSync as mkdirSync4, readFileSync as readFileSync4, readdirSync, renameSync as renameSync3, statSync, writeFileSync as writeFileSync3 } from "node:fs";
import { homedir } from "node:os";
import { basename, join as join5 } from "node:path";
function participantOf(v, where, human) {
  if (!isObject(v)) throw invalid(`${where} must be an object`);
  const known = ["participant_id", "display_name", "kind", "roles", "grants", "public_key", "party"];
  for (const k of Object.keys(v)) if (!known.includes(k)) throw invalid(`${where}: unknown member ${k}`);
  const str2 = (k) => {
    if (typeof v[k] !== "string" || !v[k]) throw invalid(`${where}.${k} must be a non-empty string`);
    return v[k];
  };
  const list2 = (k) => {
    if (!Array.isArray(v[k]) || v[k].some((x) => typeof x !== "string")) throw invalid(`${where}.${k} must be a list of strings`);
    return v[k];
  };
  const kind = human ? "human" : str2("kind");
  if (human && v.kind !== void 0 && v.kind !== "human") throw invalid(`${where}.kind must be human`);
  const party = v.party === void 0 ? void 0 : str2("party");
  if (!human && kind !== "agent" && kind !== "system" && !(kind === "human" && party !== void 0)) throw invalid(`${where}.kind must be agent or system, or human with the party they sign for`);
  const grants = list2("grants");
  for (const g of grants) if (!GRANTS.includes(g)) throw invalid(`${where}: unknown grant ${g}`);
  if (human && v.public_key !== void 0) throw invalid(`${where}: the person's key is made on this machine, so give no public_key`);
  if (!human && v.public_key === void 0) throw invalid(`${where}: an ${kind} brings its own public_key`);
  return {
    participant_id: str2("participant_id"),
    display_name: str2("display_name"),
    kind,
    roles: list2("roles"),
    grants,
    ...human ? {} : { public_key: str2("public_key") },
    ...party !== void 0 ? { party } : {}
  };
}
function parseSetup(v) {
  if (!isObject(v)) throw invalid("the setup must be an object");
  for (const k of Object.keys(v)) if (!["person", "participants", "comment", "workspace"].includes(k)) throw invalid(`setup: unknown member ${k}`);
  if (!Array.isArray(v.participants)) throw invalid("setup.participants must be a list");
  const setup = { person: participantOf(v.person, "setup.person", true), participants: v.participants.map((p, i) => participantOf(p, `setup.participants[${i}]`, false)) };
  const ids = [setup.person, ...setup.participants].map((p) => p.participant_id);
  const dup = ids.find((id, i) => ids.indexOf(id) !== i);
  if (dup) throw invalid(`setup lists ${dup} twice`);
  return setup;
}
var same = (a, s) => a.kind === s.kind && a.display_name === s.display_name && JSON.stringify([...a.roles].sort()) === JSON.stringify([...s.roles].sort()) && JSON.stringify([...a.grants].sort()) === JSON.stringify([...s.grants].sort()) && a.party === s.party && (s.public_key === void 0 || a.public_key === s.public_key);
async function applySetup(ws, setup) {
  const existing = new Map(ws.participants().map((p) => [p.participant_id, p]));
  const current = ws.store.meta("person");
  if (current !== void 0 && current !== setup.person.participant_id) throw forbidden(`this machine's person is already ${current}`);
  for (const s of [setup.person, ...setup.participants]) {
    const e = existing.get(s.participant_id);
    if (e && !same(e, s)) throw new KernelError(409, "conflict", `${s.participant_id} is already enrolled differently; enrollments are permanent, so give the new one another id`);
    if (e?.retired) throw new KernelError(409, "conflict", `${s.participant_id} is retired`);
  }
  const enrolled = [];
  const unchanged = [];
  for (const s of [setup.person, ...setup.participants]) {
    if (existing.has(s.participant_id)) {
      unchanged.push(s.participant_id);
      continue;
    }
    const { public_key, ...rest } = s;
    await ws.enroll({ ...rest, ...public_key !== void 0 ? { public_key } : {}, granted_by: "setup file" });
    enrolled.push(s.participant_id);
  }
  if (current === void 0) ws.store.setMeta("person", setup.person.participant_id);
  return { person: setup.person.participant_id, enrolled, unchanged };
}
function personOf(ws) {
  const id = ws.store.meta("person");
  return id === void 0 ? void 0 : ws.participants().find((p) => p.participant_id === id);
}
function requirePerson(ws) {
  const p = personOf(ws);
  if (!p) throw new KernelError(409, "not_set_up", "this workspace has no person yet: apply a setup file first");
  return p;
}
function defaultDraftsDir() {
  return process.env.OPSPROOF_PROCEDURE_DRAFTS || join5(homedir(), "OpsProof", "Procedure drafts");
}
var MAX_DRAFT_BYTES = 1024 * 1024;
function readDraft(path) {
  try {
    if (statSync(path).size > MAX_DRAFT_BYTES) return { problem: "the file is larger than 1 MB" };
    const raw = parseStrict(readFileSync4(path, "utf8"));
    parseProcedure(raw);
    return { raw };
  } catch (e) {
    if (e instanceof RecordError || e instanceof JsonError) return { problem: e.message };
    throw e;
  }
}
function drafts(ws, dir) {
  if (!existsSync5(dir)) return [];
  const procs = ws.procedures();
  return readdirSync(dir, { withFileTypes: true }).filter((d) => d.isFile() && d.name.endsWith(".json")).map((d) => d.name).sort().map((file) => {
    const { raw, problem } = readDraft(join5(dir, file));
    if (!raw) return { file, problem };
    const text = renderProcedure(raw);
    const signed = procs.find((p) => p.procedure_id === text.procedure_id && p.version === text.version);
    return { file, text, ...signed ? { signed } : {} };
  });
}
async function signDraft(ws, dir, file) {
  const person = requirePerson(ws);
  if (basename(file) !== file || !file.endsWith(".json")) throw invalid("name a draft file in the drafts folder");
  const path = join5(dir, file);
  if (!existsSync5(path)) throw notFound(`no draft ${file}`);
  const { raw, problem } = readDraft(path);
  if (!raw) throw invalid(`the draft cannot be signed: ${problem}`);
  const info = await ws.addProcedure(raw, person.participant_id);
  const signedDir = join5(dir, "Signed");
  mkdirSync4(signedDir, { recursive: true });
  let target = join5(signedDir, file);
  for (let n2 = 2; existsSync5(target); n2++) target = join5(signedDir, file.replace(/\.json$/, ` (${n2}).json`));
  renameSync3(path, target);
  return info;
}
function agreeProcedure(ws, digest) {
  return ws.signProcedure(digest, requirePerson(ws).participant_id);
}
function cosignForeign(ws, envelope) {
  return ws.cosignForeign(envelope, requirePerson(ws).participant_id);
}
async function needsYou(ws, dir) {
  const person = personOf(ws);
  if (!person) return [{ type: "setup" }];
  const out = [];
  for (const d of drafts(ws, dir)) {
    if (d.text && !d.signed) out.push({ type: "sign", file: d.file, title: d.text.title, procedure_id: d.text.procedure_id, version: d.text.version });
  }
  if (person.party && person.grants.includes("author") && !person.retired) {
    for (const p of ws.procedures()) {
      const mine = p.parties?.find((x) => x.party_id === person.party);
      if (p.agreed || !mine || mine.signed_by) continue;
      out.push({ type: "agree", digest: p.digest, title: p.title, procedure_id: p.procedure_id, version: p.version, party: mine.display_name, signed: p.parties.filter((x) => x.signed_by).map((x) => x.display_name), waiting: p.parties.filter((x) => !x.signed_by && x !== mine).map((x) => x.display_name) });
    }
  }
  const runs = ws.runs().filter((r) => !r.sealed).sort((a, b) => a.created_at < b.created_at ? -1 : a.created_at > b.created_at ? 1 : 0);
  for (const r of runs) {
    const st = await ws.state(r.run_id);
    const title = st.procedure.title;
    if (st.status === "closed") {
      out.push({ type: "publish", run_id: r.run_id, procedure_title: title, outcome: st.outcome, closed: true });
      continue;
    }
    let work = [];
    try {
      work = await ws.work(r.run_id, person.participant_id);
    } catch {
      work = [];
    }
    const titles = new Map(st.steps.map((s) => [s.step_id, s.title]));
    for (const w of work) out.push({ ...w, run_id: r.run_id, procedure_title: title, step_title: titles.get(w.step_id) ?? w.step_id });
    if (st.steps.every((s) => s.state !== "open")) out.push({ type: "publish", run_id: r.run_id, procedure_title: title, outcome: st.outcome, closed: false });
  }
  return out;
}
function writeDraft(dir, raw, procedure_id, version) {
  mkdirSync4(dir, { recursive: true });
  const base = `${procedure_id}-${version}`;
  const same2 = (f) => {
    try {
      return canonicalize(parseStrict(readFileSync4(f, "utf8"))) === canonicalize(raw);
    } catch {
      return false;
    }
  };
  let file = `${base}.json`;
  for (let n2 = 2; existsSync5(join5(dir, file)) && !same2(join5(dir, file)); n2++) file = `${base} (${n2}).json`;
  writeFileSync3(join5(dir, file), JSON.stringify(raw, null, 2) + "\n");
  return file;
}

// src/api.ts
function sessionMessage(workspace_id, participant_id, nonce, origin) {
  return new TextEncoder().encode(`opsproof-session-v2
${workspace_id}
${participant_id}
${nonce}
${origin}`);
}
var LOOPBACK = /* @__PURE__ */ new Set(["127.0.0.1", "::1", "localhost"]);
var ID_RE2 = /^[a-z0-9][a-z0-9._-]{0,127}$/;
var CHALLENGE_TTL_MS = 6e4;
var MAX_PENDING_CHALLENGES = 1e3;
var MAX_CHALLENGES_PER_PARTICIPANT = 8;
var MAX_SESSIONS_PER_PARTICIPANT = 16;
var OPEN_BODY_BYTES = 4096;
var MAX_STREAMS = { admin: 16, participant: 4 };
var STREAM_BUFFER_BYTES = 1024 * 1024;
var digestToken = (t) => createHash4("sha256").update(t).digest();
async function startApi(opts) {
  const ws = opts.workspace;
  const host = opts.host ?? "127.0.0.1";
  if (!LOOPBACK.has(host)) throw new Error(`the kernel API listens on loopback only, not ${host}`);
  const token = opts.token ?? `lt_${randomBytes4(32).toString("base64url")}`;
  if (token.length < 32) throw new Error("the launch token must be at least 32 characters");
  const adminDigest = digestToken(token);
  const sessionTtl = opts.sessionTtlMs ?? 12 * 36e5;
  const maxJson = opts.maxJsonBytes ?? 1024 * 1024;
  const uploadQuota = opts.uploadQuotaBytes ?? 1024 * 1024 * 1024;
  const draftsDir = opts.draftsDir ?? defaultDraftsDir();
  const challenges = /* @__PURE__ */ new Map();
  const sessions = /* @__PURE__ */ new Map();
  const uploaded = /* @__PURE__ */ new Map();
  const streams = /* @__PURE__ */ new Map();
  let port = 0;
  const origins = () => [`http://127.0.0.1:${port}`, `http://localhost:${port}`, `http://[::1]:${port}`];
  const send = (res, status, body) => {
    const data = Buffer.from(JSON.stringify(body));
    res.writeHead(status, { "content-type": "application/json; charset=utf-8", "content-length": data.length });
    res.end(data);
  };
  const readBody = (req, limit) => new Promise((resolve, reject) => {
    const declared = Number(req.headers["content-length"] ?? 0);
    if (declared > limit) return reject(new KernelError(413, "too_large", `request body is limited to ${limit} bytes`));
    const chunks = [];
    let size = 0;
    req.on("data", (c) => {
      size += c.length;
      if (size > limit) {
        reject(new KernelError(413, "too_large", `request body is limited to ${limit} bytes`));
        req.destroy();
      } else chunks.push(c);
    });
    req.on("end", () => resolve(new Uint8Array(Buffer.concat(chunks))));
    req.on("error", reject);
  });
  const json = async (ctx, limit = maxJson) => {
    const bytes3 = await readBody(ctx.req, limit);
    let v;
    try {
      v = parseStrict(decodeUtf8(bytes3));
    } catch (e) {
      throw invalid(`request body: ${e.message}`);
    }
    if (!isObject(v)) throw invalid("request body must be a JSON object");
    return v;
  };
  const str2 = (o, k, required = true) => {
    const v = o[k];
    if (v === void 0 && !required) return void 0;
    if (typeof v !== "string") throw invalid(`${k} must be a string`);
    return v;
  };
  const sessionValid = (t) => {
    const s = sessions.get(t);
    if (!s) return void 0;
    const p = s.expires >= Date.now() ? ws.participants().find((x) => x.participant_id === s.participant_id) : void 0;
    if (!p || p.retired || p.custodial) {
      sessions.delete(t);
      return void 0;
    }
    return s.participant_id;
  };
  const authenticate = (req) => {
    const h = req.headers.authorization;
    const m = typeof h === "string" ? /^Bearer (\S+)$/.exec(h) : null;
    if (!m) throw new KernelError(401, "unauthenticated", "send Authorization: Bearer <launch token or session token>");
    const t = m[1];
    if (timingSafeEqual(digestToken(t), adminDigest)) return { role: "admin" };
    const participant_id = sessionValid(t);
    if (!participant_id) throw new KernelError(401, "unauthenticated", "unknown, expired or revoked session");
    return { role: "participant", participant_id, token: t };
  };
  const admin = (ctx) => {
    if (ctx.who.role !== "admin") throw forbidden("this call needs the launch token");
  };
  const actingFor = (ctx, named) => {
    if (ctx.who.role === "participant") {
      if (named !== void 0 && named !== ctx.who.participant_id) throw forbidden(`this session acts for ${ctx.who.participant_id} only`);
      return ctx.who.participant_id;
    }
    if (ctx.who.role !== "admin") throw forbidden("authenticate first");
    if (named === void 0) throw invalid("name the participant_id");
    return named;
  };
  const routes = [];
  const route = (method, path, handler, open = false) => {
    const re = new RegExp(`^${path.replace(/:[a-z]+/g, "([^/]+)")}$`);
    routes.push({ method, path: re, open, handler });
  };
  route("GET", "/v1/health", ({ res }) => send(res, 200, { ok: true }), true);
  route("POST", "/v1/sessions/challenge", async (ctx) => {
    const b = await json(ctx, OPEN_BODY_BYTES);
    const participant_id = str2(b, "participant_id");
    if (!ID_RE2.test(participant_id)) throw invalid("participant_id is not an identifier");
    const now = Date.now();
    for (const [n2, c] of challenges) if (c.expires < now) challenges.delete(n2);
    const nonce = randomBytes4(24).toString("base64url");
    const p = ws.participants().find((x) => x.participant_id === participant_id);
    if (p && !p.retired && !p.custodial) {
      const mine = [...challenges].filter(([, c]) => c.participant_id === participant_id);
      if (mine.length >= MAX_CHALLENGES_PER_PARTICIPANT) challenges.delete(mine[0][0]);
      if (challenges.size >= MAX_PENDING_CHALLENGES) challenges.delete(challenges.keys().next().value);
      challenges.set(nonce, { participant_id, expires: now + CHALLENGE_TTL_MS });
    }
    send(ctx.res, 200, { nonce, workspace_id: ws.workspace_id });
  }, true);
  route("POST", "/v1/sessions", async (ctx) => {
    const b = await json(ctx, OPEN_BODY_BYTES);
    const participant_id = str2(b, "participant_id");
    const nonce = str2(b, "nonce");
    const c = challenges.get(nonce);
    challenges.delete(nonce);
    const deny = () => new KernelError(401, "unauthenticated", "challenge failed");
    if (!c || c.expires < Date.now() || c.participant_id !== participant_id) throw deny();
    const p = ws.participants().find((x) => x.participant_id === participant_id);
    if (!p || p.retired || p.custodial) throw deny();
    let sig;
    try {
      sig = b64Decode(str2(b, "signature"));
    } catch {
      throw deny();
    }
    const key = b64urlDecode(p.public_key);
    if (!origins().some((o) => ed25519Verify(key, sessionMessage(ws.workspace_id, participant_id, nonce, o), sig))) throw deny();
    const now = Date.now();
    for (const [k, v] of sessions) if (v.expires < now) sessions.delete(k);
    const mine = [...sessions].filter(([, v]) => v.participant_id === participant_id);
    if (mine.length >= MAX_SESSIONS_PER_PARTICIPANT) sessions.delete(mine[0][0]);
    const t = `ps_${randomBytes4(32).toString("base64url")}`;
    const expires = now + sessionTtl;
    sessions.set(t, { participant_id, expires });
    send(ctx.res, 200, { token: t, participant_id, expires_at: new Date(expires).toISOString() });
  }, true);
  route("GET", "/v1/workspace", ({ res }) => send(res, 200, { ...ws.summary(), participants: ws.participants(), procedures: ws.procedures() }));
  route("GET", "/v1/participants", ({ res }) => send(res, 200, { participants: ws.participants() }));
  route("POST", "/v1/workspace/unlock", async (ctx) => {
    admin(ctx);
    await ws.unlock();
    send(ctx.res, 200, { unlocked: true });
  });
  route("POST", "/v1/participants", async (ctx) => {
    admin(ctx);
    const b = await json(ctx);
    const p = await ws.enroll(b);
    send(ctx.res, 201, p);
  });
  route("POST", "/v1/participants/:id/retire", async (ctx) => {
    admin(ctx);
    const b = await json(ctx);
    send(ctx.res, 200, await ws.retire(ctx.params[0], str2(b, "reason")));
  });
  route("POST", "/v1/participants/:id/revoke", async (ctx) => {
    admin(ctx);
    const b = await json(ctx);
    send(ctx.res, 200, await ws.revoke(ctx.params[0], str2(b, "reason")));
  });
  route("POST", "/v1/workspace/rotate", async (ctx) => {
    admin(ctx);
    const b = await json(ctx);
    const exposed = b.exposed === true;
    const asOf = b.as_of;
    if (asOf !== void 0 && (!exposed || typeof asOf !== "number")) throw invalid("as_of is a Run number, and goes with exposed: true");
    send(ctx.res, 200, await ws.rotate(str2(b, "reason"), exposed ? asOf !== void 0 ? { as_of: asOf } : {} : void 0));
  });
  route("GET", "/v1/person", (ctx) => {
    admin(ctx);
    send(ctx.res, 200, { person: personOf(ws) ?? null, workspace: ws.summary() });
  });
  route("POST", "/v1/setup", async (ctx) => {
    admin(ctx);
    const b = await json(ctx);
    send(ctx.res, 200, await applySetup(ws, parseSetup(b.setup)));
  });
  route("GET", "/v1/needs-you", async (ctx) => {
    admin(ctx);
    send(ctx.res, 200, { person: personOf(ws)?.participant_id ?? null, items: await needsYou(ws, draftsDir) });
  });
  route("GET", "/v1/drafts", (ctx) => {
    admin(ctx);
    send(ctx.res, 200, { folder: draftsDir, drafts: drafts(ws, draftsDir) });
  });
  route("POST", "/v1/drafts/sign", async (ctx) => {
    admin(ctx);
    const b = await json(ctx);
    send(ctx.res, 201, await signDraft(ws, draftsDir, str2(b, "file")));
  });
  route("GET", "/v1/procedures", ({ res }) => send(res, 200, { procedures: ws.procedures() }));
  route("GET", "/v1/procedures/:digest/text", ({ res, params }) => send(res, 200, renderProcedure(ws.procedure(params[0]).procedure)));
  route("GET", "/v1/procedures/:digest/changes", ({ res, params }) => send(res, 200, ws.procedureChanges(params[0])));
  route("GET", "/v1/procedures/:digest", ({ res, params }) => send(res, 200, ws.procedure(params[0])));
  route("POST", "/v1/procedures/:digest/sign", async (ctx) => {
    admin(ctx);
    const b = await json(ctx);
    const who = str2(b, "participant_id", false);
    send(ctx.res, 200, who === void 0 ? await agreeProcedure(ws, ctx.params[0]) : await ws.signProcedure(ctx.params[0], who));
  });
  route("POST", "/v1/procedures/cosign", async (ctx) => {
    admin(ctx);
    const b = await json(ctx);
    if (!isObject(b.envelope)) throw invalid("pass the envelope to sign");
    send(ctx.res, 200, { envelope: parseStrict(decodeUtf8(await cosignForeign(ws, canonicalBytes(b.envelope)))) });
  });
  route("POST", "/v1/procedures", async (ctx) => {
    admin(ctx);
    const b = await json(ctx);
    if (b.envelope !== void 0) {
      if (!isObject(b.envelope)) throw invalid("envelope must be an object");
      return send(ctx.res, 201, await ws.importProcedure(canonicalBytes(b.envelope)));
    }
    if (!isObject(b.procedure)) throw invalid("pass procedure and author, or a signed envelope");
    send(ctx.res, 201, await ws.addProcedure(b.procedure, str2(b, "author")));
  });
  route("GET", "/v1/runs", ({ res }) => send(res, 200, { runs: ws.runs() }));
  route("POST", "/v1/runs", async (ctx) => {
    admin(ctx);
    const b = await json(ctx);
    const req = {};
    for (const k of ["procedure_id", "version", "digest", "run_id", "title", "site", "started_by"]) {
      const v = str2(b, k, false);
      if (v !== void 0) req[k] = v;
    }
    if (b.inputs !== void 0) {
      if (!isObject(b.inputs)) throw invalid("inputs must be an object");
      req.inputs = b.inputs;
    }
    for (const k of ["subjects", "related"]) {
      if (b[k] === void 0) continue;
      if (!Array.isArray(b[k]) || !b[k].every(isObject)) throw invalid(`${k} must be a list of objects`);
      req[k] = b[k];
    }
    send(ctx.res, 201, await ws.startRun(req));
  });
  route("GET", "/v1/runs/:run", async ({ res, params }) => send(res, 200, await ws.state(params[0])));
  route("GET", "/v1/runs/:run/events", async ({ res, params, url }) => {
    const after = Number(url.searchParams.get("after") ?? 0);
    if (!Number.isSafeInteger(after) || after < 0) throw invalid("after must be a non-negative integer");
    send(res, 200, { events: await ws.events(params[0], after) });
  });
  route("GET", "/v1/runs/:run/work", async (ctx) => {
    const who = actingFor(ctx, ctx.url.searchParams.get("participant") ?? void 0);
    send(ctx.res, 200, { participant_id: who, work: await ws.work(ctx.params[0], who) });
  });
  route("POST", "/v1/runs/:run/prepare", async (ctx) => {
    const b = await json(ctx);
    const who = actingFor(ctx, str2(b, "participant_id", false));
    if (!isObject(b.fields)) throw invalid("fields must be an object");
    send(ctx.res, 200, await ws.prepare(ctx.params[0], who, str2(b, "kind"), b.fields));
  });
  route("POST", "/v1/runs/:run/commit", async (ctx) => {
    const b = await json(ctx);
    if (!isObject(b.envelope)) throw invalid("envelope must be an object");
    const onlyFor = ctx.who.role === "participant" ? ctx.who.participant_id : void 0;
    send(ctx.res, 201, { events: await ws.commit(ctx.params[0], canonicalBytes(b.envelope), onlyFor) });
  });
  route("POST", "/v1/runs/:run/submit", async (ctx) => {
    admin(ctx);
    const b = await json(ctx);
    if (!isObject(b.fields)) throw invalid("fields must be an object");
    send(ctx.res, 201, { events: await ws.submit(ctx.params[0], str2(b, "participant_id"), str2(b, "kind"), b.fields) });
  });
  route("POST", "/v1/runs/:run/close", async (ctx) => {
    admin(ctx);
    const b = await json(ctx);
    send(ctx.res, 200, await ws.closeRun(ctx.params[0], str2(b, "closed_by", false)));
  });
  route("POST", "/v1/runs/:run/seal", async (ctx) => {
    admin(ctx);
    const b = await json(ctx);
    const r = await ws.seal(ctx.params[0], str2(b, "published_by", false));
    send(ctx.res, 200, { run_id: ctx.params[0], digest: r.digest, size: r.size, sealed_at: r.sealed_at, key_id: ws.key.keyId });
  });
  route("GET", "/v1/runs/:run/report", (ctx) => {
    admin(ctx);
    const html = Buffer.from(renderReport(ws.record(ctx.params[0]), { pin: ws.keyIds() }));
    ctx.res.writeHead(200, { "content-type": "text/html; charset=utf-8", "content-length": html.length, "content-security-policy": "default-src 'none'; style-src 'unsafe-inline'; img-src data:" });
    ctx.res.end(html);
  });
  route("GET", "/v1/shift", (ctx) => {
    admin(ctx);
    const records = ws.runs().filter((r) => r.sealed).sort((a, b) => a.sequence - b.sequence).map((r) => ({ name: `#${r.sequence} ${r.run_id}`, bytes: ws.record(r.run_id) }));
    const reg = ws.store.lastRegister();
    const html = Buffer.from(renderShift(records, { pin: ws.key.keyId, title: `Every Record of ${ws.display_name}`, ...reg ? { register: reg.bytes } : {} }));
    ctx.res.writeHead(200, { "content-type": "text/html; charset=utf-8", "content-length": html.length, "content-security-policy": "default-src 'none'; style-src 'unsafe-inline'; img-src data:" });
    ctx.res.end(html);
  });
  route("GET", "/v1/journal/entries", async (ctx) => {
    admin(ctx);
    const j = await ws.journal();
    send(ctx.res, 200, verifyJournal(j.bytes, { pin: ws.key.keyId }));
  });
  const actions = {
    start_run: {
      grant: "start",
      describe: (p) => {
        const info = ws.procedureFor({ ...typeof p.digest === "string" ? { digest: p.digest } : {}, ...typeof p.procedure_id === "string" ? { procedure_id: p.procedure_id } : {}, ...typeof p.version === "string" ? { version: p.version } : {} });
        const run_id = typeof p.run_id === "string" ? p.run_id : `run-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10).replaceAll("-", "")}-${randomBytes4(4).toString("hex")}`;
        return { kind: "RunStarted", refs: [info.digest], note: `run ${run_id}`, params: { digest: info.digest, run_id, ...typeof p.title === "string" ? { title: p.title } : {} } };
      }
    },
    draft_procedure: {
      grant: "operate",
      describe: (p) => {
        if (!isObject(p.procedure)) throw invalid("procedure must be an object");
        let parsed;
        try {
          parsed = parseProcedure(p.procedure);
        } catch (e) {
          throw invalid(`the Procedure is not valid: ${e.message}`);
        }
        return { kind: "ProcedureDrafted", refs: [digestOf(canonicalBytes(p.procedure))], note: `${parsed.procedure_id} ${parsed.version}`, params: { procedure: p.procedure } };
      }
    }
  };
  const participantAction = (ctx, b) => {
    if (ctx.who.role !== "participant") throw forbidden("a Participant takes this action in its own name, with its own session");
    const a = actions[str2(b, "action")];
    if (!a) throw invalid(`action must be one of ${Object.keys(actions).join(", ")}`);
    const me = ws.participant(ctx.who.participant_id);
    if (!me.grants.includes(a.grant)) throw forbidden(`${me.participant_id} does not hold the ${a.grant} grant`);
    return a;
  };
  route("POST", "/v1/journal/prepare", async (ctx) => {
    const b = await json(ctx);
    const a = participantAction(ctx, b);
    const d = a.describe(isObject(b.params) ? b.params : {});
    const trace = isObject(b.trace) ? b.trace : void 0;
    if (trace && (!isDigest(trace.digest) || typeof trace.media_type !== "string" || typeof trace.size !== "number")) throw invalid("trace must be { digest, media_type, size }");
    const prepared = await ws.prepareJournal(ctx.who.role === "participant" ? ctx.who.participant_id : "", d.kind, d.refs, {
      note: d.note,
      ...typeof b.on_behalf_of === "string" ? { on_behalf_of: b.on_behalf_of } : {},
      ...trace ? { trace: { digest: trace.digest, media_type: trace.media_type, size: trace.size } } : {}
    });
    send(ctx.res, 200, { ...prepared, params: d.params });
  });
  route("POST", "/v1/journal/commit", async (ctx) => {
    const b = await json(ctx);
    const a = participantAction(ctx, b);
    if (!isObject(b.envelope) || !isObject(b.params)) throw invalid("send the signed envelope and the params prepare returned");
    const envelope = canonicalBytes(b.envelope);
    const pid = ctx.who.role === "participant" ? ctx.who.participant_id : "";
    const p = b.params;
    if (a === actions.start_run) {
      const state = await ws.startRunSigned(envelope, pid, { digest: str2(p, "digest"), run_id: str2(p, "run_id"), ...typeof p.title === "string" ? { title: p.title } : {} });
      return send(ctx.res, 201, { run: state });
    }
    const procedure = p.procedure;
    const file = await ws.commitJournal(envelope, pid, async (entry) => {
      const parsed = parseProcedure(procedure);
      if (entry.kind !== "ProcedureDrafted" || entry.refs[0] !== digestOf(canonicalBytes(procedure))) throw invalid("the entry does not describe this draft");
      return writeDraft(draftsDir, procedure, parsed.procedure_id, parsed.version);
    });
    send(ctx.res, 201, { draft: file, folder: draftsDir, signed: false });
  });
  route("GET", "/v1/journal", async (ctx) => {
    admin(ctx);
    const j = await ws.journal();
    ctx.res.writeHead(200, {
      "content-type": "application/zip",
      "content-length": j.bytes.length,
      "content-disposition": `attachment; filename="${ws.workspace_id}-${j.length}.journal"`
    });
    ctx.res.end(j.bytes);
  });
  route("GET", "/v1/register", async (ctx) => {
    admin(ctx);
    const r = await ws.register();
    ctx.res.writeHead(200, {
      "content-type": "application/json",
      "content-length": r.bytes.length,
      "content-disposition": `attachment; filename="${ws.workspace_id}-${r.through}.register.json"`
    });
    ctx.res.end(r.bytes);
  });
  route("GET", "/v1/pack", async (ctx) => {
    admin(ctx);
    const p = await ws.pack(ctx.url.searchParams.get("title") ?? void 0);
    ctx.res.writeHead(200, { "content-type": "application/zip", "content-length": p.bytes.length, "content-disposition": `attachment; filename="${ws.workspace_id}-pack.zip"` });
    ctx.res.end(p.bytes);
  });
  route("GET", "/v1/runs/:run/record", (ctx) => {
    admin(ctx);
    const bytes3 = ws.record(ctx.params[0]);
    ctx.res.writeHead(200, {
      "content-type": "application/zip",
      "content-length": bytes3.length,
      "content-disposition": `attachment; filename="${ctx.params[0]}.runrec"`
    });
    ctx.res.end(bytes3);
  });
  const reviewFields = (b) => {
    if (typeof b.verdict !== "string") throw invalid("verdict must be concur, do_not_concur or more_examination");
    if (b.basis !== void 0 && (!Array.isArray(b.basis) || !b.basis.every((x) => typeof x === "string"))) throw invalid("basis must be a list of digests");
    return { verdict: b.verdict, ...typeof b.note === "string" ? { note: b.note } : {}, ...typeof b.terms === "string" ? { terms: b.terms } : {}, ...b.basis ? { basis: b.basis } : {} };
  };
  route("GET", "/v1/runs/:run/reviews", ({ res, params }) => send(res, 200, { reviews: ws.reviews(params[0]) }));
  route("POST", "/v1/runs/:run/reviews", async (ctx) => {
    admin(ctx);
    const b = await json(ctx);
    send(ctx.res, 201, await ws.review(ctx.params[0], reviewFields(b), str2(b, "reviewer")));
  });
  route("GET", "/v1/reviews/:digest/file", (ctx) => {
    const bytes3 = ws.reviewFileOf(ctx.params[0]);
    ctx.res.writeHead(200, { "content-type": "application/json", "content-length": bytes3.length, "content-disposition": `attachment; filename="${ctx.params[0].slice(7, 19)}.review.json"` });
    ctx.res.end(bytes3);
  });
  route("POST", "/v1/reviews/import", async (ctx) => {
    admin(ctx);
    const b = await json(ctx);
    if (!isObject(b.envelope)) throw invalid("pass the signed review envelope");
    send(ctx.res, 201, await ws.importReview(canonicalBytes(b.envelope)));
  });
  route("POST", "/v1/reviews/foreign", async (ctx) => {
    admin(ctx);
    const b = await json(ctx);
    if (typeof b.record !== "string") throw invalid("pass the Record as base64");
    const env = await ws.reviewForeign(b64Decode(b.record), reviewFields(b), str2(b, "reviewer"));
    send(ctx.res, 200, { envelope: parseStrict(decodeUtf8(env)) });
  });
  route("POST", "/v1/runs/:run/edition", async (ctx) => {
    admin(ctx);
    const b = await json(ctx);
    if (!Array.isArray(b.withheld) || !b.withheld.every((w) => isObject(w) && typeof w.digest === "string" && (w.reason === void 0 || typeof w.reason === "string"))) throw invalid("withheld must be a list of { digest, reason }");
    const e = await ws.edition(ctx.params[0], b.withheld, str2(b, "ordered_by"));
    ctx.res.writeHead(200, { "content-type": "application/zip", "content-length": e.bytes.length, "content-disposition": `attachment; filename="${ctx.params[0]} (edition).runrec"` });
    ctx.res.end(e.bytes);
  });
  route("POST", "/v1/blobs", async (ctx) => {
    const media = String(ctx.req.headers["content-type"] ?? "").trim();
    const who = ctx.who.role === "participant" ? ctx.who.participant_id : void 0;
    const used = who ? uploaded.get(who) ?? 0 : 0;
    const declared = Number(ctx.req.headers["content-length"] ?? 0);
    if (who && used + declared > uploadQuota) throw new KernelError(413, "too_large", `${who} has used its evidence upload quota`);
    const bytes3 = await readBody(ctx.req, ws.maxBlobBytes);
    if (who && used + bytes3.length > uploadQuota) throw new KernelError(413, "too_large", `${who} has used its evidence upload quota`);
    const artifact = ws.putBlob(bytes3, media);
    if (who) uploaded.set(who, used + bytes3.length);
    send(ctx.res, 201, artifact);
  });
  route("GET", "/v1/blobs/:digest", (ctx) => {
    const b = ws.store.blob(ctx.params[0]);
    if (!b) throw notFound("no such blob");
    ctx.res.writeHead(200, {
      "content-type": b.media_type,
      "content-length": b.bytes.length,
      "content-disposition": "attachment",
      "content-security-policy": "sandbox; default-src 'none'"
    });
    ctx.res.end(b.bytes);
  });
  route("GET", "/v1/stream", (ctx) => {
    const run2 = ctx.url.searchParams.get("run") ?? void 0;
    if (run2 !== void 0 && !ws.store.run(run2)) throw notFound(`no Run ${run2}`);
    const owner = ctx.who.role === "participant" ? ctx.who.token : "admin";
    const open = [...streams.values()].filter((o) => o === owner).length;
    if (open >= (owner === "admin" ? MAX_STREAMS.admin : MAX_STREAMS.participant)) throw new KernelError(429, "too_many", "too many open streams");
    const { res, req } = ctx;
    const valid = () => owner === "admin" || sessionValid(owner) !== void 0;
    const write = (chunk) => {
      if (!valid() || res.writableLength > STREAM_BUFFER_BYTES) {
        res.destroy();
        return;
      }
      res.write(chunk);
    };
    res.writeHead(200, { "content-type": "text/event-stream; charset=utf-8", "cache-control": "no-store", connection: "keep-alive" });
    res.write(": connected\n\n");
    streams.set(res, owner);
    const offEvents = ws.on((e) => {
      if (run2 === void 0 || e.run_id === run2) write(`id: ${e.run_id}:${e.seq}
event: appended
data: ${JSON.stringify(e)}

`);
    });
    const offPresence = owner === "admin" ? ws.onPresence((p) => write(`event: presence
data: ${JSON.stringify(p)}

`)) : () => void 0;
    const off = () => {
      offEvents();
      offPresence();
    };
    const hb = setInterval(() => write(": keep-alive\n\n"), 15e3);
    hb.unref();
    const done = () => {
      off();
      clearInterval(hb);
      streams.delete(res);
    };
    req.on("close", done);
    res.on("close", done);
  });
  const handle = async (req, res) => {
    res.setHeader("cache-control", "no-store");
    res.setHeader("x-content-type-options", "nosniff");
    try {
      const hostHeader = req.headers.host ?? "";
      const okHost = [`127.0.0.1:${port}`, `localhost:${port}`, `[::1]:${port}`].includes(hostHeader);
      if (!okHost) throw forbidden("requests must address the loopback interface");
      if (req.headers.origin !== void 0) throw forbidden("browsers may not call the kernel API");
      const url = new URL(req.url ?? "/", `http://${hostHeader}`);
      const candidates = routes.filter((r2) => r2.path.test(url.pathname));
      if (!candidates.length) throw notFound("no such route");
      const r = candidates.find((x) => x.method === req.method);
      if (!r) throw new KernelError(405, "method", `${req.method} is not allowed on this route`);
      const who = r.open ? { role: "anonymous" } : authenticate(req);
      let params;
      try {
        params = r.path.exec(url.pathname).slice(1).map(decodeURIComponent);
      } catch {
        throw invalid("malformed path");
      }
      await r.handler({ req, res, url, params, who });
    } catch (e) {
      if (res.headersSent) {
        res.destroy();
        return;
      }
      if (e instanceof KernelError) return send(res, e.status, { error: { code: e.code, message: e.message } });
      if (e instanceof RecordError || e instanceof JsonError) return send(res, 400, { error: { code: "invalid", message: e.message } });
      if (e instanceof PresenceDeclined) return send(res, 403, { error: { code: "declined", message: e.message } });
      if (e instanceof PresenceLocked) return send(res, 503, { error: { code: "locked", message: e.message } });
      if (e instanceof PresenceUnavailable) return send(res, 503, { error: { code: "presence_unavailable", message: e.message } });
      process.stderr.write(`opsproof-kernel: internal error on ${req.method} ${req.url}: ${e.stack ?? String(e)}
`);
      send(res, 500, { error: { code: "internal", message: "internal error; see the kernel log" } });
    }
  };
  const server = createServer((req, res) => void handle(req, res));
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(opts.port ?? 0, host, () => resolve());
  });
  port = server.address().port;
  const urlHost = host === "::1" ? "[::1]" : host;
  return {
    url: `http://${urlHost}:${port}`,
    port,
    token,
    server,
    close: () => new Promise((resolve) => {
      for (const s of streams.keys()) s.end();
      server.close(() => resolve());
      server.closeAllConnections();
    })
  };
}

// src/cli.ts
function args(argv) {
  const [cmd = "", ...rest] = argv;
  const flags = /* @__PURE__ */ new Map();
  for (let i = 0; i < rest.length; i++) {
    const a = rest[i];
    if (!a.startsWith("--")) usage(`unexpected argument ${a}`);
    const next = rest[i + 1];
    if (next === void 0 || next.startsWith("--")) flags.set(a.slice(2), true);
    else {
      flags.set(a.slice(2), next);
      i++;
    }
  }
  return { cmd, flags };
}
function usage(msg) {
  if (msg) process.stderr.write(`opsproof-kernel: ${msg}
`);
  process.stderr.write(
    "usage:\n  opsproof-kernel init  --dir <dir> --id <workspace_id> --name <display name> [--dev-keys] [--json]\n  opsproof-kernel serve --dir <dir> [--dev-keys] [--port <n>] [--drafts <dir>] [--exit-with-stdin]\n  opsproof-kernel serve --ephemeral [--id <workspace_id>] [--name <display name>] [--port <n>] [--exit-with-stdin]\n  opsproof-kernel info  --dir <dir>\n  opsproof-kernel register --dir <dir> [--out <file>] [--published-log <where> --published-entry <entry>]\n  opsproof-kernel journal --dir <dir> [--out <file>]\n  opsproof-kernel rotate-key --dir <dir> --reason <text> [--exposed [--as-of <run number>]]\n  opsproof-kernel revoke --dir <dir> --participant <id> --reason <text>\n"
  );
  process.exit(2);
}
function str(flags, k) {
  const v = flags.get(k);
  if (v === true) usage(`--${k} needs a value`);
  return v;
}
var SAFE_NODE_OPTION = /^--(use-openssl-ca|use-bundled-ca|use-system-ca|no-deprecation|no-warnings|max-old-space-size=\d+|max-semi-space-size=\d+)$/;
var toStderr = (p) => process.stderr.write(`opsproof-kernel: confirm on this computer, code ${p.code}: ${p.description}
`);
var toStdout = (p) => process.stdout.write(JSON.stringify({ presence: p }) + "\n");
var devKeys = false;
function keyStore(dir, notice) {
  if (devKeys) {
    process.stderr.write(`opsproof-kernel: DEVELOPMENT KEYS: keys are plain files in ${join6(dir, "dev-keys")}, with no presence check. For building and trying only.
`);
    return new DevKeyStore(join6(dir, "dev-keys"));
  }
  const unsafe = (process.env.NODE_OPTIONS ?? "").split(/\s+/).filter((o) => o && !SAFE_NODE_OPTION.test(o));
  if (unsafe.length) {
    process.stderr.write(`opsproof-kernel: NODE_OPTIONS is set with ${unsafe.join(" ")}, which can load code into this process. A workspace that holds keys is never served that way; start the kernel without it.
`);
    process.exit(2);
  }
  const s = platformKeyStore(dir);
  if (!s) {
    process.stderr.write(
      "opsproof-kernel: no presence check is available on this machine, so a persistent workspace cannot hold Human keys. Build the helper under native/ for this platform (or set OPSPROOF_PRESENCE_HELPER), or use --ephemeral for a throwaway workspace held in memory.\n"
    );
    process.exit(2);
  }
  s.onPrompt = notice;
  return s;
}
async function main() {
  const { cmd, flags } = args(process.argv.slice(2));
  const dir = str(flags, "dir");
  devKeys = flags.get("dev-keys") === true;
  if (cmd === "init") {
    const id = str(flags, "id");
    const name = str(flags, "name");
    if (!dir || !id || !name) usage("init needs --dir, --id and --name");
    const asJson = flags.get("json") === true;
    const ws = await Workspace.create({ dir, keys: keyStore(dir, asJson ? toStdout : toStderr), workspace_id: id, display_name: name });
    process.stdout.write(asJson ? JSON.stringify({ created: { workspace_id: id, key_id: ws.key.keyId } }) + "\n" : `created workspace ${id} at ${dir}
workspace key: ${ws.key.keyId}
(give this key id to anyone who will verify your Records)
`);
    ws.close();
    return;
  }
  if (cmd === "info") {
    if (!dir) usage("info needs --dir");
    const ws = await Workspace.open({ dir, keys: keyStore(dir, toStderr) });
    process.stdout.write(JSON.stringify({ ...ws.summary(), participants: ws.participants().length, procedures: ws.procedures().length, runs: ws.runs().length }, null, 2) + "\n");
    ws.close();
    return;
  }
  if (cmd === "register") {
    if (!dir) usage("register needs --dir");
    const ws = await Workspace.open({ dir, keys: keyStore(dir, toStderr) });
    const log = str(flags, "published-log");
    const entry = str(flags, "published-entry");
    if (log === void 0 !== (entry === void 0)) usage("--published-log and --published-entry go together");
    const r = await ws.register(log !== void 0 ? { log, entry } : void 0);
    const out = str(flags, "out") ?? `${ws.workspace_id}-${r.through}.register.json`;
    writeFileSync4(out, r.bytes);
    process.stdout.write(`wrote ${out}: ${r.through} run${r.through === 1 ? "" : "s"} through ${r.issued_at}, signed by workspace key ${ws.key.keyId}
`);
    ws.close();
    return;
  }
  if (cmd === "journal") {
    if (!dir) usage("journal needs --dir");
    const ws = await Workspace.open({ dir, keys: keyStore(dir, toStderr) });
    try {
      const j = await ws.journal();
      const out = str(flags, "out") ?? `${ws.workspace_id}-${j.length}.journal`;
      writeFileSync4(out, j.bytes);
      process.stdout.write(`wrote ${out}: ${j.length} entries, head ${j.head}
`);
    } finally {
      ws.close();
    }
    return;
  }
  if (cmd === "rotate-key") {
    const reason = str(flags, "reason");
    if (!dir || !reason) usage("rotate-key needs --dir and --reason");
    const asOf = str(flags, "as-of");
    if (asOf !== void 0 && !flags.has("exposed")) usage("--as-of goes with --exposed");
    const ws = await Workspace.open({ dir, keys: keyStore(dir, toStderr) });
    try {
      const before = ws.key.keyId;
      const r = await ws.rotate(reason, flags.has("exposed") ? asOf !== void 0 ? { as_of: Number(asOf) } : {} : void 0);
      process.stdout.write(`workspace key ${before} retired${flags.has("exposed") ? " and revoked" : ""}; ${r.key_id} signs from now on (register through Run ${r.register.through} issued). Tell whoever pinned the old key.
`);
    } finally {
      ws.close();
    }
    return;
  }
  if (cmd === "revoke") {
    const reason = str(flags, "reason");
    const id = str(flags, "participant");
    if (!dir || !reason || !id) usage("revoke needs --dir, --participant and --reason");
    const ws = await Workspace.open({ dir, keys: keyStore(dir, toStderr) });
    try {
      const p = await ws.revoke(id, reason);
      process.stdout.write(`${id}'s key ${p.key_id} revoked for Runs after #${p.revoked.as_of}; the next register carries it.
`);
    } finally {
      ws.close();
    }
    return;
  }
  if (cmd === "serve") {
    if (process.platform !== "win32" && !process.execArgv.includes("--disable-sigusr1")) {
      process.stderr.write("opsproof-kernel: WARNING: started without --disable-sigusr1, so any program running as you can open a debugger in this process.\n");
    }
    const ephemeral = flags.get("ephemeral") === true;
    let ws;
    if (ephemeral) {
      if (dir) usage("--ephemeral takes no --dir");
      ws = await Workspace.create({ keys: new MemoryKeyStore(), workspace_id: str(flags, "id") ?? "ws-ephemeral", display_name: str(flags, "name") ?? "Ephemeral workspace" });
      process.stderr.write("opsproof-kernel: EPHEMERAL workspace: keys and Records exist only in this process and are lost when it exits.\n");
    } else {
      if (!dir) usage("serve needs --dir or --ephemeral");
      ws = await Workspace.open({ dir, keys: keyStore(dir, toStdout) });
    }
    const port = str(flags, "port");
    const drafts2 = str(flags, "drafts");
    const k = await startApi({ workspace: ws, ...port ? { port: Number(port) } : {}, ...drafts2 ? { draftsDir: drafts2 } : {} });
    const runtimeFile = dir ? join6(dir, "runtime.json") : void 0;
    if (runtimeFile) {
      writeFileSync4(runtimeFile, JSON.stringify({ url: k.url, pid: process.pid, workspace_id: ws.workspace_id, key_id: ws.key.keyId }) + "\n", { mode: 384 });
    }
    let stopping = false;
    const stop = async () => {
      if (stopping) return;
      stopping = true;
      if (runtimeFile) rmSync4(runtimeFile, { force: true });
      await k.close();
      ws.close();
      process.exit(0);
    };
    process.on("SIGINT", () => void stop());
    process.on("SIGTERM", () => void stop());
    if (process.platform === "win32") process.on("SIGBREAK", () => void stop());
    if (flags.get("exit-with-stdin") === true) {
      process.stdin.on("end", () => void stop());
      process.stdin.on("error", () => void stop());
      process.stdin.resume();
    }
    process.stdout.write(JSON.stringify({ url: k.url, token: k.token, workspace_id: ws.workspace_id, key_id: ws.key.keyId, pid: process.pid }) + "\n");
    return;
  }
  usage(cmd ? `unknown command ${cmd}` : void 0);
}
main().catch((e) => {
  process.stderr.write(`opsproof-kernel: ${e.message}
`);
  process.exit(1);
});
