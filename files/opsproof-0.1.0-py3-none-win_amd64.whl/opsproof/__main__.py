"""python -m opsproof: check a Record, run the quickstart, or say where the engine is.

    python -m opsproof check record.runrec [--pin sha256:...]
    python -m opsproof quickstart [--out quickstart.runrec]
    python -m opsproof engine
"""
from __future__ import annotations

import json
import os
import runpy
import sys

USAGE = __doc__


def main(argv=None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    if not argv or argv[0] in ("-h", "--help"):
        sys.stdout.write(USAGE)
        return 0 if argv else 2
    cmd, rest = argv[0], argv[1:]
    if cmd == "check":
        from runrec.cli import main as runrec_main
        return runrec_main(["verify", *rest])
    if cmd == "engine":
        from .engine import find_engine
        print(" ".join(find_engine()))
        return 0
    if cmd == "quickstart":
        here = os.path.dirname(os.path.abspath(__file__))
        for path in (os.path.join(here, "quickstart.py"), os.path.join(os.path.dirname(here), "examples", "quickstart.py")):
            if os.path.exists(path):
                sys.argv = [path, *rest]
                runpy.run_path(path, run_name="__main__")
                return 0
        sys.stderr.write("opsproof: the quickstart is not in this install\n")
        return 2
    sys.stderr.write("opsproof: unknown command %s\n%s" % (cmd, USAGE))
    return 2


if __name__ == "__main__":
    sys.exit(main())
