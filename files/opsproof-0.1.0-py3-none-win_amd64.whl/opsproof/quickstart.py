"""The OpsProof quickstart: one agent, one knob, one Record.

A chiller feeds a data hall. An AI agent may lower the chiller's supply
setpoint by up to 2 °C on its own; anything more waits for the operator. A
sensor reports the inlet temperature, the chiller applies what is allowed,
and the operator signs off once the hall has settled. The Run is sealed into
a Record that anyone can check for free.

    python -m opsproof quickstart            # writes quickstart.runrec here
    python -m opsproof check quickstart.runrec --pin <the workspace key it prints>

Everything below is synthetic and runs in a throwaway workspace: no keys are
kept and no fingerprint is asked. Swap Engine.ephemeral() for
Engine.dev("./my-workspace") to keep the workspace; the same code then runs
in a workspace that is still there tomorrow.
"""
import argparse
import json
import sys

import opsproof

PROCEDURE = {
    "procedure_id": "chiller-setpoint",
    "version": "1.0.0",
    "title": "Chiller supply setpoint, data hall 2 (synthetic)",
    "purpose": "Keep the data hall's inlet temperature in band by adjusting the chiller supply setpoint within agreed limits.",
    "roles": ["operator", "sensor", "chiller"],
    "bounds": [
        {"bound_id": "lower-up-to-2", "action_type": "set_supply_temp", "parameter": "delta_c", "min": -2, "max": 0, "max_count_per_run": 1},
    ],
    "steps": [
        {
            "step_id": "adjust",
            "title": "Adjust the supply setpoint",
            "instructions": "The agent may lower the supply setpoint by up to 2 °C; anything else waits for the operator. The chiller applies an approved change; the inlet must then read 18 to 22 °C three times in a row.",
            "requires": [],
            "performers": [{"kind": "system", "role": "sensor"}, {"kind": "system", "role": "chiller"}],
            "proposals": {"allowed_kinds": ["agent"], "bound_ids": ["lower-up-to-2"], "fallback_roles": ["operator"]},
            "actions": {"types": ["set_supply_temp"], "requires_authorization": True},
            "evidence": [{"criterion_id": "inlet-in-band", "type": "measurement", "quantity": "inlet_temp_c", "unit": "°C",
                          "tolerance": {"min": 18, "max": 22}, "consecutive": 3, "max_observations": 10}],
            "decisions": [],
        },
        {
            "step_id": "sign-off",
            "title": "Operator sign-off",
            "requires": ["adjust"],
            "performers": [],
            "evidence": [],
            "decisions": [{"decision_id": "sign-off", "types": ["accept", "reject"], "decider_roles": ["operator"], "required": True}],
        },
    ],
}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--out", default="quickstart.runrec", help="where to write the Record")
    ap.add_argument("--raise-by", type=float, default=1.5, help="how far the agent lowers the setpoint (try 3: it then waits for the operator)")
    args = ap.parse_args()

    with opsproof.Engine.ephemeral() as eng:
        # Who takes part. The person's key is held by the workspace; the agent and the machines hold their own.
        operator = eng.person("h-operator", "Dana, shift operator (synthetic)", roles=["operator"])
        agent = eng.agent("agent-cooling", "Cooling agent (synthetic)")
        sensor = eng.system("sensor-inlet", "Inlet temperature sensor (synthetic)", roles=["sensor"])
        chiller = eng.system("chiller-2", "Chiller 2 (synthetic)", roles=["chiller"])

        # What was agreed: the operator signs the Procedure.
        proc = eng.procedure(PROCEDURE, author=operator)
        run = eng.start(proc, title="Hot aisle drift, 14:00")

        # The hall runs hot; the agent proposes a change, citing the reading it relied on.
        reading = sensor.observe(run, "adjust", "inlet_temp_c", "°C", 24.1, uncertainty=0.2, device_id="inlet-2")
        events = agent.propose(run, "adjust", "set_supply_temp", {"delta_c": -args.raise_by}, cites=[reading[0]["digest"]],
                               rationale="Inlet 24.1 °C, above the 22 °C band; lowering supply %.1f °C." % args.raise_by)
        proposal = events[0]["digest"]
        ruling = opsproof.authorization_of(events)
        if ruling["event"]["result"] == "allow":
            print("The limits allowed the change.")
            approval = ruling["digest"]
        else:
            print("Outside the limits: it waits for the operator, who approves it with a reason.")
            approval = operator.authorize(run, "adjust", proposal, "Hall above band; approving the agent's change.")[0]["digest"]

        # The chiller applies it, and the hall settles.
        chiller.act(run, "adjust", "set_supply_temp", {"delta_c": -args.raise_by}, authorization=approval,
                    detail="supply setpoint 12.0 °C to %.1f °C" % (12.0 - args.raise_by))
        for t in (21.6, 21.2, 20.9):
            sensor.observe(run, "adjust", "inlet_temp_c", "°C", t, uncertainty=0.2, device_id="inlet-2")

        # The person decides; the Run is closed and sealed.
        operator.decide(run, "sign-off", "sign-off", "accept", "Inlet back in band for three readings.")
        run.close(by=operator)
        record = run.seal(by=operator)
        record.save(args.out)

        report = record.verify()
        print(report["summary"])
        print("Wrote %s (%d bytes). Check it anywhere:" % (args.out, len(record)))
        print("  python -m opsproof check %s --pin %s" % (args.out, record.key_id))
        print("  or drop it on https://opsproof.systems/check")
        return 0 if report["integrity"] == "pass" and report["outcome"] == "complete" else 1


if __name__ == "__main__":
    sys.exit(main())
