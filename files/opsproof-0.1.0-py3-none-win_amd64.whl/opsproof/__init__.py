"""OpsProof for Python: run the engine, connect Agents and Systems, check Records.

    import opsproof

    with opsproof.Engine.ephemeral() as eng:
        person = eng.person("h-operator", "Operator", roles=["operator"])
        agent = eng.agent("agent-tuner", "Tuning agent")
        ...
        record = run.seal()
        print(opsproof.check(record.bytes)["summary"])

See examples/quickstart.py for the ten-minute path.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from .engine import Engine, EngineNotFound, Person, Record, Run, authorization_of, find_engine
from .participant import KernelError, Key, ParticipantClient

__version__ = "0.1.0"
__all__ = ["Engine", "EngineNotFound", "Person", "Record", "Run", "Key", "ParticipantClient", "KernelError",
           "authorization_of", "find_engine", "check"]


def check(data: bytes, pin: Optional[str] = None) -> Dict[str, Any]:
    """Check a Run Record with the independent Python checker; returns its report (spec section 9)."""
    from runrec import verify_bytes
    return verify_bytes(data, pin=pin).report
